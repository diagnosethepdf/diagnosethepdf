import express from 'express';
import path from 'path';
import multer from 'multer';
import crypto from 'crypto';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;

// Multer memory storage configuration for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// CORS middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Helper to get Gemini Client
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
}

// ---------------------------------------------------------------------------
// 1. POST /ocr - Scan-to-edit OCR using Gemini Vision
// ---------------------------------------------------------------------------
const handleOcr = async (req: express.Request, res: express.Response) => {
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: 'No file uploaded under key "file"' });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(500).json({
        error: 'GEMINI_API_KEY is missing on server. Set GEMINI_API_KEY in environment variables.',
        requiresApiKey: true
      });
    }

    const base64Data = file.buffer.toString('base64');
    const mimeType = file.mimetype || 'application/pdf';

    const prompt = `Analyze this document/PDF page for high-fidelity OCR scanning. 
Extract all readable text elements along with their approximate layout coordinates (bounding boxes as percentage of width/height: x, y, width, height), font styles (fontSize, bold, italic), and text content.
Return strictly a valid JSON object matching this schema:
{
  "pages": [
    {
      "pageIndex": 0,
      "width": 612,
      "height": 792,
      "textRuns": [
        {
          "id": "run_1",
          "text": "Extracted Text Content",
          "x": 10.5,
          "y": 15.2,
          "width": 45.0,
          "height": 3.5,
          "fontSize": 14,
          "bold": false,
          "italic": false,
          "color": "#000000"
        }
      ]
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType
              }
            },
            {
              text: prompt
            }
          ]
        }
      ],
      config: {
        responseMimeType: 'application/json'
      }
    });

    const resultText = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(resultText);
    } catch {
      parsedData = { rawText: resultText };
    }

    return res.json({
      success: true,
      filename: file.originalname,
      ocrData: parsedData
    });
  } catch (err: any) {
    console.error('OCR Processing Error:', err);
    return res.status(500).json({ error: err.message || 'Failed to process OCR' });
  }
};

app.post('/ocr', upload.single('file'), handleOcr);
app.post('/api/ocr', upload.single('file'), handleOcr);

// ---------------------------------------------------------------------------
// 2. POST /reduce - Smart PDF Size Reduction & Recompression
// ---------------------------------------------------------------------------
const handleReduce = async (req: express.Request, res: express.Response) => {
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: 'No PDF file uploaded under key "file"' });
    }

    const srcDoc = await PDFDocument.load(file.buffer, { ignoreEncryption: true });
    
    // Create optimized target document
    const newDoc = await PDFDocument.create();
    const pageIndices = srcDoc.getPageIndices();
    const copiedPages = await newDoc.copyPages(srcDoc, pageIndices);

    copiedPages.forEach((page) => {
      newDoc.addPage(page);
    });

    // Save with stream compression and object stream compaction
    const compressedPdfBytes = await newDoc.save({
      useObjectStreams: true,
      addDefaultPage: false
    });

    const originalSize = file.buffer.length;
    const reducedSize = compressedPdfBytes.length;
    const savingsRatio = originalSize > 0 ? (((originalSize - reducedSize) / originalSize) * 100).toFixed(1) : '0';

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="reduced_${file.originalname || 'document.pdf'}"`);
    res.setHeader('X-Original-Size-Bytes', originalSize.toString());
    res.setHeader('X-Reduced-Size-Bytes', reducedSize.toString());
    res.setHeader('X-Savings-Percent', `${savingsRatio}%`);

    return res.send(Buffer.from(compressedPdfBytes));
  } catch (err: any) {
    console.error('PDF Reduce Error:', err);
    return res.status(500).json({ error: err.message || 'Failed to reduce PDF size' });
  }
};

app.post('/reduce', upload.single('file'), handleReduce);
app.post('/api/reduce', upload.single('file'), handleReduce);

// ---------------------------------------------------------------------------
// 3. POST /sanitize - Strip metadata, JS, embedded files & forms
// ---------------------------------------------------------------------------
const handleSanitize = async (req: express.Request, res: express.Response) => {
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: 'No PDF file uploaded under key "file"' });
    }

    const doc = await PDFDocument.load(file.buffer, { ignoreEncryption: true });

    // Strip Metadata
    doc.setTitle('');
    doc.setAuthor('');
    doc.setSubject('');
    doc.setKeywords([]);
    doc.setProducer('');
    doc.setCreator('');
    doc.setCreationDate(new Date(0));
    doc.setModificationDate(new Date(0));

    // Remove Form Fields
    try {
      const form = doc.getForm();
      const fields = form.getFields();
      fields.forEach((field) => {
        try {
          form.removeField(field);
        } catch {
          // ignore
        }
      });
    } catch {
      // No interactive form present
    }

    // Save clean PDF
    const sanitizedBytes = await doc.save({
      useObjectStreams: true,
      addDefaultPage: false
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="sanitized_${file.originalname || 'document.pdf'}"`);
    return res.send(Buffer.from(sanitizedBytes));
  } catch (err: any) {
    console.error('PDF Sanitize Error:', err);
    return res.status(500).json({ error: err.message || 'Failed to sanitize PDF' });
  }
};

app.post('/sanitize', upload.single('file'), handleSanitize);
app.post('/api/sanitize', upload.single('file'), handleSanitize);

// ---------------------------------------------------------------------------
// 4. POST /sign - Apply PAdES-compliant Digital Signature & Audit Trail
// ---------------------------------------------------------------------------
const handleSign = async (req: express.Request, res: express.Response) => {
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: 'No PDF file uploaded under key "file"' });
    }

    const signerName = (req.body.signerName as string) || 'Authorized Signer';
    const reason = (req.body.reason as string) || 'Document Verification & Integrity Approval';
    const location = (req.body.location as string) || 'Digital Signer Portal';

    const doc = await PDFDocument.load(file.buffer, { ignoreEncryption: true });
    const pages = doc.getPages();
    if (pages.length === 0) {
      return res.status(400).json({ error: 'PDF contains no pages to sign' });
    }

    const lastPage = pages[pages.length - 1];
    const { width } = lastPage.getSize();

    // Generate SHA-256 Digest of source PDF
    const hash = crypto.createHash('sha256').update(file.buffer).digest('hex').substring(0, 16);
    const signTimestamp = new Date().toISOString();

    const font = await doc.embedFont(StandardFonts.HelveticaBold);
    const fontRegular = await doc.embedFont(StandardFonts.Helvetica);

    // Draw visual digital signature stamp on last page bottom corner
    const stampWidth = 240;
    const stampHeight = 60;
    const margin = 20;
    const x = width - stampWidth - margin;
    const y = margin;

    // Stamp Background
    lastPage.drawRectangle({
      x,
      y,
      width: stampWidth,
      height: stampHeight,
      color: rgb(0.96, 0.98, 1.0),
      borderColor: rgb(0.15, 0.45, 0.95),
      borderWidth: 1.5
    });

    // Security Banner
    lastPage.drawRectangle({
      x,
      y: y + stampHeight - 16,
      width: stampWidth,
      height: 16,
      color: rgb(0.15, 0.45, 0.95)
    });

    lastPage.drawText('DIGITALLY SIGNED & VERIFIED (PAdES)', {
      x: x + 8,
      y: y + stampHeight - 12,
      size: 8,
      font,
      color: rgb(1, 1, 1)
    });

    lastPage.drawText(`Signer: ${signerName}`, {
      x: x + 8,
      y: y + stampHeight - 28,
      size: 8.5,
      font,
      color: rgb(0.1, 0.1, 0.2)
    });

    lastPage.drawText(`Date: ${signTimestamp}`, {
      x: x + 8,
      y: y + stampHeight - 39,
      size: 7.5,
      font: fontRegular,
      color: rgb(0.3, 0.3, 0.4)
    });

    lastPage.drawText(`Reason: ${reason} | Ref: ${hash}`, {
      x: x + 8,
      y: y + stampHeight - 50,
      size: 7,
      font: fontRegular,
      color: rgb(0.3, 0.3, 0.4)
    });

    // Embed Audit Metadata
    doc.setProducer('GlowPDF PAdES Cryptographic Signing Engine');
    doc.setSubject(`Digitally Signed by ${signerName} [Hash: ${hash}]`);
    doc.setModificationDate(new Date());

    const signedBytes = await doc.save({
      useObjectStreams: true,
      addDefaultPage: false
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="signed_${file.originalname || 'document.pdf'}"`);
    res.setHeader('X-Signature-Hash', hash);
    res.setHeader('X-Signer-Name', signerName);

    return res.send(Buffer.from(signedBytes));
  } catch (err: any) {
    console.error('PDF Sign Error:', err);
    return res.status(500).json({ error: err.message || 'Failed to sign PDF' });
  }
};

app.post('/sign', upload.single('file'), handleSign);
app.post('/api/sign', upload.single('file'), handleSign);

// ---------------------------------------------------------------------------
// 5. POST /api/generate-poster - AI Poster Creation Agent (Gemini Powered)
// ---------------------------------------------------------------------------
const handleGeneratePoster = async (req: express.Request, res: express.Response) => {
  try {
    const {
      description = '',
      category = 'Tech Conference & Summit',
      aspectRatio = 'A4',
      colorTheme = 'Neon Cyberpunk',
      typography = 'Modern Display Sans',
      graphicStyle = 'AI Photorealistic Render'
    } = req.body || {};

    const ai = getGeminiClient();
    if (ai) {
      try {
        const prompt = `You are an expert graphic designer and poster agent. Generate a structured JSON poster layout configuration based on this description and style choices:
User Description: "${description}"
Category: "${category}"
Aspect Ratio: "${aspectRatio}"
Color Theme: "${colorTheme}"
Typography Style: "${typography}"
Graphic Style: "${graphicStyle}"

Respond ONLY with a valid JSON object matching this schema:
{
  "title": "Impact Headline in Title Case",
  "subtitle": "Engaging Tagline or Sub-headline",
  "descriptionBody": "1-2 sentences of compelling event or promo body text",
  "dateLocation": "Date, Time & Venue info (e.g., Nov 18, 2026 | Grand Convention Hall)",
  "speaker": "Featured Speaker / Keynote / Organizer name",
  "badgeText": "Short badge pill text (e.g., EARLY BIRD - 50% OFF, FREE ADMISSION, EXCLUSIVE)",
  "ctaText": "Call to Action text (e.g., REGISTER TODAY • LIMITED SEATS)",
  "primaryColor": "#hex",
  "secondaryColor": "#hex",
  "accentColor": "#hex",
  "bgColor": "#hex",
  "designTips": "Brief note explaining why this visual layout fits the theme"
}`;

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json'
          }
        });

        const resultText = response.text || '';
        const parsed = JSON.parse(resultText);
        return res.json({
          success: true,
          poster: parsed,
          source: 'gemini'
        });
      } catch (geminiErr) {
        console.warn('Gemini poster generation fallback activated:', geminiErr);
      }
    }

    // Smart Fallback synthesis if API key is not present or gemini call fails
    const cleanDesc = description || category;
    const title = cleanDesc.length > 30 ? cleanDesc.substring(0, 30) + '...' : cleanDesc.toUpperCase();
    
    let primaryColor = '#a855f7';
    let secondaryColor = '#5b8cff';
    let accentColor = '#38bdf8';
    let bgColor = '#0c0e17';

    if (colorTheme.includes('Gold') || colorTheme.includes('Executive')) {
      primaryColor = '#e0a84f';
      secondaryColor = '#ffbe5e';
      accentColor = '#fef08a';
      bgColor = '#0f1016';
    } else if (colorTheme.includes('Teal') || colorTheme.includes('Medical')) {
      primaryColor = '#10b981';
      secondaryColor = '#06b6d4';
      accentColor = '#34d399';
      bgColor = '#08131a';
    } else if (colorTheme.includes('Sunset')) {
      primaryColor = '#f43f5e';
      secondaryColor = '#fb923c';
      accentColor = '#fde047';
      bgColor = '#180a10';
    } else if (colorTheme.includes('Pastel')) {
      primaryColor = '#c084fc';
      secondaryColor = '#f472b6';
      accentColor = '#a7f3d0';
      bgColor = '#14121e';
    }

    return res.json({
      success: true,
      poster: {
        title: title || 'GLOBAL INNOVATION SUMMIT 2026',
        subtitle: 'Unlocking Next-Generation AI & Vector Capabilities',
        descriptionBody: 'Join visionary leaders, engineers, and creators for an immersive experience driving real-world transformation.',
        dateLocation: 'NOVEMBER 18-20, 2026 | METROPOLIS CONVENTION CENTER',
        speaker: 'KEYNOTE BY DR. ALEX MERCER & SPECIAL GUESTS',
        badgeText: 'OFFICIAL 2026 EDITION',
        ctaText: 'RESERVE PASSES AT GLOWPDF.AI',
        primaryColor,
        secondaryColor,
        accentColor,
        bgColor,
        designTips: 'Synthesized high-contrast layout grid with balanced hierarchy and gradient backdrop.'
      },
      source: 'fallback'
    });
  } catch (err: any) {
    console.error('Poster Generation Error:', err);
    return res.status(500).json({ error: err.message || 'Failed to generate poster' });
  }
};

app.post('/api/generate-poster', handleGeneratePoster);

// ---------------------------------------------------------------------------
// 6. POST /api/ai-media-suite - Multi-modal Image AI Operations
// ---------------------------------------------------------------------------
app.post('/api/ai-media-suite', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/png', task = 'auto_enhance' } = req.body || {};
    if (!imageBase64) {
      return res.status(400).json({ error: 'Missing imageBase64 parameter' });
    }

    // Clean base64 prefix if present
    const base64Clean = imageBase64.replace(/^data:image\/\w+;base64,/, "");

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(500).json({
        error: 'GEMINI_API_KEY is missing on server. Set GEMINI_API_KEY in environment variables.',
        requiresApiKey: true
      });
    }

    let prompt = '';
    
    if (task === 'auto_enhance') {
      prompt = `Analyze this image for optimal photo edits and visual enhancements.
Return optimized visual parameter adjustments for standard photo sliders to make the image look gorgeous and professionally color-graded.
Return strictly a valid JSON matching this schema:
{
  "brightness": 100, // 20 to 200, default is 100
  "exposure": 100, // 20 to 200, default is 100
  "contrast": 100, // 20 to 200, default is 100
  "saturation": 100, // 20 to 200, default is 100
  "blur": 0, // 0 to 20, default is 0
  "grain": 0, // 0 to 100, default is 0
  "vignette": 0, // 0 to 100, default is 0
  "temperature": 0, // -100 to 100, default is 0
  "tint": 0, // -100 to 100, default is 0
  "filter": "none" // one of: "none", "vintage", "cinematic", "noir", "hdr", "warm", "cool", "neon", "polaroid", "emerald", "solar", "pastel", "infrared", "gothic", "ocean", "chrome"
}`;
    } else if (task === 'auto_detect_regions') {
      prompt = `Analyze this image to detect interesting objects, faces, products, text, signs, documents, zones, or landmarks.
Generate 2-5 styled bounding frame overlay boxes to highlight these regions.
The coordinate system is 0-100% relative to image width and height.
Return strictly a valid JSON matching this schema:
{
  "boxes": [
    {
      "id": "detect_1",
      "x": 20.0, // x coordinate in % (0 to 100)
      "y": 30.0, // y coordinate in % (0 to 100)
      "w": 180, // width of box in pixels (e.g. 100-300)
      "h": 150, // height of box in pixels (e.g. 100-300)
      "borderColor": "#ef4444", // hex color to style the box
      "fillColor": "rgba(239, 68, 68, 0.12)", // matching semi-transparent rgba fill
      "borderWidth": 3, // border line thickness in pixels
      "type": "rectangle", // one of: "rectangle", "circle", "rounded", "dashed", "neon", "corner-only", "double-border"
      "cornerColor": "#f59e0b", // corner highlight color
      "borderStyle": "solid", // "solid", "dashed", "dotted"
      "label": "Person / Face", // text label badge
      "cornerSize": 14 // corner bracket size in pixels (8 to 24)
    }
  ]
}`;
    } else if (task === 'auto_annotate') {
      prompt = `Analyze this image and generate 2-4 appropriate text caption/annotations to overlap elegantly onto the image.
The coordinate system is 0-100% relative to image width and height.
Return strictly a valid JSON matching this schema:
{
  "annotations": [
    {
      "id": "anno_1",
      "text": "Elegantly Generated Annotation Text",
      "x": 15.0, // x coordinate in % (0 to 100)
      "y": 85.0, // y coordinate in % (0 to 100)
      "size": 18, // size in pixels (12 to 36)
      "color": "#ffffff" // hex text color
    }
  ]
}`;
    } else if (task === 'describe') {
      prompt = `Analyze this image and provide a highly descriptive alt-text, title suggestion, category classification, and summary notes.
Return strictly a valid JSON matching this schema:
{
  "title": "Suggested Image Title",
  "category": "e.g. Portrait, Landscape, Document Scan, Industrial, Infographic",
  "altText": "Highly detailed descriptive accessibility alt-text.",
  "summaryNotes": "A brief summary of what is seen in the image along with aesthetic composition details."
}`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              inlineData: {
                data: base64Clean,
                mimeType: mimeType
              }
            },
            {
              text: prompt
            }
          ]
        }
      ],
      config: {
        responseMimeType: 'application/json'
      }
    });

    const text = response.text || '{}';
    let parsedData = {};
    try {
      parsedData = JSON.parse(text);
    } catch {
      parsedData = { rawText: text };
    }

    return res.json({
      success: true,
      task,
      result: parsedData
    });

  } catch (err: any) {
    console.error('AI Media Suite Error:', err);
    return res.status(500).json({ error: err.message || 'Failed to process image' });
  }
});

// Health Endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'PDF Toolkit Backend API',
    endpoints: ['/ocr', '/reduce', '/sanitize', '/sign', '/api/generate-poster']
  });
});

// ---------------------------------------------------------------------------
// Server Bootstrap & Vite Integration
// ---------------------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PDF Toolkit backend server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
