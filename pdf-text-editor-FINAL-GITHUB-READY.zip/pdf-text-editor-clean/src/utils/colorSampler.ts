/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PDFTextRun } from '../types';

interface SampleResult {
  bg: string;
  ink: string;
}

// 2D Affine Matrix Multiplication to resolve coordinate transforms
function transformMatrix(m1: number[], m2: number[]): number[] {
  const [a1, b1, c1, d1, e1, f1] = m1;
  const [a2, b2, c2, d2, e2, f2] = m2;

  return [
    a1 * a2 + c1 * b2,
    b1 * a2 + d1 * b2,
    a1 * c2 + c1 * d2,
    b1 * c2 + d1 * d2,
    a1 * e2 + c1 * f2 + e1,
    b1 * e2 + d1 * f2 + f1
  ];
}

function getPixelColor(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  const rx = Math.max(0, Math.min(w - 1, Math.round(x)));
  const ry = Math.max(0, Math.min(h - 1, Math.round(y)));
  const data = ctx.getImageData(rx, ry, 1, 1).data;
  return { r: data[0], g: data[1], b: data[2], a: data[3] };
}

function rgbToHex(r: number, g: number, b: number): string {
  const hex = (n: number) => n.toString(16).padStart(2, '0');
  return `#${hex(r)}${hex(g)}${hex(b)}`;
}

export function sampleColors(
  pageIndex: number,
  runInfo: PDFTextRun,
  pageObj: any,
  scale: number
): SampleResult {
  const cachedCanvas = (window as any).p_originalCanvases?.[pageIndex];
  const canvas = cachedCanvas || (document.querySelector(`#page-container-${pageIndex} canvas`) as HTMLCanvasElement);
  if (!canvas || !pageObj) {
    return { bg: '#ffffff', ink: '#000000' };
  }

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return { bg: '#ffffff', ink: '#000000' };
  }

  // Derive the actual physical scale of the rendered canvas to prevent coordinate mismatches
  const unscaledViewport = pageObj.getViewport({ scale: 1.0 });
  const canvasScale = canvas.width / unscaledViewport.width;

  const viewport = pageObj.getViewport({ scale: canvasScale });
  const tx = transformMatrix(viewport.transform, runInfo.transform);

  const angleRad = Math.atan2(tx[1], tx[0]);
  const fontHeightPx = Math.hypot(tx[2], tx[3]);
  const canvasLeft = tx[4];
  const canvasTop = tx[5];
  const widthPx = runInfo.width * canvasScale;

  const w = canvas.width;
  const h = canvas.height;

  // Helpers to map coordinates using exact canvas-relative positions
  const localToScreen = (lx: number, ly: number): { x: number; y: number } => {
    const a = angleRad;
    return {
      x: canvasLeft + lx * Math.cos(a) - ly * Math.sin(a),
      y: canvasTop + lx * Math.sin(a) + ly * Math.cos(a),
    };
  };

  // 1. Sample background (cover box) color using surrounding outer bounds
  const bgLocalPoints = [
    [2, -fontHeightPx * 0.85],
    [widthPx * 0.25, -fontHeightPx * 0.85],
    [widthPx * 0.5, -fontHeightPx * 0.85],
    [widthPx * 0.75, -fontHeightPx * 0.85],
    [widthPx - 2, -fontHeightPx * 0.85],
    [2, fontHeightPx * 0.3],
    [widthPx * 0.25, fontHeightPx * 0.3],
    [widthPx * 0.5, fontHeightPx * 0.3],
    [widthPx * 0.75, fontHeightPx * 0.3],
    [widthPx - 2, fontHeightPx * 0.3],
    [-4, -fontHeightPx * 0.2],
    [widthPx + 4, -fontHeightPx * 0.2],
  ];

  const bgSamples: { r: number; g: number; b: number }[] = [];
  bgLocalPoints.forEach(([lx, ly]) => {
    const p = localToScreen(lx, ly);
    if (p.x >= 0 && p.y >= 0 && p.x < w && p.y < h) {
      bgSamples.push(getPixelColor(ctx, p.x, p.y, w, h));
    }
  });

  // Per-channel median calculation to withstand isolated colored edge pixels
  const median = (arr: number[]): number => {
    const s = [...arr].sort((a, b) => a - b);
    return s[Math.floor(s.length / 2)];
  };

  let bgHex = '#ffffff';
  let medR = 255, medG = 255, medB = 255;
  if (bgSamples.length > 0) {
    medR = median(bgSamples.map((s) => s.r));
    medG = median(bgSamples.map((s) => s.g));
    medB = median(bgSamples.map((s) => s.b));
    bgHex = rgbToHex(medR, medG, medB);
  }

  // 2. Sample ink (text) color with a DENSE grid to ensure thin strokes are hit
  let bestColor = { r: 0, g: 0, b: 0 };
  let maxContrast = -1;
  let found = false;

  const numX = 35;
  const numY = 10;

  for (let xi = 0; xi <= numX; xi++) {
    for (let yi = 0; yi <= numY; yi++) {
      // Offset from absolute edges to avoid sampling page background
      const lx = widthPx * (0.05 + 0.90 * (xi / numX));
      const ly = -fontHeightPx * 0.75 + fontHeightPx * 0.80 * (yi / numY);
      const p = localToScreen(lx, ly);
      
      if (p.x >= 0 && p.y >= 0 && p.x < w && p.y < h) {
        const c = getPixelColor(ctx, p.x, p.y, w, h);
        
        // Euclidean distance in RGB color space as contrast distance metric
        const contrast = Math.sqrt(
          Math.pow(c.r - medR, 2) +
          Math.pow(c.g - medG, 2) +
          Math.pow(c.b - medB, 2)
        );

        if (contrast > maxContrast) {
          maxContrast = contrast;
          bestColor = c;
          found = true;
        }
      }
    }
  }

  let finalR = bestColor.r;
  let finalG = bestColor.g;
  let finalB = bestColor.b;

  const bgBrightness = medR * 0.299 + medG * 0.587 + medB * 0.114;
  
  // Minimalist snapping: Only snap to absolute black/white if extremely close, 
  // otherwise preserve the exact colorful/gray text styles of the original PDF
  if (bgBrightness > 128) {
    if (finalR < 25 && finalG < 25 && finalB < 25) {
      finalR = 0;
      finalG = 0;
      finalB = 0;
    }
  } else {
    if (finalR > 230 && finalG > 230 && finalB > 230) {
      finalR = 255;
      finalG = 255;
      finalB = 255;
    }
  }

  const inkHex = found && maxContrast > 6
    ? rgbToHex(finalR, finalG, finalB)
    : (bgBrightness > 128 ? '#000000' : '#ffffff');

  return { bg: bgHex, ink: inkHex };
}

