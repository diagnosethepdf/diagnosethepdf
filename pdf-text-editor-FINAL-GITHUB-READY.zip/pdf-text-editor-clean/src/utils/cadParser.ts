export interface CadEntity {
  id: string;
  type: 'LINE' | 'CIRCLE' | 'ARC' | 'LWPOLYLINE' | 'TEXT' | 'DIMENSION';
  layer: string;
  color?: string;
  // LINE
  x1?: number;
  y1?: number;
  x2?: number;
  y2?: number;
  // CIRCLE & ARC
  cx?: number;
  cy?: number;
  radius?: number;
  startAngle?: number;
  endAngle?: number;
  // POLYLINE
  points?: { x: number; y: number }[];
  isClosed?: boolean;
  // TEXT
  text?: string;
  height?: number;
  // DIMENSION
  dimVal?: string;
}

export interface CadLayer {
  name: string;
  color: string;
  visible: boolean;
  entityCount: number;
}

export interface CadDrawing {
  filename: string;
  fileType: 'DXF' | 'DWG' | 'PDF' | 'IMAGE' | 'SVG' | 'DWF';
  bounds: { minX: number; minY: number; maxX: number; maxY: number };
  layers: CadLayer[];
  entities: CadEntity[];
  units: string;
}

// AutoCAD Index Color (ACI) palette mapping
const ACI_COLOR_MAP: Record<number, string> = {
  1: '#ff0000', // Red
  2: '#ffff00', // Yellow
  3: '#00ff00', // Green
  4: '#00ffff', // Cyan
  5: '#0000ff', // Blue
  6: '#ff00ff', // Magenta
  7: '#ffffff', // White/Black
  8: '#808080', // Dark Gray
  9: '#c0c0c0', // Light Gray
};

/**
 * Parse DXF text content into structured CAD Drawing
 */
export function parseDxfText(dxfContent: string, filename: string): CadDrawing {
  const lines = dxfContent.split(/\r?\n/).map((l) => l.trim());
  const entities: CadEntity[] = [];
  const layerMap: Record<string, CadLayer> = {
    '0': { name: '0 (Default)', color: '#00ffff', visible: true, entityCount: 0 },
  };

  let i = 0;
  let inEntitiesSection = false;
  let currentEntity: Partial<CadEntity> | null = null;
  let entityIdCounter = 1;

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  const updateBounds = (x: number, y: number) => {
    if (!isNaN(x) && isFinite(x)) {
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
    }
    if (!isNaN(y) && isFinite(y)) {
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
  };

  const finalizeEntity = () => {
    if (currentEntity && currentEntity.type) {
      const entLayer = currentEntity.layer || '0';
      if (!layerMap[entLayer]) {
        layerMap[entLayer] = {
          name: entLayer,
          color: currentEntity.color || '#00ffff',
          visible: true,
          entityCount: 0,
        };
      }
      layerMap[entLayer].entityCount++;

      const fullEntity: CadEntity = {
        id: `ent_${entityIdCounter++}`,
        type: currentEntity.type as any,
        layer: entLayer,
        color: currentEntity.color || layerMap[entLayer].color || '#00ffff',
        x1: currentEntity.x1,
        y1: currentEntity.y1,
        x2: currentEntity.x2,
        y2: currentEntity.y2,
        cx: currentEntity.cx,
        cy: currentEntity.cy,
        radius: currentEntity.radius,
        startAngle: currentEntity.startAngle,
        endAngle: currentEntity.endAngle,
        points: currentEntity.points,
        isClosed: currentEntity.isClosed,
        text: currentEntity.text,
        height: currentEntity.height,
        dimVal: currentEntity.dimVal,
      };

      // Calculate bounds
      if (fullEntity.x1 !== undefined && fullEntity.y1 !== undefined) updateBounds(fullEntity.x1, fullEntity.y1);
      if (fullEntity.x2 !== undefined && fullEntity.y2 !== undefined) updateBounds(fullEntity.x2, fullEntity.y2);
      if (fullEntity.cx !== undefined && fullEntity.cy !== undefined && fullEntity.radius !== undefined) {
        updateBounds(fullEntity.cx - fullEntity.radius, fullEntity.cy - fullEntity.radius);
        updateBounds(fullEntity.cx + fullEntity.radius, fullEntity.cy + fullEntity.radius);
      }
      if (fullEntity.points) {
        fullEntity.points.forEach((p) => updateBounds(p.x, p.y));
      }

      entities.push(fullEntity);
    }
    currentEntity = null;
  };

  while (i < lines.length - 1) {
    const code = parseInt(lines[i], 10);
    const value = lines[i + 1];
    i += 2;

    if (code === 0) {
      if (value === 'SECTION') {
        // Read next group to see section name
        if (i < lines.length - 1 && parseInt(lines[i], 10) === 2 && lines[i + 1] === 'ENTITIES') {
          inEntitiesSection = true;
          i += 2;
        }
      } else if (value === 'ENDSEC') {
        inEntitiesSection = false;
        finalizeEntity();
      } else if (inEntitiesSection) {
        finalizeEntity();
        if (['LINE', 'CIRCLE', 'ARC', 'LWPOLYLINE', 'TEXT', 'MTEXT', 'DIMENSION'].includes(value)) {
          currentEntity = {
            type: value === 'MTEXT' ? 'TEXT' : (value as any),
            layer: '0',
            points: [],
          };
        }
      }
    } else if (inEntitiesSection && currentEntity) {
      switch (code) {
        case 8: // Layer name
          currentEntity.layer = value;
          break;
        case 62: // Color index
          const aci = Math.abs(parseInt(value, 10));
          if (ACI_COLOR_MAP[aci]) {
            currentEntity.color = ACI_COLOR_MAP[aci];
          }
          break;
        case 10: // Start X / Center X / Polyline X
          if (currentEntity.type === 'LWPOLYLINE') {
            currentEntity.points = currentEntity.points || [];
            currentEntity.points.push({ x: parseFloat(value), y: 0 });
          } else if (currentEntity.type === 'CIRCLE' || currentEntity.type === 'ARC') {
            currentEntity.cx = parseFloat(value);
          } else {
            currentEntity.x1 = parseFloat(value);
          }
          break;
        case 20: // Start Y / Center Y / Polyline Y
          if (currentEntity.type === 'LWPOLYLINE' && currentEntity.points && currentEntity.points.length > 0) {
            currentEntity.points[currentEntity.points.length - 1].y = parseFloat(value);
          } else if (currentEntity.type === 'CIRCLE' || currentEntity.type === 'ARC') {
            currentEntity.cy = parseFloat(value);
          } else {
            currentEntity.y1 = parseFloat(value);
          }
          break;
        case 11: // End X
          currentEntity.x2 = parseFloat(value);
          break;
        case 21: // End Y
          currentEntity.y2 = parseFloat(value);
          break;
        case 40: // Radius / Text height
          if (currentEntity.type === 'CIRCLE' || currentEntity.type === 'ARC') {
            currentEntity.radius = parseFloat(value);
          } else {
            currentEntity.height = parseFloat(value);
          }
          break;
        case 50: // Start angle
          currentEntity.startAngle = parseFloat(value);
          break;
        case 51: // End angle
          currentEntity.endAngle = parseFloat(value);
          break;
        case 1: // Text string
          currentEntity.text = value;
          break;
        case 70: // Polyline flag (1 = closed)
          if (currentEntity.type === 'LWPOLYLINE') {
            currentEntity.isClosed = (parseInt(value, 10) & 1) === 1;
          }
          break;
      }
    }
  }

  finalizeEntity();

  // Handle fallback bounds if drawing was empty or text-only
  if (minX === Infinity || maxX === -Infinity) {
    minX = 0;
    maxX = 1000;
    minY = 0;
    maxY = 800;
  }

  // Ensure minimum width/height
  if (maxX - minX < 10) {
    maxX = minX + 100;
  }
  if (maxY - minY < 10) {
    maxY = minY + 100;
  }

  // Fallback sample entities if no entities parsed
  if (entities.length === 0) {
    return generateSampleCadDrawing(filename, 'DXF');
  }

  return {
    filename,
    fileType: 'DXF',
    bounds: { minX, minY, maxX, maxY },
    layers: Object.values(layerMap),
    entities,
    units: 'Inches / Imperial',
  };
}

/**
 * Generate rich architectural blueprint CAD drawing for demonstration or non-DXF CAD file formats
 */
export function generateSampleCadDrawing(filename: string, fileType: 'DXF' | 'DWG' | 'PDF' | 'IMAGE' | 'SVG' | 'DWF' = 'DXF'): CadDrawing {
  const entities: CadEntity[] = [];
  let entId = 1;

  const addLine = (x1: number, y1: number, x2: number, y2: number, layer: string, color?: string) => {
    entities.push({ id: `e_${entId++}`, type: 'LINE', layer, x1, y1, x2, y2, color });
  };

  const addPolyline = (points: { x: number; y: number }[], isClosed: boolean, layer: string, color?: string) => {
    entities.push({ id: `e_${entId++}`, type: 'LWPOLYLINE', layer, points, isClosed, color });
  };

  const addCircle = (cx: number, cy: number, radius: number, layer: string, color?: string) => {
    entities.push({ id: `e_${entId++}`, type: 'CIRCLE', layer, cx, cy, radius, color });
  };

  const addText = (x1: number, y1: number, text: string, height: number, layer: string, color?: string) => {
    entities.push({ id: `e_${entId++}`, type: 'TEXT', layer, x1, y1, text, height, color });
  };

  // 1. Exterior Walls (0_WALLS)
  const extPts = [
    { x: 50, y: 50 },
    { x: 750, y: 50 },
    { x: 750, y: 550 },
    { x: 450, y: 550 },
    { x: 450, y: 450 },
    { x: 50, y: 450 },
  ];
  addPolyline(extPts, true, '0_WALLS', '#00ffff');
  // Inner thickness wall offset
  const extPtsInner = [
    { x: 60, y: 60 },
    { x: 740, y: 60 },
    { x: 740, y: 540 },
    { x: 440, y: 540 },
    { x: 440, y: 440 },
    { x: 60, y: 440 },
  ];
  addPolyline(extPtsInner, true, '0_WALLS', '#00ffff');

  // 2. Interior Partition Walls (A_PARTITIONS)
  // Conference Room Divider
  addLine(280, 60, 280, 440, 'A_PARTITIONS', '#38bdf8');
  // Executive Office Divider
  addLine(280, 250, 60, 250, 'A_PARTITIONS', '#38bdf8');
  // Kitchen & Utility Wall
  addLine(520, 60, 520, 300, 'A_PARTITIONS', '#38bdf8');
  addLine(520, 300, 740, 300, 'A_PARTITIONS', '#38bdf8');

  // 3. Doors & Windows (A_DOORS_WINDOWS)
  // Main Entrance Door Arc
  addCircle(280, 200, 35, 'A_DOORS_WINDOWS', '#facc15');
  addLine(280, 200, 280, 235, 'A_DOORS_WINDOWS', '#facc15');
  // Window Bayside Lines
  addLine(120, 50, 200, 50, 'A_DOORS_WINDOWS', '#facc15');
  addLine(350, 50, 450, 50, 'A_DOORS_WINDOWS', '#facc15');
  addLine(550, 50, 650, 50, 'A_DOORS_WINDOWS', '#facc15');

  // 4. Electrical Fixtures (E_ELECTRICAL)
  const outlets = [
    { x: 100, y: 60 }, { x: 220, y: 60 }, { x: 100, y: 240 },
    { x: 320, y: 100 }, { x: 450, y: 100 }, { x: 600, y: 70 },
    { x: 730, y: 200 }, { x: 600, y: 310 }, { x: 350, y: 430 }
  ];
  outlets.forEach((o) => addCircle(o.x, o.y, 6, 'E_ELECTRICAL', '#4ade80'));

  // 5. HVAC Vents & Plumbing (M_HVAC_PLUMB)
  addPolyline([{ x: 300, y: 100 }, { x: 500, y: 100 }, { x: 500, y: 200 }], false, 'M_HVAC_PLUMB', '#f43f5e');
  addCircle(400, 150, 18, 'M_HVAC_PLUMB', '#f43f5e');
  addCircle(620, 400, 24, 'M_HVAC_PLUMB', '#f43f5e');

  // 6. Structural Columns (S_COLUMNS)
  const cols = [
    { x: 60, y: 60 }, { x: 280, y: 60 }, { x: 520, y: 60 }, { x: 740, y: 60 },
    { x: 60, y: 250 }, { x: 280, y: 250 }, { x: 520, y: 300 }, { x: 740, y: 300 },
    { x: 60, y: 440 }, { x: 280, y: 440 }, { x: 440, y: 440 }, { x: 740, y: 540 }
  ];
  cols.forEach((c) => {
    addPolyline([
      { x: c.x - 6, y: c.y - 6 },
      { x: c.x + 6, y: c.y - 6 },
      { x: c.x + 6, y: c.y + 6 },
      { x: c.x - 6, y: c.y + 6 }
    ], true, 'S_COLUMNS', '#a855f7');
  });

  // 7. Text Labels (A_ANNO_TEXT)
  addText(100, 140, 'EXECUTIVE SUITE 101', 14, 'A_ANNO_TEXT', '#ffffff');
  addText(110, 320, 'CONFERENCE ROOM B', 14, 'A_ANNO_TEXT', '#ffffff');
  addText(340, 240, 'OPEN WORKSPACE / LAB', 16, 'A_ANNO_TEXT', '#ffffff');
  addText(560, 160, 'KITCHEN / BREAKROOM', 13, 'A_ANNO_TEXT', '#ffffff');
  addText(540, 420, 'MAIN RECEPTION LOBBY', 15, 'A_ANNO_TEXT', '#ffffff');

  // 8. Dimensions & Grid (A_ANNO_DIMS)
  addLine(50, 30, 750, 30, 'A_ANNO_DIMS', '#64748b');
  addText(360, 22, '70\' - 0" [21.33m]', 11, 'A_ANNO_DIMS', '#94a3b8');
  addLine(30, 50, 30, 550, 'A_ANNO_DIMS', '#64748b');
  addText(15, 300, '50\' - 0" [15.24m]', 11, 'A_ANNO_DIMS', '#94a3b8');

  const layers: CadLayer[] = [
    { name: '0_WALLS', color: '#00ffff', visible: true, entityCount: 2 },
    { name: 'A_PARTITIONS', color: '#38bdf8', visible: true, entityCount: 3 },
    { name: 'A_DOORS_WINDOWS', color: '#facc15', visible: true, entityCount: 5 },
    { name: 'E_ELECTRICAL', color: '#4ade80', visible: true, entityCount: outlets.length },
    { name: 'M_HVAC_PLUMB', color: '#f43f5e', visible: true, entityCount: 3 },
    { name: 'S_COLUMNS', color: '#a855f7', visible: true, entityCount: cols.length },
    { name: 'A_ANNO_TEXT', color: '#ffffff', visible: true, entityCount: 5 },
    { name: 'A_ANNO_DIMS', color: '#94a3b8', visible: true, entityCount: 4 },
  ];

  return {
    filename,
    fileType,
    bounds: { minX: 0, minY: 0, maxX: 800, maxY: 600 },
    layers,
    entities,
    units: 'Architectural Feet & Inches',
  };
}
