/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PDFTextRun, EditMap } from '../types';

let sharedPdfLibDoc: any = null;
const fontMetricsCache: { [fontName: string]: any } = {};

export function cleanFontFamilyName(f: string | undefined): string {
  if (!f) return 'sans';
  let clean = f.replace(/^[A-Z0-9]{6}\+/i, ''); // Strip PDF subset prefix
  clean = clean.replace(/[-_]/g, ' ');
  // Strip weight and style suffixes that break standard CSS font-family matching
  clean = clean.replace(/\b(Bold|BoldItalic|Italic|Oblique|Regular|Roman|Light|Medium|Semibold|Heavy|Black|MT|PSMT|PS|Type1)\b/gi, '').trim();
  clean = clean.replace(/\s+/g, ' ').trim();
  return clean || f;
}

export function cssFamily(f: string | undefined): string {
  if (!f) return 'Arial, Helvetica, sans-serif';
  const family = f.toLowerCase();
  
  if (family === 'sans') return 'Arial, Helvetica, "Plus Jakarta Sans", sans-serif';
  if (family === 'serif') return 'Georgia, "Times New Roman", serif';
  if (family === 'mono') return '"Courier New", Consolas, monospace';

  if (family.includes('calibri') || family.includes('carlito')) return 'Calibri, "Carlito", "Segoe UI", sans-serif';
  if (family.includes('arial') || family.includes('arimo')) return 'Arial, "Arimo", Helvetica, sans-serif';
  if (family.includes('helvetica')) return 'Helvetica, Arial, "Arimo", sans-serif';
  if (family.includes('times') || family.includes('tinos') || family.includes('times new roman')) return '"Times New Roman", "Tinos", Times, serif';
  if (family.includes('georgia') || family.includes('lora')) return 'Georgia, "Lora", serif';
  if (family.includes('courier') || family.includes('cousine') || family.includes('mono') || family.includes('consolas')) return '"Courier New", "Cousine", monospace';
  if (family.includes('cambria')) return 'Cambria, Georgia, serif';
  if (family.includes('garamond')) return 'Garamond, "Times New Roman", serif';
  if (family.includes('verdana')) return 'Verdana, Geneva, sans-serif';
  if (family.includes('trebuchet')) return '"Trebuchet MS", sans-serif';
  if (family.includes('jakarta')) return '"Plus Jakarta Sans", sans-serif';
  
  const cleanedName = cleanFontFamilyName(f);
  const fallback = (family.includes('serif') && !family.includes('sans')) ? 'serif' : 'sans-serif';
  return `"${cleanedName}", ${fallback}`;
}

export function granularizeRuns(
  runs: PDFTextRun[],
  granularity: 'line' | 'sentence' | 'word' | undefined,
  edits: EditMap
): PDFTextRun[] {
  if (!runs || runs.length === 0) return [];
  if (!granularity || granularity === 'line') return runs;

  const result: PDFTextRun[] = [];

  for (const run of runs) {
    // If there is an existing edit for this exact parent run ID, keep it intact
    if (edits && edits[run.id]) {
      result.push(run);
      continue;
    }

    const str = run.str || '';
    if (!str.trim()) {
      result.push(run);
      continue;
    }

    const [a, b, c, d, e, f] = run.transform;
    const angleRad = run.angleRad !== undefined ? run.angleRad : Math.atan2(b, a);
    const fontHeightPx = run.fontHeightPx !== undefined ? run.fontHeightPx : Math.hypot(c, d);

    const scaleX = Math.hypot(a, b) || 1;
    const ux = a / scaleX;
    const uy = b / scaleX;

    if (granularity === 'word') {
      const wordMatches = Array.from(str.matchAll(/\S+/g));
      if (wordMatches.length <= 1) {
        result.push(run);
        continue;
      }

      const totalLen = Math.max(1, str.length);

      for (let i = 0; i < wordMatches.length; i++) {
        const match = wordMatches[i];
        const wordText = match[0];
        const charIdx = match.index || 0;

        const subId = `${run.id}-w${charIdx}`;
        const startRatio = charIdx / totalLen;
        const wordRatio = wordText.length / totalLen;

        const subWidth = run.width * wordRatio;
        const subWidthPx = (run.widthPx || run.width) * wordRatio;

        const dx = run.width * startRatio;
        const subLeft = e + dx * ux;
        const subTop = f + dx * uy;

        result.push({
          ...run,
          id: subId,
          str: wordText,
          width: subWidth,
          widthPx: subWidthPx,
          transform: [a, b, c, d, subLeft, subTop],
          baseLeft: subLeft,
          baseTop: subTop,
          angleRad,
          fontHeightPx,
        });
      }
    } else if (granularity === 'sentence') {
      const sentenceRegex = /[^.!?]+[.!?]+(?:\s+|$)|[^.!?]+$/g;
      const sentenceMatches = Array.from(str.matchAll(sentenceRegex));
      if (sentenceMatches.length <= 1) {
        result.push(run);
        continue;
      }

      const totalLen = Math.max(1, str.length);

      for (let i = 0; i < sentenceMatches.length; i++) {
        const match = sentenceMatches[i];
        const sentenceText = match[0].trimEnd();
        const charIdx = match.index || 0;

        const subId = `${run.id}-s${charIdx}`;
        const startRatio = charIdx / totalLen;
        const sentenceRatio = sentenceText.length / totalLen;

        const subWidth = run.width * sentenceRatio;
        const subWidthPx = (run.widthPx || run.width) * sentenceRatio;

        const dx = run.width * startRatio;
        const subLeft = e + dx * ux;
        const subTop = f + dx * uy;

        result.push({
          ...run,
          id: subId,
          str: sentenceText,
          width: subWidth,
          widthPx: subWidthPx,
          transform: [a, b, c, d, subLeft, subTop],
          baseLeft: subLeft,
          baseTop: subTop,
          angleRad,
          fontHeightPx,
        });
      }
    }
  }

  return result;
}

export function getStdFontName(family: string, bold: boolean, italic: boolean): string {
  const { StandardFonts } = (window as any).PDFLib || {};
  if (!StandardFonts) return 'Helvetica';
  const f = family.toLowerCase();
  if (f === 'serif' || f === 'times' || f === 'georgia') {
    if (bold && italic) return StandardFonts.TimesRomanBoldItalic;
    if (bold) return StandardFonts.TimesRomanBold;
    if (italic) return StandardFonts.TimesRomanItalic;
    return StandardFonts.TimesRoman;
  }
  if (f === 'mono' || f === 'courier') {
    if (bold && italic) return StandardFonts.CourierBoldOblique;
    if (bold) return StandardFonts.CourierBold;
    if (italic) return StandardFonts.CourierOblique;
    return StandardFonts.Courier;
  }
  if (bold && italic) return StandardFonts.HelveticaBoldOblique;
  if (bold) return StandardFonts.HelveticaBold;
  if (italic) return StandardFonts.HelveticaOblique;
  return StandardFonts.Helvetica;
}

export async function initFontMetrics() {
  if (sharedPdfLibDoc) return;
  const { PDFDocument, StandardFonts } = (window as any).PDFLib || {};
  if (!PDFDocument) return;
  try {
    sharedPdfLibDoc = await PDFDocument.create();
    const fontsToEmbed = [
      StandardFonts.Helvetica, StandardFonts.HelveticaBold, StandardFonts.HelveticaOblique, StandardFonts.HelveticaBoldOblique,
      StandardFonts.Courier, StandardFonts.CourierBold, StandardFonts.CourierOblique, StandardFonts.CourierBoldOblique,
      StandardFonts.TimesRoman, StandardFonts.TimesRomanBold, StandardFonts.TimesRomanItalic, StandardFonts.TimesRomanBoldItalic
    ];
    for (const f of fontsToEmbed) {
      fontMetricsCache[f] = await sharedPdfLibDoc.embedFont(f);
    }
  } catch (err) {
    console.error('Failed to pre-embed standard fonts for metrics:', err);
  }
}

export function getStandardTextWidth(
  text: string,
  family: string,
  bold: boolean,
  italic: boolean,
  size: number
): number {
  const lines = text.split('\n');
  if (lines.length > 1) {
    let maxWidth = 0;
    for (const line of lines) {
      const w = getStandardTextWidth(line, family, bold, italic, size);
      if (w > maxWidth) maxWidth = w;
    }
    return maxWidth;
  }

  const fontName = getStdFontName(family, bold, italic);
  const font = fontMetricsCache[fontName];
  if (font) {
    try {
      return font.widthOfTextAtSize(text, size);
    } catch (e) {
      // Fallback
    }
  }

  // Precise mathematical fallbacks if font is not yet embedded or error occurred:
  const f = family.toLowerCase();
  if (f === 'courier' || f === 'mono') {
    return text.length * size * 0.6;
  }
  if (f === 'sans' || f === 'arial' || f === 'calibri') {
    // Helvetica proportional average widths
    let widthSum = 0;
    for (let i = 0; i < text.length; i++) {
      const charCode = text.charCodeAt(i);
      // Standard character width estimates
      if (charCode === 32) widthSum += 0.28; // space
      else if (/[iIlLt1\(\)\[\]]/.test(text[i])) widthSum += 0.26;
      else if (/[fjrI\-]/.test(text[i])) widthSum += 0.33;
      else if (/[abcdeghkmnopqrsuvxyzJFPSTUVXYZ]/.test(text[i])) widthSum += 0.55;
      else if (/[mwW\+=\#]/.test(text[i])) widthSum += 0.72;
      else widthSum += 0.53; // default
    }
    return widthSum * size;
  }
  
  // Serif (Times Roman) fallback width estimate
  let widthSum = 0;
  for (let i = 0; i < text.length; i++) {
    const charCode = text.charCodeAt(i);
    if (charCode === 32) widthSum += 0.25;
    else if (/[iIlLt]/.test(text[i])) widthSum += 0.28;
    else if (/[fjr\-]/.test(text[i])) widthSum += 0.33;
    else if (/[abcdeghkmnopqrsuvxyz]/.test(text[i])) widthSum += 0.44;
    else if (/[mw]/.test(text[i])) widthSum += 0.70;
    else if (/[A-Z]/.test(text[i])) widthSum += 0.68;
    else widthSum += 0.50;
  }
  return widthSum * size;
}
