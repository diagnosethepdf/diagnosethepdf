/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type SignatureSizePreset = 'medium' | 'large' | 'xlarge' | 'custom';
export type PageFormat = 'A0' | 'A1' | 'A2' | 'A3' | 'A4' | 'A5' | 'Letter' | 'Legal' | 'Tabloid' | 'Executive' | 'Arch A' | 'Arch B' | 'Custom';

export interface FormatPlacementSetting {
  xPercent: number;
  yPercent: number;
  rotation: number;
  scalePercent: number;
  presetName?: string;
  isSaved?: boolean;
}

export interface PlacementConfig {
  a4HeaderPosition?: 'top-right' | 'top-center' | 'top-left';
  a4SignaturePreset?: SignatureSizePreset;
  a4SignatureCustomScale?: number;

  a3SignaturePreset?: SignatureSizePreset;
  a3SignatureCustomScale?: number;
  a3RotationDegrees?: number; // default 90 (0, 90, 180, 270)
  a3LeftOffsetPt?: number; // default 144 (2 inches)
  a3BottomOffsetPt?: number; // default 144 (2 inches)

  formatConfigs?: Record<string, FormatPlacementSetting>;
}

export interface SignaturePlacementResult {
  x: number; // PDF points from left
  y: number; // PDF points from bottom
  width: number; // PDF points
  height: number; // PDF points
  cornerName: string; // e.g. 'Top-Right Header (A4)', 'A3 Landscape Center (90° Clockwise)'
  scaleApplied: number; // e.g. 1.0 or 0.85
  autoShrunk: boolean;
  cleanGapFound: boolean;
  isTextOverlayFallback: boolean;
  opacity: number; // 1.0 for clean gap, 0.85 for text overlay fallback
  overlapCount: number;
  pageFormat: PageFormat;
  isLandscape?: boolean;
  rotationDegrees?: number; // e.g. 90
}

export interface PaperFormat {
  name: string;
  minPt: number;
  maxPt: number;
}

export interface PdfPlacementCoords {
  x: number;
  y: number;
  rotationDegrees: number;
}

/**
 * Standard paper dimensions in points (1 pt = 1/72 inch).
 * Evaluates min and max dimensions to support both portrait and landscape.
 */
const PAPER_FORMATS: PaperFormat[] = [
  { name: 'A5', minPt: 420, maxPt: 595 },
  { name: 'A4', minPt: 595, maxPt: 842 },
  { name: 'A3', minPt: 842, maxPt: 1191 },   // 297mm x 420mm (~842pt x 1191pt)
  { name: 'A2', minPt: 1191, maxPt: 1684 },  // 420mm x 594mm (~1191pt x 1684pt)
  { name: 'A1', minPt: 1684, maxPt: 2384 },  // 594mm x 841mm (~1684pt x 2384pt)
  { name: 'A0', minPt: 2384, maxPt: 3370 },
  { name: 'LETTER', minPt: 612, maxPt: 792 },
  { name: 'LEGAL', minPt: 612, maxPt: 1008 },
  { name: 'TABLOID', minPt: 792, maxPt: 1224 },
  { name: 'EXECUTIVE', minPt: 522, maxPt: 756 },
  { name: 'ARCH_A', minPt: 648, maxPt: 864 },
  { name: 'ARCH_B', minPt: 864, maxPt: 1296 },
];

/**
 * Pure Physical Dimension Classifier for A0-A5 & Architectural Formats.
 */
export function detectPaperFormat(
  rawWidth: number,
  rawHeight: number,
  userUnit: number = 1
): string {
  const scaledWidth = rawWidth * userUnit;
  const scaledHeight = rawHeight * userUnit;

  const minDim = Math.min(scaledWidth, scaledHeight);
  const maxDim = Math.max(scaledWidth, scaledHeight);

  // Precision physical dimension classifier for ISO paper sizes (in PDF points, 1pt = 1/72 in):
  // A0: ~2384 x 3370 pt
  // A1: ~1684 x 2384 pt
  // A2: ~1191 x 1684 pt
  // A3: ~842 x 1191 pt
  // A4: ~595 x 842 pt
  // A5: ~420 x 595 pt
  if (minDim >= 1850 || maxDim >= 2500) return 'A0';
  if (minDim >= 1350 || maxDim >= 1800) return 'A1';
  if (minDim >= 950 || maxDim >= 1300) return 'A2';
  if (minDim >= 680 || maxDim >= 950) return 'A3';
  if (minDim >= 480 || maxDim >= 680) return 'A4';
  if (minDim >= 300 || maxDim >= 480) return 'A5';

  return 'A4';
}

/**
 * Proportional scaling factors for different paper formats.
 * Keeps the signature visually readable and beautifully scaled on large plotter sheets (A0-A3).
 */
export function getPageFormatScaleFactor(format: string): number {
  switch (format) {
    case 'A5': return 0.7;
    case 'A4':
    case 'Letter':
    case 'Legal':
    case 'Executive':
      return 1.0;
    case 'A3':
    case 'Tabloid':
    case 'Arch A':
      return 1.4;
    case 'A2': return 2.0;
    case 'A1':
    case 'Arch B':
      return 3.0;
    case 'A0': return 4.5;
    default: return 1.0;
  }
}

/**
 * Center-Anchored Coordinate Translation.
 * Synchronizes visual Top-Left (0–100%) UI placements with PDF Bottom-Left point coordinates.
 */
export function calculatePdfCoordinates(
  uiXPercent: number,
  uiYPercent: number,
  pageWidthPt: number,
  pageHeightPt: number,
  stampWidthPt: number,
  stampHeightPt: number,
  userRotationAngle: number = 0,
  pageNativeRotation: number = 0
): PdfPlacementCoords {
  const W = pageWidthPt;
  const H = pageHeightPt;
  const nativeRot = ((pageNativeRotation % 360) + 360) % 360;

  let centerX = 0;
  let centerY = 0;

  if (nativeRot === 90) {
    // Rendered width is H, rendered height is W
    const x_vis = (uiXPercent / 100) * H;
    const y_vis = (uiYPercent / 100) * W;
    centerX = y_vis;
    centerY = x_vis;
  } else if (nativeRot === 180) {
    // Rendered width is W, rendered height is H
    const x_vis = (uiXPercent / 100) * W;
    const y_vis = (uiYPercent / 100) * H;
    centerX = W - x_vis;
    centerY = y_vis;
  } else if (nativeRot === 270) {
    // Rendered width is H, rendered height is W
    const x_vis = (uiXPercent / 100) * H;
    const y_vis = (uiYPercent / 100) * W;
    centerX = W - y_vis;
    centerY = H - x_vis;
  } else {
  // nativeRot === 0
    centerX = (uiXPercent / 100) * W;
    const centerYFromTop = (uiYPercent / 100) * H;
    centerY = H - centerYFromTop;
  }

  // Determine paper-format scale-aware margin inset
  const format = detectPaperFormat(W, H);

  if (format === 'A0') {
    console.log(`[Diagnostic Log] Right when placement is triggered: raw canvas coordinate computed (centerX=${centerX}, centerY=${centerY}) BEFORE any scale conversion`);
  }

  // Calculate bounding offsets under rotation
  const unrotatedX = centerX - stampWidthPt / 2;
  const unrotatedY = centerY - stampHeightPt / 2;

  // Total combined rotation
  const totalRotation = (userRotationAngle + pageNativeRotation) % 360;

  // Shift origin based on rotation angle so center remains locked
  let pdfX = unrotatedX;
  let pdfY = unrotatedY;

  if (totalRotation === 90) {
    pdfX = centerX + stampHeightPt / 2;
    pdfY = centerY - stampWidthPt / 2;
  } else if (totalRotation === 180) {
    pdfX = centerX + stampWidthPt / 2;
    pdfY = centerY + stampHeightPt / 2;
  } else if (totalRotation === 270) {
    pdfX = centerX - stampHeightPt / 2;
    pdfY = centerY + stampWidthPt / 2;
  }

  if (format === 'A0') {
    console.log(`[Diagnostic Log] Right after scale conversion: realX=${pdfX}, realY=${pdfY} BEFORE clamping`);
  }

  const isLargeSheet = format === 'A0' || format === 'A1';
  const margin = isLargeSheet ? 48 : 24;

  let clampedX = pdfX;
  let clampedY = pdfY;

  if (totalRotation === 90) {
    clampedX = Math.max(stampHeightPt + margin, Math.min(pdfX, W - margin));
    clampedY = Math.max(margin, Math.min(pdfY, H - stampWidthPt - margin));
  } else if (totalRotation === 180) {
    clampedX = Math.max(stampWidthPt + margin, Math.min(pdfX, W - margin));
    clampedY = Math.max(stampHeightPt + margin, Math.min(pdfY, H - margin));
  } else if (totalRotation === 270) {
    clampedX = Math.max(margin, Math.min(pdfX, W - stampHeightPt - margin));
    clampedY = Math.max(stampWidthPt + margin, Math.min(pdfY, H - margin));
  } else {
    // totalRotation === 0
    clampedX = Math.max(margin, Math.min(pdfX, W - stampWidthPt - margin));
    clampedY = Math.max(margin, Math.min(pdfY, H - stampHeightPt - margin));
  }

  if (format === 'A0') {
    console.log(`[Diagnostic Log] Right after clamping: final realX=${clampedX}, realY=${clampedY} actually used to stamp the signature`);
  }

  return {
    x: clampedX,
    y: clampedY,
    rotationDegrees: totalRotation,
  };
}

export function getSignatureBaseDimensions(
  preset: SignatureSizePreset = 'medium',
  customScale: number = 100,
  imgWidth: number = 200,
  imgHeight: number = 100
): { width: number; height: number } {
  const aspect = imgWidth / Math.max(1, imgHeight);
  
  let targetWidthPt = 130; // Medium ~ 150px in PDF points
  if (preset === 'large') {
    targetWidthPt = 210; // Large ~ 250px in PDF points
  } else if (preset === 'xlarge') {
    targetWidthPt = 300; // Extra Large ~ 350px in PDF points
  } else if (preset === 'custom') {
    targetWidthPt = 130 * Math.max(0.5, Math.min(2.0, customScale / 100));
  }

  const targetHeightPt = targetWidthPt / aspect;
  return { width: targetWidthPt, height: targetHeightPt };
}

export async function detectSmartPlacement(
  pdfJsDoc: any | null,
  pageIndex: number,
  pageWidth: number,
  pageHeight: number,
  baseWidth: number,
  baseHeight: number,
  config?: PlacementConfig
): Promise<SignaturePlacementResult> {
  const pageFormat = detectPaperFormat(pageWidth, pageHeight) as PageFormat;

  if (pageFormat === 'A0') {
    console.log(`[Diagnostic Log] Right after page size detection: detectedPageSize=${pageFormat}, actualPageWidthPt=${pageWidth}, actualPageHeightPt=${pageHeight}`);
  }

  // Retrieve user template configuration for this format or use fallback
  const cfg = config?.formatConfigs?.[pageFormat] || 
              config?.formatConfigs?.['A4'] || {
                xPercent: 80,
                yPercent: 85,
                rotation: 0,
                scalePercent: 100
              };

  const scalePercent = cfg.scalePercent ?? 100;
  const rotationDegrees = cfg.rotation ?? 0;
  
  const pageScaleFactor = getPageFormatScaleFactor(pageFormat);
  const finalWidth = baseWidth * pageScaleFactor * (scalePercent / 100);
  const finalHeight = baseHeight * pageScaleFactor * (scalePercent / 100);

  let pageNativeRotation = 0;
  if (pdfJsDoc) {
    try {
      const page = await pdfJsDoc.getPage(pageIndex + 1);
      pageNativeRotation = page.rotate || 0;
    } catch (e) {
      console.warn("Could not fetch page rotation in detectSmartPlacement:", e);
    }
  }

  const { x: posX, y: posY, rotationDegrees: finalRotation } = calculatePdfCoordinates(
    cfg.xPercent,
    cfg.yPercent,
    pageWidth,
    pageHeight,
    finalWidth,
    finalHeight,
    rotationDegrees,
    pageNativeRotation
  );

  return {
    x: posX,
    y: posY,
    width: finalWidth,
    height: finalHeight,
    cornerName: `Template Position (${pageFormat} - ${cfg.xPercent.toFixed(0)}%, ${cfg.yPercent.toFixed(0)}%)`,
    scaleApplied: scalePercent / 100,
    autoShrunk: false,
    cleanGapFound: true,
    isTextOverlayFallback: false,
    opacity: 1.0,
    overlapCount: 0,
    pageFormat: pageFormat as PageFormat,
    rotationDegrees: finalRotation,
  };
}
