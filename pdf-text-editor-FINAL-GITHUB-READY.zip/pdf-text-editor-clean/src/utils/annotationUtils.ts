/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface StampConfig {
  type: 'preset' | 'custom';
  presetKey?: string;
  text: string;
  subtext?: string;
  style: 'box' | 'double-box' | 'round' | 'oval' | 'distressed' | 'badge';
  color: string;
  rotation?: number; // degrees
  includeDate?: boolean;
  dateStr?: string;
}

export interface ShapeConfig {
  shapeType: 'rectangle' | 'rounded-rect' | 'circle' | 'line' | 'arrow' | 'double-arrow' | 'star' | 'speech-bubble' | 'cloud' | 'checkmark' | 'cross' | 'triangle';
  strokeColor: string;
  strokeWidth: number;
  strokeStyle: 'solid' | 'dashed' | 'dotted';
  fillColor: string;
  fillOpacity: number; // 0 to 1
  shadow?: boolean;
}

export interface FloatingTextConfig {
  text: string;
  fontFamily: string;
  fontSize: number;
  textColor: string;
  bgColor: string;
  bgOpacity: number;
  alignment: 'left' | 'center' | 'right';
  bold: boolean;
  italic: boolean;
  underline: boolean;
  borderColor: string;
  borderWidth: number;
  borderStyle: 'none' | 'solid' | 'dashed' | 'double';
  borderRadius: number;
  padding: number;
}

export interface SignatureConfig {
  mode: 'type' | 'draw' | 'upload';
  text?: string;
  fontFamily?: string;
  color: string;
  dataUrl?: string; // For drawn canvas or uploaded image
  includeDate?: boolean;
  signerName?: string;
}

// Preset Stamps Catalog
export const STAMP_PRESETS: { [key: string]: { label: string; text: string; color: string; style: 'box' | 'double-box' | 'round' | 'oval' } } = {
  APPROVED: { label: 'APPROVED', text: 'APPROVED', color: '#10b981', style: 'double-box' },
  REJECTED: { label: 'REJECTED', text: 'REJECTED', color: '#ef4444', style: 'box' },
  CONFIDENTIAL: { label: 'CONFIDENTIAL', text: 'CONFIDENTIAL', color: '#8b5cf6', style: 'double-box' },
  DRAFT: { label: 'DRAFT', text: 'DRAFT', color: '#f59e0b', style: 'box' },
  FINAL: { label: 'FINAL', text: 'FINAL DOCUMENT', color: '#3b82f6', style: 'double-box' },
  PAID: { label: 'PAID', text: 'PAID IN FULL', color: '#059669', style: 'round' },
  VOID: { label: 'VOID', text: 'VOID', color: '#dc2626', style: 'box' },
  COPY: { label: 'COPY', text: 'DUPLICATE COPY', color: '#64748b', style: 'box' },
  URGENT: { label: 'URGENT', text: 'PRIORITY URGENT', color: '#ea580c', style: 'box' },
  FOR_REVIEW: { label: 'FOR REVIEW', text: 'PENDING REVIEW', color: '#0d9488', style: 'double-box' },
  CERTIFIED: { label: 'CERTIFIED', text: 'OFFICIAL CERTIFIED', color: '#d97706', style: 'round' },
  COMPLETED: { label: 'COMPLETED', text: 'TASK COMPLETED', color: '#4f46e5', style: 'round' },
  EXPIRED: { label: 'EXPIRED', text: 'EXPIRED', color: '#475569', style: 'box' },
  APPROVED_CHANGES: { label: 'APPROVED W/ CHANGES', text: 'APPROVED WITH CHANGES', color: '#65a30d', style: 'double-box' },
};

/**
 * Generates a high-res 300 DPI Data URL for a Stamp
 */
export function generateStampPNG(config: StampConfig): string {
  const canvas = document.createElement('canvas');
  const scale = 2; // Retina Crispness
  const w = 360 * scale;
  const h = 180 * scale;
  canvas.width = w;
  canvas.height = h;

  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  ctx.clearRect(0, 0, w, h);
  ctx.save();

  // Rotation if needed
  const rotRad = ((config.rotation || 0) * Math.PI) / 180;
  ctx.translate(w / 2, h / 2);
  ctx.rotate(rotRad);
  ctx.translate(-w / 2, -h / 2);

  const mainColor = config.color || '#ef4444';
  const text = (config.text || 'STAMP').toUpperCase();
  const sub = config.subtext || (config.includeDate ? (config.dateStr || new Date().toISOString().split('T')[0]) : '');

  if (config.style === 'round') {
    // Circular Seal Stamp
    const cx = w / 2;
    const cy = h / 2;
    const radius = Math.min(w, h) * 0.42;

    // Outer Circle
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.lineWidth = 6 * scale;
    ctx.strokeStyle = mainColor;
    ctx.stroke();

    // Inner Circle
    ctx.beginPath();
    ctx.arc(cx, cy, radius - 8 * scale, 0, Math.PI * 2);
    ctx.lineWidth = 2 * scale;
    ctx.strokeStyle = mainColor;
    ctx.stroke();

    // Text in center
    ctx.font = `bold ${22 * scale}px "Plus Jakarta Sans", sans-serif`;
    ctx.fillStyle = mainColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, cx, sub ? cy - 10 * scale : cy);

    if (sub) {
      ctx.font = `bold ${12 * scale}px "Courier New", monospace`;
      ctx.fillText(sub, cx, cy + 16 * scale);
    }
  } else if (config.style === 'oval') {
    // Oval Badge Stamp
    const cx = w / 2;
    const cy = h / 2;
    const rx = w * 0.42;
    const ry = h * 0.38;

    ctx.beginPath();
    ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
    ctx.lineWidth = 5 * scale;
    ctx.strokeStyle = mainColor;
    ctx.stroke();

    ctx.font = `bold ${24 * scale}px "Plus Jakarta Sans", sans-serif`;
    ctx.fillStyle = mainColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, cx, sub ? cy - 10 * scale : cy);

    if (sub) {
      ctx.font = `bold ${12 * scale}px monospace`;
      ctx.fillText(sub, cx, cy + 18 * scale);
    }
  } else {
    // Rectangular / Double-Box Stamp
    const pad = 12 * scale;
    const boxW = w - pad * 2;
    const boxH = h - pad * 2;

    // Outer border
    ctx.lineWidth = (config.style === 'double-box' ? 5 : 4) * scale;
    ctx.strokeStyle = mainColor;
    ctx.strokeRect(pad, pad, boxW, boxH);

    // Inner border if double-box
    if (config.style === 'double-box') {
      const innerGap = 6 * scale;
      ctx.lineWidth = 2 * scale;
      ctx.strokeRect(pad + innerGap, pad + innerGap, boxW - innerGap * 2, boxH - innerGap * 2);
    }

    // Main Stamp Text
    const fontSize = text.length > 12 ? 22 * scale : 28 * scale;
    ctx.font = `900 ${fontSize}px "Plus Jakarta Sans", "Arial Black", sans-serif`;
    ctx.fillStyle = mainColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, w / 2, sub ? h / 2 - 12 * scale : h / 2);

    if (sub) {
      ctx.font = `bold ${13 * scale}px "Courier New", monospace`;
      ctx.fillText(sub, w / 2, h / 2 + 18 * scale);
    }
  }

  ctx.restore();
  return canvas.toDataURL('image/png');
}

/**
 * Generates a high-res 300 DPI Data URL for Geometric Shapes
 */
export function generateShapePNG(config: ShapeConfig, canvasWidth = 300, canvasHeight = 200): string {
  const canvas = document.createElement('canvas');
  const scale = 2;
  const w = canvasWidth * scale;
  const h = canvasHeight * scale;
  canvas.width = w;
  canvas.height = h;

  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  ctx.clearRect(0, 0, w, h);

  const sw = (config.strokeWidth || 2) * scale;
  const strokeCol = config.strokeColor || '#3b82f6';
  const fillCol = config.fillColor || '#3b82f6';
  const opacity = config.fillOpacity !== undefined ? config.fillOpacity : 0.2;

  ctx.lineWidth = sw;
  ctx.strokeStyle = strokeCol;

  // Set dash pattern
  if (config.strokeStyle === 'dashed') {
    ctx.setLineDash([8 * scale, 4 * scale]);
  } else if (config.strokeStyle === 'dotted') {
    ctx.setLineDash([3 * scale, 3 * scale]);
  } else {
    ctx.setLineDash([]);
  }

  // Helper for RGBA fill
  ctx.save();
  ctx.globalAlpha = opacity;
  ctx.fillStyle = fillCol;

  const p = sw + 8 * scale; // padding
  const shapeW = w - p * 2;
  const shapeH = h - p * 2;

  ctx.beginPath();
  switch (config.shapeType) {
    case 'circle': {
      const cx = w / 2;
      const cy = h / 2;
      const rx = shapeW / 2;
      const ry = shapeH / 2;
      ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
      break;
    }
    case 'rounded-rect': {
      const r = Math.min(shapeW, shapeH) * 0.15;
      ctx.roundRect(p, p, shapeW, shapeH, r);
      break;
    }
    case 'line': {
      ctx.moveTo(p, h / 2);
      ctx.lineTo(w - p, h / 2);
      break;
    }
    case 'arrow': {
      const startX = p;
      const endX = w - p - 16 * scale;
      const cy = h / 2;
      ctx.moveTo(startX, cy);
      ctx.lineTo(endX, cy);
      // Arrowhead
      ctx.lineTo(endX, cy - 12 * scale);
      ctx.lineTo(w - p, cy);
      ctx.lineTo(endX, cy + 12 * scale);
      ctx.lineTo(endX, cy);
      break;
    }
    case 'double-arrow': {
      const startX = p + 16 * scale;
      const endX = w - p - 16 * scale;
      const cy = h / 2;
      // Left Arrowhead
      ctx.moveTo(p, cy);
      ctx.lineTo(startX, cy - 12 * scale);
      ctx.lineTo(startX, cy);
      // Shaft
      ctx.lineTo(endX, cy);
      // Right Arrowhead
      ctx.lineTo(endX, cy - 12 * scale);
      ctx.lineTo(w - p, cy);
      ctx.lineTo(endX, cy + 12 * scale);
      ctx.lineTo(endX, cy);
      ctx.lineTo(startX, cy);
      ctx.lineTo(startX, cy + 12 * scale);
      ctx.closePath();
      break;
    }
    case 'star': {
      const cx = w / 2;
      const cy = h / 2;
      const outerR = Math.min(shapeW, shapeH) / 2;
      const innerR = outerR * 0.4;
      for (let i = 0; i < 10; i++) {
        const r = i % 2 === 0 ? outerR : innerR;
        const angle = (i * Math.PI) / 5 - Math.PI / 2;
        const x = cx + r * Math.cos(angle);
        const y = cy + r * Math.sin(angle);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      break;
    }
    case 'speech-bubble': {
      const r = 16 * scale;
      const bh = shapeH * 0.8;
      ctx.roundRect(p, p, shapeW, bh, r);
      // Tail
      ctx.moveTo(p + shapeW * 0.2, p + bh);
      ctx.lineTo(p + shapeW * 0.1, h - p);
      ctx.lineTo(p + shapeW * 0.35, p + bh);
      break;
    }
    case 'checkmark': {
      ctx.moveTo(p + shapeW * 0.15, p + shapeH * 0.5);
      ctx.lineTo(p + shapeW * 0.4, p + shapeH * 0.85);
      ctx.lineTo(p + shapeW * 0.85, p + shapeH * 0.15);
      break;
    }
    case 'cross': {
      ctx.moveTo(p + shapeW * 0.2, p + shapeH * 0.2);
      ctx.lineTo(p + shapeW * 0.8, p + shapeH * 0.8);
      ctx.moveTo(p + shapeW * 0.8, p + shapeH * 0.2);
      ctx.lineTo(p + shapeW * 0.2, p + shapeH * 0.8);
      break;
    }
    case 'triangle': {
      ctx.moveTo(w / 2, p);
      ctx.lineTo(w - p, h - p);
      ctx.lineTo(p, h - p);
      ctx.closePath();
      break;
    }
    case 'rectangle':
    default: {
      ctx.rect(p, p, shapeW, shapeH);
      break;
    }
  }

  if (opacity > 0 && config.shapeType !== 'line' && config.shapeType !== 'checkmark' && config.shapeType !== 'cross') {
    ctx.fill();
  }
  ctx.restore();

  // Stroke shape
  ctx.stroke();

  return canvas.toDataURL('image/png');
}

/**
 * Generates a high-res Data URL for "Write Text Here" Floating Adjustable Text Box
 */
export function generateFloatingTextPNG(config: FloatingTextConfig, boxWidth = 280, boxHeight = 100): string {
  const canvas = document.createElement('canvas');
  const scale = 2;
  const w = boxWidth * scale;
  const h = boxHeight * scale;
  canvas.width = w;
  canvas.height = h;

  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  ctx.clearRect(0, 0, w, h);

  // Background
  if (config.bgColor && config.bgColor !== 'transparent') {
    ctx.save();
    ctx.globalAlpha = config.bgOpacity !== undefined ? config.bgOpacity : 1.0;
    ctx.fillStyle = config.bgColor;
    if (config.borderRadius > 0) {
      ctx.roundRect(0, 0, w, h, config.borderRadius * scale);
      ctx.fill();
    } else {
      ctx.fillRect(0, 0, w, h);
    }
    ctx.restore();
  }

  // Border
  if (config.borderStyle && config.borderStyle !== 'none' && config.borderWidth > 0) {
    ctx.lineWidth = config.borderWidth * scale;
    ctx.strokeStyle = config.borderColor || '#3b82f6';
    if (config.borderStyle === 'dashed') ctx.setLineDash([6 * scale, 4 * scale]);
    if (config.borderStyle === 'double') ctx.lineWidth = (config.borderWidth + 2) * scale;
    
    if (config.borderRadius > 0) {
      ctx.beginPath();
      ctx.roundRect(0, 0, w, h, config.borderRadius * scale);
      ctx.stroke();
    } else {
      ctx.strokeRect(0, 0, w, h);
    }
    ctx.setLineDash([]);
  }

  // Text Rendering
  const pad = (config.padding || 8) * scale;
  const fontStyle = `${config.italic ? 'italic ' : ''}${config.bold ? 'bold ' : ''}`;
  const fontSizePx = (config.fontSize || 16) * scale;
  const fontFamily = config.fontFamily || 'Plus Jakarta Sans';

  ctx.font = `${fontStyle}${fontSizePx}px "${fontFamily}", sans-serif`;
  ctx.fillStyle = config.textColor || '#000000';
  ctx.textBaseline = 'top';

  const text = config.text || 'Write Text Here...';
  const lines = text.split('\n');
  const lineHeight = fontSizePx * 1.3;

  lines.forEach((line, idx) => {
    let x = pad;
    if (config.alignment === 'center') {
      x = w / 2;
      ctx.textAlign = 'center';
    } else if (config.alignment === 'right') {
      x = w - pad;
      ctx.textAlign = 'right';
    } else {
      ctx.textAlign = 'left';
    }

    const y = pad + idx * lineHeight;
    if (y + fontSizePx <= h) {
      ctx.fillText(line, x, y);

      if (config.underline) {
        const textWidth = ctx.measureText(line).width;
        let startX = x;
        if (config.alignment === 'center') startX = x - textWidth / 2;
        if (config.alignment === 'right') startX = x - textWidth;

        ctx.beginPath();
        ctx.lineWidth = 2 * scale;
        ctx.strokeStyle = config.textColor || '#000000';
        ctx.moveTo(startX, y + fontSizePx + 2 * scale);
        ctx.lineTo(startX + textWidth, y + fontSizePx + 2 * scale);
        ctx.stroke();
      }
    }
  });

  return canvas.toDataURL('image/png');
}

/**
 * Generates Cursive Typed Signature PNG
 */
export function generateCursiveSignaturePNG(config: SignatureConfig): string {
  const canvas = document.createElement('canvas');
  const scale = 2;
  const w = 320 * scale;
  const h = 120 * scale;
  canvas.width = w;
  canvas.height = h;

  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  ctx.clearRect(0, 0, w, h);

  const text = config.text || config.signerName || 'Signature';
  const font = config.fontFamily || 'Dancing Script';
  const color = config.color || '#1e3a8a';

  // Signature line baseline
  ctx.beginPath();
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.4)';
  ctx.lineWidth = 1.5 * scale;
  ctx.setLineDash([4 * scale, 3 * scale]);
  ctx.moveTo(16 * scale, h - 28 * scale);
  ctx.lineTo(w - 16 * scale, h - 28 * scale);
  ctx.stroke();
  ctx.setLineDash([]);

  // Typed Cursive Signature
  ctx.font = `bold ${36 * scale}px "${font}", "Brush Script MT", cursive`;
  ctx.fillStyle = color;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.fillText(text, 24 * scale, h - 34 * scale);

  // Optional Date or Audit Stamp
  if (config.includeDate) {
    const dateStr = `Digitally Signed ${new Date().toISOString().split('T')[0]}`;
    ctx.font = `bold ${10 * scale}px monospace`;
    ctx.fillStyle = '#64748b';
    ctx.fillText(dateStr, 24 * scale, h - 10 * scale);
  }

  return canvas.toDataURL('image/png');
}
