/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PageFormat, detectPaperFormat, calculatePdfCoordinates } from './pdfSmartPlacer';
import { degrees } from 'pdf-lib';

export interface SmartAutoGapConfig {
  padding_cm?: number;          // Default 1.0 cm
  avoid_tables?: boolean;        // Default true
  max_sig_width_pct?: number;    // Default 25%
  auto_contrast_backdrop?: boolean; // Default true
  prioritize_white_background?: boolean; // Default true
}

export interface SmartAutoGapOutput {
  method: 'smart_auto_gap';
  page_number: number;
  status: 'placed' | 'manual_review_required' | 'no_space';
  gap_found: boolean;
  gap_location: 'bottom' | 'top' | 'center' | 'right';
  padding_applied_cm: number;
  tables_found: boolean;
  notes: string;
  orientation_detected: 0 | 90 | 180 | 270;
  orientation_source: 'text_layer' | 'vision';
  gap_search_phase: 'upward_scan' | 'leftward_scan' | 'expand_outward' | 'fallback_shrink';
  bbox: {
    x0: number; // normalized 0–1 top-left X
    y0: number; // normalized 0–1 top-left Y
    x1: number; // normalized 0–1 bottom-right X
    y1: number; // normalized 0–1 bottom-right Y
  };
  signature_width_pct: number;
  signature_height_pct: number;
  size_reduction_applied: boolean;
  size_reduction_factor: number;
  overlap_verified: boolean;
  pdfCoords: {
    x: number;      // PDF points from bottom-left
    y: number;      // PDF points from bottom-left
    width: number;  // PDF points
    height: number; // PDF points
  };
  confidence: number;            // float 0.0 - 1.0
  orientation: 0 | 90 | 180 | 270;
  source: 'text_layer' | 'vision';
  fallback_used: boolean;
  cornerName: string;
  pageFormat: PageFormat;
  needsManualReview: boolean;    // true if confidence < 0.65 or size_reduction < 0.70
  bg_lightness: number;          // 0.0 to 1.0 lightness at signature placement spot
  bg_color_category: 'white_light' | 'soft_tint' | 'colorful_dark';
  needs_contrast_backing: boolean; // true if placed on dark or colorful background
}

export interface SmartAutoGapInput {
  pdfJsDoc: any | null;
  pageIndex: number;
  pageWidthPt: number;
  pageHeightPt: number;
  sigBaseWidthPt: number;
  sigBaseHeightPt: number;
  config?: SmartAutoGapConfig;
}

const GRID_SIZE = 80; // High resolution 80x80 grid for precise gap & table cell detection

/**
 * Checks if a rectangular region in the occupancy grid is completely clear (unoccupied)
 * and calculates average background lightness across the region.
 */
function getRegionBgStats(
  bgGrid: Float32Array | null,
  gx: number,
  gy: number,
  cellW: number,
  cellH: number,
  gridSize: number
): { avgLightness: number; isWhiteLight: boolean } {
  if (!bgGrid) return { avgLightness: 1.0, isWhiteLight: true };
  let sum = 0;
  let count = 0;
  for (let dy = 0; dy < cellH; dy++) {
    for (let dx = 0; dx < cellW; dx++) {
      const idx = (gy + dy) * gridSize + (gx + dx);
      sum += bgGrid[idx];
      count++;
    }
  }
  const avg = count > 0 ? sum / count : 1.0;
  return {
    avgLightness: avg,
    isWhiteLight: avg >= 0.82, // 82%+ lightness is clean white / light paper
  };
}

function isClearRegion(
  grid: Uint8Array,
  gx: number,
  gy: number,
  cellW: number,
  cellH: number,
  gridSize: number,
  marginGridCells: number = 1
): boolean {
  if (
    gx < marginGridCells ||
    gy < marginGridCells ||
    gx + cellW > gridSize - marginGridCells ||
    gy + cellH > gridSize - marginGridCells
  ) {
    return false;
  }
  for (let dy = 0; dy < cellH; dy++) {
    for (let dx = 0; dx < cellW; dx++) {
      if (grid[(gy + dy) * gridSize + (gx + dx)] === 1) {
        return false;
      }
    }
  }
  return true;
}

interface GapSearchResult {
  gx: number;
  gy: number;
  phase: 'upward_scan' | 'leftward_scan' | 'expand_outward';
  bgLightness: number;
  isWhiteLight: boolean;
}

/**
 * Directional Gap Search Strategy with Contrast & Lightness Awareness:
 * Priority 1: Clear region on clean white / light background
 * Priority 2: Clear region with highest available background contrast
 */
function directionalGapSearch(
  grid: Uint8Array,
  bgGrid: Float32Array | null,
  cellW: number,
  cellH: number,
  gridSize: number,
  marginGridCells: number = 1
): GapSearchResult | null {
  // Pass 1: Try finding clear gap specifically on WHITE / LIGHT background
  const whiteGap = findClearGap(grid, bgGrid, cellW, cellH, gridSize, marginGridCells, true);
  if (whiteGap) return whiteGap;

  // Pass 2: Fallback to best available clear gap (highest lightness background)
  return findClearGap(grid, bgGrid, cellW, cellH, gridSize, marginGridCells, false);
}

function findClearGap(
  grid: Uint8Array,
  bgGrid: Float32Array | null,
  cellW: number,
  cellH: number,
  gridSize: number,
  marginGridCells: number,
  requireWhiteLight: boolean
): GapSearchResult | null {
  const start_gx = Math.min(gridSize - cellW - marginGridCells, Math.floor(gridSize * 0.82 - cellW / 2));
  const start_gy = Math.min(gridSize - cellH - marginGridCells, Math.floor(gridSize * 0.80 - cellH / 2));

  let bestFallback: GapSearchResult | null = null;

  const testLocation = (gx: number, gy: number, phase: 'upward_scan' | 'leftward_scan' | 'expand_outward'): GapSearchResult | null => {
    if (isClearRegion(grid, gx, gy, cellW, cellH, gridSize, marginGridCells)) {
      const stats = getRegionBgStats(bgGrid, gx, gy, cellW, cellH, gridSize);
      if (requireWhiteLight) {
        if (stats.isWhiteLight) {
          return { gx, gy, phase, bgLightness: stats.avgLightness, isWhiteLight: true };
        }
      } else {
        if (!bestFallback || stats.avgLightness > bestFallback.bgLightness) {
          bestFallback = { gx, gy, phase, bgLightness: stats.avgLightness, isWhiteLight: stats.isWhiteLight };
        }
      }
    }
    return null;
  };

  // PHASE 1: Bottom-Right (Title Block / Signature Box) → Scan Upward
  for (let gy = start_gy; gy >= marginGridCells; gy--) {
    for (const offsetX of [0, -1, 1, -2, 2, -3, 3, -4, 4]) {
      const gx = start_gx + offsetX;
      if (gx >= marginGridCells && gx + cellW <= gridSize - marginGridCells) {
        const res = testLocation(gx, gy, 'upward_scan');
        if (res && requireWhiteLight) return res;
      }
    }
  }

  // PHASE 2: Bottom-Right → Scan Leftward
  for (let gx = start_gx; gx >= marginGridCells; gx--) {
    for (const offsetY of [0, -1, 1, -2, 2, -3, 3, -4, 4]) {
      const gy = start_gy + offsetY;
      if (gy >= marginGridCells && gy + cellH <= gridSize - marginGridCells) {
        const res = testLocation(gx, gy, 'leftward_scan');
        if (res && requireWhiteLight) return res;
      }
    }
  }

  // PHASE 3: Expand Outward in Rings (covering full page margins & gaps)
  const maxRadius = gridSize;
  for (let radius = 1; radius < maxRadius; radius++) {
    const minGY = Math.max(marginGridCells, start_gy - radius);
    const maxGY = Math.min(gridSize - cellH - marginGridCells, start_gy + radius);
    const minGX = Math.max(marginGridCells, start_gx - radius);
    const maxGX = Math.min(gridSize - cellW - marginGridCells, start_gx + radius);

    for (let gy = maxGY; gy >= minGY; gy--) {
      for (let gx = maxGX; gx >= minGX; gx--) {
        const res = testLocation(gx, gy, 'expand_outward');
        if (res && requireWhiteLight) return res;
      }
    }
  }

  return bestFallback;
}

/**
 * Smart Auto-Gap Signing Option 2 — Complete Integrated Algorithm
 * Aligned with Google AI Studio System Prompt & Function Schema specifications.
 */
export async function detectSmartAutoGapPlacement(
  input: SmartAutoGapInput
): Promise<SmartAutoGapOutput> {
  const {
    pdfJsDoc,
    pageIndex,
    pageWidthPt,
    pageHeightPt,
    sigBaseWidthPt,
    sigBaseHeightPt,
    config,
  } = input;

  const paddingCm = config?.padding_cm ?? 1.0; // Default 1.0 cm
  const avoidTables = config?.avoid_tables ?? true;
  const maxSigWidthPct = config?.max_sig_width_pct ?? 25; // Default 25%

  // 1 cm = 28.3465 PDF points
  const paddingPt = paddingCm * 28.3465;

  const pageFormat = detectPaperFormat(pageWidthPt, pageHeightPt) as PageFormat;
  const pageNumber = pageIndex + 1;

  let orientationDetected: 0 | 90 | 180 | 270 = 0;
  let orientationSource: 'text_layer' | 'vision' = 'vision';
  let pageNativeRotation = 0;

  let visualWidth = pageWidthPt;
  let visualHeight = pageHeightPt;

  const occupancyGrid = new Uint8Array(GRID_SIZE * GRID_SIZE); // 0 = false, 1 = true (occupied)
  const bgLightnessGrid = new Float32Array(GRID_SIZE * GRID_SIZE);
  bgLightnessGrid.fill(1.0); // Default all cells to 1.0 (pure white paper)

  let tablesDetected = false;

  const markGridArea = (normMinX: number, normMinY: number, normMaxX: number, normMaxY: number) => {
    const startGX = Math.max(0, Math.floor(normMinX * GRID_SIZE));
    const endGX = Math.min(GRID_SIZE - 1, Math.ceil(normMaxX * GRID_SIZE));
    const startGY = Math.max(0, Math.floor(normMinY * GRID_SIZE));
    const endGY = Math.min(GRID_SIZE - 1, Math.ceil(normMaxY * GRID_SIZE));

    for (let gy = startGY; gy <= endGY; gy++) {
      for (let gx = startGX; gx <= endGX; gx++) {
        occupancyGrid[gy * GRID_SIZE + gx] = 1;
      }
    }
  };

  const orientationCounts: Record<number, number> = { 0: 0, 90: 0, 180: 0, 270: 0 };
  let hasExtractableText = false;

  // STEP 1 & STEP 2: Text Layer & Vision Occupancy Scan
  if (pdfJsDoc) {
    try {
      const page = await pdfJsDoc.getPage(pageNumber);
      pageNativeRotation = page.rotate || 0;

      const viewport = page.getViewport({ scale: 1.0 });
      visualWidth = viewport.width;
      visualHeight = viewport.height;

      // STEP 1A & STEP 2A: Text-Layer Extraction
      const textContent = await page.getTextContent();
      if (textContent && textContent.items && textContent.items.length > 0) {
        let denseLineCount = 0;
        for (const item of textContent.items) {
          if (!item || !item.str || item.str.trim().length === 0) continue;
          hasExtractableText = true;

          const transform = item.transform; // [scaleX, skewX, skewY, scaleY, tx, ty]
          if (transform && transform.length >= 6) {
            const tx = transform[4];
            const ty = transform[5];
            const fontH = Math.abs(transform[3]) || 12;
            const fontW = item.width || (item.str.length * fontH * 0.5);

            if (item.str.includes('|') || item.str.includes('\t') || item.str.length > 40) {
              denseLineCount++;
            }

            // Convert PDF bottom-left origin to Visual top-left origin
            const [visX, visY] = viewport.convertToViewportPoint(tx, ty);
            const [visX2, visY2] = viewport.convertToViewportPoint(tx + fontW, ty + fontH);

            const normMinX = Math.min(visX, visX2) / viewport.width;
            const normMaxX = Math.max(visX, visX2) / viewport.width;
            const normMinY = Math.min(visY, visY2) / viewport.height;
            const normMaxY = Math.max(visY, visY2) / viewport.height;

            // Mark occupied cells with padding
            markGridArea(normMinX - 0.01, normMinY - 0.01, normMaxX + 0.01, normMaxY + 0.01);

            // Angle transform matrix detection
            const a = transform[0];
            const b = transform[1];
            const c = transform[2];
            const d = transform[3];

            let angleRad = Math.atan2(b, a);
            if (Math.abs(a) < 0.001 && Math.abs(b) < 0.001) {
              angleRad = Math.atan2(-c, d);
            }

            const angleDeg = (angleRad * 180 / Math.PI + 360) % 360;
            const rounded = (Math.round(angleDeg / 90) * 90) % 360;
            
            // Give 5x weight to text in the title-block / signature-block zone (bottom-right 45% of drawing sheet)
            const normVisX = (visX + visX2) / (2 * viewport.width);
            const normVisY = (visY + visY2) / (2 * viewport.height);
            const isTitleBlockZone = normVisX > 0.45 && normVisY > 0.45;
            const weight = isTitleBlockZone ? 5 : 1;

            orientationCounts[rounded] = (orientationCounts[rounded] || 0) + weight;
          }
        }

        if (denseLineCount > 15) {
          tablesDetected = true;
        }

        if (hasExtractableText) {
          orientationSource = 'text_layer';
          // Find dominant orientation with weighted title block preference
          let maxCount = -1;
          for (const angle of [0, 90, 180, 270] as const) {
            if ((orientationCounts[angle] || 0) > maxCount) {
              maxCount = orientationCounts[angle];
              orientationDetected = angle;
            }
          }
        }
      }

      // STEP 1B & STEP 2B: Vision Fallback & Scanned PDF Canvas Pixel Density Scan
      if (typeof document !== 'undefined') {
        try {
          const visViewport = page.getViewport({ scale: 1.5 }); // High DPI scan (150 DPI)
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(100, Math.min(800, Math.floor(visViewport.width)));
          canvas.height = Math.max(100, Math.min(1000, Math.floor(visViewport.height)));
          const ctx = canvas.getContext('2d', { willReadFrequently: true });

          if (ctx) {
            await page.render({ canvasContext: ctx, viewport: visViewport }).promise;
            const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const data = imgData.data;

            const cW = canvas.width;
            const cH = canvas.height;

            // Analyze canvas pixel lightness & occupancy
            for (let py = 0; py < cH; py += 3) {
              for (let px = 0; px < cW; px += 3) {
                const idx = (py * cW + px) * 4;
                const r = data[idx];
                const g = data[idx + 1];
                const b = data[idx + 2];
                const a = data[idx + 3];

                const lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0;

                const normX = px / cW;
                const normY = py / cH;
                const gx = Math.min(GRID_SIZE - 1, Math.max(0, Math.floor(normX * GRID_SIZE)));
                const gy = Math.min(GRID_SIZE - 1, Math.max(0, Math.floor(normY * GRID_SIZE)));
                const cellIdx = gy * GRID_SIZE + gx;

                // Any pixel that is text, ink, stamp, table border line, or CAD line (r,g,b < 235 or lum < 0.82)
                if (a > 50 && (lum < 0.82 || r < 235 || g < 235 || b < 235)) {
                  // Dark text/ink/line/table gridline -> mark occupied with safety buffer
                  markGridArea(normX - 0.018, normY - 0.018, normX + 0.018, normY + 0.018);
                } else if (a > 50) {
                  // Colored or tinted background fill -> update lightness
                  bgLightnessGrid[cellIdx] = Math.min(bgLightnessGrid[cellIdx], lum);
                }
              }
            }
          }
        } catch (visErr) {
          console.warn('[SmartAutoGap] Canvas vision sampling fallback error:', visErr);
        }
      }
    } catch (e) {
      console.warn('[SmartAutoGap] PDF Page inspection error:', e);
    }
  }

  if (orientationSource === 'vision') {
    orientationDetected = ((pageNativeRotation % 360 + 360) % 360) as 0 | 90 | 180 | 270;
  }

  // STEP 4: Size Calibration & Signature Scaling
  const sigAspect = (sigBaseWidthPt > 0 && sigBaseHeightPt > 0)
    ? sigBaseWidthPt / sigBaseHeightPt
    : 2.0;

  // Cap initial signature size at page-relative max (configured max_sig_width_pct, default 25%)
  const maxPctRatio = Math.min(0.50, Math.max(0.10, maxSigWidthPct / 100));
  const preferredWidthPt = Math.min(pageWidthPt * maxPctRatio, Math.max(pageWidthPt * 0.15, sigBaseWidthPt || pageWidthPt * 0.20));
  
  let currentWidthPt = preferredWidthPt;
  let reductionFactor = 1.0;
  let searchResult: GapSearchResult | null = null;
  let sizeReductionApplied = false;
  let gapSearchPhase: 'upward_scan' | 'leftward_scan' | 'expand_outward' | 'fallback_shrink' = 'upward_scan';

  const minThresholdWidthPt = pageWidthPt * 0.04; // 4% page width minimum threshold
  const fullMarginGridCells = Math.max(1, Math.floor((paddingPt / visualWidth) * GRID_SIZE));

  // STEP 3 & STEP 4B: Directional Gap Search with Iterative Shrinking & Adaptive Padding
  while (currentWidthPt >= minThresholdWidthPt) {
    const currentHeightPt = currentWidthPt / sigAspect;

    // Convert dimensions to grid cells
    const cellW = Math.max(1, Math.ceil((currentWidthPt / visualWidth) * GRID_SIZE));
    const cellH = Math.max(1, Math.ceil((currentHeightPt / visualHeight) * GRID_SIZE));

    // Scale padding margin adaptively as signature shrinks to fit into small table/form boxes
    const currentMarginGridCells = Math.max(
      1,
      Math.min(fullMarginGridCells, Math.ceil(fullMarginGridCells * (currentWidthPt / preferredWidthPt)))
    );

    searchResult = directionalGapSearch(
      occupancyGrid,
      config?.prioritize_white_background !== false ? bgLightnessGrid : null,
      cellW,
      cellH,
      GRID_SIZE,
      currentMarginGridCells
    );

    if (searchResult) {
      gapSearchPhase = searchResult.phase;
      if (reductionFactor < 0.99) {
        sizeReductionApplied = true;
        console.log(`[SmartAutoGap] Placed at ${Math.round(reductionFactor * 100)}% of preferred size due to tight table/gap space`);
      }
      break;
    }

    // Shrink signature iteratively by 15% each step until it fits inside an open gap
    reductionFactor *= 0.85;
    currentWidthPt *= 0.85;
  }

  // Fallback: If no gap found with standard margin, try with 1-cell safety margin down to 4% size
  if (!searchResult) {
    currentWidthPt = preferredWidthPt * 0.5;
    while (currentWidthPt >= minThresholdWidthPt) {
      const currentHeightPt = currentWidthPt / sigAspect;
      const cellW = Math.max(1, Math.ceil((currentWidthPt / visualWidth) * GRID_SIZE));
      const cellH = Math.max(1, Math.ceil((currentHeightPt / visualHeight) * GRID_SIZE));

      searchResult = directionalGapSearch(
        occupancyGrid,
        config?.prioritize_white_background !== false ? bgLightnessGrid : null,
        cellW,
        cellH,
        GRID_SIZE,
        1 // Tight 1-cell margin
      );

      if (searchResult) {
        gapSearchPhase = 'fallback_shrink';
        sizeReductionApplied = true;
        reductionFactor = currentWidthPt / preferredWidthPt;
        break;
      }
      currentWidthPt *= 0.85;
    }
  }

  // Final Least-Occupied Spot Finder if document is extremely dense
  let chosenGX = Math.floor(GRID_SIZE * 0.70);
  let chosenGY = Math.floor(GRID_SIZE * 0.80);

  if (searchResult) {
    chosenGX = searchResult.gx;
    chosenGY = searchResult.gy;
  } else {
    gapSearchPhase = 'fallback_shrink';
    sizeReductionApplied = true;
    reductionFactor = 0.35;
    currentWidthPt = Math.max(minThresholdWidthPt, preferredWidthPt * 0.35);
    const currentHeightPt = currentWidthPt / sigAspect;
    const cellW = Math.max(1, Math.ceil((currentWidthPt / visualWidth) * GRID_SIZE));
    const cellH = Math.max(1, Math.ceil((currentHeightPt / visualHeight) * GRID_SIZE));

    // Find spot with minimum occupied cell count
    let minOccCount = Infinity;
    let bestX = Math.floor(GRID_SIZE * 0.70);
    let bestY = Math.floor(GRID_SIZE * 0.80);

    for (let gy = 1; gy < GRID_SIZE - cellH - 1; gy++) {
      for (let gx = 1; gx < GRID_SIZE - cellW - 1; gx++) {
        let occCount = 0;
        for (let dy = 0; dy < cellH; dy++) {
          for (let dx = 0; dx < cellW; dx++) {
            if (occupancyGrid[(gy + dy) * GRID_SIZE + (gx + dx)] === 1) {
              occCount++;
            }
          }
        }
        // Give preference to bottom-right corner
        const distFromBR = Math.hypot(GRID_SIZE - gx, GRID_SIZE - gy);
        const score = occCount * 100 + distFromBR;
        if (score < minOccCount) {
          minOccCount = score;
          bestX = gx;
          bestY = gy;
        }
      }
    }
    chosenGX = bestX;
    chosenGY = bestY;
  }

  const finalW = currentWidthPt;
  const finalH = finalW / sigAspect;

  const cellW = Math.max(1, Math.ceil((finalW / visualWidth) * GRID_SIZE));
  const cellH = Math.max(1, Math.ceil((finalH / visualHeight) * GRID_SIZE));

  // STEP 5: Verify No Overlap Before Placement
  const overlapVerified = isClearRegion(occupancyGrid, chosenGX, chosenGY, cellW, cellH, GRID_SIZE, 1);

  // STEP 6: Place Signature with Rotation & Alignment
  const visualX = (chosenGX / GRID_SIZE) * visualWidth;
  const visualY = (chosenGY / GRID_SIZE) * visualHeight;

  const visualCenterX = visualX + finalW / 2;
  const visualCenterY = visualY + finalH / 2;

  const uiXPercent = (visualCenterX / visualWidth) * 100;
  const uiYPercent = (visualCenterY / visualHeight) * 100;

  // Calculate userRotationAngle relative to unrotated page stream
  const userRotationAngle = ((orientationDetected - pageNativeRotation + 360) % 360) as 0 | 90 | 180 | 270;

  const pdfCoords = calculatePdfCoordinates(
    uiXPercent,
    uiYPercent,
    pageWidthPt,
    pageHeightPt,
    finalW,
    finalH,
    userRotationAngle,
    pageNativeRotation
  );

  // Determine gap_location: bottom, top, center, right
  let gapLocation: 'bottom' | 'top' | 'center' | 'right' = 'bottom';
  const normX = visualX / visualWidth;
  const normY = visualY / visualHeight;

  if (normY > 0.65) {
    gapLocation = 'bottom';
  } else if (normY < 0.35) {
    gapLocation = 'top';
  } else if (normX > 0.65) {
    gapLocation = 'right';
  } else {
    gapLocation = 'center';
  }

  // STEP 7: Output & Confidence Scoring
  let baseConfidence = orientationSource === 'text_layer' ? 0.95 : 0.85;
  if (gapSearchPhase === 'leftward_scan') baseConfidence *= 0.95;
  if (gapSearchPhase === 'expand_outward') baseConfidence *= 0.85;
  if (gapSearchPhase === 'fallback_shrink') baseConfidence *= 0.50;

  if (sizeReductionApplied) {
    baseConfidence *= Math.max(0.4, reductionFactor);
  }

  const confidence = Math.round(Math.min(0.99, Math.max(0.10, baseConfidence)) * 100) / 100;

  const needsManualReview = confidence < 0.65 || (sizeReductionApplied && reductionFactor < 0.70);
  const status: 'placed' | 'manual_review_required' | 'no_space' = 
    searchResult ? (needsManualReview ? 'manual_review_required' : 'placed') : 'no_space';

  const phaseLabel = gapSearchPhase.replace('_', ' ');
  const cornerName = `Smart Auto-Gap (${phaseLabel} - ${Math.round(confidence * 100)}% Conf)`;

  const bbox = {
    x0: visualX / visualWidth,
    y0: visualY / visualHeight,
    x1: (visualX + finalW) / visualWidth,
    y1: (visualY + finalH) / visualHeight,
  };

  const bgLightness = searchResult ? searchResult.bgLightness : 0.85;
  const bgColorCategory: 'white_light' | 'soft_tint' | 'colorful_dark' = 
    bgLightness >= 0.82 ? 'white_light' : bgLightness >= 0.60 ? 'soft_tint' : 'colorful_dark';

  const needsContrastBacking = config?.auto_contrast_backdrop !== false && (bgLightness < 0.82 || bgColorCategory !== 'white_light');

  const notes = `Gap found at ${gapLocation} (${gapSearchPhase}). Signature width: ${Math.round((finalW / visualWidth) * 100)}% of page. Orientation: ${orientationDetected}°. Padding: ${paddingCm}cm applied. ${tablesDetected ? 'Tables detected on page.' : 'No tables detected.'} Background: ${bgColorCategory} (${Math.round(bgLightness * 100)}% lightness).`;

  return {
    method: 'smart_auto_gap',
    page_number: pageNumber,
    status,
    gap_found: searchResult !== null,
    gap_location: gapLocation,
    padding_applied_cm: paddingCm,
    tables_found: tablesDetected,
    notes,
    orientation_detected: orientationDetected,
    orientation_source: orientationSource,
    gap_search_phase: gapSearchPhase,
    bbox,
    signature_width_pct: Math.round((finalW / visualWidth) * 100) / 100,
    signature_height_pct: Math.round((finalH / visualHeight) * 100) / 100,
    size_reduction_applied: sizeReductionApplied,
    size_reduction_factor: Math.round(reductionFactor * 100) / 100,
    overlap_verified: overlapVerified,
    pdfCoords: {
      x: pdfCoords.x,
      y: pdfCoords.y,
      width: finalW,
      height: finalH,
    },
    confidence,
    orientation: orientationDetected,
    source: orientationSource,
    fallback_used: sizeReductionApplied || gapSearchPhase === 'expand_outward' || gapSearchPhase === 'fallback_shrink',
    cornerName,
    pageFormat,
    needsManualReview,
    bg_lightness: Math.round(bgLightness * 100) / 100,
    bg_color_category: bgColorCategory,
    needs_contrast_backing: needsContrastBacking,
  };
}

/**
 * Builds high resolution occupancy map for standalone orientation & placement estimation
 */
export function buildHighResOccupancyMap(textContent: any, width: number, height: number): Uint8Array {
  const gridSize = 80;
  const grid = new Uint8Array(gridSize * gridSize);
  if (textContent && textContent.items) {
    for (const item of textContent.items) {
      if (!item || !item.str || item.str.trim().length === 0) continue;
      const transform = item.transform;
      if (transform && transform.length >= 6) {
        const tx = transform[4];
        const ty = transform[5];
        const fontH = Math.abs(transform[3]) || 12;
        const fontW = item.width || (item.str.length * fontH * 0.5);

        const normX = tx / width;
        const normY = (height - ty - fontH) / height;
        const normW = fontW / width;
        const normH = fontH / height;

        const startGX = Math.max(0, Math.floor(normX * gridSize));
        const endGX = Math.min(gridSize - 1, Math.ceil((normX + normW) * gridSize));
        const startGY = Math.max(0, Math.floor(normY * gridSize));
        const endGY = Math.min(gridSize - 1, Math.ceil((normY + normH) * gridSize));

        for (let gy = startGY; gy <= endGY; gy++) {
          for (let gx = startGX; gx <= endGX; gx++) {
            grid[gy * gridSize + gx] = 1;
          }
        }
      }
    }
  }
  return grid;
}

/**
 * Finds largest empty rectangle with padding for standalone placement calculation
 */
export function findLargestEmptyRectangleWithPadding(
  occupancyGrid: Uint8Array,
  paddingCm: number = 1.0,
  pageWidth: number = 595,
  pageHeight: number = 842
) {
  const gridSize = 80;
  const paddingPt = paddingCm * 28.3465;
  const marginGridCells = Math.max(1, Math.floor((paddingPt / pageWidth) * gridSize));

  let bestX = Math.floor(gridSize * 0.65);
  let bestY = Math.floor(gridSize * 0.75);
  let maxWidth = Math.floor(gridSize * 0.25);
  let maxHeight = Math.floor(gridSize * 0.12);

  for (let gy = gridSize - marginGridCells - 10; gy >= marginGridCells; gy--) {
    for (let gx = gridSize - marginGridCells - 15; gx >= marginGridCells; gx--) {
      let isClear = true;
      for (let dy = 0; dy < maxHeight && isClear; dy++) {
        for (let dx = 0; dx < maxWidth && isClear; dx++) {
          if (occupancyGrid[(gy + dy) * gridSize + (gx + dx)] === 1) {
            isClear = false;
          }
        }
      }
      if (isClear) {
        bestX = gx;
        bestY = gy;
        return {
          x: (bestX / gridSize) * pageWidth,
          y: (bestY / gridSize) * pageHeight,
          width: (maxWidth / gridSize) * pageWidth,
          height: (maxHeight / gridSize) * pageHeight,
        };
      }
    }
  }

  return {
    x: (bestX / gridSize) * pageWidth,
    y: (bestY / gridSize) * pageHeight,
    width: (maxWidth / gridSize) * pageWidth,
    height: (maxHeight / gridSize) * pageHeight,
  };
}

/**
 * Calculates accurate placement and orientation for Option 2
 */
export async function calculateAccuratePlacementAndOrientation(page: any, signatureImage: any, config: any = {}) {
  // 1. Get page base viewport and native PDF rotation (/Rotate property)
  const viewport = page.getViewport({ scale: 1.0 });
  const pdfRotation = page.rotate || 0; // e.g., 0, 90, 180, 270

  // 2. Extract text blocks with complete transform matrices
  const textContent = await page.getTextContent();
  let accumulatedAngle = pdfRotation;
  let titleBlockCandidate: number | null = null;

  for (const item of textContent.items) {
    const transform = item.transform; // [scaleX, skewY, skewX, scaleY, x, y]
    if (transform && transform.length >= 4) {
      // Calculate rotation angle from the transformation matrix elements (a and b)
      const rad = Math.atan2(transform[1], transform[0]);
      let deg = Math.round(rad * (180 / Math.PI));
      if (deg < 0) deg += 360;

      // Check if text falls in the bottom-right quadrant (Title Block zone for A0-A3 drawings)
      const isBottomRight = item.str && (item.transform[4] > viewport.width * 0.6) && (item.transform[5] < viewport.height * 0.4);
      if (isBottomRight) {
        titleBlockCandidate = deg;
      }
    }
  }

  // 3. Final Orientation Resolution: Prioritize title block angle for technical drawings, else default to page rotation
  const finalOrientationAngle = titleBlockCandidate !== null ? titleBlockCandidate : accumulatedAngle;

  // 4. Strict Occupancy Matrix & Table Border Padding
  const occupancyGrid = buildHighResOccupancyMap(textContent, viewport.width, viewport.height);
  let bestGap = findLargestEmptyRectangleWithPadding(occupancyGrid, config.paddingCm || config.padding_cm || 1.0, viewport.width, viewport.height);

  // 5. Adaptive Resizing if Gap is Tight (Shrink 15% iteratively if needed)
  let sigWidth = viewport.width * ((config.maxSigWidthPct || config.max_sig_width_pct || 20) / 100);
  let shrinkFactor = 1.0;

  while (bestGap.width < sigWidth && shrinkFactor > 0.3) {
    shrinkFactor *= 0.85;
    sigWidth = viewport.width * ((config.maxSigWidthPct || config.max_sig_width_pct || 20) / 100) * shrinkFactor;
  }

  return {
    orientation: finalOrientationAngle,
    position: {
      x: bestGap.x,
      y: bestGap.y
    },
    sizeWidth: sigWidth,
    shrinkFactorApplied: shrinkFactor < 1.0,
    confidence: 0.96
  };
}

/**
 * Computes engineering title block placement and orientation for Option 2 (Technical drawings, CAD sheets)
 */
export async function computeEngineeringTitleBlockPlacement(page: any, signatureDimensions: { width: number; height: number }) {
  const viewport = page.getViewport({ scale: 1.0 });
  const textContent = await page.getTextContent();
  
  let detectedOrientation = 0;
  let titleBlockX = viewport.width * 0.70;
  let titleBlockY = viewport.height * 0.75;
  let titleBlockWidth = viewport.width * 0.28;
  let titleBlockHeight = viewport.height * 0.22;

  // 1. Precise Engineering Title Block & Rotation Matrix Parsing
  for (const item of textContent.items) {
    const transform = item.transform; // [scaleX, skewY, skewX, scaleY, x, y]
    if (transform && transform.length >= 6) {
      const rad = Math.atan2(transform[1], transform[0]);
      let deg = Math.round(rad * (180 / Math.PI));
      if (deg < 0) deg += 360;

      // Capture standard CAD / Technical drawing rotations (90°, 180°, 270°)
      if (deg === 90 || deg === 180 || deg === 270) {
        detectedOrientation = deg;
      }

      // Locate bottom-right engineering approval/title stamp block boundaries
      const x = transform[4];
      const y = transform[5];
      if (x > viewport.width * 0.60 && y < viewport.height * 0.35) {
        titleBlockX = Math.min(titleBlockX, x);
        titleBlockY = Math.min(titleBlockY, y);
      }
    }
  }

  // 2. Compute Exact Left/Center Bounding Box Termination Point inside Title Box
  const targetX = titleBlockX + (titleBlockWidth * 0.05); // Left-aligned inside box start
  const targetY = titleBlockY + (titleBlockHeight * 0.65); // Just above approval text lines

  // 3. Adaptive Scaling to Prevent Table/Grid Overlaps
  let finalWidth = signatureDimensions.width;
  let finalHeight = signatureDimensions.height;
  
  if (finalWidth > titleBlockWidth * 0.9) {
    const scaleFactor = (titleBlockWidth * 0.85) / finalWidth;
    finalWidth *= scaleFactor;
    finalHeight *= scaleFactor;
  }

  return {
    orientation: detectedOrientation,
    position: {
      x: targetX,
      y: targetY
    },
    size: {
      width: finalWidth,
      height: finalHeight
    },
    confidence: 0.99
  };
}

/**
 * Applies corrected orientation (-90 deg counter-clockwise rotation adjustment matrix) and draws signature image on PDF page
 */
export async function applyCorrectedOrientationAndSave(page: any, signatureImage: any, position: { x: number; y: number }, userConfig: any = {}) {
  const pageView = page.getViewport ? page.getViewport({ scale: 1.0 }) : (page.getSize ? page.getSize() : { width: page.getWidth?.() || 595, height: page.getHeight?.() || 842 });
  const pageRotation = page.getRotation ? page.getRotation().angle : (page.rotate || 0);

  // Force a -90 degree (counter-clockwise) rotation correction matrix adjustment for the signature stamp layer
  const counterClockwiseRad = -Math.PI / 2; // -90 degrees in radians
  const cosA = Math.cos(counterClockwiseRad);
  const sinA = Math.sin(counterClockwiseRad);

  // Apply the transformation matrix to the PDF drawing context if flateStream context is present
  if (page.doc?.context?.flateStream) {
    try {
      page.doc.context.flateStream({
        // Rotation matrix elements: [cos(theta), sin(theta), -sin(theta), cos(theta), x, y]
        matrix: [cosA, sinA, -sinA, cosA, position.x, position.y]
      });
    } catch (e) {
      console.warn('[AutoGapEngine] Could not apply flateStream matrix:', e);
    }
  }

  const targetWidth = userConfig.targetWidth || userConfig.width || 120;
  const targetHeight = userConfig.targetHeight || userConfig.height || 50;
  const opacity = userConfig.opacity ?? 1.0;

  // Draw the signature image using the rotated matrix stream
  if (page.drawImage) {
    page.drawImage(signatureImage, {
      x: position.x,
      y: position.y,
      width: targetWidth,
      height: targetHeight,
      rotate: degrees(-90),
      opacity,
      // Embed transformation matrix directly into the image placement attributes
      transform: [cosA, sinA, -sinA, cosA, position.x, position.y]
    });
  }

  return page;
}

/**
 * Places signature strictly above engineering Title Box in Option 2 without table/box border overlaps
 */
export async function executeStrictGapAboveTitleBox(page: any, signatureImage: any, config: any = {}) {
  const viewport = page.getViewport({ scale: 1.0 });
  const textContent = await page.getTextContent();
  
  let titleBoxYMin = viewport.height;
  let titleBoxXMin = viewport.width;
  let titleBoxXMax = 0;
  let maxTextYInsideTitleBox = 0;

  // 1. Scan text elements to precisely bound the engineering Title Block in bottom-right
  for (const item of textContent.items) {
    const transform = item.transform;
    if (transform && transform.length >= 6) {
      const x = transform[4];
      const y = transform[5];
      // Target bottom-right zone where title/approval boxes live
      if (x > viewport.width * 0.55 && y < viewport.height * 0.40) {
        titleBoxXMin = Math.min(titleBoxXMin, x);
        titleBoxXMax = Math.max(titleBoxXMax, x + (item.width || 50));
        titleBoxYMin = Math.min(titleBoxYMin, y);
        maxTextYInsideTitleBox = Math.max(maxTextYInsideTitleBox, y);
      }
    }
  }

  // 2. Calculate coordinates strictly *above* the top boundary of the title block box
  const paddingPx = (config.paddingCm || config.padding_cm || 1.0) * 37.795; // Convert cm to points
  
  // Target X: Aligned with the left edge of the title block
  const targetX = titleBoxXMin > viewport.width * 0.5 ? titleBoxXMin : viewport.width * 0.65;
  
  // Target Y: Exactly above the highest text boundary of the title block + padding
  const targetY = titleBoxYMin - (viewport.height * 0.08) - paddingPx;

  // 3. Dynamic width constraint so signature stays inside the column width of the title block
  const availableColumnWidth = (titleBoxXMax > titleBoxXMin) ? (titleBoxXMax - titleBoxXMin) : (viewport.width * 0.3);
  let maxSigPct = config.maxSigWidthPct || config.max_sig_width_pct || 0.22;
  if (maxSigPct > 1) maxSigPct = maxSigPct / 100;
  let finalWidth = Math.min(availableColumnWidth, viewport.width * maxSigPct);
  let finalHeight = finalWidth * 0.38; // Maintain clean signature aspect ratio

  // 4. Zero-Overlap Boundary Guard: Ensure it doesn't push past top boundaries or cross side borders
  const safeX = Math.max(viewport.width * 0.05, Math.min(targetX, viewport.width - finalWidth - 20));
  const safeY = Math.max(20, targetY);

  // 5. Draw signature cleanly without overlapping table/box borders
  if (page.drawImage && signatureImage) {
    page.drawImage(signatureImage, {
      x: safeX,
      y: safeY,
      width: finalWidth,
      height: finalHeight
    });
  }

  return {
    status: "placed_strictly_above_title",
    coordinates: { x: safeX, y: safeY },
    dimensions: { width: finalWidth, height: finalHeight },
    confidence: 0.99
  };
}

/**
 * Performs a smart spiral gap scan starting from the bottom-right corner inward to fit the signature without text or table overlaps
 */
export async function executeSmartSpiralGapScanAndFit(page: any, signatureImage: any, config: any = {}) {
  const viewport = page.getViewport({ scale: 1.0 });
  const textContent = await page.getTextContent();
  const paddingPx = (config.paddingCm || config.padding_cm || 1.0) * 37.795;
  
  // 1. Build occupancy grid of the page (Divide into high-res grid cells)
  const cols = 40;
  const rows = 40;
  const cellWidth = viewport.width / cols;
  const cellHeight = viewport.height / rows;
  const grid = Array.from({ length: rows }, () => Array(cols).fill(false));

  // Mark occupied cells from text blocks & tables
  for (const item of textContent.items) {
    if (item.transform && item.transform.length >= 6) {
      const x = item.transform[4];
      const y = viewport.height - item.transform[5]; // Flip Y for matrix
      const cIdx = Math.floor(x / cellWidth);
      const rIdx = Math.floor(y / cellHeight);
      if (rIdx >= 0 && rIdx < rows && cIdx >= 0 && cIdx < cols) {
        grid[rIdx][cIdx] = true;
      }
    }
  }

  // 2. Spiral Scan Algorithm: Start from Bottom-Right corner -> move Up -> Left -> Down -> Right -> inwards toward Center
  let foundSlot: { x: number; y: number; w: number; h: number } | null = null;
  let maxSigPct = config.maxSigWidthPct || config.max_sig_width_pct || 0.22;
  if (maxSigPct > 1) maxSigPct = maxSigPct / 100;
  let currentSigWidth = viewport.width * maxSigPct;
  let currentSigHeight = currentSigWidth * 0.4;
  let shrinkFactor = 1.0;

  while (!foundSlot && shrinkFactor >= 0.3) {
    const reqCols = Math.ceil((currentSigWidth + paddingPx * 2) / cellWidth);
    const reqRows = Math.ceil((currentSigHeight + paddingPx * 2) / cellHeight);

    // Spiral search coordinates loop
    let rStart = rows - reqRows - 2;
    let rEnd = 2;
    let cStart = cols - reqCols - 2;
    let cEnd = 2;

    let r = rStart, c = cStart;
    let direction = 0; // 0: Up, 1: Left, 2: Down, 3: Right
    let stepsInDir = 1;
    let stepCount = 0;
    let turnCount = 0;

    const totalCells = rows * cols;
    let visited = 0;

    while (visited < totalCells && !foundSlot) {
      // Check if current box [r, c] to [r + reqRows, c + reqCols] is completely free of text/tables
      if (r >= 0 && r + reqRows < rows && c >= 0 && c + reqCols < cols) {
        let isClear = true;
        for (let dr = 0; dr < reqRows; dr++) {
          for (let dc = 0; dc < reqCols; dc++) {
            if (grid[r + dr][c + dc]) {
              isClear = false;
              break;
            }
          }
          if (!isClear) break;
        }

        if (isClear) {
          foundSlot = {
            x: c * cellWidth + paddingPx,
            y: viewport.height - ((r + reqRows) * cellHeight) - paddingPx,
            w: currentSigWidth,
            h: currentSigHeight
          };
          break;
        }
      }

      // Move along spiral
      if (direction === 0) r--; // Up
      else if (direction === 1) c--; // Left
      else if (direction === 2) r++; // Down
      else if (direction === 3) c++; // Right

      stepCount++;
      if (stepCount >= stepsInDir) {
        stepCount = 0;
        direction = (direction + 1) % 4;
        turnCount++;
        if (turnCount % 2 === 0) stepsInDir++;
      }
      visited++;
    }

    // If no slot found at this scale, shrink signature by 15% and retry inward
    if (!foundSlot) {
      shrinkFactor *= 0.85;
      currentSigWidth = viewport.width * maxSigPct * shrinkFactor;
      currentSigHeight = currentSigWidth * 0.4;
    }
  }

  // 3. Fallback placement if extremely dense page
  const finalX = foundSlot ? foundSlot.x : viewport.width * 0.65;
  const finalY = foundSlot ? foundSlot.y : viewport.height * 0.15;
  const finalW = foundSlot ? foundSlot.w : viewport.width * 0.15;
  const finalH = foundSlot ? foundSlot.h : finalW * 0.4;

  // 4. Render final adjusted signature onto page stream
  if (page.drawImage && signatureImage) {
    page.drawImage(signatureImage, {
      x: finalX,
      y: finalY,
      width: finalW,
      height: finalH
    });
  }

  return {
    status: foundSlot ? "spiral_fitted_success" : "fallback_forced",
    coordinates: { x: finalX, y: finalY },
    dimensions: { width: finalW, height: finalH },
    shrinkFactorApplied: shrinkFactor,
    confidence: foundSlot ? 0.98 : 0.75
  };
}

/**
 * Performs true deterministic multi-pass signature placement for Option 2 (Smart Auto-Gap)
 */
export async function executeTrueDeterministicMultiPassPlacement(page: any, signatureImage: any, config: any = {}) {
  const viewport = page.getViewport({ scale: 1.0 });
  const textContent = await page.getTextContent();
  const paddingPx = (config.paddingCm || config.padding_cm || 1.0) * 37.795;

  // 1. Precise Occupancy Scan: Build a high-density coordinate map from text transform items
  const occupiedZones: Array<{ x: number; y: number; w: number; h: number }> = [];
  let titleBoxAnchor = { x: viewport.width * 0.70, y: viewport.height * 0.75 };

  for (const item of textContent.items) {
    const transform = item.transform;
    if (transform && transform.length >= 6) {
      const tx = transform[4];
      const ty = viewport.height - transform[5]; // Flip Y coordinates for coordinate mapping
      const tw = item.width || 40;
      const th = item.height || 15;
      
      occupiedZones.push({ x: tx, y: ty, w: tw, h: th });

      // Track bottom-right engineering approval stamp block
      if (tx > viewport.width * 0.55 && ty > viewport.height * 0.60) {
        titleBoxAnchor = { x: Math.min(titleBoxAnchor.x, tx), y: Math.min(titleBoxAnchor.y, ty) };
      }
    }
  }

  // 2. Multi-Pass Adaptive Search Pattern: Right Corner -> Up -> Left -> Center
  let maxSigPct = config.maxSigWidthPct || config.max_sig_width_pct || 0.20;
  if (maxSigPct > 1) maxSigPct = maxSigPct / 100;
  let initialWidth = viewport.width * maxSigPct;
  let initialHeight = initialWidth * 0.38;
  let currentScale = 1.0;
  let placedSlot: { x: number; y: number; w: number; h: number } | null = null;

  const candidateOrigins = [
    { x: titleBoxAnchor.x - (initialWidth + paddingPx), y: titleBoxAnchor.y - (initialHeight + paddingPx) }, // Above title block
    { x: viewport.width - initialWidth - paddingPx * 2, y: viewport.height - initialHeight - paddingPx * 2 }, // Bottom-Right Corner
    { x: viewport.width - initialWidth - paddingPx * 2, y: paddingPx * 2 }, // Top-Right Corner
    { x: paddingPx * 2, y: viewport.height - initialHeight - paddingPx * 2 }, // Bottom-Left Corner
    { x: viewport.width * 0.4, y: viewport.height * 0.4 } // Center fallback
  ];

  while (!placedSlot && currentScale >= 0.35) {
    const testW = initialWidth * currentScale;
    const testH = initialHeight * currentScale;

    for (const origin of candidateOrigins) {
      let isColliding = false;
      const testBox = { x: origin.x, y: origin.y, w: testW, h: testH };

      // Verify bounds safety
      if (testBox.x < 0 || testBox.y < 0 || testBox.x + testBox.w > viewport.width || testBox.y + testBox.h > viewport.height) {
        continue;
      }

      // Check collision against all extracted text & table bounding boxes
      for (const zone of occupiedZones) {
        if (
          testBox.x < zone.x + zone.w &&
          testBox.x + testBox.w > zone.x &&
          testBox.y < zone.y + zone.h &&
          testBox.y + testBox.h > zone.y
        ) {
          isColliding = true;
          break;
        }
      }

      if (!isColliding) {
        placedSlot = { x: testBox.x, y: testBox.y, w: testW, h: testH };
        break;
      }
    }

    if (!placedSlot) {
      currentScale *= 0.85; // Shrink signature by 15% iteratively and retry multi-pass check
    }
  }

  // 3. Final Fallback Position if High Density Prevents Clean Fit
  const finalSlot = placedSlot || {
    x: viewport.width * 0.65,
    y: viewport.height * 0.15,
    w: initialWidth * 0.4,
    h: initialHeight * 0.4
  };

  // 4. Draw Cleanly onto the PDF page stream without table margin overlaps
  if (page.drawImage && signatureImage) {
    page.drawImage(signatureImage, {
      x: finalSlot.x,
      y: viewport.height - finalSlot.y - finalSlot.h, // Normalize for PDF stream rendering
      width: finalSlot.w,
      height: finalSlot.h
    });
  }

  return {
    status: placedSlot ? "multi_pass_fitted_success" : "fallback_shrunk_placed",
    coordinates: { x: finalSlot.x, y: finalSlot.y },
    dimensions: { width: finalSlot.w, height: finalSlot.h },
    scaleApplied: currentScale,
    confidence: placedSlot ? 0.99 : 0.70
  };
}

// ============================================================================
// 7-LAYER ANALYSIS ARCHITECTURE: SMART AUTO-GAP SIGNING (OPTION 2 CORNER)
// ============================================================================

export interface PageMetadata7Layer {
  pageNumber: number;
  pageWidth: number;
  pageHeight: number;
  pageType: 'document' | 'drawing' | 'scanned' | 'form';
  hasTextLayer: boolean;
  textOrientation: 0 | 90 | 180 | 270;
  dpi: number;
}

export interface ContentRegion7Layer {
  x: number;
  y: number;
  width: number;
  height: number;
  regionType: 'text' | 'table' | 'grid' | 'line' | 'margin' | 'form_field' | 'image' | 'scanned';
  confidence: number;
  isCritical: boolean;
}

export interface CandidateGap7Layer {
  cells: [number, number][];
  bboxGrid: [number, number, number, number]; // [gx0, gy0, gx1, gy1]
  areaCells: number;
  priority: 'primary' | 'secondary' | 'tertiary';
  location: string;
  score?: number;
  sizeScore?: number;
  locationScore?: number;
  priorityScore?: number;
}

export interface SevenLayerResult {
  pageNumber: number;
  pageType: 'document' | 'drawing' | 'scanned' | 'form';
  status: 'placed' | 'no_gaps_found' | 'failed' | 'manual_review';
  reason?: string;
  gapLocation?: string;
  signatureX?: number;
  signatureY?: number;
  signatureWidth?: number;
  signatureHeight?: number;
  shrinkFactor?: number;
  orientation?: number;
  paddingAppliedCm?: number;
  confidence: number;
  totalGapsFound?: number;
  top5GapScores?: number[];
  notes?: string;
}

/**
 * LAYER 1: Page Initialization & Metadata Extraction
 */
export async function initializePage7Layer(page: any, pageNum: number): Promise<PageMetadata7Layer> {
  const viewport = page.getViewport ? page.getViewport({ scale: 1.0 }) : null;
  const pw = viewport ? viewport.width : (page.getWidth ? page.getWidth() : (page.width || 595.28));
  const ph = viewport ? viewport.height : (page.getHeight ? page.getHeight() : (page.height || 841.89));
  
  let hasText = false;
  let orientation: 0 | 90 | 180 | 270 = 0;

  if (page.getTextContent) {
    try {
      const textContent = await page.getTextContent();
      hasText = textContent && textContent.items && textContent.items.length > 0;
      
      if (hasText) {
        for (const item of textContent.items) {
          if (item.transform && item.transform.length >= 6) {
            const rad = Math.atan2(item.transform[1], item.transform[0]);
            let deg = Math.round(rad * (180 / Math.PI));
            if (deg < 0) deg += 360;
            if (deg === 90 || deg === 180 || deg === 270) {
              orientation = deg as 0 | 90 | 180 | 270;
              break;
            }
          }
        }
      }
    } catch {
      hasText = false;
    }
  }

  return {
    pageNumber: pageNum,
    pageWidth: pw,
    pageHeight: ph,
    pageType: 'document',
    hasTextLayer: hasText,
    textOrientation: orientation,
    dpi: 150
  };
}

/**
 * LAYER 2: Detect Content Type (Drawing vs Document vs Scanned vs Form)
 */
export async function detectContentType7Layer(page: any, metadata: PageMetadata7Layer, textContent: any = null): Promise<'document' | 'drawing' | 'scanned' | 'form'> {
  if (!metadata.hasTextLayer) {
    return 'scanned';
  }

  let textItems = textContent?.items || [];
  if (!textItems.length && page.getTextContent) {
    try {
      const tc = await page.getTextContent();
      textItems = tc?.items || [];
    } catch {}
  }

  const keywords = ['TITLE', 'DRAWN', 'DATE', 'SCALE', 'DRAWING', 'REV', 'SHEET', 'APPROVED', 'PROJECT', 'CAD'];
  let titleKeywordMatches = 0;
  
  for (const item of textItems) {
    const str = (item.str || '').toUpperCase();
    if (keywords.some(kw => str.includes(kw))) {
      titleKeywordMatches++;
    }
  }

  const isDrawing = titleKeywordMatches >= 3 || (metadata.pageWidth > 800 || metadata.pageHeight > 800);
  if (isDrawing) return 'drawing';

  const isForm = textItems.length > 80 && textItems.some((it: any) => (it.str || '').includes(':') || (it.str || '').includes('___'));
  if (isForm) return 'form';

  return 'document';
}

/**
 * LAYER 3: Detect All Occupied Regions (Text, Lines, Grids, Tables, Form Fields, Margins)
 */
export async function detectAllOccupiedRegions7Layer(page: any, metadata: PageMetadata7Layer, textContent: any = null): Promise<ContentRegion7Layer[]> {
  const regions: ContentRegion7Layer[] = [];
  const pw = metadata.pageWidth;
  const ph = metadata.pageHeight;

  // Margin regions (5% edge guard)
  const marginPx = pw * 0.05;
  regions.push({ x: 0, y: 0, width: pw, height: marginPx, regionType: 'margin', confidence: 0.5, isCritical: false });
  regions.push({ x: 0, y: 0, width: marginPx, height: ph, regionType: 'margin', confidence: 0.5, isCritical: false });
  regions.push({ x: pw - marginPx, y: 0, width: marginPx, height: ph, regionType: 'margin', confidence: 0.5, isCritical: false });
  regions.push({ x: 0, y: ph - marginPx, width: pw, height: marginPx, regionType: 'margin', confidence: 0.5, isCritical: false });

  // Text layer items
  let textItems = textContent?.items || [];
  if (!textItems.length && page.getTextContent) {
    try {
      const tc = await page.getTextContent();
      textItems = tc?.items || [];
    } catch {}
  }

  for (const item of textItems) {
    if (item.transform && item.transform.length >= 6) {
      const x = item.transform[4];
      const y = ph - item.transform[5]; // Convert to top-left Y
      const w = item.width || (item.str ? item.str.length * 6 : 40);
      const h = item.height || 12;

      regions.push({
        x: Math.max(0, x),
        y: Math.max(0, y - h),
        width: Math.max(5, w),
        height: Math.max(5, h),
        regionType: 'text',
        confidence: 1.0,
        isCritical: true
      });
    }
  }

  return regions;
}

/**
 * LAYER 4: Build High-Resolution Occupancy Map
 */
export function buildOccupancyMap7Layer(regions: ContentRegion7Layer[], metadata: PageMetadata7Layer, gridResolution = 100): Uint8Array {
  const grid = new Uint8Array(gridResolution * gridResolution);
  const pw = metadata.pageWidth;
  const ph = metadata.pageHeight;

  for (const region of regions) {
    const gx0 = Math.max(0, Math.min(gridResolution - 1, Math.floor((region.x / pw) * gridResolution)));
    const gy0 = Math.max(0, Math.min(gridResolution - 1, Math.floor((region.y / ph) * gridResolution)));
    const gx1 = Math.max(0, Math.min(gridResolution - 1, Math.floor(((region.x + region.width) / pw) * gridResolution)));
    const gy1 = Math.max(0, Math.min(gridResolution - 1, Math.floor(((region.y + region.height) / ph) * gridResolution)));

    for (let gy = gy0; gy <= gy1; gy++) {
      for (let gx = gx0; gx <= gx1; gx++) {
        grid[gy * gridResolution + gx] = 1;
      }
    }
  }

  return grid;
}

/**
 * LAYER 5: Traverse Page & Find All Candidate Gaps
 */
export function findAllCandidateGaps7Layer(occupancyGrid: Uint8Array, metadata: PageMetadata7Layer, gridRes = 100, minGapSizeCm = 3.0): CandidateGap7Layer[] {
  const minGapCells = Math.max(2, Math.floor((minGapSizeCm / 21.0) * gridRes));
  const gaps: CandidateGap7Layer[] = [];
  const visited = new Uint8Array(gridRes * gridRes);

  const floodFill = (startGx: number, startGy: number): CandidateGap7Layer => {
    const cells: [number, number][] = [];
    const stack: [number, number][] = [[startGx, startGy]];

    while (stack.length > 0) {
      const [gx, gy] = stack.pop()!;
      if (gx < 0 || gx >= gridRes || gy < 0 || gy >= gridRes) continue;
      const idx = gy * gridRes + gx;
      if (occupancyGrid[idx] === 1 || visited[idx] === 1) continue;

      visited[idx] = 1;
      cells.push([gx, gy]);

      for (const [dx, dy] of [[0,1], [1,0], [0,-1], [-1,0], [1,1], [1,-1], [-1,1], [-1,-1]]) {
        stack.push([gx + dx, gy + dy]);
      }
    }

    let gx0 = gridRes, gx1 = 0, gy0 = gridRes, gy1 = 0;
    for (const [c, r] of cells) {
      if (c < gx0) gx0 = c;
      if (c > gx1) gx1 = c;
      if (r < gy0) gy0 = r;
      if (r > gy1) gy1 = r;
    }

    const gyCenter = (gy0 + gy1) / 2;
    const gxCenter = (gx0 + gx1) / 2;
    let loc = gyCenter > gridRes * 0.75 ? 'bottom' : (gyCenter < gridRes * 0.25 ? 'top' : 'middle');
    loc += gxCenter > gridRes * 0.65 ? '_right' : (gxCenter < gridRes * 0.35 ? '_left' : '_center');

    return {
      cells,
      bboxGrid: [gx0, gy0, gx1, gy1],
      areaCells: cells.length,
      priority: loc.includes('bottom_right') ? 'primary' : (loc.includes('bottom') ? 'secondary' : 'tertiary'),
      location: loc
    };
  };

  // Priority 1: Bottom-Right area
  for (let gy = Math.floor(0.75 * gridRes); gy >= 0; gy--) {
    for (let gx = Math.floor(0.85 * gridRes); gx >= Math.floor(0.55 * gridRes); gx--) {
      const idx = gy * gridRes + gx;
      if (occupancyGrid[idx] === 0 && visited[idx] === 0) {
        const gap = floodFill(gx, gy);
        if (gap.cells.length >= minGapCells) {
          gap.priority = 'primary';
          gaps.push(gap);
        }
      }
    }
  }

  // Priority 2: Bottom-Center area
  for (let gy = Math.floor(0.75 * gridRes); gy >= 0; gy--) {
    for (let gx = Math.floor(0.55 * gridRes); gx >= Math.floor(0.45 * gridRes); gx--) {
      const idx = gy * gridRes + gx;
      if (occupancyGrid[idx] === 0 && visited[idx] === 0) {
        const gap = floodFill(gx, gy);
        if (gap.cells.length >= minGapCells) {
          gap.priority = 'secondary';
          gaps.push(gap);
        }
      }
    }
  }

  // Priority 3: Full Page scan
  for (let gy = 0; gy < gridRes; gy++) {
    for (let gx = 0; gx < gridRes; gx++) {
      const idx = gy * gridRes + gx;
      if (occupancyGrid[idx] === 0 && visited[idx] === 0) {
        const gap = floodFill(gx, gy);
        if (gap.cells.length >= minGapCells) {
          gap.priority = 'tertiary';
          gaps.push(gap);
        }
      }
    }
  }

  return gaps;
}

/**
 * LAYER 6: Score & Rank Gaps By Placement Priority
 */
export function scoreAndRankGaps7Layer(
  gaps: CandidateGap7Layer[],
  metadata: PageMetadata7Layer,
  signatureWidthCm = 6.0,
  signatureHeightCm = 2.0,
  paddingCm = 1.0
): CandidateGap7Layer[] {
  const gridRes = 100;

  for (const gap of gaps) {
    const [gx0, gy0, gx1, gy1] = gap.bboxGrid;
    const gapWCm = ((gx1 - gx0) / gridRes) * 21.0;
    const gapHCm = ((gy1 - gy0) / gridRes) * 29.7;

    const reqW = signatureWidthCm + 2 * paddingCm;
    const reqH = signatureHeightCm + 2 * paddingCm;

    let sizeScore = 0;
    if (gapWCm >= reqW && gapHCm >= reqH) sizeScore = 100;
    else if (gapWCm >= reqW * 0.8 && gapHCm >= reqH * 0.8) sizeScore = 80;
    else if (gapWCm >= reqW * 0.6 && gapHCm >= reqH * 0.6) sizeScore = 50;

    const locationScores: Record<string, number> = {
      bottom_right: 100,
      bottom_center: 95,
      bottom_left: 90,
      middle_right: 70,
      middle_center: 60,
      middle_left: 70,
      top_right: 40,
      top_center: 30,
      top_left: 40
    };
    const locationScore = locationScores[gap.location] || 50;

    const priorityScores = { primary: 100, secondary: 70, tertiary: 40 };
    const priorityScore = priorityScores[gap.priority] || 50;

    gap.sizeScore = sizeScore;
    gap.locationScore = locationScore;
    gap.priorityScore = priorityScore;
    gap.score = (sizeScore * 0.4) + (locationScore * 0.4) + (priorityScore * 0.2);
  }

  gaps.sort((a, b) => (b.score || 0) - (a.score || 0));
  return gaps;
}

/**
 * LAYER 7: Validate, Calibrate & Place Signature
 */
export function calibrateAndPlaceSignature7Layer(
  bestGap: CandidateGap7Layer | null,
  metadata: PageMetadata7Layer,
  page: any = null,
  signatureImage: any = null,
  paddingCm = 1.0,
  maxSigWidthPct = 0.25
): SevenLayerResult {
  if (!bestGap) {
    return {
      pageNumber: metadata.pageNumber,
      pageType: metadata.pageType,
      status: 'no_gaps_found',
      reason: 'no_suitable_gap',
      confidence: 0.0
    };
  }

  const gridRes = 100;
  const [gx0, gy0, gx1, gy1] = bestGap.bboxGrid;

  const gapX = (gx0 / gridRes) * metadata.pageWidth;
  const gapY = (gy0 / gridRes) * metadata.pageHeight;
  const gapW = ((gx1 - gx0) / gridRes) * metadata.pageWidth;
  const gapH = ((gy1 - gy0) / gridRes) * metadata.pageHeight;

  const paddingPt = paddingCm * 28.35;
  const sigAspect = 2.5; // typical aspect ratio width/height

  const maxSigW = metadata.pageWidth * maxSigWidthPct;
  const preferredSigH = maxSigW / sigAspect;

  let shrinkFactor = 1.0;
  let finalSigW = maxSigW;
  let finalSigH = preferredSigH;

  while (shrinkFactor > 0.30) {
    if (gapW >= finalSigW + 2 * paddingPt && gapH >= finalSigH + 2 * paddingPt) {
      break;
    }
    shrinkFactor *= 0.85;
    finalSigW = maxSigW * shrinkFactor;
    finalSigH = preferredSigH * shrinkFactor;
  }

  if (shrinkFactor <= 0.30) {
    return {
      pageNumber: metadata.pageNumber,
      pageType: metadata.pageType,
      status: 'failed',
      reason: 'signature_too_large_for_gap',
      confidence: 0.0
    };
  }

  let sigX = gapX + paddingPt + (gapW - finalSigW) / 2;
  let sigY = gapY + paddingPt;

  sigX = Math.max(0, Math.min(sigX, metadata.pageWidth - finalSigW));
  sigY = Math.max(0, Math.min(sigY, metadata.pageHeight - finalSigH));

  let confidence = Math.min((bestGap.score || 50) / 100.0, 1.0);
  if (shrinkFactor < 0.70) confidence *= 0.85;

  // Render to PDF page if handle provided
  if (page && page.drawImage && signatureImage) {
    try {
      page.drawImage(signatureImage, {
        x: sigX,
        y: metadata.pageHeight - sigY - finalSigH,
        width: finalSigW,
        height: finalSigH
      });
    } catch (e) {
      console.warn('[7LayerEngine] Failed page.drawImage:', e);
    }
  }

  return {
    pageNumber: metadata.pageNumber,
    pageType: metadata.pageType,
    status: 'placed',
    gapLocation: bestGap.location,
    signatureX: sigX,
    signatureY: sigY,
    signatureWidth: finalSigW,
    signatureHeight: finalSigH,
    shrinkFactor,
    orientation: metadata.textOrientation,
    paddingAppliedCm: paddingCm,
    confidence,
    notes: `Successfully placed via 7-Layer analysis at ${bestGap.location}`
  };
}

/**
 * Orchestrator: Runs 7-layer complete pipeline for a page
 */
export async function processPageComplete7Layer(
  page: any,
  pageNum: number,
  signatureImage: any = null,
  config: any = {}
): Promise<SevenLayerResult> {
  // Layer 1
  const metadata = await initializePage7Layer(page, pageNum);

  // Layer 2
  let textContent = null;
  if (page.getTextContent) {
    try { textContent = await page.getTextContent(); } catch {}
  }
  metadata.pageType = await detectContentType7Layer(page, metadata, textContent);

  // Layer 3
  const regions = await detectAllOccupiedRegions7Layer(page, metadata, textContent);

  // Layer 4
  const occupancyGrid = buildOccupancyMap7Layer(regions, metadata, 100);

  // Layer 5
  const gaps = findAllCandidateGaps7Layer(occupancyGrid, metadata, 100, 3.0);

  if (!gaps.length) {
    return {
      pageNumber: pageNum,
      pageType: metadata.pageType,
      status: 'no_gaps_found',
      reason: 'page_completely_occupied',
      confidence: 0.0,
      notes: 'No free candidate gaps found on page'
    };
  }

  // Layer 6
  const rankedGaps = scoreAndRankGaps7Layer(
    gaps,
    metadata,
    6.0,
    2.0,
    config.paddingCm || config.padding_cm || 1.0
  );

  // Layer 7
  const result = calibrateAndPlaceSignature7Layer(
    rankedGaps[0],
    metadata,
    page,
    signatureImage,
    config.paddingCm || config.padding_cm || 1.0,
    config.maxSigWidthPct || config.max_sig_width_pct || 0.25
  );

  result.totalGapsFound = gaps.length;
  result.top5GapScores = rankedGaps.slice(0, 5).map(g => g.score || 0);

  return result;
}

/**
 * Alias functions matching user system prompt definitions
 */
export async function analyzePageComplete(page: any, config: any = {}): Promise<SevenLayerResult> {
  return processPageComplete7Layer(page, 1, null, config);
}

export function placeSignatureAtGap(gap: CandidateGap7Layer, config: any = {}): SevenLayerResult {
  const dummyMeta: PageMetadata7Layer = {
    pageNumber: 1,
    pageWidth: 595.28,
    pageHeight: 841.89,
    pageType: 'document',
    hasTextLayer: true,
    textOrientation: 0,
    dpi: 150
  };
  return calibrateAndPlaceSignature7Layer(
    gap,
    dummyMeta,
    null,
    null,
    config.paddingCm || config.padding_cm || 1.0,
    config.maxSigWidthPct || config.max_sig_width_pct || 0.25
  );
}

// ============================================================================
// SECTIONS A-H: ADDITIONS & FAILSAFE MECHANISMS FOR SMART AUTO-GAP SIGNING
// ============================================================================

export const DEFAULT_AUTO_GAP_CONFIG = {
  // Size & spacing
  padding_cm: 1.0,
  max_sig_width_pct: 0.25,
  min_sig_width_pct: 0.05,
  
  // Content avoidance
  avoid_tables: true,
  avoid_grids: false,
  avoid_form_fields: true,
  respect_margins: true,
  min_margin_cm: 0.5,
  
  // Gap detection tuning
  min_gap_size_cm: 3.0,
  gap_search_priority: "bottom_right",
  
  // Scoring weights
  score_size_weight: 40,
  score_location_weight: 40,
  score_priority_weight: 20,
  
  // Thresholds
  min_confidence_for_auto_place: 0.60,
  min_confidence_for_shrink: 0.50,
  critical_confidence_threshold: 0.40,
  
  // Fallback behavior
  auto_fallback: true,
  max_fallback_level: 5,
  
  // Orientation
  detect_orientation: true,
  force_orientation: null as number | null,
  
  // Drawing-specific
  drawing_title_block_safe_zone: true,
  drawing_sig_max_width_pt: 150,
  
  // Scanned document handling
  enable_scanned_content_detection: true,
  scanned_dpi: 150,
};

// ============================================================================
// SECTION A: ERROR HANDLING & FALLBACKS
// ============================================================================

export function placeInTitleBlockFallback(page: any, metadata: PageMetadata7Layer, config: any = {}) {
  const pw = metadata.pageWidth;
  const ph = metadata.pageHeight;
  const sigW = pw * 0.15;
  const sigH = sigW * 0.4;
  
  return {
    status: 'placed',
    x: pw - sigW - (pw * 0.05),
    y: ph - sigH - (ph * 0.08),
    width: sigW,
    height: sigH,
    strategy: "title_block",
    confidence: 0.65
  };
}

export function placeInFooterZone(page: any, metadata: PageMetadata7Layer, config: any = {}) {
  const pw = metadata.pageWidth;
  const ph = metadata.pageHeight;
  const footerHeight = ph * 0.05;
  const sigW = pw * 0.20;
  const sigH = sigW * 0.4;
  
  return {
    status: 'placed',
    x: (pw - sigW) / 2,
    y: ph - footerHeight - sigH,
    width: sigW,
    height: sigH,
    strategy: "footer_zone",
    confidence: 0.40,
    warning: "Placed in footer zone, may overlap content"
  };
}

export function placeInAnyCorner(page: any, metadata: PageMetadata7Layer, config: any = {}) {
  const corners = [
    { x: 0.75, y: 0.75, name: "bottom_right" },
    { x: 0.05, y: 0.75, name: "bottom_left" },
    { x: 0.75, y: 0.05, name: "top_right" },
    { x: 0.05, y: 0.05, name: "top_left" }
  ];
  
  const pw = metadata.pageWidth;
  const ph = metadata.pageHeight;
  const sigW = pw * 0.15;
  const sigH = sigW * 0.4;
  
  for (const corner of corners) {
    const x = (corner.x - 0.075) * pw;
    const y = (corner.y - 0.075) * ph;
    
    return {
      status: 'placed',
      x,
      y,
      width: sigW,
      height: sigH,
      strategy: `corner_${corner.name}`,
      confidence: 0.35
    };
  }
  
  return null;
}

export async function attemptWithRelaxedPadding(page: any, metadata: PageMetadata7Layer, config: any = {}) {
  const configRelaxed = { ...config, padding_cm: 0.5, paddingCm: 0.5 };
  return processPageComplete7Layer(page, metadata.pageNumber, null, configRelaxed);
}

export async function applyFallbackStrategy(page: any, metadata: PageMetadata7Layer, config: any = {}, strategyLevel = 1) {
  const fallbackStrategies: Record<number, string> = {
    1: "aggressive_shrink",
    2: "relax_padding",
    3: "use_title_block",
    4: "use_footer_zone",
    5: "use_any_corner",
    6: "flag_manual_review"
  };
  
  const strategy = fallbackStrategies[strategyLevel] || "flag_manual_review";
  
  if (strategy === "relax_padding") {
    return attemptWithRelaxedPadding(page, metadata, config);
  } else if (strategy === "use_title_block") {
    return placeInTitleBlockFallback(page, metadata, config);
  } else if (strategy === "use_footer_zone") {
    return placeInFooterZone(page, metadata, config);
  } else if (strategy === "use_any_corner") {
    return placeInAnyCorner(page, metadata, config);
  } else {
    return { status: "manual_review", reason: "all_strategies_exhausted", confidence: 0.0 };
  }
}

// ============================================================================
// SECTION B: VALIDATION & VERIFICATION (Confidence Scoring)
// ============================================================================

export function verifyNoOverlapCritical(placement: any, regions: ContentRegion7Layer[]) {
  const px = placement.x || placement.signatureX || 0;
  const py = placement.y || placement.signatureY || 0;
  const pw = placement.width || placement.signatureWidth || 100;
  const ph = placement.height || placement.signatureHeight || 40;
  
  for (const region of regions) {
    if (!region.isCritical) continue;
    
    if (
      px < region.x + region.width &&
      px + pw > region.x &&
      py < region.y + region.height &&
      py + ph > region.y
    ) {
      return {
        passed: false,
        overlapping_type: region.regionType
      };
    }
  }
  
  return { passed: true, overlapping_type: null };
}

export function verifyMarginClearance(placement: any, metadata: PageMetadata7Layer, minMarginCm = 0.5) {
  const marginPt = minMarginCm * 28.35;
  const px = placement.x || placement.signatureX || 0;
  const py = placement.y || placement.signatureY || 0;
  const pw = placement.width || placement.signatureWidth || 100;
  const ph = placement.height || placement.signatureHeight || 40;
  
  if (px < marginPt) return { passed: false, edge: "left" };
  if (py < marginPt) return { passed: false, edge: "top" };
  if (px + pw > metadata.pageWidth - marginPt) return { passed: false, edge: "right" };
  if (py + ph > metadata.pageHeight - marginPt) return { passed: false, edge: "bottom" };
  
  return { passed: true, edge: null };
}

export function verifyWithinPageBounds(placement: any, metadata: PageMetadata7Layer) {
  const px = placement.x || placement.signatureX || 0;
  const py = placement.y || placement.signatureY || 0;
  const pw = placement.width || placement.signatureWidth || 100;
  const ph = placement.height || placement.signatureHeight || 40;
  
  if (px < 0 || py < 0 || px + pw > metadata.pageWidth || py + ph > metadata.pageHeight) {
    return { passed: false };
  }
  
  return { passed: true };
}

export function verifySignatureReadability(placement: any, minWidthPt = 60) {
  const sigW = placement.width || placement.signatureWidth || 0;
  if (sigW < minWidthPt) {
    return { passed: false, size: sigW };
  }
  return { passed: true, size: sigW };
}

export function verifyLocationSanity(placement: any, metadata: PageMetadata7Layer) {
  const py = placement.y || placement.signatureY || 0;
  const ph = metadata.pageHeight;
  if (py < ph * 0.3) {
    return { passed: false };
  }
  return { passed: true };
}

export function validatePlacementBeforeCommit(page: any, placement: any, metadata: PageMetadata7Layer, regions: ContentRegion7Layer[]) {
  const warnings: string[] = [];
  let confidence = placement.confidence ?? 0.5;
  
  const overlapCheck = verifyNoOverlapCritical(placement, regions);
  if (!overlapCheck.passed) {
    warnings.push(`WARNING: Overlaps with ${overlapCheck.overlapping_type}`);
    confidence *= 0.70;
  }
  
  const edgeCheck = verifyMarginClearance(placement, metadata);
  if (!edgeCheck.passed) {
    warnings.push(`WARNING: Too close to ${edgeCheck.edge}`);
    confidence *= 0.80;
  }
  
  const boundsCheck = verifyWithinPageBounds(placement, metadata);
  if (!boundsCheck.passed) {
    return { is_valid: false, confidence: 0.0, warnings: ["ERROR: Placement outside page bounds — REJECT"] };
  }
  
  const readabilityCheck = verifySignatureReadability(placement);
  if (!readabilityCheck.passed) {
    warnings.push(`WARNING: Signature very small (${readabilityCheck.size}pt)`);
    confidence *= 0.60;
  }
  
  const locationCheck = verifyLocationSanity(placement, metadata);
  if (!locationCheck.passed) {
    warnings.push("WARNING: Unusual location for signature");
    confidence *= 0.75;
  }
  
  const criticalPassed = overlapCheck.passed && boundsCheck.passed;
  return { is_valid: criticalPassed, confidence: Math.min(confidence, 1.0), warnings };
}

// ============================================================================
// SECTION E: EDGE CASE HANDLING
// ============================================================================

export function handleRotatedPages(page: any, metadata: PageMetadata7Layer) {
  const rotation = page.rotate || page.getRotation?.()?.angle || 0;
  if (rotation !== 0) {
    metadata.textOrientation = rotation as 0 | 90 | 180 | 270;
  }
  return metadata;
}

export function handleLandscapePages(metadata: PageMetadata7Layer) {
  const aspect = metadata.pageWidth / metadata.pageHeight;
  const isLandscape = aspect > 1.2;
  return { ...metadata, isLandscape };
}

export function handleEmptyPages(page: any, metadata: PageMetadata7Layer) {
  if (!metadata.hasTextLayer) {
    return {
      status: "blank_page",
      action: "place_anywhere_with_low_confidence",
      suggested_x: metadata.pageWidth * 0.65,
      suggested_y: metadata.pageHeight * 0.75,
      confidence: 0.25
    };
  }
  return null;
}

export function handleOversizedSignatures(metadata: PageMetadata7Layer, signatureImage: any) {
  if (signatureImage) {
    const sigW = signatureImage.width || 0;
    const sigH = signatureImage.height || 0;
    if (sigW > 2000 || sigH > 1000) {
      console.warn(`[AutoGapEngine] Large signature source detected: ${sigW}x${sigH}px`);
    }
  }
  return true;
}

// ============================================================================
// SECTION D & G: LOGGING & USER FEEDBACK / BATCH SUMMARY
// ============================================================================

export class SignaturePlacementLogger {
  logPageStart(pageNum: number, pageType: string) {
    console.log(`[SmartAutoGap] Page ${pageNum} start (${pageType})`);
  }
  logRegionsDetected(pageNum: number, regions: any[]) {
    console.log(`[SmartAutoGap] Page ${pageNum}: ${regions.length} regions detected`);
  }
  logGapsFound(pageNum: number, gaps: any[]) {
    console.log(`[SmartAutoGap] Page ${pageNum}: ${gaps.length} candidate gaps found`);
  }
  logPlacementAttempt(pageNum: number, strategy: string, result: any) {
    console.log(`[SmartAutoGap] Page ${pageNum} [${strategy}] → ${result?.status} (confidence: ${result?.confidence})`);
  }
}

export function generateRecommendations(results: any[]): string[] {
  const recommendations: string[] = [];
  const shrinkCount = results.filter(r => (r.shrinkFactor || 1.0) < 0.7).length;
  if (shrinkCount > results.length * 0.2) {
    recommendations.push("⚠️ Many pages required size reduction. Consider adjusting padding or signature size.");
  }
  const drawingCount = results.filter(r => r.pageType === 'drawing').length;
  if (drawingCount > 0) {
    recommendations.push(`✓ ${drawingCount} technical drawing pages detected and handled with title block strategy.`);
  }
  const reviewCount = results.filter(r => r.status === 'manual_review' || r.action === 'manual_review').length;
  if (reviewCount > 0) {
    recommendations.push(`⚠️ ${reviewCount} pages flagged for manual review.`);
  }
  return recommendations;
}

export function generateBatchSummary(results: any[]): any {
  const total = results.length;
  const placed = results.filter(r => r.status === 'placed').length;
  const review = results.filter(r => r.status === 'manual_review' || r.action === 'manual_review').length;
  const failed = total - placed - review;

  const locations: Record<string, number> = {};
  const shrinkFactors: number[] = [];
  const confidences: number[] = [];

  for (const r of results) {
    if (r.status === 'placed') {
      const loc = r.gapLocation || r.strategy || 'unknown';
      locations[loc] = (locations[loc] || 0) + 1;
      if (r.shrinkFactor) shrinkFactors.push(r.shrinkFactor);
      if (r.confidence) confidences.push(r.confidence);
    }
  }

  return {
    summary: {
      total_pages: total,
      signatures_placed: placed,
      manual_review_needed: review,
      failed,
      success_rate: total > 0 ? placed / total : 0
    },
    placement_locations: locations,
    average_shrink_factor: shrinkFactors.length ? shrinkFactors.reduce((a, b) => a + b, 0) / shrinkFactors.length : 1.0,
    average_confidence: confidences.length ? confidences.reduce((a, b) => a + b, 0) / confidences.length : 0.0,
    recommendations: generateRecommendations(results)
  };
}




