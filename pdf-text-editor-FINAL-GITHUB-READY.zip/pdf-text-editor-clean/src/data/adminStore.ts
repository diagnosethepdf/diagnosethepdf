export interface RegisteredUser {
  id: string;
  fullName: string;
  emailOrPhone: string;
  accountType: 'Enterprise' | 'Healthcare / HIPAA' | 'Legal & Defense' | 'Academic' | 'Personal Developer';
  authMethod: 'Email & Password' | 'Mobile Number (OTP)' | 'LinkedIn OAuth' | 'Bypass Whitelist' | 'Guest';
  registeredAt: string;
  lastActiveAt: string;
  status: 'active' | 'suspended' | 'bypassed';
  timeSpentMinutes: number;
  toolUsageMinutes: {
    canvas: number;
    ocr: number;
    zkdVault: number;
    posterAi: number;
    formBuilder: number;
    converter: number;
  };
  docsProcessedCount: number;
  isOnline: boolean;
  currentActiveTool?: string;
}

export interface GranularRoleRestrictions {
  guest: { disabledSections: string[]; disabledTools: string[] };
  registered: { disabledSections: string[]; disabledTools: string[] };
  bypassed: { disabledSections: string[]; disabledTools: string[] };
}

export interface CustomBoxStyleConfig {
  boxBgColor: string;
  boxBorderColor: string;
  borderStrokeWidthPx: number; // 1 to 8
  glowIntensityPercent: number; // 0 to 100
  borderRadiusStyle: 'sharp' | 'curved' | 'pill';
  autoLegibilityContrast: boolean;
}

export type ThemeType =
  | 'cyberpunk-neon'
  | 'solar-amber'
  | 'cosmic-dark'
  | 'standard'
  | 'matrix-green'
  | 'crimson-cyber'
  | 'nordic-frost'
  | 'vibrant-dusk'
  | 'emerald-forest'
  | 'cyberpunk-2099'
  | 'espresso-lux'
  | 'vaporwave';

export interface ApprovedCredential {
  id: string;
  identifier: string; // e.g. diagnosethepdf@gmail.com, +1 (555) 019-2831, VIP-CODE-99
  type: 'email' | 'phone' | 'passcode';
  role: 'VIP Master Admin' | 'Approved Practitioner' | 'Enterprise Verified' | 'Bypass User';
  approvedAt: string;
  approvedBy: string;
  notes: string;
  unconditionalAccess: boolean;
  isBypassEnabled: boolean;
  accessStatus: 'active' | 'disabled' | 'revoked';
}

export interface FreeSampleDownloadConfig {
  enabled: boolean;
  buttonLabel: string;
  modalTitle: string;
  modalSubtitle: string;
  requireName: boolean;
  requireEmail: boolean;
  requireMacAddress: boolean;
  requirePhone: boolean;
  requireCompanyName: boolean;
  requirePurpose: boolean;
  downloadFileUrl: string;
  downloadFileName: string;
  successMessage: string;
}

export interface LoginPageVisualConfig {
  cardBgColor: string;
  cardBorderColor: string;
  cardBorderWidthPx: number;
  cardBorderRadiusStyle: 'curved' | 'pill' | 'sharp' | 'rounded-3xl';
  pageBgGradient: string;
  pageCustomBgHex: string;
  primaryButtonBgColor: string;
  primaryButtonTextColor: string;
  showSocialSso: boolean;
  showGuestOption: boolean;
}

export interface AppTextOverrides {
  appTitle: string;
  appSubtitle: string;
  mainLandingTitle: string;
  mainLandingSubtitle: string;
  headerContactPhone: string;
  headerContactEmail: string;
  footerCopyright: string;
  searchPlaceholder: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: string;
  category: 'typography' | 'canvas' | 'media' | 'suite' | 'security' | 'login' | 'system' | 'telemetry' | 'branding';
  severity: 'info' | 'success' | 'warning' | 'alert';
  details: string;
  user: string;
}

export interface MasterAdminConfig {
  // Typography additions
  globalHeading1Size: number;
  globalHeading2Size: number;
  globalBodySize: number;
  globalLineHeight: number;
  globalLetterSpacing: number;
  globalHeadingUppercase: boolean;
  globalHeadingWeight: string;
  globalTextDecoration: 'none' | 'underline' | 'line-through';

  // Global Text Override
  uiTextOverrides: Record<string, string>;

  // Feature Flags
  featureFlags: {
    // Media Pipeline Flags
    autoSilenceCutting?: boolean;
    aiSpeechToTextCaptions?: boolean;
    highResVideoFrameExtraction?: boolean;
    photoToVideoKenBurns?: boolean;
    highBitrate4KRender?: boolean;

    documentVault: boolean;
    mediaStudio: boolean;
    interactiveWhiteboard: boolean;
    aiCleanupTools: boolean;
    publicRegistrations: boolean;
  };

  // Maintenance & Emergency
  maintenanceMode: boolean;
  killSwitches: {
    videoRenderPipeline: boolean;
    aiSpeechToText: boolean;
  };
  maxUploadLimits: {
    pdfMaxMb: number;
    videoMaxMb: number;
  };

  // RBAC
  roleFeatureAccess: Record<string, {
    pdfViewing: boolean;
    basicTextEditing: boolean;
    maxUploadMb: number;
    mediaStudio: boolean;
    highResExport: boolean;
    aiBackgroundRemoval: boolean;
    unlimitedStorage: boolean;
    whiteboardStudio: boolean;
    sessionRecording: boolean;
    studentManagement: boolean;
    cohortAnalytics: boolean;
  }>;

  // 1. Text & Typography Engine Controls
  defaultFontFamilyOverride: string;
  customFontUrl: string;
  textGranularity: 'word' | 'sentence' | 'line';
  lockPdfFontFamily: boolean;
  lockPdfFontSize: boolean;
  lockPdfFontWeight: boolean;
  lockPdfFontColor: boolean;

  // 2. Interactive Canvas & Drawing Tools
  enabledTools: {
    addText: boolean;
    editText: boolean;
    freehandDraw: boolean;
    shapes: boolean;
    imageUpload: boolean;
    signature: boolean;
    highlightRedact: boolean;
  };
  gapDetectionThresholdPx: number;
  tableDetectionSensitivityPercent: number;
  paragraphSpacingTolerancePt: number;
  selectionBoxColor: string;
  selectionBoxStrokeWidth: number;
  wordHighlightColor: string;
  wordHighlightOpacity: number;
  hoverOutlineStyle: 'solid' | 'dashed' | 'dotted';
  snapToGridEnabled: boolean;
  gridSpacingPx: number;

  // 3. Media & Object Management
  maxImageSizeMb: number;
  supportedImageFormats: {
    png: boolean;
    jpeg: boolean;
    webp: boolean;
    svg: boolean;
  };
  autoCompressionQualityPercent: number;
  backgroundRemovalEnabled: boolean;
  defaultShapeStrokeColor: string;
  defaultShapeFillColor: string;
  defaultShapeFillOpacity: number;
  defaultArrowHeadStyle: 'none' | 'standard' | 'filled' | 'double';
  defaultBorderRadiusPx: number;

  // 4. Suite & Navigation Reordering & Module Feature Flags
  disabledSections: string[];
  disabledTools: string[];
  sectionOrder: string[];
  sectionScale: number; // Scale factor for landing page boxes

  // Granular Restrictions Per User Tier
  granularRoleRestrictions: GranularRoleRestrictions;

  // 5. User Login, Branding & Approved Credentials Vault
  guestAccessMode: 'allowed' | 'passcode_required' | 'disabled';
  guestPasscode: string;
  loginHeadingText: string;
  loginSubheadingText: string;
  loginWelcomeBanner: string;
  loginDisclaimer: string;
  loginSecurityKeyLabel: string;
  loginHeaderBadgeText: string;
  loginLogoText: string;
  loginCalloutBannerText: string;
  approvedCredentialsVault: ApprovedCredential[];

  // Registered Users Registry & Telemetry Data
  userRegistry: RegisteredUser[];

  // 6. System Theme & Box Palette Manager
  forcedTheme: 'none' | ThemeType;
  highContrastEnforcement: boolean;
  activeGlobalTheme: ThemeType;
  customBoxStyle: CustomBoxStyleConfig;

  // Audit Log Stream
  auditLogs: AuditLogEntry[];

  // 7. Security, Layout & Corner Controls
  showFloatingCornerAdminButton: boolean;
  showFloatingCornerChatAssistant: boolean;
  showHeaderCornerBranding: boolean;
  showPageCornerRegistrationMarks: boolean;
  hideHeaderEntirely: boolean;
  hideFooterEntirely: boolean;

  // 8. Free Sample Download & App Text Controls
  freeSampleDownloadConfig: FreeSampleDownloadConfig;
  loginPageVisualConfig: LoginPageVisualConfig;
  appTextOverrides: AppTextOverrides;
}

export const DEFAULT_ADMIN_CONFIG: MasterAdminConfig = {
  freeSampleDownloadConfig: {
    enabled: true,
    buttonLabel: '🎁 Download Free Sample Pack',
    modalTitle: 'Free Enterprise PDF Sample & Spec Sheet',
    modalSubtitle: 'Enter your details below to instantly download your cryptographically verified sample PDF package.',
    requireName: true,
    requireEmail: true,
    requireMacAddress: true,
    requirePhone: true,
    requireCompanyName: true,
    requirePurpose: false,
    downloadFileUrl: 'https://www.w3.org/W3C/DesignIssues/Overview.html',
    downloadFileName: 'GlowPDF_Enterprise_Sample_2026.pdf',
    successMessage: '🎉 Free Sample Pack downloaded successfully!',
  },
  loginPageVisualConfig: {
    cardBgColor: '#ffffff',
    cardBorderColor: '#0e4475',
    cardBorderWidthPx: 4,
    cardBorderRadiusStyle: 'rounded-3xl',
    pageBgGradient: 'from-slate-900 via-blue-950 to-slate-900',
    pageCustomBgHex: '#0f172a',
    primaryButtonBgColor: '#001f70',
    primaryButtonTextColor: '#ffffff',
    showSocialSso: true,
    showGuestOption: true,
  },
  appTextOverrides: {
    appTitle: 'L&T Construction',
    appSubtitle: 'Heavy Civil Infrastructure',
    mainLandingTitle: 'Enterprise PDF & Intelligence Platform',
    mainLandingSubtitle: 'Secure, high-speed document processing, vector editing, and cryptographic verification.',
    headerContactPhone: '+1 (800) 555-GLOW',
    headerContactEmail: 'support@glowpdf.com',
    footerCopyright: '© 2026 L&T Heavy Civil Infrastructure. All rights reserved.',
    searchPlaceholder: 'Search 120+ PDF tools, workflows, OCR, and AI suites...',
  },
  globalHeading1Size: 32,
  globalHeading2Size: 24,
  globalBodySize: 14,
  globalLineHeight: 1.5,
  globalLetterSpacing: 0,
  globalHeadingUppercase: false,
  globalHeadingWeight: '700',
  globalTextDecoration: 'none',

  uiTextOverrides: {},

  featureFlags: {
    autoSilenceCutting: true,
    aiSpeechToTextCaptions: true,
    highResVideoFrameExtraction: true,
    photoToVideoKenBurns: true,
    highBitrate4KRender: true,

    documentVault: true,
    mediaStudio: true,
    interactiveWhiteboard: true,
    aiCleanupTools: true,
    publicRegistrations: true,
  },

  maintenanceMode: false,
  killSwitches: {
    videoRenderPipeline: false,
    aiSpeechToText: false,
  },
  maxUploadLimits: {
    pdfMaxMb: 50,
    videoMaxMb: 500,
  },

  roleFeatureAccess: {
    'Basic User': {
      pdfViewing: true,
      basicTextEditing: true,
      maxUploadMb: 5,
      mediaStudio: false,
      highResExport: false,
      aiBackgroundRemoval: false,
      unlimitedStorage: false,
      whiteboardStudio: false,
      sessionRecording: false,
      studentManagement: false,
      cohortAnalytics: false,
    },
    'Pro User': {
      pdfViewing: true,
      basicTextEditing: true,
      maxUploadMb: 50,
      mediaStudio: true,
      highResExport: true,
      aiBackgroundRemoval: true,
      unlimitedStorage: true,
      whiteboardStudio: false,
      sessionRecording: false,
      studentManagement: false,
      cohortAnalytics: false,
    },
    'Teacher': {
      pdfViewing: true,
      basicTextEditing: true,
      maxUploadMb: 100,
      mediaStudio: true,
      highResExport: true,
      aiBackgroundRemoval: true,
      unlimitedStorage: true,
      whiteboardStudio: true,
      sessionRecording: true,
      studentManagement: true,
      cohortAnalytics: true,
    },
  },

  // 1. Typography
  defaultFontFamilyOverride: 'Standard',
  customFontUrl: '',
  textGranularity: 'sentence',
  lockPdfFontFamily: true,
  lockPdfFontSize: true,
  lockPdfFontWeight: true,
  lockPdfFontColor: true,

  // 2. Interactive Canvas
  enabledTools: {
    addText: true,
    editText: true,
    freehandDraw: true,
    shapes: true,
    imageUpload: true,
    signature: true,
    highlightRedact: true,
  },
  gapDetectionThresholdPx: 12,
  tableDetectionSensitivityPercent: 75,
  paragraphSpacingTolerancePt: 8,
  selectionBoxColor: '#a855f7',
  selectionBoxStrokeWidth: 2,
  wordHighlightColor: '#fef08a',
  wordHighlightOpacity: 0.4,
  hoverOutlineStyle: 'solid',
  snapToGridEnabled: false,
  gridSpacingPx: 10,

  // 3. Media
  maxImageSizeMb: 25,
  supportedImageFormats: {
    png: true,
    jpeg: true,
    webp: true,
    svg: true,
  },
  autoCompressionQualityPercent: 85,
  backgroundRemovalEnabled: true,
  defaultShapeStrokeColor: '#3b82f6',
  defaultShapeFillColor: '#93c5fd',
  defaultShapeFillOpacity: 0.25,
  defaultArrowHeadStyle: 'filled',
  defaultBorderRadiusPx: 6,

  // 4. Suite Reordering & Feature Flags
  disabledSections: [],
  disabledTools: [],
  sectionOrder: [
    'section-1-core-editing-conversion',
    'section-2-ai-tools',
    'section-3-core-diagnostics',
    'section-4-security-encryption',
    'section-5-stamping-watermark',
    'section-6-form-building',
    'section-7-accessibility-archiving',
    'section-8-niche-vertical-suites',
    'section-9-gov-edu-financial',
    'section-10-zkd-pqc-shield',
  ],
  sectionScale: 1.0,

  granularRoleRestrictions: {
    guest: { disabledSections: [], disabledTools: ['zkd-pqc-shield', 'gov-fips'] },
    registered: { disabledSections: [], disabledTools: [] },
    bypassed: { disabledSections: [], disabledTools: [] },
  },

  // 5. Login Branding & Approved Credentials Vault
  guestAccessMode: 'allowed',
  guestPasscode: 'GLOWGUEST2026',
  loginHeadingText: 'GlowPDF Master Console',
  loginSubheadingText: '✨ Makes your documents glow',
  loginWelcomeBanner: 'Welcome to GlowPDF. Authenticate via Email, Mobile OTP, LinkedIn, or VIP Credential.',
  loginDisclaimer: 'Protected enterprise node. All document streams encrypted under AES-256 GCM sandbox.',
  loginSecurityKeyLabel: 'Console Security Passcode / VIP Credential',
  loginHeaderBadgeText: 'PRO INTELLIGENCE SUITE v2026.4',
  loginLogoText: 'GlowPDF',
  loginCalloutBannerText: '⚡ VIP Whitelisted accounts bypass standard login barriers automatically.',
  approvedCredentialsVault: [
    {
      id: 'vip-1',
      identifier: 'diagnosethepdf@gmail.com',
      type: 'email',
      role: 'VIP Master Admin',
      approvedAt: '2026-07-28 02:00',
      approvedBy: 'System Root',
      notes: 'Master Administrator Email - Always Unconditional Access',
      unconditionalAccess: true,
      isBypassEnabled: true,
      accessStatus: 'active',
    },
    {
      id: 'vip-2',
      identifier: '+1 (555) 987-6543',
      type: 'phone',
      role: 'Approved Practitioner',
      approvedAt: '2026-07-28 02:15',
      approvedBy: 'GlowAdmin',
      notes: 'Verified Clinical Physician Mobile Number',
      unconditionalAccess: true,
      isBypassEnabled: true,
      accessStatus: 'active',
    },
    {
      id: 'vip-3',
      identifier: 'glowpdf',
      type: 'passcode',
      role: 'Enterprise Verified',
      approvedAt: '2026-07-28 02:20',
      approvedBy: 'System Root',
      notes: 'Standard Default Security Key',
      unconditionalAccess: true,
      isBypassEnabled: true,
      accessStatus: 'active',
    },
  ],

  // Registered Users Registry & Telemetry Data
  userRegistry: [
    {
      id: 'usr-1',
      fullName: 'Dr. Sarah Jenkins',
      emailOrPhone: 'diagnosethepdf@gmail.com',
      accountType: 'Healthcare / HIPAA',
      authMethod: 'Bypass Whitelist',
      registeredAt: '2026-07-28 01:10',
      lastActiveAt: '2026-07-28 03:05',
      status: 'bypassed',
      timeSpentMinutes: 142,
      toolUsageMinutes: {
        canvas: 45,
        ocr: 38,
        zkdVault: 22,
        posterAi: 12,
        formBuilder: 15,
        converter: 10,
      },
      docsProcessedCount: 28,
      isOnline: true,
      currentActiveTool: '18 PHI Safe Harbor Diagnostics',
    },
    {
      id: 'usr-2',
      fullName: 'Marcus Vance',
      emailOrPhone: 'marcus.vance@defense-gov.us',
      accountType: 'Legal & Defense',
      authMethod: 'LinkedIn OAuth',
      registeredAt: '2026-07-27 14:30',
      lastActiveAt: '2026-07-28 02:40',
      status: 'active',
      timeSpentMinutes: 88,
      toolUsageMinutes: {
        canvas: 20,
        ocr: 15,
        zkdVault: 35,
        posterAi: 0,
        formBuilder: 8,
        converter: 10,
      },
      docsProcessedCount: 14,
      isOnline: true,
      currentActiveTool: 'Quantum Cryptography Vault',
    },
    {
      id: 'usr-3',
      fullName: 'Elena Rostova',
      emailOrPhone: '+1 (555) 019-2831',
      accountType: 'Enterprise',
      authMethod: 'Mobile Number (OTP)',
      registeredAt: '2026-07-26 09:15',
      lastActiveAt: '2026-07-27 18:20',
      status: 'active',
      timeSpentMinutes: 205,
      toolUsageMinutes: {
        canvas: 80,
        ocr: 45,
        zkdVault: 10,
        posterAi: 30,
        formBuilder: 25,
        converter: 15,
      },
      docsProcessedCount: 42,
      isOnline: false,
      currentActiveTool: 'Offline',
    },
  ],

  // 6. Theme & Box Palette
  forcedTheme: 'none',
  highContrastEnforcement: true,
  activeGlobalTheme: 'cyberpunk-neon',
  customBoxStyle: {
    boxBgColor: '#121522',
    boxBorderColor: '#a855f7',
    borderStrokeWidthPx: 2,
    glowIntensityPercent: 35,
    borderRadiusStyle: 'curved',
    autoLegibilityContrast: true,
  },

  // 7. Security, Layout & Corner Controls Defaults
  showFloatingCornerAdminButton: true,
  showFloatingCornerChatAssistant: true,
  showHeaderCornerBranding: true,
  showPageCornerRegistrationMarks: true,
  hideHeaderEntirely: false,
  hideFooterEntirely: false,

  // Initial Logs
  auditLogs: [
    {
      id: 'log-1',
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      action: 'Master Admin Control Panel Initialized',
      category: 'system',
      severity: 'success',
      details: 'All 6 control modules, Telemetry Registry, and VIP Whitelist Vault mounted successfully.',
      user: 'System Root',
    },
  ],
};

const STORAGE_KEY = 'glowpdf_master_admin_config_v2';

// Subscribers for real-time state updates
type AdminChangeListener = (config: MasterAdminConfig) => void;
const listeners: Set<AdminChangeListener> = new Set();

export function getAdminConfig(): MasterAdminConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_ADMIN_CONFIG;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_ADMIN_CONFIG,
      ...parsed,
      granularRoleRestrictions: {
        ...DEFAULT_ADMIN_CONFIG.granularRoleRestrictions,
        ...(parsed.granularRoleRestrictions || {}),
      },
      customBoxStyle: {
        ...DEFAULT_ADMIN_CONFIG.customBoxStyle,
        ...(parsed.customBoxStyle || {}),
      },
      freeSampleDownloadConfig: {
        ...DEFAULT_ADMIN_CONFIG.freeSampleDownloadConfig,
        ...(parsed.freeSampleDownloadConfig || {}),
      },
      loginPageVisualConfig: {
        ...DEFAULT_ADMIN_CONFIG.loginPageVisualConfig,
        ...(parsed.loginPageVisualConfig || {}),
      },
      appTextOverrides: {
        ...DEFAULT_ADMIN_CONFIG.appTextOverrides,
        ...(parsed.appTextOverrides || {}),
      },
    };
  } catch (err) {
    console.error('Error loading admin config:', err);
    return DEFAULT_ADMIN_CONFIG;
  }
}

export function saveAdminConfig(config: MasterAdminConfig): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
    listeners.forEach((listener) => listener(config));
  } catch (err) {
    console.error('Error saving admin config:', err);
  }
}

export function addAuditLog(
  action: string,
  category: AuditLogEntry['category'],
  severity: AuditLogEntry['severity'],
  details: string,
  user: string = 'GlowAdmin'
): void {
  const current = getAdminConfig();
  const newLog: AuditLogEntry = {
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    action,
    category,
    severity,
    details,
    user,
  };

  const updated: MasterAdminConfig = {
    ...current,
    auditLogs: [newLog, ...(current.auditLogs || [])].slice(0, 100),
  };

  saveAdminConfig(updated);
}

export function registerNewUser(newUser: Omit<RegisteredUser, 'id' | 'registeredAt' | 'lastActiveAt' | 'timeSpentMinutes' | 'toolUsageMinutes' | 'docsProcessedCount' | 'isOnline'>): RegisteredUser {
  const config = getAdminConfig();
  const user: RegisteredUser = {
    ...newUser,
    id: `usr-${Date.now()}`,
    registeredAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    lastActiveAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    timeSpentMinutes: 1,
    toolUsageMinutes: {
      canvas: 0,
      ocr: 0,
      zkdVault: 0,
      posterAi: 0,
      formBuilder: 0,
      converter: 0,
    },
    docsProcessedCount: 0,
    isOnline: true,
    currentActiveTool: 'Dashboard',
  };

  const updated = {
    ...config,
    userRegistry: [user, ...config.userRegistry],
  };

  saveAdminConfig(updated);
  addAuditLog(
    `New User Registered: ${user.fullName}`,
    'login',
    'success',
    `Registered ${user.accountType} account via ${user.authMethod} (${user.emailOrPhone}).`,
    user.fullName
  );

  return user;
}

export function subscribeAdminConfig(listener: AdminChangeListener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function resetAdminConfigToDefaults(): void {
  saveAdminConfig(DEFAULT_ADMIN_CONFIG);
  addAuditLog(
    'Reset App State to Defaults',
    'system',
    'warning',
    'Restored all typography, canvas, suite flags, themes, and login policies to default factory state.',
    'GlowAdmin'
  );
}

/**
 * Checks if a credential input matches an approved credential in the VIP Whitelist Vault
 */
export function checkApprovedCredential(input: string): ApprovedCredential | null {
  if (!input || !input.trim()) return null;
  const config = getAdminConfig();
  const normalizedInput = input.trim().toLowerCase();

  const found = config.approvedCredentialsVault.find(
    (c) => c.identifier.toLowerCase() === normalizedInput
  );

  if (found && found.accessStatus !== 'revoked' && found.isBypassEnabled) {
    return found;
  }

  return null;
}

