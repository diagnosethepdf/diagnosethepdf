/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SubSubheadingOption {
  id: string;
  title: string;
  desc: string;
  badge: string;
  toolId: string; // The working function tab ID in Workspace Editor
  iconName?: string;
}

export interface SubheadingItem {
  id: string;
  title: string;
  badge: string;
  badgeColor: string;
  description: string;
  iconName: string;
  subSubheadings: SubSubheadingOption[];
}

export interface HeadingCategory {
  id: string;
  sectionNumber: number;
  title: string;
  subtitle: string;
  badge: string;
  badgeColor: string;
  colorGradient: string;
  iconName: string;
  description: string;
  subheadings: SubheadingItem[];
}

export const MAIN_SECTION_HEADINGS: HeadingCategory[] = [
  {
    id: 'section-1-core-editing-conversion',
    sectionNumber: 1,
    title: 'SECTION 1: Core PDF Editing, Layout, Assembly, Conversion, Compression & OCR',
    subtitle: 'Direct Canvas Text Editor, Merge, Split, Reorder, PDF/Image Conversion, Target KB & OCR',
    badge: 'EDIT, CONVERT & COMPRESS',
    badgeColor: 'bg-blue-500/15 text-blue-600 border-blue-500/30 dark:text-blue-400',
    colorGradient: 'from-blue-600 via-indigo-600 to-pink-600',
    iconName: 'Layers',
    description: 'Direct canvas text and image editor, PDF page assembly/merge, custom split ranges, visual page reordering, rotation, margin cropping, format conversion (PDF/JPEG/PNG/Image-to-PDF), target KB compression, OCR scanner, and watermark stamping.',
    subheadings: [
      {
        id: 'sub-text-canvas-edit',
        title: '✏️ Direct PDF Text & Visual Canvas Editor',
        badge: 'CANVAS EDIT',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Click any text element or image on the PDF canvas to edit text, font size, and layout.',
        iconName: 'PenTool',
        subSubheadings: [
          {
            id: 'opt-canvas-text',
            title: '1. Interactive PDF Canvas Text & Image Editor',
            desc: 'Edit PDF text runs directly in-place with font family, size, color, and stretch options.',
            badge: 'LIVE TEXT',
            toolId: 'editor',
            iconName: 'PenTool'
          },
          {
            id: 'opt-image-overlay',
            title: '2. Image & Graphics Placement Tool',
            desc: 'Stamp high-res logos, signatures, and raster overlays anywhere on PDF pages.',
            badge: 'STAMP IMAGE',
            toolId: 'image-converter',
            iconName: 'ImageIcon'
          }
        ]
      },
      {
        id: 'sub-merge-assemble',
        title: '📂 Merge & Assemble PDF Files',
        badge: 'ASSEMBLY',
        badgeColor: 'bg-blue-500/15 text-blue-600 border-blue-500/30 dark:text-blue-400',
        description: 'Combine multiple PDF files or individual pages into a single organized document.',
        iconName: 'FolderArchive',
        subSubheadings: [
          {
            id: 'opt-merge-order',
            title: '1. Merge by Upload Order',
            desc: 'Combine multiple uploaded PDFs sequentially in the order they were selected.',
            badge: 'SEQUENTIAL',
            toolId: 'merge-console',
            iconName: 'FileText'
          },
          {
            id: 'opt-merge-custom',
            title: '2. Merge with Custom Sequence & Cover',
            desc: 'Specify exact page ranges from each PDF and add an optional cover page.',
            badge: 'CUSTOM RANGE',
            toolId: 'merge-console',
            iconName: 'Sliders'
          }
        ]
      },
      {
        id: 'sub-split-extract',
        title: '✂️ Split & Extract PDF Pages',
        badge: 'SPLIT',
        badgeColor: 'bg-indigo-500/15 text-indigo-600 border-indigo-500/30 dark:text-indigo-400',
        description: 'Divide documents into individual single-page PDFs or extract targeted chapter ranges.',
        iconName: 'Scissors',
        subSubheadings: [
          {
            id: 'opt-split-single',
            title: '1. Split into Single-Page PDFs',
            desc: 'Separate every page of a multi-page PDF into independent single-page files.',
            badge: 'SINGLE PAGES',
            toolId: 'reorder',
            iconName: 'FileText'
          },
          {
            id: 'opt-split-range',
            title: '2. Extract Custom Page Range',
            desc: 'Specify page numbers or ranges (e.g. 1-5, 8, 12-15) to export as a new document.',
            badge: 'PAGE EXTRACT',
            toolId: 'reorder',
            iconName: 'Crop'
          }
        ]
      },
      {
        id: 'sub-reorder-rotate',
        title: '🔄 Page Reorder, Rotate & Crop Margins',
        badge: 'ORGANIZER',
        badgeColor: 'bg-sky-500/15 text-sky-600 border-sky-500/30 dark:text-sky-400',
        description: 'Visual drag-and-drop page grid reordering, batch page rotation, and margin cropping.',
        iconName: 'Sliders',
        subSubheadings: [
          {
            id: 'opt-reorder-grid',
            title: '1. Visual Drag & Drop Page Grid Reorder',
            desc: 'Interactive grid interface to drag pages into your desired page order.',
            badge: 'DRAG & DROP',
            toolId: 'reorder',
            iconName: 'Layers'
          },
          {
            id: 'opt-rotate-batch',
            title: '2. Batch Rotate Pages (+90° / -90° / 180°)',
            desc: 'Rotate selected pages or all document pages to portrait/landscape orientations.',
            badge: 'ROTATE',
            toolId: 'reorder',
            iconName: 'RotateCw'
          },
          {
            id: 'opt-crop-margins',
            title: '3. Crop Margins & Adjust Trim Box',
            desc: 'Trim unwanted white margins and set custom bleed boxes across PDF pages.',
            badge: 'CROP',
            toolId: 'crop-margins',
            iconName: 'Crop'
          }
        ]
      },
      {
        id: 'sub-convert-ocr',
        title: '🔄 Multi-Format Document Converters & OCR',
        badge: '8 CONVERTERS',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Two-way conversion between PDF, Microsoft Word, Excel, Google Docs, Plain Text, and High-Res Images.',
        iconName: 'RefreshCw',
        subSubheadings: [
          {
            id: 'opt-pdf-to-docx',
            title: '1. PDF to Word (.docx)',
            desc: 'Convert PDF text and layout into editable Microsoft Word documents.',
            badge: 'PDF ➔ DOCX',
            toolId: 'convert',
            iconName: 'FileText'
          },
          {
            id: 'opt-pdf-to-xlsx',
            title: '2. PDF to Excel (.xlsx)',
            desc: 'Extract tabular data directly into native Excel spreadsheet files.',
            badge: 'PDF ➔ XLSX',
            toolId: 'convert',
            iconName: 'FileText'
          },
          {
            id: 'opt-pdf-to-txt',
            title: '3. PDF to Text / Google Docs (.txt)',
            desc: 'Extract clean, structured prose and plain text.',
            badge: 'PDF ➔ TXT',
            toolId: 'convert',
            iconName: 'FileText'
          },
          {
            id: 'opt-pdf-to-img',
            title: '4. PDF to Image (.jpg / .png)',
            badge: 'PDF ➔ IMG',
            desc: 'Render and download PDF pages as high-resolution images.',
            toolId: 'convert',
            iconName: 'ImageIcon'
          },
          {
            id: 'opt-docx-to-pdf',
            title: '5. Word to PDF (.docx → .pdf)',
            desc: 'Convert Word documents into high-fidelity PDFs.',
            badge: 'DOCX ➔ PDF',
            toolId: 'convert',
            iconName: 'FileText'
          },
          {
            id: 'opt-xlsx-to-pdf',
            title: '6. Excel to PDF (.xlsx → .pdf)',
            desc: 'Convert spreadsheets into formatted PDF pages.',
            badge: 'XLSX ➔ PDF',
            toolId: 'convert',
            iconName: 'FileText'
          },
          {
            id: 'opt-img-to-pdf',
            title: '7. Image to PDF (.jpg / .png → .pdf)',
            desc: 'Bundle image files into a single structured PDF.',
            badge: 'IMG ➔ PDF',
            toolId: 'convert',
            iconName: 'ImageIcon'
          },
          {
            id: 'opt-office-to-jpg',
            title: '8. Office to JPEG (.docx / .xlsx → .jpg)',
            desc: 'Export Office document pages as standalone JPEG images.',
            badge: 'OFFICE ➔ JPG',
            toolId: 'convert',
            iconName: 'Layers'
          },
          {
            id: 'opt-ocr-scanner',
            title: '9. OCR Optical Character Recognition Scanner',
            desc: 'Process scanned PDF pages into searchable, copyable vector text layers.',
            badge: 'OCR SCAN',
            toolId: 'ocr-scanner',
            iconName: 'Scan'
          }
        ]
      },
      {
        id: 'sub-compress-downsample',
        title: '⚡ Compress PDF Size to Target KB',
        badge: 'COMPRESS',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Target custom KB file size, downsample raster images, and optimize vector streams.',
        iconName: 'Zap',
        subSubheadings: [
          {
            id: 'opt-compress-kb',
            title: '1. Compress PDF to Target KB Size',
            desc: 'Adjust compression target slider to reduce file size for email or web portal submission.',
            badge: 'TARGET KB',
            toolId: 'compress',
            iconName: 'Sliders'
          },
          {
            id: 'opt-compress-image',
            title: '2. Image Downsampling & DPI Optimization',
            desc: 'Reduce high-res embedded image DPI while maintaining visual clarity.',
            badge: 'DPI REDUCE',
            toolId: 'compress',
            iconName: 'Zap'
          }
        ]
      },
      {
        id: 'sub-stamps-watermark',
        title: '🏷️ Page Numbering & Watermark Seals',
        badge: 'STAMPING',
        badgeColor: 'bg-cyan-500/15 text-cyan-600 border-cyan-500/30 dark:text-cyan-400',
        description: 'Add custom header/footer page numbers and security watermark text/image overlays.',
        iconName: 'Hash',
        subSubheadings: [
          {
            id: 'opt-page-numbers',
            title: '1. Header & Footer Page Numbering',
            desc: 'Insert "Page X of Y" or custom numbered stamps at top/bottom page positions.',
            badge: 'NUMBERS',
            toolId: 'page-numbers',
            iconName: 'Hash'
          },
          {
            id: 'opt-watermark-text',
            title: '2. Custom Text & Image Watermark Overlay',
            desc: 'Overlay transparent "CONFIDENTIAL", "DRAFT", or custom logo graphics.',
            badge: 'WATERMARK',
            toolId: 'watermark-engine',
            iconName: 'Droplet'
          }
        ]
      }
    ]
  },
  {
    id: 'section-2-ai-tools',
    sectionNumber: 2,
    title: 'SECTION 2: AI Document Intelligence & Machine Learning Suite',
    subtitle: 'AI Chat Q&A, Executive Summarizer, Multi-Lingual Translator & Poster Generator',
    badge: 'AI INTELLIGENCE SUITE',
    badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
    colorGradient: 'from-purple-600 via-indigo-600 to-blue-600',
    iconName: 'Bot',
    description: 'All artificial intelligence tools grouped together: Contextual Q&A chat with page citations, executive auto-summarizer, multi-lingual translator, and AI poster/infographic generator.',
    subheadings: [
      {
        id: 'sub-ai-doc-chat',
        title: '🤖 Interactive AI Document Chat & Q&A',
        badge: 'AI CHAT',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Ask questions about contract clauses, financial figures, or research with exact page citations.',
        iconName: 'MessageSquare',
        subSubheadings: [
          {
            id: 'opt-ai-chat-main',
            title: '1. AI Document Assistant Chat & Deep Q&A',
            desc: 'Query long-form PDFs, extract specific clauses, and get page-level answers.',
            badge: 'DEEP CHAT',
            toolId: 'chat',
            iconName: 'MessageSquare'
          }
        ]
      },
      {
        id: 'sub-ai-summarizer',
        title: '📝 Executive Auto-Summarizer & Key Insights',
        badge: 'SUMMARIZER',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Extract executive summaries, bullet point takeaways, and actionable insights instantly.',
        iconName: 'Sparkles',
        subSubheadings: [
          {
            id: 'opt-ai-summarize-main',
            title: '1. Executive Auto-Summarizer',
            desc: 'Generate concise executive summaries and key decision takeaways.',
            badge: 'EXECUTIVE SUMMARY',
            toolId: 'summarizer',
            iconName: 'Sparkles'
          }
        ]
      },
      {
        id: 'sub-ai-translator',
        title: '🌐 Layout-Preserving Multi-Lingual Translator',
        badge: 'TRANSLATE',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Translate PDF documents into 50+ languages while preserving typography and formatting.',
        iconName: 'Globe',
        subSubheadings: [
          {
            id: 'opt-ai-translate-main',
            title: '1. 50+ Multi-Lingual Document Translator',
            desc: 'Translate entire documents or selected pages without distorting layout.',
            badge: 'TRANSLATION',
            toolId: 'translator',
            iconName: 'Globe'
          }
        ]
      },
      {
        id: 'sub-ai-poster-gen',
        title: '🎨 AI Poster, Diagram & Infographic Generator',
        badge: 'AI VISUALS',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Transform raw PDF text into visual infographics, summary posters, and presentation slides.',
        iconName: 'ImageIcon',
        subSubheadings: [
          {
            id: 'opt-ai-poster-main',
            title: '1. AI Document Infographic & Poster Studio',
            desc: 'Synthesize complex documents into clear, visual graphic summaries.',
            badge: 'INFOGRAPHIC',
            toolId: 'editor',
            iconName: 'ImageIcon'
          }
        ]
      }
    ]
  },
  {
    id: 'section-3-core-diagnostics',
    sectionNumber: 3,
    title: 'SECTION 3: Core PDF Diagnostics & 18 PHI Safe Harbor Suite',
    subtitle: 'All 18 PHI Safe Harbor Health Audits, Vector Syntax & Stream Diagnostics',
    badge: 'CORE DIAGNOSTICS & 18 PHI',
    badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
    colorGradient: 'from-emerald-600 via-teal-600 to-cyan-600',
    iconName: 'Stethoscope',
    description: 'All 18 Protected Health Information (PHI) Safe Harbor health diagnostics grouped together in one place alongside PDF vector syntax audits, xref recovery, and visual compare.',
    subheadings: [
      {
        id: 'sub-18-phi-diagnostics',
        title: '🩺 Complete 18 PHI Safe Harbor Health Diagnostics Suite (Grouped Together)',
        badge: '18 PHI SAFE HARBOR',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Comprehensive HIPAA §164.514(b)(2) health audit & auto-sanitization across all 18 legal PHI categories.',
        iconName: 'Shield',
        subSubheadings: [
          {
            id: 'phi-1-names',
            title: '1. Patient Names & Full Legal Identities Audit',
            desc: 'Detect and redact patient full names, initials, and legal aliases.',
            badge: 'PHI #1 NAMES',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-2-geo',
            title: '2. Geographic Addresses, Zip Codes & Counties',
            desc: 'Purge street addresses, zip codes, and geographic sub-regions.',
            badge: 'PHI #2 ADDRESS',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-3-dates',
            title: '3. Clinical Dates (Birth, Admission, Discharge & Death)',
            desc: 'Sanitize all dates related to patient care and age markers over 89.',
            badge: 'PHI #3 DATES',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-4-phone',
            title: '4. Patient Telephone & Mobile Numbers',
            desc: 'Scan and scrub domestic & international patient phone contacts.',
            badge: 'PHI #4 PHONE',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-5-fax',
            title: '5. Medical Fax Numbers',
            desc: 'Detect facsimile transmission numbers across medical records.',
            badge: 'PHI #5 FAX',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-6-email',
            title: '6. Electronic Mail (Email) Addresses',
            desc: 'Purge clinician and patient email address streams.',
            badge: 'PHI #6 EMAIL',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-7-ssn',
            title: '7. Social Security Numbers (SSN)',
            desc: 'Identify and permanently blackout 9-digit SSN identifiers.',
            badge: 'PHI #7 SSN',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-8-mrn',
            title: '8. Medical Record Numbers (MRN)',
            desc: 'Audit hospital medical record and EHR chart identifiers.',
            badge: 'PHI #8 MRN',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-9-healthplan',
            title: '9. Health Plan Beneficiary Numbers',
            desc: 'Scrub Medicare, Medicaid, and private insurance policy IDs.',
            badge: 'PHI #9 INSURANCE',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-10-account',
            title: '10. Clinical Account & Billing Numbers',
            desc: 'Scrub patient billing account and hospital visit reference numbers.',
            badge: 'PHI #10 ACCOUNT',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-11-license',
            title: '11. Certificate / Driver License Numbers',
            desc: 'Remove state license numbers and medical practitioner credentials.',
            badge: 'PHI #11 LICENSE',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-12-vehicle',
            title: '12. Vehicle Identifiers & License Plates',
            desc: 'Sanitize ambulance & patient transport vehicle serial codes.',
            badge: 'PHI #12 VEHICLE',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-13-device',
            title: '13. Medical Device & Pacemaker Serial Numbers',
            desc: 'Scrub implantable device UDI and manufacturer serial numbers.',
            badge: 'PHI #13 DEVICE',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-14-urls',
            title: '14. Web Universal Resource Locators (URLs)',
            desc: 'Sanitize patient portal URLs and external healthcare links.',
            badge: 'PHI #14 URLS',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-15-ip',
            title: '15. Internet Protocol (IP) Address Numbers',
            desc: 'Blackout telemetry IPv4/IPv6 address footprints.',
            badge: 'PHI #15 IP ADDR',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-16-biometrics',
            title: '16. Biometric Identifiers (Fingerprints & Voiceprints)',
            desc: 'Purge embedded biometric raw datasets and scans.',
            badge: 'PHI #16 BIOMETRICS',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-17-photos',
            title: '17. Full-Face Patient Photographic Images',
            desc: 'Detect and blur clinical facial photographs and dermatological images.',
            badge: 'PHI #17 PHOTOS',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          },
          {
            id: 'phi-18-unique',
            title: '18. Any Other Unique Identifying Code or Characteristic',
            desc: 'Purge custom clinical trial IDs, barcodes, and proprietary patient tags.',
            badge: 'PHI #18 UNIQUE',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          }
        ]
      },
      {
        id: 'sub-vector-syntax-health',
        title: '🔬 PDF Vector Syntax & FlateDecode Stream Audit',
        badge: 'SYNTAX AUDIT',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Inspect compressed stream buffers, indirect object trees, and recover corrupted xref structures.',
        iconName: 'Activity',
        subSubheadings: [
          {
            id: 'opt-health-audit',
            title: '1. Comprehensive PDF Vector & Syntax Audit',
            desc: 'Diagnose font encoding tables, object xref tables, and FlateDecode streams.',
            badge: 'SYNTAX AUDIT',
            toolId: 'doc-analytics',
            iconName: 'Activity'
          },
          {
            id: 'opt-pdf-compare',
            title: '2. Visual Side-by-Side PDF Compare & Diff',
            desc: 'Compare two PDFs side-by-side to highlight text changes and visual pixel differences.',
            badge: 'DIFF COMPARE',
            toolId: 'pdf-compare',
            iconName: 'Eye'
          }
        ]
      }
    ]
  },
  {
    id: 'section-4-security-encryption',
    sectionNumber: 4,
    title: 'SECTION 4: Security, AES-256 Encryption & Smart Redaction Suite',
    subtitle: 'Regex Auto-Redactor, AES Password Protection, Digital Signatures & Dynamic DRM',
    badge: 'SECURITY & ENCRYPTION',
    badgeColor: 'bg-rose-500/15 text-rose-600 border-rose-500/30 dark:text-rose-400',
    colorGradient: 'from-rose-600 via-pink-600 to-amber-600',
    iconName: 'Shield',
    description: 'Regex-powered automatic redaction of sensitive data, AES-256 encryption, password removal, PKCS#7 digital signature embedding, and dynamic DRM expiration rules.',
    subheadings: [
      {
        id: 'sub-redact-purge',
        title: '🛡️ Smart Regex Redaction & Metadata Purge',
        badge: 'REDACTION',
        badgeColor: 'bg-rose-500/15 text-rose-600 border-rose-500/30 dark:text-rose-400',
        description: 'Regex-powered automatic redaction of SSNs, emails, and sensitive metadata sanitization.',
        iconName: 'Shield',
        subSubheadings: [
          {
            id: 'opt-regex-redact',
            title: '1. Smart Regex Text & Pattern Redactor',
            desc: 'Automatically detect and permanently blackout SSNs, credit cards, emails, and phone numbers.',
            badge: 'SMART REDACT',
            toolId: 'smart-redact',
            iconName: 'Shield'
          },
          {
            id: 'opt-sanitize-purge',
            title: '2. Sanitize & Purge Hidden PDF Metadata',
            desc: 'Wipe document revisions, author info, hidden bookmarks, and embedded XML streams.',
            badge: 'SANITY PURGE',
            toolId: 'sanitize-purge',
            iconName: 'RotateCcw'
          }
        ]
      },
      {
        id: 'sub-encrypt-pass',
        title: '🔒 Password Protection & Encryption',
        badge: 'ENCRYPTION',
        badgeColor: 'bg-amber-500/15 text-amber-600 border-amber-500/30 dark:text-amber-400',
        description: 'Encrypt PDFs with AES-256 bit passwords or unlock password-protected files.',
        iconName: 'Lock',
        subSubheadings: [
          {
            id: 'opt-encrypt-pwd',
            title: '1. Encrypt PDF with AES-256 Password',
            desc: 'Apply strong owner and user password permissions to prevent unauthorized printing or editing.',
            badge: 'ENCRYPT',
            toolId: 'protect',
            iconName: 'Lock'
          },
          {
            id: 'opt-unlock-pwd',
            title: '2. Unlock Password Protected PDF',
            desc: 'Remove password restrictions with valid owner credentials.',
            badge: 'UNLOCK',
            toolId: 'unlock',
            iconName: 'KeyRound'
          }
        ]
      },
      {
        id: 'sub-sign-drm-control',
        title: '✒️ Digital PKCS#7 Signatures & Dynamic DRM',
        badge: 'SIGNATURES & DRM',
        badgeColor: 'bg-red-500/15 text-red-600 border-red-500/30 dark:text-red-400',
        description: 'Apply cryptographic digital signatures and set dynamic DRM document expiration rules.',
        iconName: 'FileSignature',
        subSubheadings: [
          {
            id: 'opt-digital-signer',
            title: '1. Cryptographic Digital Signature Engine',
            desc: 'Embed cryptographic PKCS#7 digital signature certificates into PDF documents.',
            badge: 'DIGITAL SIGN',
            toolId: 'digital-signer',
            iconName: 'FileSignature'
          },
          {
            id: 'opt-dynamic-drm',
            title: '2. Dynamic DRM & Document Expiration Control',
            desc: 'Set view limits, expiration dates, and hardware-locking parameters on PDF files.',
            badge: 'DRM CONTROL',
            toolId: 'dynamic-drm',
            iconName: 'ShieldAlert'
          }
        ]
      }
    ]
  },
  {
    id: 'section-5-healthcare-hub',
    sectionNumber: 5,
    title: 'SECTION 5: Healthcare, Life Sciences & Clinical Compliance Hub',
    subtitle: 'HIPAA §164.514(b)(2) Safe Harbor, HL7/FHIR, DICOM Medical Viewer & FDA 21 CFR Part 11',
    badge: 'HEALTHCARE & LIFE SCIENCES',
    badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
    colorGradient: 'from-emerald-600 via-teal-600 to-green-600',
    iconName: 'Stethoscope',
    description: 'Specialized healthcare & clinical research tools: HIPAA §164.514(b)(2) Safe Harbor sanitization, HL7/FHIR data structure converter, DICOM medical X-Ray viewer, 21 CFR Part 11 FDA compliance, and e-Prescription verifier.',
    subheadings: [
      {
        id: 'sub-health-hipaa-hub',
        title: '🏥 HIPAA §164.514(b)(2) Safe Harbor Audit & Sanitizer',
        badge: 'HIPAA SAFE HARBOR',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Sanitize patient health records in strict compliance with United States federal HIPAA standards.',
        iconName: 'Shield',
        subSubheadings: [
          {
            id: 'opt-health-hipaa-tool',
            title: '1. HIPAA §164.514(b)(2) Safe Harbor Sanitizer',
            desc: 'Audit and scrub medical record numbers, dates, patient identifiers, and health plan IDs.',
            badge: 'HIPAA SCRUB',
            toolId: 'health-hipaa',
            iconName: 'Shield'
          }
        ]
      },
      {
        id: 'sub-health-fhir-hub',
        title: '🧬 HL7 & FHIR Interoperability Clinical Data Converter',
        badge: 'HL7 & FHIR',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Extract HL7 v2/v3 segments and FHIR JSON clinical resources from embedded PDF tables.',
        iconName: 'Activity',
        subSubheadings: [
          {
            id: 'opt-health-fhir-tool',
            title: '1. HL7 / FHIR Clinical Data Extractor & Converter',
            desc: 'Parse EHR health record tables into standard HL7 messages and FHIR JSON objects.',
            badge: 'HL7 / FHIR',
            toolId: 'health-fhir',
            iconName: 'Activity'
          }
        ]
      },
      {
        id: 'sub-health-dicom-hub',
        title: '🩺 DICOM Medical Imaging & X-Ray Attachment Viewer',
        badge: 'DICOM IMAGING',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Inspect embedded DICOM medical imaging attachments, X-Rays, and CT scan slice metadata.',
        iconName: 'Eye',
        subSubheadings: [
          {
            id: 'opt-health-dicom-tool',
            title: '1. DICOM Medical Imaging Inspection Tool',
            desc: 'View DICOM headers, image frames, and modality tags directly inside clinical PDFs.',
            badge: 'DICOM VIEW',
            toolId: 'health-dicom',
            iconName: 'Eye'
          }
        ]
      },
      {
        id: 'sub-health-audit-hub',
        title: '📜 21 CFR Part 11 FDA Electronic Signature & Audit Trail',
        badge: '21 CFR PART 11',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Verify FDA 21 CFR Part 11 compliant electronic signature manifests and record integrity logs.',
        iconName: 'FileCheck',
        subSubheadings: [
          {
            id: 'opt-health-audit-tool',
            title: '1. 21 CFR Part 11 Electronic Signature & Audit Trail Verification',
            desc: 'Ensure clinical trial documents adhere to FDA electronic recordkeeping requirements.',
            badge: 'FDA AUDIT',
            toolId: 'health-audit',
            iconName: 'FileCheck'
          }
        ]
      },
      {
        id: 'sub-health-eprescribe-hub',
        title: '💊 e-Prescription & DEA Controlled Substance Verifier',
        badge: 'E-PRESCRIBE',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Verify DEA Schedule II-V digital signatures, prescriber NPI, and DEA registration numbers.',
        iconName: 'CheckSquare',
        subSubheadings: [
          {
            id: 'opt-health-eprescribe-tool',
            title: '1. DEA Schedule II-V Controlled Substance e-Prescription Verifier',
            desc: 'Verify prescriber identity, NPI registry, and digital prescription manifest integrity.',
            badge: 'DEA VERIFY',
            toolId: 'health-eprescribe',
            iconName: 'CheckSquare'
          }
        ]
      }
    ]
  },
  {
    id: 'section-6-gov-compliance-hub',
    sectionNumber: 6,
    title: 'SECTION 6: Government & Defense Compliance Hub',
    subtitle: 'NIST FIPS 140-3 Cryptography, FOIA (b)(1)-(b)(9) Redactor, Dynamic CUI Banners & PIV/CAC',
    badge: 'GOVERNMENT & DEFENSE',
    badgeColor: 'bg-blue-500/15 text-blue-600 border-blue-500/30 dark:text-blue-400',
    colorGradient: 'from-blue-700 via-indigo-700 to-slate-900',
    iconName: 'Flag',
    description: 'Federal government & defense sector compliance: NIST FIPS 140-3 cryptographic enforcer, Freedom of Information Act (FOIA) automated redactor with exemption codes (b)(1)-(b)(9), Controlled Unclassified Information (CUI) banner engine, Section 508 VPAT accessibility auditor, and PIV/CAC smart card identity signer.',
    subheadings: [
      {
        id: 'sub-gov-fips-hub',
        title: '🔐 FIPS 140-3 Cryptographic Validation & Enforcer',
        badge: 'FIPS 140-3',
        badgeColor: 'bg-blue-500/15 text-blue-600 border-blue-500/30 dark:text-blue-400',
        description: 'Verify NIST FIPS 140-3 hardware & software cryptographic module compliance across document streams.',
        iconName: 'Shield',
        subSubheadings: [
          {
            id: 'opt-gov-fips-tool-spec',
            title: '1. FIPS 140-3 Cryptographic Validation Enforcer',
            desc: 'Audit AES-256 and SHA-2 cryptographic algorithms against NIST FIPS requirements.',
            badge: 'FIPS ENFORCE',
            toolId: 'gov-fips',
            iconName: 'Shield'
          }
        ]
      },
      {
        id: 'sub-gov-foia-hub',
        title: '🏛️ Automated FOIA Redactor with Exemption Codes (b)(1)-(b)(9)',
        badge: 'FOIA REDACTOR',
        badgeColor: 'bg-blue-500/15 text-blue-600 border-blue-500/30 dark:text-blue-400',
        description: 'Apply official FOIA statutory exemption stamps (b)(1) Classified through (b)(9) Wells Data.',
        iconName: 'Flag',
        subSubheadings: [
          {
            id: 'opt-gov-foia-tool-spec',
            title: '1. Automated FOIA Exemption Code Redactor',
            desc: 'Select statutory FOIA exemption reasons and auto-stamp blackout redactions.',
            badge: 'FOIA STAMPS',
            toolId: 'gov-foia',
            iconName: 'Flag'
          }
        ]
      },
      {
        id: 'sub-gov-cui-hub',
        title: '🏷️ Dynamic CUI (Controlled Unclassified Information) Banners',
        badge: 'CUI BANNERS',
        badgeColor: 'bg-blue-500/15 text-blue-600 border-blue-500/30 dark:text-blue-400',
        description: 'Generate standardized CUI top/bottom header banners, warning block overlays, and distribution markings.',
        iconName: 'ShieldAlert',
        subSubheadings: [
          {
            id: 'opt-gov-cui-tool-spec',
            title: '1. Dynamic CUI Header & Footer Banner Engine',
            desc: 'Inject mandatory DoD/NIST CUI classification banners across every document page.',
            badge: 'CUI MARKINGS',
            toolId: 'gov-cui',
            iconName: 'ShieldAlert'
          }
        ]
      },
      {
        id: 'sub-gov-508-hub',
        title: '♿ Section 508 VPAT Accessibility Auditor & Tag Tree Repair',
        badge: 'SECTION 508',
        badgeColor: 'bg-blue-500/15 text-blue-600 border-blue-500/30 dark:text-blue-400',
        description: 'Inspect PDF logical structure tags, screen reader order, alt-text markers, and contrast ratios.',
        iconName: 'FileCheck',
        subSubheadings: [
          {
            id: 'opt-gov-508-tool-spec',
            title: '1. Section 508 VPAT Accessibility Auditor',
            desc: 'Verify PDF/UA screen reader compliance and generate official VPAT reporting audit logs.',
            badge: 'VPAT AUDIT',
            toolId: 'gov-508',
            iconName: 'FileCheck'
          }
        ]
      },
      {
        id: 'sub-gov-piv-hub',
        title: '🪪 PIV / CAC Smart Card Identity Signer & PKI Verification',
        badge: 'PIV / CAC',
        badgeColor: 'bg-blue-500/15 text-blue-600 border-blue-500/30 dark:text-blue-400',
        description: 'Enforce hardware-backed identity signing for government employee PIV/CAC smart cards.',
        iconName: 'KeyRound',
        subSubheadings: [
          {
            id: 'opt-gov-piv-tool-spec',
            title: '1. PIV / CAC Smart Card Digital Identity Signer',
            desc: 'Connect USB smart card readers or PIV tokens to apply hardware-backed digital signatures.',
            badge: 'SMART CARD',
            toolId: 'gov-piv',
            iconName: 'KeyRound'
          }
        ]
      }
    ]
  },
  {
    id: 'section-7-academic-research-hub',
    sectionNumber: 7,
    title: 'SECTION 7: Academic & STEM Research Suite',
    subtitle: 'LaTeX Formula Compiler, Turnitin Similarity Auditor, BibTeX & FERPA Anonymizer',
    badge: 'ACADEMIC & RESEARCH',
    badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
    colorGradient: 'from-purple-700 via-indigo-700 to-violet-900',
    iconName: 'GraduationCap',
    description: 'Academic university & research laboratory tools: LaTeX vector formula compiler, Turnitin plagiarism citation & similarity auditor, BibTeX bibliography extractor, arXiv metadata normalizer, and FERPA double-blind peer review anonymizer.',
    subheadings: [
      {
        id: 'sub-edu-latex-hub',
        title: '📐 LaTeX Vector Formula & Mathematical Equation Compiler',
        badge: 'LATEX ENGINE',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Compile raw LaTeX equation strings into crisp vector math layers and inline symbols.',
        iconName: 'GraduationCap',
        subSubheadings: [
          {
            id: 'opt-edu-latex-tool-spec',
            title: '1. LaTeX Vector Equation Compiler & Math Renderer',
            desc: 'Inject vector mathematical formulas and physics equations directly into research PDFs.',
            badge: 'LATEX MATH',
            toolId: 'edu-latex',
            iconName: 'GraduationCap'
          }
        ]
      },
      {
        id: 'sub-edu-turnitin-hub',
        title: '🔍 Turnitin Citation & Plagiarism Similarity Auditor',
        badge: 'TURNITIN AUDIT',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Scan academic manuscripts against publication citation indices and neural AI text probability maps.',
        iconName: 'Search',
        subSubheadings: [
          {
            id: 'opt-edu-turnitin-tool-spec',
            title: '1. Turnitin Plagiarism & Citation Similarity Auditor',
            desc: 'Detect un-cited verbatim text, paraphrased passages, and generated AI probability scores.',
            badge: 'PLAGIARISM CHECK',
            toolId: 'edu-turnitin',
            iconName: 'Search'
          }
        ]
      },
      {
        id: 'sub-edu-bibtex-hub',
        title: '📚 BibTeX Bibliography Extractor & Reference Formatter',
        badge: 'BIBTEX CITATIONS',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Extract footnotes, in-text citations, and generate clean .bib BibTeX reference files.',
        iconName: 'FileText',
        subSubheadings: [
          {
            id: 'opt-edu-bibtex-tool-spec',
            title: '1. BibTeX Reference Extractor & Citation Manager',
            desc: 'Parse footnotes and endnotes into APA, IEEE, MLA, and BibTeX structured formats.',
            badge: 'BIBTEX FORMAT',
            toolId: 'edu-bibtex',
            iconName: 'FileText'
          }
        ]
      },
      {
        id: 'sub-edu-arxiv-hub',
        title: '🌌 arXiv Scientific Manuscript & Metadata Normalizer',
        badge: 'ARXIV MANUSCRIPT',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Normalize pre-print manuscripts to conform with arXiv and IEEE publisher layout specifications.',
        iconName: 'Globe',
        subSubheadings: [
          {
            id: 'opt-edu-arxiv-tool-spec',
            title: '1. arXiv Pre-print Manuscript & Source Package Normalizer',
            desc: 'Check PDF font embedding, figure resolution, and generate submission manifest files.',
            badge: 'ARXIV NORM',
            toolId: 'edu-arxiv',
            iconName: 'Globe'
          }
        ]
      },
      {
        id: 'sub-edu-anonymizer-hub',
        title: '🙈 FERPA Student Double-Blind Peer Review Anonymizer',
        badge: 'FERPA PRIVACY',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Sanitize student author names, university affiliations, and metadata for blind peer reviews.',
        iconName: 'Eye',
        subSubheadings: [
          {
            id: 'opt-edu-anonymizer-tool-spec',
            title: '1. FERPA Student Identity Anonymizer for Peer Reviews',
            desc: 'Strip student IDs, class markers, and personal info for double-blind referee evaluations.',
            badge: 'BLIND REVIEW',
            toolId: 'edu-anonymizer',
            iconName: 'Eye'
          }
        ]
      }
    ]
  },
  {
    id: 'section-8-financial-hub',
    sectionNumber: 8,
    title: 'SECTION 8: Financial & Banking Compliance Hub',
    subtitle: 'SEC Inline XBRL Tagging, Anti-Money Laundering (AML), Invoice Parsing & SOC2',
    badge: 'FINANCIAL & BANKING',
    badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
    colorGradient: 'from-emerald-700 via-teal-700 to-cyan-900',
    iconName: 'DollarSign',
    description: 'Corporate financial & banking tools: SEC 10-K/10-Q Inline XBRL taxonomy tagging, Anti-Money Laundering (AML) & GLBA masking filter, automated invoice/receipt data parser, RFC 3161 cryptographic timestamping, and SOC2 Type II audit logger.',
    subheadings: [
      {
        id: 'sub-fin-xbrl-hub',
        title: '📊 SEC Inline XBRL Financial Taxonomy Tagging Engine',
        badge: 'SEC IXBRL',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Tag corporate financial tables (balance sheets, income statements) with SEC GAAP/IFRS Inline XBRL tags.',
        iconName: 'DollarSign',
        subSubheadings: [
          {
            id: 'opt-fin-xbrl-tool-spec',
            title: '1. SEC Inline XBRL Financial Tagging Engine',
            desc: 'Map financial figures to official US-GAAP & IFRS taxonomy items for EDGAR filing.',
            badge: 'IXBRL TAGGING',
            toolId: 'fin-xbrl',
            iconName: 'DollarSign'
          }
        ]
      },
      {
        id: 'sub-fin-aml-hub',
        title: '🛡️ Anti-Money Laundering (AML) & GLBA Financial Masking Filter',
        badge: 'AML & GLBA',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Mask bank account numbers, credit card PANs, and wire routing codes per GLBA guidelines.',
        iconName: 'Shield',
        subSubheadings: [
          {
            id: 'opt-fin-aml-tool-spec',
            title: '1. Anti-Money Laundering (AML) & GLBA Masking Engine',
            desc: 'Detect and obscure IBANs, SWIFT codes, and cardholder data across financial PDF statements.',
            badge: 'FINANCIAL MASK',
            toolId: 'fin-aml',
            iconName: 'Shield'
          }
        ]
      },
      {
        id: 'sub-fin-invoice-hub',
        title: '🧾 Automated PDF Invoice & Financial Receipt Parser',
        badge: 'INVOICE PARSER',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Extract line items, tax subtotals, vendor tax IDs, and dates from invoices into structured JSON/CSV.',
        iconName: 'FileText',
        subSubheadings: [
          {
            id: 'opt-fin-invoice-tool-spec',
            title: '1. Automated PDF Invoice & Receipt Structured Data Parser',
            desc: 'Parse unstructured PDF invoice documents into tabular CSV rows and accounting datasets.',
            badge: 'PARSE INVOICE',
            toolId: 'fin-invoice',
            iconName: 'FileText'
          }
        ]
      },
      {
        id: 'sub-fin-timestamp-hub',
        title: '⏱️ RFC 3161 Qualified Cryptographic Timestamping Engine',
        badge: 'RFC 3161 TIME',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Bind cryptographic TSA time-stamps to prove document existence at an exact universal time.',
        iconName: 'RotateCw',
        subSubheadings: [
          {
            id: 'opt-fin-timestamp-tool-spec',
            title: '1. RFC 3161 Cryptographic Timestamping Engine',
            desc: 'Query external Time Stamping Authorities (TSA) to embed trusted timestamps in financial records.',
            badge: 'TIMESTAMP',
            toolId: 'fin-timestamp',
            iconName: 'RotateCw'
          }
        ]
      },
      {
        id: 'sub-fin-soc2-hub',
        title: '📋 SOC2 Type II Audit Logging & Compliance Monitor',
        badge: 'SOC2 TYPE II',
        badgeColor: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
        description: 'Record tamper-evident operation logs and data access boundaries for SOC2 compliance audits.',
        iconName: 'CheckSquare',
        subSubheadings: [
          {
            id: 'opt-fin-soc2-tool-spec',
            title: '1. SOC2 Type II Audit Logging & Security Monitor',
            desc: 'Generate audit trail manifests documenting user actions, document hashes, and access controls.',
            badge: 'SOC2 LOGS',
            toolId: 'fin-soc2',
            iconName: 'CheckSquare'
          }
        ]
      }
    ]
  },
  {
    id: 'section-9-engineering-cad-media-hub',
    sectionNumber: 9,
    title: 'SECTION 9: Engineering, CAD & Creative Media Production Studio',
    subtitle: 'CAD Blueprint Measurement, CMYK Preflight, Bleed/Crop Marks, Font Curves & High DPI',
    badge: 'ENGINEERING, CAD & MEDIA',
    badgeColor: 'bg-cyan-500/15 text-cyan-600 border-cyan-500/30 dark:text-cyan-400',
    colorGradient: 'from-cyan-600 via-teal-600 to-blue-700',
    iconName: 'Ruler',
    description: 'Architectural, engineering & print production studio: CAD blueprint measurement suite (perimeter, area, volume & scale), CMYK color preflight inspector, 3mm/5mm print bleed & crop mark generator, font embedding & glyph curve converter, press-ready DPI rasterizer (300/600/1200 DPI), and asset package bundler.',
    subheadings: [
      {
        id: 'sub-cad-blueprint-hub',
        title: '📐 CAD & Blueprint Measurement Suite (Perimeter, Area & Scale)',
        badge: 'CAD & BLUEPRINT',
        badgeColor: 'bg-cyan-500/15 text-cyan-600 border-cyan-500/30 dark:text-cyan-400',
        description: 'Architectural tools to compute perimeter, area, volume, and custom scale measurements on blueprint vectors.',
        iconName: 'Ruler',
        subSubheadings: [
          {
            id: 'opt-cad-blueprint-tool-spec',
            title: '1. CAD & Blueprint Scale & Measurement Suite',
            desc: 'Compute perimeter, room square footage, volume, and custom architectural scales.',
            badge: 'BLUEPRINT MEASURE',
            toolId: 'blueprint-measurer',
            iconName: 'Ruler'
          }
        ]
      },
      {
        id: 'sub-media-cmyk-hub',
        title: '🎨 CMYK Preflight & Color Separation Auditor',
        badge: 'CMYK PREFLIGHT',
        badgeColor: 'bg-cyan-500/15 text-cyan-600 border-cyan-500/30 dark:text-cyan-400',
        description: 'Inspect RGB vs CMYK color spaces, spot channels, and Total Ink Coverage (TAC %).',
        iconName: 'Palette',
        subSubheadings: [
          {
            id: 'opt-media-cmyk-tool-spec',
            title: '1. CMYK Preflight & Color Separation Inspector',
            desc: 'Verify press color separation channels, detect RGB images, and audit Total Ink Coverage.',
            badge: 'COLOR PREFLIGHT',
            toolId: 'media-cmyk',
            iconName: 'Palette'
          }
        ]
      },
      {
        id: 'sub-media-bleed-hub',
        title: '✂️ Bleed, Crop Mark & Trim Line Generator',
        badge: 'PRINT BLEED',
        badgeColor: 'bg-cyan-500/15 text-cyan-600 border-cyan-500/30 dark:text-cyan-400',
        description: 'Inject professional print shop bleed zones (3mm/5mm), registration targets, and crop marks.',
        iconName: 'Crop',
        subSubheadings: [
          {
            id: 'opt-media-bleed-tool-spec',
            title: '1. Professional Print Bleed & Crop Mark Generator',
            desc: 'Add trim lines, bleed margins, color bars, and registration marks for print production.',
            badge: 'BLEED MARKS',
            toolId: 'media-bleed',
            iconName: 'Crop'
          }
        ]
      },
      {
        id: 'sub-media-font-hub',
        title: '🔤 Font Embedding & Subsetting Glyph Inspector',
        badge: 'FONT INSPECTOR',
        badgeColor: 'bg-cyan-500/15 text-cyan-600 border-cyan-500/30 dark:text-cyan-400',
        description: 'Analyze embedded font matrices, repair missing subsets, and outline text to vector curves.',
        iconName: 'Type',
        subSubheadings: [
          {
            id: 'opt-media-font-tool-spec',
            title: '1. Font Embedding & Vector Curve Converter',
            desc: 'Inspect embedded font subsets and convert font glyphs to vector outlines to eliminate font errors.',
            badge: 'FONT OUTLINES',
            toolId: 'media-font',
            iconName: 'Type'
          }
        ]
      },
      {
        id: 'sub-media-dpi-hub',
        title: '⚡ High-Resolution DPI Press-Ready Rasterizer',
        badge: 'HIGH DPI',
        badgeColor: 'bg-cyan-500/15 text-cyan-600 border-cyan-500/30 dark:text-cyan-400',
        description: 'Re-sample document layers at press-ready resolutions (300 DPI, 600 DPI, 1200 DPI).',
        iconName: 'Zap',
        subSubheadings: [
          {
            id: 'opt-media-dpi-tool-spec',
            title: '1. High-Resolution 300 / 600 / 1200 DPI Rasterizer',
            desc: 'Render document pages at ultra-high resolution for commercial printing presses.',
            badge: '300/600 DPI',
            toolId: 'media-dpi',
            iconName: 'Zap'
          }
        ]
      },
      {
        id: 'sub-media-bundle-hub',
        title: '📦 Dynamic Asset Package & Print Spec Bundler',
        badge: 'PRINT BUNDLE',
        badgeColor: 'bg-cyan-500/15 text-cyan-600 border-cyan-500/30 dark:text-cyan-400',
        description: 'Bundle PDF with linked vector assets, ICC color profiles, and print spec sheets into a ZIP archive.',
        iconName: 'FolderArchive',
        subSubheadings: [
          {
            id: 'opt-media-bundle-tool-spec',
            title: '1. Asset Package & ICC Profile ZIP Bundler',
            desc: 'Export a complete print production package containing PDF, ICC profiles, fonts, and specs.',
            badge: 'ZIP PACKAGE',
            toolId: 'media-bundle',
            iconName: 'FolderArchive'
          }
        ]
      }
    ]
  },
  {
    id: 'section-10-quantum-cryptography-zkd-vault',
    sectionNumber: 10,
    title: 'SECTION 10: Quantum Cryptography & Zero-Knowledge Vault',
    subtitle: 'NIST PQC ML-KEM Shield, ZK-Proof Redactor, Dark-Data Ghost Extractor, Polymorphic Watermark & Timelock',
    badge: 'QUANTUM & ZK-VAULT',
    badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
    colorGradient: 'from-purple-600 via-indigo-600 to-fuchsia-700',
    iconName: 'KeyRound',
    description: 'Next-generation privacy & quantum-resistant security suite: NIST PQC post-quantum encryption shield, zero-knowledge proof verification redactor, raw PDF binary dark-data ghost image extractor, imperceptible polymorphic steganographic watermarking, and ephemeral cryptographic self-destruct timelocks.',
    subheadings: [
      {
        id: 'sub-zkd-pqc-shield-hub',
        title: '⚛️ Post-Quantum Encryption Shield (NIST PQC ML-KEM / Kyber)',
        badge: 'NIST PQC',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Encrypt PDF files using quantum-resistant lattice algorithms (ML-KEM / Kyber) to safeguard sensitive documents against future quantum attacks.',
        iconName: 'Shield',
        subSubheadings: [
          {
            id: 'opt-zkd-pqc-tool-spec',
            title: '1. Post-Quantum Encryption Shield (NIST PQC ML-KEM)',
            desc: 'Encrypt sensitive PDFs using quantum-resistant algorithms so documents remain secure even against future quantum computing decryption attacks.',
            badge: 'PQC SHIELD',
            toolId: 'zkd-pqc-shield',
            iconName: 'Shield'
          }
        ]
      },
      {
        id: 'sub-zkd-zkp-redactor-hub',
        title: '🔒 Zero-Knowledge Proof (ZKP) Redactor',
        badge: 'ZK-PROOF',
        badgeColor: 'bg-indigo-500/15 text-indigo-600 border-indigo-500/30 dark:text-indigo-400',
        description: 'Generate cryptographic ZK-Proofs verifying document assertions without revealing underlying sensitive text or personal identity data.',
        iconName: 'KeyRound',
        subSubheadings: [
          {
            id: 'opt-zkd-zkp-tool-spec',
            title: '1. Zero-Knowledge Proof (ZKP) Fact Verifier',
            desc: 'Generates a cryptographic ZK-Proof verifying a document contains specific facts (like income > $50k or valid ID) without revealing sensitive PDF text.',
            badge: 'ZK-PROOF',
            toolId: 'zkd-zkp-redactor',
            iconName: 'KeyRound'
          }
        ]
      },
      {
        id: 'sub-zkd-ghost-extractor-hub',
        title: '👻 Dark-Data Ghost Image Extractor',
        badge: 'GHOST EXTRACTOR',
        badgeColor: 'bg-fuchsia-500/15 text-fuchsia-600 border-fuchsia-500/30 dark:text-fuchsia-400',
        description: 'Deep scan raw PDF binary streams to recover lost vector paths, unlinked thumbnail caches, or historical micro-edits left behind by photo editors.',
        iconName: 'Eye',
        subSubheadings: [
          {
            id: 'opt-zkd-ghost-tool-spec',
            title: '1. Dark-Data Ghost Image & Stream Extractor',
            desc: 'Scans raw PDF binary streams to recover lost vector paths, unlinked thumbnail caches, or historical micro-edits left behind by photo editors.',
            badge: 'GHOST EXTRACTOR',
            toolId: 'zkd-ghost-extractor',
            iconName: 'Eye'
          }
        ]
      },
      {
        id: 'sub-zkd-polymorphic-watermark-hub',
        title: '🕵️ Polymorphic Steganographic Watermarker',
        badge: 'STEGANO NOISE',
        badgeColor: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
        description: 'Inject dynamically generated, imperceptible steganographic noise into document backgrounds to trace leaks back to recipient sessions.',
        iconName: 'Sparkles',
        subSubheadings: [
          {
            id: 'opt-zkd-polymorphic-tool-spec',
            title: '1. Polymorphic Steganographic Watermarker',
            desc: 'Injects dynamically generated, imperceptible steganographic noise into document backgrounds that traces leaks back to specific recipient sessions.',
            badge: 'STEGANO TRACER',
            toolId: 'zkd-polymorphic-watermark',
            iconName: 'Sparkles'
          }
        ]
      },
      {
        id: 'sub-zkd-timelock-hub',
        title: '⏳ Ephemeral Self-Destruct Timelock',
        badge: 'SELF-DESTRUCT',
        badgeColor: 'bg-rose-500/15 text-rose-600 border-rose-500/30 dark:text-rose-400',
        description: 'Embed smart cryptographic keys into the PDF header that permanently lock or scramble rendering after a specific timestamp or access threshold.',
        iconName: 'Lock',
        subSubheadings: [
          {
            id: 'opt-zkd-timelock-tool-spec',
            title: '1. Ephemeral Self-Destruct Timelock',
            desc: 'Embeds smart cryptographic keys into the PDF header that permanently lock or scramble content rendering after a specific timestamp or access threshold.',
            badge: 'SELF-DESTRUCT',
            toolId: 'zkd-timelock',
            iconName: 'Lock'
          }
        ]
      }
    ]
  }
];
