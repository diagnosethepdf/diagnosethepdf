import { PDFDocument, StandardFonts } from 'pdf-lib';

export let cachedA4Bytes: Uint8Array | null = null;
export let cachedA3Bytes: Uint8Array | null = null;
export let cachedA1Bytes: Uint8Array | null = null;
export let cachedLetterBytes: Uint8Array | null = null;
export let cachedA5Bytes: Uint8Array | null = null;

export async function getCached50PagePdf(type: string): Promise<ArrayBuffer> {
  const generate = async (width: number, height: number, label: string) => {
    const pdfDoc = await PDFDocument.create();
    const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
    for (let i=0; i<52; i++) { // > 50 pages
      const page = pdfDoc.addPage([width, height]);
      page.drawText(`Document: ${label} - Page ${i+1}`, { x: 50, y: height - 50, size: 18, font: helveticaFont });
    }
    return await pdfDoc.save();
  };

  let bytes: Uint8Array;
  if (type === 'A4') {
    if (!cachedA4Bytes) cachedA4Bytes = await generate(595, 842, 'A4 Format');
    bytes = cachedA4Bytes;
  } else if (type === 'A3') {
    if (!cachedA3Bytes) cachedA3Bytes = await generate(842, 1191, 'A3 Format');
    bytes = cachedA3Bytes;
  } else if (type === 'A1') {
    if (!cachedA1Bytes) cachedA1Bytes = await generate(1684, 2384, 'A1 Format');
    bytes = cachedA1Bytes;
  } else if (type === 'A5') {
    if (!cachedA5Bytes) cachedA5Bytes = await generate(420, 595, 'A5 Format');
    bytes = cachedA5Bytes;
  } else if (type === 'Letter') {
    if (!cachedLetterBytes) cachedLetterBytes = await generate(612, 792, 'Letter Format');
    bytes = cachedLetterBytes;
  } else {
    if (!cachedA4Bytes) cachedA4Bytes = await generate(595, 842, 'A4 Format');
    bytes = cachedA4Bytes;
  }
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}
