/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PDFTextRun {
  id: string;
  str: string;
  transform: number[];
  width: number;
  height: number;
  familyGuess: 'sans' | 'serif' | 'mono';
  boldGuess: boolean;
  italicGuess: boolean;
  fontFamily?: string;
  baseLeft: number;
  baseTop: number;
  angleRad: number;
  fontHeightPx: number;
  widthPx: number;
}

export interface PageEditData {
  runs: PDFTextRun[];
  images: PDFImageObject[];
}

export interface PDFImageObject {
  id: string;
  transform: number[];
  width: number;
  height: number;
  isDiagram?: boolean;
  diagType?: 'grid-horizontal' | 'grid-vertical' | 'table-cell' | 'checkbox' | 'icon-bullet' | 'diagram-generic';
  diagLabel?: string;
}

export interface ImageEditOverride {
  pageIdx: number;
  imageBytes?: string; // Base64 data URL
  imageType?: 'png' | 'jpeg';
  transform: number[];
  width: number;
  height: number;
  isDeleted?: boolean;
  outlineColor?: string;
  outlineWidth?: number;
  bgColor?: string;
  bgColor2?: string;
  bgStyle?: 'solid' | 'split-h' | 'split-v' | 'gradient-h' | 'gradient-v' | 'transparent';
  bgSplitRatio?: number;
}

export interface ImageEditMap {
  [imageId: string]: ImageEditOverride;
}

export interface TextEditOverride {
  pageIdx: number;
  newText: string;
  family: 'sans' | 'serif' | 'mono' | 'calibri' | 'arial' | 'times' | 'georgia' | 'courier' | 'jakarta' | string;
  bold: boolean;
  italic: boolean;
  underline?: boolean;
  strikethrough?: boolean;
  noCover: boolean;
  sizeMul: number;
  color: string;
  bg: string;
  bgMode?: 'auto' | 'custom' | 'transparent';
  alignment?: 'left' | 'center' | 'right' | 'justify';
  lineHeight?: number;
  letterSpacing?: number;
  transform: number[];
  width: number;
  height: number;
  stretch?: number; // Optional horizontal stretch/scale factor (e.g. 0.5 to 2.5)
}

export interface EditMap {
  [runId: string]: TextEditOverride;
}

export interface PopupState {
  id: string;
  pageIdx: number;
  x: number;
  y: number;
  rect: { left: number; top: number; right: number; bottom: number };
}

export interface PageNumberingState {
  enabled: boolean;
  style: 'standard' | 'of-total' | 'boxed';
  position: 'bottom-center' | 'bottom-right' | 'bottom-left' | 'top-center' | 'top-right' | 'top-left';
  useAllPages: boolean;
  startPage: number;
  endPage: number;
  color: string;
}

export interface FindReplaceState {
  findText: string;
  replaceText: string;
  statusMsg: string;
  matchCount: number;
}


