import React, { useState } from 'react';

export const LiveSignaturePreviewer = ({
  activeDocument,
  currentPreset,
}: {
  activeDocument: any;
  currentPreset: any;
}) => {
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);

  if (!activeDocument) return null;

  return (
    <div className="mt-6 border border-pink-500/30 bg-gray-900/80 p-4 rounded-xl text-white">
      <div className="flex justify-between items-center mb-3">
        <div>
          <h4 className="font-bold text-sm text-pink-400">
            👁️ Live Document Stamping Preview
          </h4>
          <p className="text-xs text-gray-400">
            Previewing: <span className="text-gray-200">{activeDocument.name}</span> ({activeDocument.detectedFormat})
          </p>
        </div>
        
        {/* Toggle Modal Preview */}
        <button
          onClick={() => setIsPreviewModalOpen(true)}
          className="bg-pink-600 hover:bg-pink-500 text-white text-xs px-3 py-1.5 rounded-lg font-semibold transition"
        >
          🔍 Inspect Full Page Preview
        </button>
      </div>

      {/* Embedded Live Preview Canvas */}
      <div className="relative w-full overflow-hidden rounded-lg bg-gray-950 border border-gray-800 flex items-center justify-center p-4 min-h-[250px]">
        {/* Actual Document Page Background */}
        <div
          className="relative bg-white shadow-2xl transition-all duration-200"
          style={{
            aspectRatio: `${activeDocument.width} / ${activeDocument.height}`,
            maxHeight: '350px',
            width: 'auto',
          }}
        >
          {/* Rendered Document Snapshot */}
          {activeDocument.previewDataUrl && (
            <img
              src={activeDocument.previewDataUrl}
              alt="Page Preview"
              className="w-full h-full object-contain pointer-events-none"
            />
          )}

          {/* Real-time Overlaid Signature Stamp */}
          <div
            className="absolute border border-dashed border-pink-500 bg-pink-500/10 transition-all duration-150 flex items-center justify-center"
            style={{
              left: `${currentPreset.xPercent}%`,
              top: `${currentPreset.yPercent}%`,
              width: `${18 * (currentPreset.scalePercent / 100)}%`,
              aspectRatio: '2/1',
              transform: `translate(-50%, -50%) rotate(${currentPreset.rotationAngle}deg)`,
            }}
          >
            <span className="text-[10px] font-bold text-pink-600 bg-white/90 px-1 rounded shadow">
              ✍️ Signature Here
            </span>
          </div>
        </div>
      </div>

      {/* Full Screen Modal Inspector */}
      {isPreviewModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-6">
          <div className="bg-gray-900 border border-pink-500/50 rounded-2xl p-6 max-w-4xl w-full max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-pink-400">
                Full Page Stamping Inspector
              </h3>
              <button
                onClick={() => setIsPreviewModalOpen(false)}
                className="text-gray-400 hover:text-white font-bold text-xl"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-auto bg-gray-950 p-4 rounded-xl flex justify-center items-center">
              <div
                className="relative bg-white shadow-2xl"
                style={{
                  width: '100%',
                  maxWidth: '700px',
                  aspectRatio: `${activeDocument.width} / ${activeDocument.height}`,
                }}
              >
                {activeDocument.previewDataUrl && (
                  <img
                    src={activeDocument.previewDataUrl}
                    alt="Full Inspection"
                    className="w-full h-full object-contain"
                  />
                )}

                <div
                  className="absolute border-2 border-pink-500 bg-pink-500/20"
                  style={{
                    left: `${currentPreset.xPercent}%`,
                    top: `${currentPreset.yPercent}%`,
                    width: `${18 * (currentPreset.scalePercent / 100)}%`,
                    aspectRatio: '2/1',
                    transform: `translate(-50%, -50%) rotate(${currentPreset.rotationAngle}deg)`,
                  }}
                >
                  <div className="w-full h-full flex items-center justify-center text-xs font-bold text-pink-700 bg-white/80 p-1">
                    Signature Stamp
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
