/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useMemo } from 'react';
import { PageEditData, EditMap, PDFTextRun, PDFImageObject, ImageEditMap } from '../types';
import { Trash2, Image as ImageIcon, Plus, Eye, Sparkles, HelpCircle, Undo, Redo, Search, Files } from 'lucide-react';
import { getStandardTextWidth, cssFamily, granularizeRuns } from '../utils/textMetrics';
import { sampleColors } from '../utils/colorSampler';

interface PageRendererProps {
  key?: any;
  pageIndex: number;
  pageObj: any;
  scale: number;
  runs: PDFTextRun[];
  edits: EditMap;
  onRunClick: (runId: string, pageIdx: number, rect: DOMRect) => void;
  highlightedRunIds: Set<string>;
  images: PDFImageObject[];
  imageEdits: ImageEditMap;
  onImageClick: (imageId: string, pageIdx: number, rect: DOMRect) => void;
  placingImage: { imageBytes: string; imageType: 'png' | 'jpeg'; width: number; height: number } | null;
  onPlaceImage: (pageIdx: number, transform: number[]) => void;
  onUpdateImageTransform: (imageId: string, pageIdx: number, newTransform: number[]) => void;
  selectedImageId?: string;
  onDeleteImage: (imageId: string, pageIdx: number) => void;
  onReplaceImageContent: (imageId: string, pageIdx: number, imageBytes: string, imageType: 'png' | 'jpeg') => void;
  onPlaceNewImageWithBytes: (pageIdx: number, transform: number[], imageBytes: string, imageType: 'png' | 'jpeg') => void;
  onUpdateImageDimensions: (imageId: string, pageIdx: number, newWidth: number, newHeight: number) => void;
  selectedRunId?: string;
  onMergeRuns?: (activeId: string, siblingId: string, pageIdx: number) => void;
  onAddTextRunAtGap?: (pageIdx: number, beforeId: string, afterId: string, customText?: string, forceOpenPopup?: boolean) => void;
  // NEW:
  connectSourceId?: string;
  onStartConnect?: (runId: string, pageIdx: number) => void;
  onAddTextAtCoord?: (pageIdx: number, pdfX: number, pdfY: number) => void;
  onAddFloatingTextBox?: (pageIdx: number, pdfX: number, pdfY: number) => void;
  onAddShapeBox?: (pageIdx: number, pdfX: number, pdfY: number) => void;
  onAddSignatureBox?: (pageIdx: number, pdfX: number, pdfY: number) => void;
  onAddStampBox?: (pageIdx: number, pdfX: number, pdfY: number) => void;
  pageNumbering?: any;
  totalPages?: number;
  onDeletePage?: (pageIdx: number) => void;
  onInsertBlankPage?: (pageIdx: number, position: 'before' | 'after') => void;
  onMergeGaps?: (pageIdx: number, x: number, y: number, w: number, h: number) => void;
  onUndo?: () => void;
  onRedo?: () => void;
  canUndo?: boolean;
  canRedo?: boolean;
  onShowAddPagesDialog?: (pageIdx: number) => void;
  onToggleFindReplace?: () => void;
  onTriggerAddImage?: (pageIdx: number) => void;
  onInsertFile?: (pageIdx: number, file: File) => void;
  glowTheme?: 'cyberpunk-neon' | 'solar-amber' | 'cosmic-dark' | 'standard';
  role?: 'admin' | 'user';
  textGranularity?: 'line' | 'sentence' | 'word';
  canvasMode?: 'select' | 'text' | 'editText' | 'highlight' | 'draw' | 'shape' | 'signature' | 'stamp';
  drawOptions?: {
    brushType: 'pen' | 'marker' | 'calligraphy' | 'neon' | 'eraser';
    brushColor: string;
    brushSize: number;
    brushOpacity: number;
  };
  highlightOptions?: {
    color: string;
    style: 'freehand' | 'box' | 'underline' | 'strike';
    opacity: number;
  };
}

// 2D Affine Matrix Multiplication to resolve coordinate transforms independently of PDF.js internal utilities
function transformMatrix(m1: number[], m2: number[]): number[] {
  const [a1, b1, c1, d1, e1, f1] = m1;
  const [a2, b2, c2, d2, e2, f2] = m2;

  return [
    a1 * a2 + c1 * b2,
    b1 * a2 + d1 * b2,
    a1 * c2 + c1 * d2,
    b1 * c2 + d1 * d2,
    a1 * e2 + c1 * f2 + e1,
    b1 * e2 + d1 * f2 + f1
  ];
}

interface OriginalImageCropProps {
  pageIndex: number;
  origLeft: number;
  origTop: number;
  origWidth: number;
  origHeight: number;
  viewport: any;
  renderId: number;
}

const OriginalImageCrop: React.FC<OriginalImageCropProps> = ({
  pageIndex,
  origLeft,
  origTop,
  origWidth,
  origHeight,
  viewport,
  renderId,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const cached = (window as any).p_originalCanvases?.[pageIndex];
    if (cached && origWidth > 0 && origHeight > 0) {
      canvas.width = origWidth;
      canvas.height = origHeight;
      ctx.drawImage(
        cached,
        origLeft,
        origTop,
        origWidth,
        origHeight,
        0,
        0,
        origWidth,
        origHeight
      );
    }
  }, [pageIndex, origLeft, origTop, origWidth, origHeight, viewport, renderId]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full object-fill pointer-events-none rounded-sm"
    />
  );
};

export default function PageRenderer({
  pageIndex,
  pageObj,
  scale,
  runs,
  edits,
  onRunClick,
  highlightedRunIds,
  images,
  imageEdits,
  onImageClick,
  placingImage,
  onPlaceImage,
  onUpdateImageTransform,
  selectedImageId,
  onDeleteImage,
  onReplaceImageContent,
  onPlaceNewImageWithBytes,
  onUpdateImageDimensions,
  selectedRunId,
  onMergeRuns,
  onAddTextRunAtGap,
  connectSourceId,
  onStartConnect,
  onAddTextAtCoord,
  onAddFloatingTextBox,
  onAddShapeBox,
  onAddSignatureBox,
  onAddStampBox,
  pageNumbering,
  totalPages,
  onDeletePage,
  onInsertBlankPage,
  onMergeGaps,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  onShowAddPagesDialog,
  onToggleFindReplace,
  onTriggerAddImage,
  onInsertFile,
  glowTheme = 'cyberpunk-neon',
  role = 'admin',
  textGranularity = 'word',
  canvasMode = 'select',
  drawOptions,
  highlightOptions,
}: PageRendererProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const renderTaskRef = useRef<any>(null);
  const [viewport, setViewport] = useState<any>(null);
  const [renderError, setRenderError] = useState<string | null>(null);

  // Compute active runs based on selected editing granularity (word, sentence, line)
  const effectiveRuns = useMemo(() => {
    return granularizeRuns(runs, textGranularity, edits);
  }, [runs, textGranularity, edits]);

  // Local state for multi-select gap slots
  const [selectedGapIdxs, setSelectedGapIdxs] = useState<Set<number>>(new Set());

  // Local state for element identification HUD diagnostic tools
  const [identifyImages, setIdentifyImages] = useState(true);
  const [identifySpecial, setIdentifySpecial] = useState(true);
  const [identifyGaps, setIdentifyGaps] = useState(false);

  // Local state for click context menu to insert elements
  const [activeClickMenu, setActiveClickMenu] = useState<{
    x: number;
    y: number;
    pdfX: number;
    pdfY: number;
  } | null>(null);

  // Drawing Canvas Refs and Handlers
  const drawCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDrawingRef = useRef<boolean>(false);
  const [hasDrawingStrokes, setHasDrawingStrokes] = useState<boolean>(false);

  const handlePointerDownDraw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (canvasMode !== 'draw' && canvasMode !== 'highlight') return;
    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    isDrawingRef.current = true;
    try {
      canvas.setPointerCapture(e.pointerId);
    } catch (err) {}

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);

    if (canvasMode === 'highlight') {
      ctx.strokeStyle = highlightOptions?.color || '#fef08a';
      ctx.globalAlpha = highlightOptions?.opacity || 0.45;
      ctx.lineWidth = 18;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    } else {
      const bType = drawOptions?.brushType || 'pen';
      if (bType === 'eraser') {
        ctx.globalCompositeOperation = 'destination-out';
        ctx.lineWidth = (drawOptions?.brushSize || 10) * 2;
      } else {
        ctx.globalCompositeOperation = 'source-over';
        ctx.strokeStyle = drawOptions?.brushColor || '#ef4444';
        ctx.globalAlpha = drawOptions?.brushOpacity || 1.0;
        ctx.lineWidth = (drawOptions?.brushSize || 3) * (bType === 'marker' ? 3 : 1);
        ctx.lineCap = bType === 'calligraphy' ? 'square' : 'round';
        ctx.lineJoin = 'round';
      }
    }
  };

  const handlePointerMoveDraw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
    setHasDrawingStrokes(true);
  };

  const handlePointerUpDraw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    isDrawingRef.current = false;
    const canvas = drawCanvasRef.current;
    if (canvas) {
      try {
        canvas.releasePointerCapture(e.pointerId);
      } catch (err) {}
    }
  };

  const handleSaveDrawingLayer = () => {
    const canvas = drawCanvasRef.current;
    if (!canvas || !viewport) return;
    const dataUrl = canvas.toDataURL('image/png');
    const transform = [viewport.width, 0, 0, viewport.height, 0, viewport.height];
    onPlaceNewImageWithBytes(pageIndex, transform, dataUrl, 'png');
    const ctx = canvas.getContext('2d');
    if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasDrawingStrokes(false);
  };

  // Local state for dragging to keep FPS high and avoid re-drawing the PDF.js canvas on every mouse move
  const [dragState, setDragState] = useState<{
    id: string;
    startX: number;
    startY: number;
    dx: number;
    dy: number;
  } | null>(null);

  // Tracking drag states securely using refs to prevent re-renders or delays
  const dragItem = useRef<{ id: string; pageIdx: number } | null>(null);
  const dragStartPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const dragStartTransform = useRef<number[] | null>(null);
  const lastDelta = useRef<{ dx: number; dy: number }>({ dx: 0, dy: 0 });

  // Local state for dynamic resizing of selected image on the canvas
  const [resizeState, setResizeState] = useState<{
    id: string;
    startX: number;
    startY: number;
    startWidth: number;
    startHeight: number;
  } | null>(null);

  // Local state for interactive text inputs in gap boxes
  const [gapTexts, setGapTexts] = useState<Record<string, string>>({});
  // Local state to force trigger re-crop of original PDF images once background canvas completes rendering
  const [renderId, setRenderId] = useState(0);

  // Calculate shifts for connected boxes caused by user writing space expansion
  const getRunShifts = (): { [id: string]: number } => {
    if (!viewport) return {};
    const runShifts: { [id: string]: number } = {};
    for (const runId in edits) {
      const e = edits[runId];
      if (e.pageIdx !== pageIndex) continue;

      const tx = transformMatrix(viewport.transform, e.transform);
      const fontHeightPx = Math.hypot(tx[2], tx[3]) * e.sizeMul;
      const origWidthPx = e.width * scale * e.sizeMul;
      const measuredWidthPx = getStandardTextWidth(e.newText, e.family, e.bold, e.italic, fontHeightPx);

      const deltaW = Math.max(0, measuredWidthPx - origWidthPx);

      if (deltaW > 0) {
        const curLeft = tx[4];
        const curTop = tx[5];
        effectiveRuns.forEach((other) => {
          if (other.id !== runId) {
            const otherTx = transformMatrix(viewport.transform, other.transform);
            if (Math.abs(otherTx[5] - curTop) < fontHeightPx * 0.85 && otherTx[4] > curLeft) {
              runShifts[other.id] = (runShifts[other.id] || 0) + deltaW;
            }
          }
        });
      }
    }
    return runShifts;
  };

  // Find active and sibling runs for the 3-box grouping UI
  const getGroupedRuns = () => {
    if (!selectedRunId || !viewport) return null;
    const shifts = getRunShifts();
    
    // Resolve coordinates of all runs on the current page
    const resolved = effectiveRuns.map((run) => {
      const tx = transformMatrix(viewport.transform, run.transform);
      const angleRad = Math.atan2(tx[1], tx[0]);
      const fontHeightPx = Math.hypot(tx[2], tx[3]);
      const left = tx[4] + (shifts[run.id] || 0);
      const top = tx[5] - fontHeightPx;
      const editOverride = edits[run.id];
      const measuredW = editOverride 
        ? getStandardTextWidth(editOverride.newText, editOverride.family, editOverride.bold, editOverride.italic, fontHeightPx * editOverride.sizeMul)
        : 0;
      const widthPx = Math.max(run.width * scale * (editOverride?.sizeMul || 1), measuredW > 0 ? measuredW + 8 : 0);
      const heightPx = fontHeightPx;
      const centerY = top + heightPx / 2;
      
      const isDeleted = editOverride && editOverride.newText === '';
      const text = editOverride ? editOverride.newText : run.str;

      const textLinesCount = (text || '').split('\n').length;
      const baseH = heightPx * (editOverride?.sizeMul || 1);
      const totalH = baseH + Math.max(0, textLinesCount - 1) * (baseH * 1.25);

      return {
        id: run.id,
        run,
        left,
        top,
        width: widthPx,
        height: totalH,
        centerY,
        isDeleted,
        text,
        angleRad
      };
    });

    const active = resolved.find((r) => r.id === selectedRunId);
    if (!active) return null;

    // Filter to runs on the same line (similar centerY and same angle/direction)
    const onLine = resolved.filter((r) => {
      if (r.id === selectedRunId) return false;
      // Vertically overlapping or close baseline
      const vertClose = Math.abs(r.centerY - active.centerY) < active.height * 0.85;
      const angleClose = Math.abs(r.angleRad - active.angleRad) < 0.1;
      return vertClose && angleClose;
    });

    // Find left sibling (closest to active on the left)
    const leftSiblings = onLine
      .filter((r) => r.left < active.left)
      .sort((a, b) => b.left - a.left); // descending, so index 0 is closest
    const leftSibling = leftSiblings[0] || null;

    // Find right sibling (closest to active on the right)
    const rightSiblings = onLine
      .filter((r) => r.left > active.left)
      .sort((a, b) => a.left - b.left); // ascending, so index 0 is closest
    const rightSibling = rightSiblings[0] || null;

    return {
      active,
      leftSibling,
      rightSibling,
    };
  };

  // Find gaps of empty space on the current page
  const detectGaps = () => {
    if (!viewport) return [];
    
    // Group all runs by their line (centerY)
    const resolved = effectiveRuns.map((run) => {
      const tx = transformMatrix(viewport.transform, run.transform);
      const fontHeightPx = Math.hypot(tx[2], tx[3]);
      const left = tx[4];
      const top = tx[5] - fontHeightPx;
      const widthPx = run.width * scale;
      const heightPx = fontHeightPx;
      const centerY = top + heightPx / 2;
      
      const editOverride = edits[run.id];
      const isDeleted = editOverride && editOverride.newText === '';

      return {
        id: run.id,
        run,
        left,
        top,
        width: widthPx * (editOverride?.sizeMul || 1),
        height: heightPx * (editOverride?.sizeMul || 1),
        centerY,
        isDeleted
      };
    });

    // Group runs by line. Let's group runs where centerY difference is small
    const lines: typeof resolved[] = [];
    resolved.forEach((run) => {
      if (run.isDeleted) return; // ignore deleted runs for gap detection
      let added = false;
      for (const line of lines) {
        if (Math.abs(line[0].centerY - run.centerY) < run.height * 0.75) {
          line.push(run);
          added = true;
          break;
        }
      }
      if (!added) {
        lines.push([run]);
      }
    });

    const gaps: { left: number; top: number; width: number; height: number; beforeId: string; afterId: string }[] = [];

    lines.forEach((line) => {
      // Sort runs on this line from left to right
      line.sort((a, b) => a.left - b.left);
      
      for (let i = 0; i < line.length - 1; i++) {
        const a = line[i];
        const b = line[i+1];
        
        const rRight = a.left + a.width;
        const lLeft = b.left;
        const gapWidth = lLeft - rRight;
        
        // If gap is significant (between 15px and 350px)
        if (gapWidth > 20 && gapWidth < 350) {
          gaps.push({
            left: rRight,
            top: Math.min(a.top, b.top),
            width: gapWidth,
            height: Math.max(a.height, b.height),
            beforeId: a.id,
            afterId: b.id
          });
        }
      }
    });

    return gaps;
  };

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, id: string, origTransform: number[]) => {
    e.stopPropagation();
    
    dragItem.current = { id, pageIdx: pageIndex };
    dragStartTransform.current = origTransform;
    
    const rect = e.currentTarget.getBoundingClientRect();
    dragStartPos.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
    
    // Ensure HTML5 dataTransfer is fully initiated immediately so the first drag registers
    e.dataTransfer.setData('text/plain', id);
    e.dataTransfer.effectAllowed = 'move';
    
    setDragState({
      id,
      startX: e.clientX,
      startY: e.clientY,
      dx: 0,
      dy: 0,
    });
    lastDelta.current = { dx: 0, dy: 0 };
  };

  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (!dragItem.current || !dragState || e.clientX === 0) return;
    
    const dx = e.clientX - dragState.startX;
    const dy = e.clientY - dragState.startY;
    
    lastDelta.current = { dx, dy };
    setDragState((prev) => prev ? { ...prev, dx, dy } : null);
  };

  const handleDragEnd = (e: React.DragEvent<HTMLDivElement>, id: string) => {
    e.stopPropagation();
    if (!dragItem.current || dragItem.current.id !== id) {
      setDragState(null);
      return;
    }
    
    const dx = lastDelta.current.dx;
    const dy = lastDelta.current.dy;
    setDragState(null);
    lastDelta.current = { dx: 0, dy: 0 };
    
    // Treat as click/tap if dragged less than 3px
    if (Math.hypot(dx, dy) < 3) {
      const rect = e.currentTarget.getBoundingClientRect();
      onImageClick(id, pageIndex, rect);
      return;
    }
    
    const startTx = dragStartTransform.current;
    if (startTx) {
      const dxPdf = dx / scale;
      const dyPdf = -dy / scale;
      
      const [a, b, c, d, x, y] = startTx;
      let newX = x + dxPdf;
      let newY = y + dyPdf;

      // Clamp coordinates to remain strictly within page bounds
      const pageW = viewport ? viewport.width / scale : 612;
      const pageH = viewport ? viewport.height / scale : 792;
      const boxW = Math.abs(a);
      const boxH = Math.abs(d);

      newX = Math.max(10, Math.min(pageW - boxW - 10, newX));
      newY = Math.max(10 + boxH, Math.min(pageH - 10, newY));

      const newTransform = [a, b, c, d, newX, newY];
      
      onUpdateImageTransform(id, pageIndex, newTransform);
    }
    
    dragItem.current = null;
    dragStartTransform.current = null;
  };

  const boxPointerDrag = useRef<{
    id: string;
    startX: number;
    startY: number;
    startTransform: number[];
    hasMoved: boolean;
  } | null>(null);

  const handleBoxPointerDown = (e: React.PointerEvent<HTMLDivElement>, id: string, transform: number[]) => {
    const target = e.target as HTMLElement;
    if (target.closest('button')) return;

    e.stopPropagation();
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch (err) {}

    boxPointerDrag.current = {
      id,
      startX: e.clientX,
      startY: e.clientY,
      startTransform: [...transform],
      hasMoved: false,
    };
  };

  const handleBoxPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!boxPointerDrag.current) return;
    e.stopPropagation();

    const drag = boxPointerDrag.current;
    const dx = e.clientX - drag.startX;
    const dy = e.clientY - drag.startY;

    if (Math.hypot(dx, dy) > 3) {
      drag.hasMoved = true;
    }

    if (drag.hasMoved) {
      const dxPdf = dx / scale;
      const dyPdf = -dy / scale;

      const [a, b, c, d, x, y] = drag.startTransform;
      let newX = x + dxPdf;
      let newY = y + dyPdf;

      const pageW = viewport ? viewport.width / scale : 612;
      const pageH = viewport ? viewport.height / scale : 792;
      const boxW = Math.abs(a);
      const boxH = Math.abs(d);

      newX = Math.max(10, Math.min(pageW - boxW - 10, newX));
      newY = Math.max(10 + boxH, Math.min(pageH - 10, newY));

      const newTransform = [a, b, c, d, newX, newY];
      onUpdateImageTransform(drag.id, pageIndex, newTransform);
    }
  };

  const handleBoxPointerUp = (e: React.PointerEvent<HTMLDivElement>, id: string) => {
    if (!boxPointerDrag.current) return;
    e.stopPropagation();
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (err) {}

    const drag = boxPointerDrag.current;
    boxPointerDrag.current = null;

    if (!drag.hasMoved) {
      const rect = e.currentTarget.getBoundingClientRect();
      onImageClick(id, pageIndex, rect);
    }
  };

  const handleResizePointerDown = (e: React.PointerEvent, id: string, startWidth: number, startHeight: number) => {
    e.stopPropagation();
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    setResizeState({
      id,
      startX: e.clientX,
      startY: e.clientY,
      startWidth,
      startHeight,
    });
  };

  const handleResizePointerMove = (e: React.PointerEvent) => {
    if (!resizeState) return;
    e.stopPropagation();
    e.preventDefault();

    const dx = (e.clientX - resizeState.startX) / scale;
    const dy = (e.clientY - resizeState.startY) / scale;

    const newWidth = Math.max(10, resizeState.startWidth + dx);
    const newHeight = Math.max(10, resizeState.startHeight + dy);

    onUpdateImageDimensions(resizeState.id, pageIndex, newWidth, newHeight);
  };

  const handleResizePointerUp = (e: React.PointerEvent) => {
    if (!resizeState) return;
    e.stopPropagation();
    e.preventDefault();
    (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    setResizeState(null);
  };

  const handleImageFileDrop = (e: React.DragEvent<HTMLDivElement>, id: string) => {
    e.preventDefault();
    e.stopPropagation();
    const file = e.dataTransfer.files?.[0];
    if (file && (file.type === 'image/png' || file.type === 'image/jpeg')) {
      const type = file.type === 'image/png' ? 'png' : 'jpeg';
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          onReplaceImageContent(id, pageIndex, reader.result, type);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const [isPageDragOver, setIsPageDragOver] = useState(false);

  const handlePageFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsPageDragOver(false);

    let file: File | null = null;
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      file = e.dataTransfer.files[0];
    }

    if (file && file.type.startsWith('image/')) {
      const type = file.type.includes('png') ? 'png' : 'jpeg';
      const rect = e.currentTarget.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;

      const [pdfX, pdfY] = viewport.convertToPdfPoint(clickX, clickY);

      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          const imageBytes = reader.result;
          const img = new window.Image();
          img.src = imageBytes;
          img.onload = () => {
            const imgW = 140;
            const aspect = (img.height && img.width) ? img.height / img.width : 0.75;
            const imgH = imgW * aspect;
            const x = Math.max(10, pdfX - imgW / 2);
            const y = pdfY + imgH / 2;
            const transform = [imgW, 0, 0, imgH, x, y];

            onPlaceNewImageWithBytes(pageIndex, transform, imageBytes, type);
          };
        }
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    if (!pageObj) return;
    if ((window as any).p_originalCanvases) {
      (window as any).p_originalCanvases[pageIndex] = null;
    }
    if (pageObj.isBlank) {
      setViewport({
        width: 595 * scale,
        height: 842 * scale,
        scale,
        transform: [scale, 0, 0, -scale, 0, 842 * scale],
        convertToPdfPoint(x: number, y: number) {
          return [x / scale, 842 - y / scale];
        },
        convertToViewportPoint(x: number, y: number) {
          return [x * scale, (842 - y) * scale];
        }
      });
      return;
    }
    const vp = pageObj.getViewport({ scale });
    setViewport(vp);
  }, [pageObj, scale]);

  useEffect(() => {
    let isCancelled = false;

    async function renderPage() {
      if (!canvasRef.current || !pageObj || !viewport) return;

      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      canvas.width = viewport.width;
      canvas.height = viewport.height;

      const cached = (window as any).p_originalCanvases?.[pageIndex];
      if (cached && cached.width === canvas.width && cached.height === canvas.height) {
        ctx.drawImage(cached, 0, 0);
        drawEditsOnCanvas(ctx);
        setRenderError(null);
        return;
      }

      if (pageObj.isBlank) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Cache pristine blank canvas
        if (!(window as any).p_originalCanvases) {
          (window as any).p_originalCanvases = {};
        }
        const origCanvas = document.createElement('canvas');
        origCanvas.width = canvas.width;
        origCanvas.height = canvas.height;
        const origCtx = origCanvas.getContext('2d');
        if (origCtx) {
          origCtx.fillStyle = '#ffffff';
          origCtx.fillRect(0, 0, canvas.width, canvas.height);
        }
        (window as any).p_originalCanvases[pageIndex] = origCanvas;
        setRenderId(prev => prev + 1);

        drawEditsOnCanvas(ctx);
        setRenderError(null);
        return;
      }

      // Cancel previous rendering task if one exists
      if (renderTaskRef.current) {
        try {
          renderTaskRef.current.cancel();
        } catch (e) {
          // Ignored
        }
      }

      const renderContext = {
        canvasContext: ctx,
        viewport: viewport,
      };

      const renderTask = pageObj.render(renderContext);
      renderTaskRef.current = renderTask;

      try {
        await renderTask.promise;
        if (isCancelled) return;

        // Cache pristine canvas copy for color sampling before drawing any edits on top
        if (!(window as any).p_originalCanvases) {
          (window as any).p_originalCanvases = {};
        }
        const origCanvas = document.createElement('canvas');
        origCanvas.width = canvas.width;
        origCanvas.height = canvas.height;
        const origCtx = origCanvas.getContext('2d');
        if (origCtx) {
          origCtx.drawImage(canvas, 0, 0);
        }
        (window as any).p_originalCanvases[pageIndex] = origCanvas;
        setRenderId(prev => prev + 1);
        
        // Draw edits on top of the original PDF content
        drawEditsOnCanvas(ctx);
        setRenderError(null);
      } catch (err: any) {
        if (err.name !== 'RenderingCancelledException') {
          console.error('PDF.js Render error:', err);
          setRenderError(err.message || 'Error rendering page.');
        }
      }
    }

    renderPage();

    return () => {
      isCancelled = true;
      if (renderTaskRef.current) {
        try {
          renderTaskRef.current.cancel();
        } catch (e) {
          // Ignored
        }
      }
    };
  }, [pageObj, viewport, edits, imageEdits]);

  const drawEditsOnCanvas = (ctx: CanvasRenderingContext2D) => {
    if (!viewport) return;

    // Cover original images that have been deleted or replaced
    for (const imageId in imageEdits) {
      const imgOverride = imageEdits[imageId];
      if (imgOverride.pageIdx !== pageIndex) continue;

      // Only cover original PDF images (IDs start with 'img-')
      if (imageId.startsWith('img-')) {
        const origImg = images?.find((img) => img.id === imageId);
        const coverTransform = origImg ? origImg.transform : imgOverride.transform;
        const coverWidth = origImg ? origImg.width : imgOverride.width;
        const coverHeight = origImg ? origImg.height : imgOverride.height;

        const tx = transformMatrix(viewport.transform, coverTransform);
        const angleRad = Math.atan2(tx[1], tx[0]);
        const left = tx[4];
        const top = tx[5];
        const w = coverWidth * scale;
        const h = coverHeight * scale;

        ctx.save();
        ctx.translate(left, top);
        ctx.rotate(angleRad);
        ctx.fillStyle = '#ffffff'; // Cover standard background
        ctx.fillRect(0, -h, w, h);
        ctx.restore();
      }
    }

    // Calculate connected box shifts caused by user writing space expansion
    const runShifts = getRunShifts();

    for (const runId in edits) {
      const e = edits[runId];
      if (e.pageIdx !== pageIndex) continue;

      const tx = transformMatrix(viewport.transform, e.transform);
      const angleRad = Math.atan2(tx[1], tx[0]);
      const fontHeightPx = Math.hypot(tx[2], tx[3]) * e.sizeMul;
      const shiftX = runShifts[runId] || 0;
      const left = tx[4] + shiftX;
      const origLeft = tx[4];
      const top = tx[5];
      const origWidthPx = e.width * scale * e.sizeMul;
      const padX = 1.5;
      const ASCENT = 1.05;
      const DESCENT = 0.35;

      const familyToUse = cssFamily(e.family);

      let fontSpec = '';
      if (e.italic) fontSpec += 'italic ';
      if (e.bold) fontSpec += 'bold ';
      fontSpec += `${fontHeightPx}px ${familyToUse}`;
      
      ctx.font = fontSpec;
      const measuredWidthPx = getStandardTextWidth(e.newText, e.family, e.bold, e.italic, fontHeightPx);

      const textLines = (e.newText || '').split('\n');
      const lineH = fontHeightPx * 1.25;
      const totalCoverHeight = fontHeightPx * (ASCENT + DESCENT) + Math.max(0, textLines.length - 1) * lineH;

      let activeStretch = 1.0;
      if (e.stretch !== undefined && Math.abs(e.stretch - 1.0) > 0.01) {
        activeStretch = e.stretch;
      } else if (measuredWidthPx > origWidthPx && origWidthPx > 0 && shiftX === 0) {
        // Auto-squeeze longer edited text to fit cleanly inside original row bounds
        activeStretch = Math.max(0.68, origWidthPx / measuredWidthPx);
      }

      const widthPx = Math.max(origWidthPx, measuredWidthPx * activeStretch);
      const shouldDrawCover = e.bgMode ? (e.bgMode !== 'transparent') : (!e.noCover);

      // If shifted to the right, cover original unshifted position as well
      if (shouldDrawCover && shiftX > 0) {
        ctx.save();
        ctx.translate(origLeft, top);
        ctx.rotate(angleRad);
        ctx.fillStyle = e.bg;
        ctx.fillRect(
          -padX,
          -fontHeightPx * ASCENT,
          origWidthPx + padX * 2,
          totalCoverHeight
        );
        ctx.restore();
      }

      ctx.save();
      ctx.translate(left, top);
      ctx.rotate(angleRad);

      if (shouldDrawCover) {
        ctx.fillStyle = e.bg;
        ctx.fillRect(
          -padX,
          -fontHeightPx * ASCENT,
          widthPx + padX * 2,
          totalCoverHeight
        );
      }

      ctx.scale(activeStretch, 1);

      ctx.font = fontSpec;
      ctx.fillStyle = e.color;
      ctx.textBaseline = 'alphabetic';

      let xPos = 0;
      const unscaledWidth = widthPx / activeStretch;
      if (e.alignment === 'center') {
        ctx.textAlign = 'center';
        xPos = unscaledWidth / 2;
      } else if (e.alignment === 'right') {
        ctx.textAlign = 'right';
        xPos = unscaledWidth;
      } else {
        ctx.textAlign = 'left';
        xPos = 0;
      }

      textLines.forEach((lineStr, lineIdx) => {
        const yOffset = lineIdx * lineH;
        ctx.fillText(lineStr, xPos, yOffset);

        // Underline per line
        if (e.underline) {
          ctx.beginPath();
          ctx.strokeStyle = e.color;
          ctx.lineWidth = Math.max(1, fontHeightPx * 0.08);
          const lineMeasured = getStandardTextWidth(lineStr, e.family, e.bold, e.italic, fontHeightPx);
          const textLen = lineMeasured || unscaledWidth;
          const startX = e.alignment === 'center' ? xPos - textLen / 2 : (e.alignment === 'right' ? xPos - textLen : xPos);
          ctx.moveTo(startX, yOffset + fontHeightPx * 0.12);
          ctx.lineTo(startX + textLen, yOffset + fontHeightPx * 0.12);
          ctx.stroke();
        }
      });

      // Strikethrough
      if (e.strikethrough) {
        ctx.beginPath();
        ctx.strokeStyle = e.color;
        ctx.lineWidth = Math.max(1, fontHeightPx * 0.08);
        const textLen = measuredWidthPx || unscaledWidth;
        const startX = e.alignment === 'center' ? xPos - textLen / 2 : (e.alignment === 'right' ? xPos - textLen : xPos);
        ctx.moveTo(startX, -fontHeightPx * 0.35);
        ctx.lineTo(startX + textLen, -fontHeightPx * 0.35);
        ctx.stroke();
      }

      ctx.restore();
    }

    // Cover and redraw unedited runs that were shifted to the right so they don't get overwritten
    effectiveRuns.forEach((run) => {
      if (edits[run.id]) return; // Already rendered in edits loop
      const shiftX = runShifts[run.id];
      if (!shiftX || shiftX <= 0) return;

      const tx = transformMatrix(viewport.transform, run.transform);
      const angleRad = Math.atan2(tx[1], tx[0]);
      const fontHeightPx = Math.hypot(tx[2], tx[3]);
      const origLeft = tx[4];
      const shiftLeft = origLeft + shiftX;
      const top = tx[5];
      const origWidthPx = run.width * scale;
      const padX = fontHeightPx * 0.35 + 2;
      const ASCENT = 1.05;
      const DESCENT = 0.35;

      const familyToUse = cssFamily(run.fontFamily || run.familyGuess);
      let fontSpec = '';
      if (run.italicGuess) fontSpec += 'italic ';
      if (run.boldGuess) fontSpec += 'bold ';
      fontSpec += `${fontHeightPx}px ${familyToUse}`;

      const sampled = sampleColors(pageIndex, run, pageObj, scale);

      // 1. Cover original unshifted position on canvas so original text printed by PDF.js is erased
      ctx.save();
      ctx.translate(origLeft, top);
      ctx.rotate(angleRad);
      ctx.fillStyle = sampled.bg || '#ffffff';
      ctx.fillRect(
        -padX,
        -fontHeightPx * ASCENT,
        origWidthPx + padX * 2,
        fontHeightPx * (ASCENT + DESCENT)
      );
      ctx.restore();

      // 2. Draw unedited text at shifted position
      ctx.save();
      ctx.translate(shiftLeft, top);
      ctx.rotate(angleRad);
      ctx.font = fontSpec;
      ctx.fillStyle = sampled.ink || '#000000';
      ctx.textBaseline = 'alphabetic';
      ctx.textAlign = 'left';
      ctx.fillText(run.str, 0, 0);
      ctx.restore();
    });
  };

  const handlePageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (!viewport) return;

    // Guard: ignore clicks on interactive elements (runs, images, buttons, popups)
    const target = e.target as HTMLElement;
    if (target.closest('.run') || target.closest('.image-element') || target.closest('button') || target.closest('.popup')) {
      return;
    }

    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const [pdfX, pdfY] = viewport.convertToPdfPoint(clickX, clickY);

    if (placingImage) {
      const imgW = placingImage.width;
      const imgH = placingImage.height;
      const x = pdfX - imgW / 2;
      const y = pdfY - imgH / 2;
      const transform = [imgW, 0, 0, imgH, x, y + imgH];

      onPlaceImage(pageIndex, transform);
      return;
    }

    if (canvasMode === 'text' && onAddFloatingTextBox) {
      onAddFloatingTextBox(pageIndex, pdfX, pdfY);
      return;
    }
    if (canvasMode === 'shape' && onAddShapeBox) {
      onAddShapeBox(pageIndex, pdfX, pdfY);
      return;
    }
    if (canvasMode === 'signature' && onAddSignatureBox) {
      onAddSignatureBox(pageIndex, pdfX, pdfY);
      return;
    }
    if (canvasMode === 'stamp' && onAddStampBox) {
      onAddStampBox(pageIndex, pdfX, pdfY);
      return;
    }

    // Toggle/open a click menu at the screen position of the click
    setActiveClickMenu((prev) => 
      prev ? null : { x: clickX, y: clickY, pdfX, pdfY }
    );
  };

  if (!viewport) {
    return (
      <div className="w-[600px] h-[800px] bg-[#1a1c23] border border-[#2b2e3a] rounded-lg flex items-center justify-center animate-pulse">
        <span className="text-[#9297a3] font-sans text-sm">Preparing page {pageIndex + 1}...</span>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center">
      <div className="mb-2 flex items-center justify-between w-full max-w-4xl px-2">
        <div className="flex items-center gap-2 overflow-x-auto custom-scrollbar py-0.5">
          <span className="text-xs font-mono font-bold text-slate-200 bg-[#161822] px-2.5 py-1 rounded-lg border border-[#2b2f42] shrink-0">
            PAGE {pageIndex + 1}
          </span>

          <div className="h-4 w-[1px] bg-[#2b2f42] mx-0.5 shrink-0" />

          {/* Insert File */}
          <button
            onClick={() => {
              const fileInput = document.createElement('input');
              fileInput.type = 'file';
              fileInput.accept = '.pdf, .jpg, .jpeg, .png, .txt, .docx, .doc';
              fileInput.onchange = (ev: any) => {
                const file = ev.target.files?.[0];
                if (file && onInsertFile) {
                  onInsertFile(pageIndex, file);
                }
              };
              fileInput.click();
            }}
            className="px-2.5 py-1 text-xs font-medium bg-[#161822] border border-[#2b2f42] rounded-lg text-slate-300 hover:text-white hover:bg-[#1f2333] hover:border-blue-500/50 transition-all cursor-pointer flex items-center gap-1.5 shrink-0 shadow-sm"
            title="Insert PDF, Image, Word, or Text File after this page"
          >
            <Files className="w-3.5 h-3.5 text-amber-400" />
            <span>Insert File</span>
          </button>

          {/* Add Page */}
          {onShowAddPagesDialog && (
            <button
              onClick={() => onShowAddPagesDialog(pageIndex)}
              className="px-2.5 py-1 text-xs font-medium bg-[#161822] border border-[#2b2f42] rounded-lg text-slate-300 hover:text-white hover:bg-[#1f2333] hover:border-blue-500/50 transition-all cursor-pointer flex items-center gap-1.5 shrink-0 shadow-sm"
              title="Add or Insert Pages"
            >
              <Plus className="w-3.5 h-3.5 text-blue-400" />
              <span>Add Page</span>
            </button>
          )}

          {/* Undo / Redo */}
          <div className="flex items-center bg-[#161822] rounded-lg border border-[#2b2f42] p-0.5 shrink-0">
            <button
              onClick={() => onUndo?.()}
              disabled={!canUndo}
              title="Undo last change"
              className="p-1 text-slate-400 hover:text-white hover:bg-[#252838] disabled:opacity-30 disabled:hover:bg-transparent rounded-md cursor-pointer transition-all"
            >
              <Undo className="w-3.5 h-3.5" />
            </button>
            <div className="h-3 w-[1px] bg-[#2b2f42]" />
            <button
              onClick={() => onRedo?.()}
              disabled={!canRedo}
              title="Redo / Forward change"
              className="p-1 text-slate-400 hover:text-white hover:bg-[#252838] disabled:opacity-30 disabled:hover:bg-transparent rounded-md cursor-pointer transition-all"
            >
              <Redo className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Delete Page */}
          {onDeletePage && (
            <button
              onClick={() => {
                if (confirm(`Are you sure you want to delete page ${pageIndex + 1}?`)) {
                  onDeletePage(pageIndex);
                }
              }}
              className="px-2.5 py-1 text-xs font-medium bg-red-500/10 border border-red-500/20 text-rose-300 hover:bg-red-500/20 hover:text-rose-200 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 shrink-0 shadow-sm"
              title="Delete this page"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-400" />
              <span>Delete Page</span>
            </button>
          )}
        </div>
        
        <span className="text-[11px] font-mono text-slate-400 shrink-0 flex items-center gap-2 pl-2">
          <span>{runs.length} lines</span>
          <span>•</span>
          <span>{images?.length || 0} images</span>
        </span>
      </div>

      {/* HUD Element Identification Diagnostics bar */}
      <div className="mb-3 w-full max-w-4xl bg-[#151720]/90 border border-[#232635] rounded-xl px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs text-[#9297a3] backdrop-blur shadow-lg">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#e0a84f] animate-pulse" />
          <span className="font-semibold text-white tracking-wide">
            Interactive HUD Diagnostics:
          </span>
          <span className="text-[11px] opacity-80 hidden sm:inline">Highlight elements for easy click-to-edit selection.</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIdentifyImages(!identifyImages)}
            className={`px-3 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer flex items-center gap-1.5 border ${
              identifyImages 
                ? 'bg-cyan-500/10 border-cyan-500/50 text-cyan-400 shadow-sm shadow-cyan-500/5' 
                : 'bg-[#1b1c24] border-zinc-800 text-zinc-500 hover:text-zinc-300'
            }`}
            title="Identify and highlight original PDF images with neon blue borders"
          >
            <span className={`w-1.5 h-1.5 rounded-full ${identifyImages ? 'bg-cyan-400 animate-pulse' : 'bg-zinc-600'}`} />
            Images {images?.filter(img => !img.isDiagram).length > 0 ? `(${images?.filter(img => !img.isDiagram).length})` : ''}
          </button>

          <button
            onClick={() => setIdentifySpecial(!identifySpecial)}
            className={`px-3 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer flex items-center gap-1.5 border ${
              identifySpecial 
                ? 'bg-purple-500/10 border-purple-500/50 text-purple-400 shadow-sm shadow-purple-500/5' 
                : 'bg-[#1b1c24] border-zinc-800 text-zinc-500 hover:text-zinc-300'
            }`}
            title="Identify and highlight special symbols (checkboxes, table lines, bullets, graphics) in violet"
          >
            <span className={`w-1.5 h-1.5 rounded-full ${identifySpecial ? 'bg-purple-400 animate-pulse' : 'bg-zinc-600'}`} />
            Special Symbols {images?.filter(img => img.isDiagram).length > 0 ? `(${images?.filter(img => img.isDiagram).length})` : ''}
          </button>

          <button
            onClick={() => setIdentifyGaps(!identifyGaps)}
            className={`px-3 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer flex items-center gap-1.5 border ${
              identifyGaps 
                ? 'bg-amber-500/10 border-amber-500/50 text-amber-400 shadow-sm shadow-amber-500/5' 
                : 'bg-[#1b1c24] border-zinc-800 text-zinc-500 hover:text-zinc-300'
            }`}
            title="Identify and highlight open spaces/gaps to insert new text"
          >
            <span className={`w-1.5 h-1.5 rounded-full ${identifyGaps ? 'bg-amber-400 animate-pulse' : 'bg-zinc-600'}`} />
            Open Gaps
          </button>
        </div>
      </div>

      <div
        id={`page-container-${pageIndex}`}
        ref={containerRef}
        onClick={handlePageClick}
        onDragOver={(e) => {
          e.preventDefault();
          e.stopPropagation();
          e.dataTransfer.dropEffect = 'copy';
          if (!isPageDragOver) setIsPageDragOver(true);
        }}
        onDragLeave={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setIsPageDragOver(false);
        }}
        onDrop={(e) => {
          setIsPageDragOver(false);
          handlePageFileDrop(e);
        }}
        className={`page-wrap relative border rounded-xl overflow-hidden transition-all duration-300
          shadow-[0_25px_50px_-12px_rgba(0,0,0,0.35)] ring-1 ring-white/10 hover:shadow-[0_30px_60px_-10px_rgba(91,140,255,0.25)]
          ${isPageDragOver ? 'ring-4 ring-blue-500 border-blue-400 bg-blue-50/20' : ''}
          ${glowTheme === 'cyberpunk-neon' ? 'bg-white ring-2 ring-[#a855f7]/30 shadow-[0_0_35px_rgba(168,85,247,0.25)] border-[#a855f7]/40 hover:shadow-[0_0_45px_rgba(91,140,255,0.35)]' : ''}
          ${glowTheme === 'solar-amber' ? 'bg-[#fffdfa] shadow-[0_20px_50px_rgba(224,168,79,0.2)] border-[#e0a84f]/40 hover:border-[#ffc05e]' : ''}
          ${glowTheme === 'cosmic-dark' ? 'bg-[#0a0a0f] shadow-[0_25px_50px_rgba(91,140,255,0.15)] border-[#2d3042] ring-1 ring-white/10' : ''}
          ${glowTheme === 'standard' || !glowTheme ? 'bg-white border-white/20' : ''}
          ${placingImage ? 'cursor-crosshair border-[#5b8cff] ring-2 ring-[#5b8cff]/40' : ''}
        `}
        style={{ width: `${viewport.width}px`, height: `${viewport.height}px` }}
      >
        {isPageDragOver && (
          <div className="absolute inset-0 z-50 bg-blue-500/15 border-4 border-dashed border-blue-500/90 rounded-xl flex items-center justify-center backdrop-blur-xs pointer-events-none animate-pulse">
            <div className="bg-slate-900/95 text-white font-mono text-sm px-5 py-3 rounded-2xl shadow-2xl border border-blue-400/50 flex items-center gap-3">
              <span className="text-2xl">✍️</span>
              <div>
                <div className="font-bold text-blue-300">Drop Signature / Image Here</div>
                <div className="text-[10px] text-slate-300">Place directly on page at cursor location</div>
              </div>
            </div>
          </div>
        )}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 block pointer-events-none select-none"
          style={{
            width: `${viewport.width}px`,
            height: `${viewport.height}px`,
            filter: glowTheme === 'cosmic-dark' ? 'invert(0.92) hue-rotate(185deg) brightness(1.1) contrast(1.1)' : ''
          }}
        />

        {/* Interactive Drawing & Highlighting Canvas Overlay */}
        {(canvasMode === 'draw' || canvasMode === 'highlight' || hasDrawingStrokes) && (
          <canvas
            ref={drawCanvasRef}
            width={viewport.width}
            height={viewport.height}
            onPointerDown={handlePointerDownDraw}
            onPointerMove={handlePointerMoveDraw}
            onPointerUp={handlePointerUpDraw}
            className={`absolute inset-0 z-30 touch-none ${
              canvasMode === 'draw' || canvasMode === 'highlight' ? 'pointer-events-auto cursor-crosshair' : 'pointer-events-none'
            }`}
            style={{ width: `${viewport.width}px`, height: `${viewport.height}px` }}
          />
        )}

        {hasDrawingStrokes && (
          <div className="absolute top-3 right-3 z-40 bg-[#0d0f1a]/90 border border-purple-500/50 p-2 rounded-xl shadow-xl flex items-center gap-2 text-xs">
            <span className="text-purple-300 font-bold">Drawing Active</span>
            <button
              onClick={handleSaveDrawingLayer}
              className="px-2.5 py-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-lg shadow-md transition-all cursor-pointer"
            >
              Bake Drawing into Page
            </button>
            <button
              onClick={() => {
                const canvas = drawCanvasRef.current;
                if (canvas) {
                  const ctx = canvas.getContext('2d');
                  if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
                }
                setHasDrawingStrokes(false);
              }}
              className="px-2 py-1 bg-red-600/30 hover:bg-red-600/50 text-red-300 font-bold rounded-lg transition-all cursor-pointer"
            >
              Clear
            </button>
          </div>
        )}

        {/* Placing Image Cursor Preview */}
        {placingImage && (
          <div className="absolute inset-0 z-40 bg-blue-500/5 pointer-events-none flex items-center justify-center">
            <span className="bg-[#5b8cff] text-white text-xs font-bold px-2.5 py-1 rounded-full shadow-lg">
              Click anywhere on Page {pageIndex + 1} to place image
            </span>
          </div>
        )}

        {/* Interactive Image Layer */}
        <div
          className="image-layer absolute inset-0 z-20 pointer-events-none"
          style={{ width: `${viewport.width}px`, height: `${viewport.height}px` }}
        >
          {/* Render original detected images */}
          {images?.map((img) => {
            const editOverride = imageEdits[img.id];
            const isDeleted = editOverride?.isDeleted;
            const hasReplacement = editOverride && !isDeleted && editOverride.imageBytes;

            if (isDeleted) return null;

            const activeTransform = editOverride?.transform || img.transform;
            const tx = transformMatrix(viewport.transform, activeTransform);
            const angleRad = Math.atan2(tx[1], tx[0]);

            const isDragging = dragState && dragState.id === img.id;
            const dragDx = isDragging ? dragState.dx : 0;
            const dragDy = isDragging ? dragState.dy : 0;

            const widthPx = (editOverride?.width || img.width) * scale;
            const heightPx = (editOverride?.height || img.height) * scale;
            const left = tx[4] + dragDx;
            const top = tx[5] - heightPx + dragDy;

            // Compute original coordinates on the pristine background canvas for dynamic cropping
            const origTx = transformMatrix(viewport.transform, img.transform);
            const origWidthPx = img.width * scale;
            const origHeightPx = img.height * scale;
            const origLeft = origTx[4];
            const origTop = origTx[5] - origHeightPx;

            const isSelected = img.id === selectedImageId;

            const isDiagram = !!img.isDiagram;
            const diagType = img.diagType;
            const diagLabel = img.diagLabel || 'Vector Shape';

            let borderStyle = 'none';
            if (editOverride?.outlineWidth && editOverride?.outlineColor) {
              borderStyle = `${editOverride.outlineWidth * scale}px solid ${editOverride.outlineColor}`;
            } else if (isDiagram) {
              if (diagType === 'grid-horizontal' || diagType === 'grid-vertical') {
                borderStyle = `1px dashed rgba(91, 140, 255, 0.45)`; 
              } else if (diagType === 'table-cell') {
                borderStyle = `1px dashed rgba(16, 185, 129, 0.45)`; 
              } else if (diagType === 'checkbox') {
                borderStyle = `1.5px dashed rgba(139, 92, 246, 0.65)`; 
              } else if (diagType === 'icon-bullet') {
                borderStyle = `1.5px dashed rgba(245, 158, 11, 0.65)`; 
              } else {
                borderStyle = `1px dashed rgba(236, 72, 153, 0.5)`; 
              }
            }

            let backgroundCSS = 'transparent';
            if (editOverride) {
              const bgStyle = editOverride.bgStyle || 'solid';
              const bgColor = editOverride.bgColor || '#ffffff';
              const bgColor2 = editOverride.bgColor2 || '#e1ebff';
              const bgSplitRatio = editOverride.bgSplitRatio !== undefined ? editOverride.bgSplitRatio : 0.5;

              if (bgStyle === 'transparent') {
                backgroundCSS = 'transparent';
              } else if (bgStyle === 'solid') {
                backgroundCSS = bgColor;
              } else {
                const percent = Math.round(bgSplitRatio * 100);
                if (bgStyle === 'split-h') {
                  backgroundCSS = `linear-gradient(to bottom, ${bgColor} ${percent}%, ${bgColor2} ${percent}%)`;
                } else if (bgStyle === 'split-v') {
                  backgroundCSS = `linear-gradient(to right, ${bgColor} ${percent}%, ${bgColor2} ${percent}%)`;
                } else if (bgStyle === 'gradient-h') {
                  backgroundCSS = `linear-gradient(to right, ${bgColor}, ${bgColor2})`;
                } else if (bgStyle === 'gradient-v') {
                  backgroundCSS = `linear-gradient(to bottom, ${bgColor}, ${bgColor2})`;
                }
              }
            }

            const isClickable = 
              isSelected || 
              (identifyImages && !isDiagram) || 
              (identifySpecial && isDiagram) || 
              !!editOverride;

              return (
              <div
                key={img.id}
                id={`image-${img.id}`}
                onClick={(e) => {
                  if (!isClickable) return;
                  e.stopPropagation();
                }}
                draggable={isClickable}
                onDragStart={(e) => handleDragStart(e, img.id, activeTransform)}
                onDrag={handleDrag}
                onDragEnd={(e) => handleDragEnd(e, img.id)}
                className={`absolute group select-none transition-[box-shadow,ring,background-color,border-color] duration-150
                  ${isClickable ? 'pointer-events-auto cursor-pointer' : 'pointer-events-none'}
                  ${isSelected ? 'ring-2 ring-[#5b8cff] z-50 shadow-2xl' : 'hover:ring-1 hover:ring-[#5b8cff]/50'}
                  ${isDragging ? 'cursor-grabbing z-50 ring-2 ring-[#5b8cff] shadow-xl scale-[1.01]' : (isClickable ? 'cursor-grab' : '')}
                  ${!isSelected && identifyImages && !isDiagram ? 'ring-2 ring-cyan-400 ring-offset-1 ring-offset-[#1a1c24] bg-cyan-400/10 shadow-[0_0_10px_rgba(34,211,238,0.4)] animate-pulse' : ''}
                  ${!isSelected && identifySpecial && isDiagram ? 'ring-2 ring-purple-500 ring-offset-1 ring-offset-[#1a1c24] bg-purple-500/10 shadow-[0_0_10px_rgba(139,92,246,0.4)]' : ''}
                `}
                style={{
                  left: `${left}px`,
                  top: `${top}px`,
                  width: `${widthPx}px`,
                  height: `${heightPx}px`,
                  transform: `rotate(${angleRad}rad)`,
                  transformOrigin: 'left bottom',
                  touchAction: 'none',
                  background: backgroundCSS,
                  border: borderStyle,
                }}
                onDragOver={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  e.dataTransfer.dropEffect = 'copy';
                }}
                onDrop={(e) => handleImageFileDrop(e, img.id)}
              >
                <div className={`w-full h-full flex items-center justify-center transition-all relative
                  ${isDiagram ? 'hover:bg-[#5b8cff]/10' : 'border border-dashed border-transparent hover:border-[#5b8cff] hover:bg-[#5b8cff]/10'}
                `}>
                  {hasReplacement ? (
                    <img
                      src={editOverride.imageBytes}
                      className="w-full h-full object-fill pointer-events-none"
                      alt="Replacement"
                      referrerPolicy="no-referrer"
                    />
                  ) : isDiagram ? (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="opacity-0 group-hover:opacity-100 bg-[#161822]/95 text-white text-[9px] font-semibold px-2 py-1 rounded-md shadow-xl border border-[#2c2f3d] flex items-center gap-1.5 transition-opacity pointer-events-auto">
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          diagType === 'table-cell' ? 'bg-[#10b981]' :
                          diagType === 'checkbox' ? 'bg-[#8b5cf6]' :
                          diagType === 'icon-bullet' ? 'bg-[#f59e0b]' : 'bg-[#5b8cff]'
                        }`} />
                        {diagLabel}
                        <span className="text-[8px] text-[#9297a3] bg-zinc-800 px-1 py-0.5 rounded ml-1">Edit / style</span>
                      </div>
                    </div>
                  ) : (
                    <div className="relative w-full h-full flex items-center justify-center">
                      <OriginalImageCrop
                        pageIndex={pageIndex}
                        origLeft={origLeft}
                        origTop={origTop}
                        origWidth={origWidthPx}
                        origHeight={origHeightPx}
                        viewport={viewport}
                        renderId={renderId}
                      />
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="opacity-0 group-hover:opacity-100 bg-[#1a1c24]/95 text-white text-[10px] font-semibold px-2 py-1 rounded-md shadow-lg border border-[#2c2f3d] flex items-center gap-1.5 transition-opacity">
                          <span className="w-2 h-2 rounded-full bg-[#5b8cff] animate-pulse" />
                          Drag Image Here / Select
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Top-Right Delete Button */}
                  {isSelected && (
                    <button
                      onPointerDown={(e) => e.stopPropagation()}
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteImage(img.id, pageIndex);
                      }}
                      className="absolute -top-3.5 -right-3.5 w-7 h-7 bg-red-600 hover:bg-red-500 text-white rounded-full flex items-center justify-center shadow-lg border border-red-700 pointer-events-auto cursor-pointer z-50 transition-transform hover:scale-110 active:scale-95"
                      title="Delete original image"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Bottom-Right Resize Handle */}
                  {isSelected && (
                    <div
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        handleResizePointerDown(e, img.id, editOverride?.width || img.width, editOverride?.height || img.height);
                      }}
                      onPointerMove={handleResizePointerMove}
                      onPointerUp={handleResizePointerUp}
                      onPointerCancel={handleResizePointerUp}
                      className="absolute -bottom-2.5 -right-2.5 w-5.5 h-5.5 bg-white hover:bg-[#e1ebff] border-2 border-[#5b8cff] rounded-full flex items-center justify-center shadow-lg pointer-events-auto cursor-se-resize z-50 transition-transform hover:scale-110"
                      title="Drag to Resize"
                    >
                      <div className="w-1.5 h-1.5 bg-[#5b8cff] rounded-full" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {/* Render custom added images */}
          {Object.keys(imageEdits).map((id) => {
            if (id.startsWith('img-')) return null; // handled above
            const imgOverride = imageEdits[id];
            if (imgOverride.pageIdx !== pageIndex || imgOverride.isDeleted) return null;

            const tx = transformMatrix(viewport.transform, imgOverride.transform);
            const angleRad = Math.atan2(tx[1], tx[0]);

            const isDragging = dragState && dragState.id === id;
            const dragDx = isDragging ? dragState.dx : 0;
            const dragDy = isDragging ? dragState.dy : 0;

            const widthPx = imgOverride.width * scale;
            const heightPx = imgOverride.height * scale;
            const left = tx[4] + dragDx;
            const top = tx[5] - heightPx + dragDy;

            const isSelected = id === selectedImageId;

            const bgStyle = imgOverride.bgStyle || 'solid';
            const bgColor = imgOverride.bgColor || '#ffffff';
            const bgColor2 = imgOverride.bgColor2 || '#e1ebff';
            const bgSplitRatio = imgOverride.bgSplitRatio !== undefined ? imgOverride.bgSplitRatio : 0.5;

            let backgroundCSS = 'transparent';
            if (bgStyle === 'solid') {
              backgroundCSS = bgColor;
            } else if (bgStyle !== 'transparent') {
              const percent = Math.round(bgSplitRatio * 100);
              if (bgStyle === 'split-h') {
                backgroundCSS = `linear-gradient(to bottom, ${bgColor} ${percent}%, ${bgColor2} ${percent}%)`;
              } else if (bgStyle === 'split-v') {
                backgroundCSS = `linear-gradient(to right, ${bgColor} ${percent}%, ${bgColor2} ${percent}%)`;
              } else if (bgStyle === 'gradient-h') {
                backgroundCSS = `linear-gradient(to right, ${bgColor}, ${bgColor2})`;
              } else if (bgStyle === 'gradient-v') {
                backgroundCSS = `linear-gradient(to bottom, ${bgColor}, ${bgColor2})`;
              }
            }

            return (
              <div
                key={id}
                id={`image-${id}`}
                onClick={(e) => {
                  e.stopPropagation();
                  const rect = e.currentTarget.getBoundingClientRect();
                  onImageClick(id, pageIndex, rect);
                }}
                onPointerDown={(e) => handleBoxPointerDown(e, id, imgOverride.transform)}
                onPointerMove={handleBoxPointerMove}
                onPointerUp={(e) => handleBoxPointerUp(e, id)}
                onPointerCancel={(e) => handleBoxPointerUp(e, id)}
                draggable={true}
                onDragStart={(e) => handleDragStart(e, id, imgOverride.transform)}
                onDrag={handleDrag}
                onDragEnd={(e) => handleDragEnd(e, id)}
                className={`absolute pointer-events-auto group select-none transition-[box-shadow,ring,background-color,border-color] duration-150
                  ${isSelected ? 'ring-2 ring-[#5b8cff] z-50 shadow-2xl' : 'hover:ring-1 hover:ring-[#5b8cff]/50'}
                  ${isDragging ? 'cursor-grabbing z-50 ring-2 ring-[#5b8cff] shadow-xl scale-[1.01]' : 'cursor-grab'}
                  ${!isSelected && identifyImages ? 'ring-2 ring-cyan-400 ring-offset-1 ring-offset-[#1a1c24] bg-cyan-400/10 shadow-[0_0_10px_rgba(34,211,238,0.4)] animate-pulse' : ''}
                `}
                style={{
                  left: `${left}px`,
                  top: `${top}px`,
                  width: `${widthPx}px`,
                  height: `${heightPx}px`,
                  transform: `rotate(${angleRad}rad)`,
                  transformOrigin: 'left bottom',
                  touchAction: 'none',
                  background: backgroundCSS,
                  border: imgOverride.outlineWidth && imgOverride.outlineColor
                    ? `${imgOverride.outlineWidth * scale}px solid ${imgOverride.outlineColor}`
                    : 'none',
                }}
                onDragOver={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  e.dataTransfer.dropEffect = 'copy';
                }}
                onDrop={(e) => handleImageFileDrop(e, id)}
              >
                <div className="w-full h-full border border-dashed border-transparent hover:border-[#5b8cff] hover:bg-[#5b8cff]/15 flex items-center justify-center transition-all relative">
                  {imgOverride.imageBytes ? (
                    <img
                      src={imgOverride.imageBytes}
                      className="w-full h-full object-fill pointer-events-none"
                      alt="Added"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="text-[9px] text-slate-500 font-bold italic">Image Missing</div>
                  )}
                  <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 bg-black/85 text-white text-[9px] font-semibold px-1.5 py-0.5 rounded border border-[#2c2f3d]">
                    Custom Image
                  </div>

                  {/* Top-Right Delete Button */}
                  {isSelected && (
                    <button
                      onPointerDown={(e) => e.stopPropagation()}
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteImage(id, pageIndex);
                      }}
                      className="absolute -top-3.5 -right-3.5 w-7 h-7 bg-red-600 hover:bg-red-500 text-white rounded-full flex items-center justify-center shadow-lg border border-red-700 pointer-events-auto cursor-pointer z-50 transition-transform hover:scale-110 active:scale-95"
                      title="Delete image"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Bottom-Right Resize Handle */}
                  {isSelected && (
                    <div
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        handleResizePointerDown(e, id, imgOverride.width, imgOverride.height);
                      }}
                      onPointerMove={handleResizePointerMove}
                      onPointerUp={handleResizePointerUp}
                      onPointerCancel={handleResizePointerUp}
                      className="absolute -bottom-2.5 -right-2.5 w-5.5 h-5.5 bg-white hover:bg-[#e1ebff] border-2 border-[#5b8cff] rounded-full flex items-center justify-center shadow-lg pointer-events-auto cursor-se-resize z-50 transition-transform hover:scale-110"
                      title="Drag to Resize"
                    >
                      <div className="w-1.5 h-1.5 bg-[#5b8cff] rounded-full" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Interactive transparent text layers */}
        <div
          className="text-layer absolute inset-0 z-[60] pointer-events-none"
          style={{ width: `${viewport.width}px`, height: `${viewport.height}px` }}
        >
          {(() => {
            const shifts = getRunShifts();
            return effectiveRuns.map((run) => {
              const tx = transformMatrix(viewport.transform, run.transform);
              const angleRad = Math.atan2(tx[1], tx[0]);
              const fontHeightPx = Math.hypot(tx[2], tx[3]);
              const shiftX = shifts[run.id] || 0;
              const left = tx[4] + shiftX;
              const top = tx[5] - fontHeightPx;

              const editOverride = edits[run.id];
              const displayStr = editOverride ? editOverride.newText : run.str;
              const isEdited = !!editOverride;
              const isDeleted = editOverride && editOverride.newText === '';
              const isMatch = highlightedRunIds.has(run.id);

              const measuredWidthPx = editOverride 
                ? getStandardTextWidth(editOverride.newText, editOverride.family, editOverride.bold, editOverride.italic, fontHeightPx * editOverride.sizeMul)
                : 0;
              const widthPx = Math.max(run.width * scale * (editOverride?.sizeMul || 1), measuredWidthPx > 0 ? measuredWidthPx + 12 : 0);

              const isConnectSource = connectSourceId === run.id;
              const isConnectTarget = connectSourceId && connectSourceId !== run.id;

              return (
                <div
                  key={run.id}
                  id={`run-${run.id}`}
                  className={`run absolute whitespace-pre cursor-text select-none leading-none transition-all group pointer-events-auto
                    ${isDeleted 
                      ? 'border-2 border-dashed border-red-500/50 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-mono text-[9px] font-bold flex items-center justify-center rounded px-1' 
                      : (isConnectSource 
                        ? 'outline-2 outline-solid outline-[#10b981] bg-[#10b981]/15 text-transparent z-50 shadow-lg'
                        : (isConnectTarget 
                          ? 'outline-2 outline-dashed outline-[#10b981]/70 hover:outline-solid hover:outline-[#10b981] hover:bg-[#10b981]/25 text-transparent animate-pulse cursor-pointer'
                          : 'text-transparent hover:outline-2 hover:outline-dashed hover:outline-[#5b8cff]/90 hover:bg-[#5b8cff]/15'
                        )
                      )
                    }
                    ${isMatch ? 'outline-2 outline-solid outline-[#e0a84f] bg-[#e0a84f]/25 animate-pulse' : ''}
                  `}
                  style={{
                    left: `${left}px`,
                    top: `${top}px`,
                    fontSize: isDeleted ? '9px' : `${fontHeightPx * (editOverride?.sizeMul || 1)}px`,
                    width: `${widthPx}px`,
                    fontFamily: isDeleted ? 'monospace' : cssFamily(editOverride ? editOverride.family : (run.fontFamily || run.familyGuess)),
                  fontWeight: editOverride 
                    ? (editOverride.bold ? 'bold' : 'normal') 
                    : (run.boldGuess ? 'bold' : 'normal'),
                  fontStyle: editOverride 
                    ? (editOverride.italic ? 'italic' : 'normal') 
                    : (run.italicGuess ? 'italic' : 'normal'),
                  transform: `rotate(${angleRad}rad)`,
                  transformOrigin: 'left bottom',
                  height: `${(() => {
                    const textLinesCount = (displayStr || '').split('\n').length;
                    const effFontH = fontHeightPx * (editOverride?.sizeMul || 1);
                    return effFontH + Math.max(0, textLinesCount - 1) * (effFontH * 1.25);
                  })()}px`,
                  zIndex: 50,
                }}
                onMouseDown={(e) => {
                  e.stopPropagation();
                  if (!connectSourceId) {
                    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                    onRunClick(run.id, pageIndex, rect);
                  }
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  if (connectSourceId) {
                    if (isConnectSource) {
                      if (onStartConnect) onStartConnect('', pageIndex);
                    } else {
                      if (onMergeRuns) onMergeRuns(connectSourceId, run.id, pageIndex);
                      if (onStartConnect) onStartConnect('', pageIndex);
                    }
                  } else {
                    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                    onRunClick(run.id, pageIndex, rect);
                  }
                }}
                onDoubleClick={(e) => {
                  e.stopPropagation();
                  const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                  onRunClick(run.id, pageIndex, rect);
                }}
                title={isConnectSource ? 'Click to Cancel Connect Mode' : (isConnectTarget ? 'Click to Merge with selected' : (isDeleted ? 'Deleted Open Space - Click to edit/restore text' : (isEdited ? `Edited: "${displayStr}"` : 'Click to edit line')))}
              >
                {isDeleted ? '+ Open Space' : displayStr}

                {/* Click to Edit hover badge indicator */}
                {!isDeleted && !isConnectSource && !isConnectTarget && (
                  <span className="absolute -top-4 left-0 bg-blue-600 text-white text-[8px] font-mono px-1 py-0.5 rounded shadow-sm opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50">
                    Click to Edit Text
                  </span>
                )}
              </div>
            );
          });
        })()}
        </div>

        {/* Active Editing Box Highlight */}
        {viewport && selectedRunId && (
          <div
            className="absolute inset-0 z-40 pointer-events-none overflow-hidden"
            style={{ width: `${viewport.width}px`, height: `${viewport.height}px` }}
          >
            {(() => {
              const group = getGroupedRuns();
              if (!group || !group.active) return null;
              const { active } = group;

              return (
                <div
                  className="absolute border-2 border-solid border-blue-500 bg-blue-500/10 rounded-sm shadow-[0_0_8px_rgba(59,130,246,0.3)] transition-all"
                  style={{
                    left: `${active.left - 4}px`,
                    top: `${active.top - 2}px`,
                    width: `${active.width + 8}px`,
                    height: `${active.height + 4}px`,
                    transform: `rotate(${active.angleRad}rad)`,
                    transformOrigin: 'left bottom',
                  }}
                >
                  <div className="absolute -top-5 left-0 bg-blue-600 text-[9px] text-white px-1.5 py-0.5 rounded font-semibold whitespace-nowrap shadow-xs">
                    Editing Text
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {/* Open Space / Gap Detection Overlay */}
        {viewport && identifyGaps && (
          <div
            className="absolute inset-0 z-45 pointer-events-none overflow-hidden"
            style={{ width: `${viewport.width}px`, height: `${viewport.height}px` }}
          >
            {(() => {
              const gaps = detectGaps();
              return gaps.map((gap, gIdx) => {
                const isSelected = selectedGapIdxs.has(gIdx);
                const uniqueGapKey = `${gap.beforeId}-${gap.afterId}`;
                return (
                  <div
                    key={`gap-${gIdx}`}
                    className={`absolute border border-dashed rounded-sm transition-all flex items-center justify-between group pointer-events-auto overflow-visible
                      ${isSelected 
                        ? 'border-2 border-solid border-[#e0a84f] bg-[#e0a84f]/45 shadow-[0_0_12px_rgba(224,168,79,0.7)] z-40' 
                        : 'border-[#e0a84f]/60 bg-[#e0a84f]/15 hover:border-[#e0a84f]/100 hover:bg-[#e0a84f]/30 shadow-[0_0_8px_rgba(224,168,79,0.25)]'
                      }
                    `}
                    style={{
                      left: `${gap.left}px`,
                      top: `${gap.top}px`,
                      width: `${gap.width}px`,
                      height: `${gap.height}px`,
                    }}
                  >
                    {/* Editable direct input field inside the gap highlighted box */}
                    <div className="relative w-full h-full flex items-center">
                      <button
                        type="button"
                        title="Click to add custom styled text here"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onAddTextRunAtGap) {
                            onAddTextRunAtGap(pageIndex, gap.beforeId, gap.afterId, 'New Text', true);
                          }
                        }}
                        className="h-full px-1.5 bg-[#e0a84f]/25 hover:bg-[#e0a84f] text-[#1e1405] font-black text-[9px] transition-colors border-r border-[#e0a84f]/30 flex items-center justify-center cursor-pointer pointer-events-auto shrink-0"
                      >
                        + Add Text
                      </button>
                      <input
                        type="text"
                        placeholder="Type..."
                        value={gapTexts[uniqueGapKey] || ''}
                        onClick={(e) => e.stopPropagation()}
                        onMouseDown={(e) => e.stopPropagation()}
                        onPointerDown={(e) => e.stopPropagation()}
                        onChange={(e) => {
                          const val = e.target.value;
                          setGapTexts(prev => ({
                            ...prev,
                            [uniqueGapKey]: val
                          }));
                        }}
                        onKeyDown={(e) => {
                          e.stopPropagation();
                          if (e.key === 'Enter') {
                            const text = gapTexts[uniqueGapKey];
                            if (text && text.trim()) {
                              if (onAddTextRunAtGap) {
                                onAddTextRunAtGap(pageIndex, gap.beforeId, gap.afterId, text);
                              }
                              setGapTexts(prev => {
                                const next = { ...prev };
                                delete next[uniqueGapKey];
                                return next;
                              });
                            }
                          }
                        }}
                        className="w-full h-full bg-transparent border-none text-[10px] font-sans font-semibold text-[#1e1405] placeholder-[#1e1405]/50 text-center outline-none px-1"
                      />

                      {/* Smart Floating Formatting Bar */}
                      {gapTexts[uniqueGapKey] && gapTexts[uniqueGapKey].trim() && (
                        <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 flex items-center gap-1 bg-[#101216] border border-[#2c2f3d] rounded-lg p-1 shadow-2xl z-50 pointer-events-auto min-w-[200px]">
                          <button
                            title="Insert with Same Sibling Formatting"
                            onMouseDown={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              const text = gapTexts[uniqueGapKey];
                              if (text && text.trim() && onAddTextRunAtGap) {
                                onAddTextRunAtGap(pageIndex, gap.beforeId, gap.afterId, text);
                                setGapTexts(prev => {
                                  const next = { ...prev };
                                  delete next[uniqueGapKey];
                                  return next;
                                });
                              }
                            }}
                            className="flex-1 py-1 px-1.5 text-[9px] bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500 hover:text-white rounded-md font-bold transition-all cursor-pointer text-center whitespace-nowrap"
                          >
                            ✓ Same Formatting
                          </button>
                          <button
                            title="Insert and open full Styling Palette"
                            onMouseDown={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              const text = gapTexts[uniqueGapKey];
                              if (onAddTextRunAtGap) {
                                onAddTextRunAtGap(pageIndex, gap.beforeId, gap.afterId, text || 'New Text', true);
                                setGapTexts(prev => {
                                  const next = { ...prev };
                                  delete next[uniqueGapKey];
                                  return next;
                                });
                              }
                            }}
                            className="flex-1 py-1 px-1.5 text-[9px] bg-[#5b8cff]/15 border border-[#5b8cff]/30 text-[#5b8cff] hover:bg-[#5b8cff] hover:text-white rounded-md font-bold transition-all cursor-pointer text-center whitespace-nowrap"
                          >
                            🎨 Custom Styling
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Merge Selection Button */}
                    <div className="absolute -top-2.5 -right-2.5 z-45 flex items-center">
                      <button
                        title={isSelected ? "Deselect from merging" : "Select for merging"}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedGapIdxs((prev) => {
                            const next = new Set(prev);
                            if (next.has(gIdx)) {
                              next.delete(gIdx);
                            } else {
                              next.add(gIdx);
                            }
                            return next;
                          });
                        }}
                        className={`w-5 h-5 rounded-full flex items-center justify-center border text-[9px] font-bold transition-all cursor-pointer shadow-lg hover:scale-110 active:scale-95
                          ${isSelected 
                            ? 'bg-[#e0a84f] border-[#1e1405] text-[#1e1405]' 
                            : 'bg-[#1e1405] border-[#e0a84f] text-[#e0a84f] hover:bg-[#e0a84f] hover:text-[#1e1405]'
                          }
                        `}
                      >
                        {isSelected ? '✓' : '+'}
                      </button>
                    </div>

                    <div className="absolute -bottom-5 bg-[#e0a84f] text-[8px] text-[#1e1405] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 shadow-md pointer-events-none">
                      Type directly or click '+' to merge spaces
                    </div>
                  </div>
                );
              });
            })()}
          </div>
        )}

        {/* Floating Merge Button for Gap Slots */}
        {viewport && selectedGapIdxs.size >= 2 && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 animate-bounce">
            <button
              onClick={(e) => {
                e.stopPropagation();
                const gaps = detectGaps();
                const selectedGapsList = [...selectedGapIdxs].map((idx: number) => gaps[idx]);
                
                const minLeft = Math.min(...selectedGapsList.map(g => g.left));
                const minTop = Math.min(...selectedGapsList.map(g => g.top));
                const maxRight = Math.max(...selectedGapsList.map(g => g.left + g.width));
                const maxBottom = Math.max(...selectedGapsList.map(g => g.top + g.height));
                
                const [pdfLeft, pdfTop] = viewport.convertToPdfPoint(minLeft, minTop);
                const [pdfRight, pdfBottom] = viewport.convertToPdfPoint(maxRight, maxBottom);
                
                const pdfW = Math.max(20, pdfRight - pdfLeft);
                const pdfH = Math.max(10, pdfTop - pdfBottom);

                if (onMergeGaps) {
                  onMergeGaps(pageIndex, pdfLeft, pdfBottom, pdfW, pdfH);
                }
                setSelectedGapIdxs(new Set());
              }}
              className="px-4 py-2 bg-[#e0a84f] hover:bg-[#d49635] text-[#1e1405] text-xs font-bold font-sans rounded-full shadow-2xl border border-[#ffffff]/20 flex items-center gap-1.5 transition-all hover:scale-105 active:scale-95 pointer-events-auto cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3px]" />
              Merge {selectedGapIdxs.size} Selected Open Spaces
            </button>
          </div>
        )}

        {/* Context click menu to insert elements anywhere in empty space */}
        {viewport && activeClickMenu && (
          <div
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
            className="absolute z-50 bg-[#171a25] border border-[#2c2f3d] rounded-xl shadow-2xl p-2.5 flex flex-col gap-1.5 w-44 font-sans text-xs"
            style={{
              left: `${activeClickMenu.x}px`,
              top: `${activeClickMenu.y}px`,
              transform: 'translate(-50%, -100%) translateY(-10px)'
            }}
          >
            <div className="text-[9px] font-bold text-[#9297a3] uppercase tracking-wider border-b border-[#2c2f3d]/60 pb-1.5 mb-1 text-center">
              Insert Element
            </div>
            
            <button
              onClick={() => {
                if (onAddTextAtCoord) {
                  onAddTextAtCoord(pageIndex, activeClickMenu.pdfX, activeClickMenu.pdfY);
                }
                setActiveClickMenu(null);
              }}
              className="w-full text-left px-2 py-1.5 rounded hover:bg-[#5b8cff] hover:text-white transition-colors flex items-center gap-1.5 text-[#e8e9ec] font-medium cursor-pointer"
            >
              <span className="font-bold text-sm leading-none">+</span>
              Write Text Here
            </button>
            
            <button
              onClick={() => {
                const fileInput = document.createElement('input');
                fileInput.type = 'file';
                fileInput.accept = 'image/png, image/jpeg';
                fileInput.onchange = (ev: any) => {
                  const file = ev.target.files?.[0];
                  if (file) {
                    const type = file.type === 'image/png' ? 'png' : 'jpeg';
                    const reader = new FileReader();
                    reader.onload = () => {
                      if (typeof reader.result === 'string') {
                        const img = new Image();
                        img.src = reader.result;
                        img.onload = () => {
                          const w = 120;
                          const h = 120 * (img.height / img.width);
                          const transform = [w, 0, 0, h, activeClickMenu.pdfX - w/2, activeClickMenu.pdfY - h/2 + h];
                          onPlaceNewImageWithBytes(pageIndex, transform, reader.result as string, type);
                        };
                      }
                    };
                    reader.readAsDataURL(file);
                  }
                };
                fileInput.click();
                setActiveClickMenu(null);
              }}
              className="w-full text-left px-2 py-1.5 rounded hover:bg-[#5b8cff] hover:text-white transition-colors flex items-center gap-1.5 text-[#e8e9ec] font-medium cursor-pointer"
            >
              <span className="font-bold text-sm leading-none">+</span>
              Insert Image Here
            </button>
            
            <div className="flex items-center justify-between border-t border-[#2c2f3d]/60 pt-1.5 mt-1 text-[9px] text-[#9297a3] font-mono">
              <span>X: {Math.round(activeClickMenu.pdfX)}pt</span>
              <span>Y: {Math.round(activeClickMenu.pdfY)}pt</span>
            </div>
          </div>
        )}

        {/* Dynamic Page Numbering Layer */}
        {viewport && pageNumbering?.enabled && (
          (() => {
            const isWithinRange = pageNumbering.useAllPages || 
              ((pageIndex + 1) >= (pageNumbering.startPage || 1) && (pageIndex + 1) <= (pageNumbering.endPage || 9999));
            
            if (!isWithinRange) return null;
            
            let textStr = `${pageIndex + 1}`;
            if (pageNumbering.style === 'standard') {
              textStr = `Page ${pageIndex + 1}`;
            } else if (pageNumbering.style === 'of-total') {
              textStr = `Page ${pageIndex + 1} of ${totalPages || pageIndex + 1}`;
            } else if (pageNumbering.style === 'boxed') {
              textStr = `Page ${pageIndex + 1}`;
            }
            
            const posClasses = {
              'bottom-center': 'bottom-4 left-1/2 -translate-x-1/2',
              'bottom-right': 'bottom-4 right-4',
              'bottom-left': 'bottom-4 left-4',
              'top-center': 'top-4 left-1/2 -translate-x-1/2',
              'top-right': 'top-4 right-4',
              'top-left': 'top-4 left-4',
            }[pageNumbering.position as 'bottom-center' || 'bottom-center'];
            
            const isBoxed = pageNumbering.style === 'boxed';
            
            return (
              <div
                className={`absolute pointer-events-none z-30 font-medium tracking-wide
                  ${posClasses}
                  ${isBoxed 
                    ? 'border border-[#2c2f3d] bg-[#1a1c24] px-2.5 py-1 rounded shadow-md text-xs text-[#e8e9ec] font-mono' 
                    : 'text-xs font-sans'
                  }
                `}
                style={{ color: pageNumbering.color || '#6b7280' }}
              >
                {textStr}
              </div>
            );
          })()
        )}

        {renderError && (
          <div className="absolute inset-0 bg-red-950/80 z-50 flex flex-col items-center justify-center p-6 text-center">
            <span className="text-red-400 font-semibold mb-2">Failed to render page</span>
            <span className="text-red-300/80 text-xs font-mono max-w-md">{renderError}</span>
          </div>
        )}
      </div>
    </div>
  );
}
