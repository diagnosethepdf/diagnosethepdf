import React, { useState } from 'react';
import {
  ShieldCheck,
  Building2,
  Stethoscope,
  DollarSign,
  GraduationCap,
  Sparkles,
  KeyRound,
  CheckCircle2,
  Lock,
  Smartphone,
  Cpu,
  Fingerprint,
  Mail,
  Globe,
  UserCheck,
  X,
  ShieldAlert,
  HardDrive,
  QrCode,
  Zap,
  BadgeCheck
} from 'lucide-react';

export interface IAMUserProfile {
  isLoggedIn: boolean;
  id: string;
  name: string;
  email: string;
  domain: 'gov' | 'health' | 'fin' | 'edu' | 'general';
  domainLabel: string;
  authMethod: string;
  clearance: string;
  role: 'admin' | 'editor' | 'viewer' | 'auditor';
  organization: string;
  ipAddress: string;
  tokenHash: string;
  issuedAt: string;
  avatarIcon?: string;
}

interface IamModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: IAMUserProfile;
  onAuthenticate: (user: IAMUserProfile) => void;
  theme: any;
}

export const EnterpriseIamPortalModal: React.FC<IamModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onAuthenticate,
  theme,
}) => {
  const [activeTab, setActiveTab] = useState<'gov' | 'health' | 'fin' | 'edu' | 'general'>('gov');

  // Domain 1: Gov States
  const [govPivPin, setGovPivPin] = useState('849201');
  const [govCert, setGovCert] = useState('DoD CA-59 (PIV-AUTH) - EDIPI #1084920412');
  const [govClearance, setGovClearance] = useState('TOP SECRET / CUI');
  const [govOrg, setGovOrg] = useState('US Dept of Defense / Defense Logistics Agency');

  // Domain 2: Health States
  const [healthNpi, setHealthNpi] = useState('1942850129');
  const [healthSystem, setHealthSystem] = useState('Epic Hyperspace / Mayo Clinic SSO');
  const [healthEpcsCode, setHealthEpcsCode] = useState('942104');
  const [healthRole, setHealthRole] = useState('Attending Physician / EPCS Level 3');

  // Domain 3: Fin States
  const [finIdp, setFinIdp] = useState('Okta Universal Directory');
  const [finTenant, setFinTenant] = useState('capital-partners.okta.com');
  const [finMfaCode, setFinMfaCode] = useState('739102');
  const [finRole, setFinRole] = useState('M&A Senior Partner / Administrator');

  // Domain 4: Edu States
  const [eduInst, setEduInst] = useState('Harvard University / EduGAIN Federation');
  const [eduOrcid, setEduOrcid] = useState('0000-0002-1825-0097');
  const [eduRole, setEduRole] = useState('Principal Investigator (PI)');

  // Domain 5: General States
  const [genEmail, setGenEmail] = useState('alex.vance@enterprise-corp.com');
  const [genRole, setGenRole] = useState<'admin' | 'editor' | 'viewer'>('admin');

  // Authentication Processing state
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authSuccessMsg, setAuthSuccessMsg] = useState('');

  if (!isOpen) return null;

  const handleRunAuth = (domainType: 'gov' | 'health' | 'fin' | 'edu' | 'general') => {
    setIsAuthenticating(true);
    setAuthSuccessMsg('');

    setTimeout(() => {
      setIsAuthenticating(false);
      let profile: IAMUserProfile;

      const now = new Date().toLocaleString();
      const randomIp = `192.168.1.${Math.floor(Math.random() * 200) + 10} (TLS 1.3 Strict)`;
      const tokenHash = `SHA256-${Math.random().toString(36).substring(2, 10).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;

      if (domainType === 'gov') {
        profile = {
          isLoggedIn: true,
          id: `CAC-${Math.floor(Math.random() * 89999) + 10000}`,
          name: 'Cmdr. Alex Vance, USN',
          email: 'alex.vance.mil@mail.mil',
          domain: 'gov',
          domainLabel: '🏛️ Public Sector & Defense (FIPS 140-3)',
          authMethod: 'CAC/PIV Hardware Smart Card & DoD PKI',
          clearance: govClearance,
          role: 'admin',
          organization: govOrg,
          ipAddress: randomIp,
          tokenHash,
          issuedAt: now,
        };
      } else if (domainType === 'health') {
        profile = {
          isLoggedIn: true,
          id: `NPI-${healthNpi}`,
          name: 'Dr. Alex Vance, MD',
          email: 'alex.vance@mayoclinic.org',
          domain: 'health',
          domainLabel: '🩺 Healthcare & Clinical (HIPAA / EPCS)',
          authMethod: 'HIPAA Certified Biometric & EPCS 2FA',
          clearance: healthRole,
          role: 'admin',
          organization: healthSystem,
          ipAddress: randomIp,
          tokenHash,
          issuedAt: now,
        };
      } else if (domainType === 'fin') {
        profile = {
          isLoggedIn: true,
          id: `FIN-${Math.floor(Math.random() * 89999) + 10000}`,
          name: 'Alex Vance, CFA',
          email: 'alex.vance@capitalpartners.com',
          domain: 'fin',
          domainLabel: '💰 Financial & M&A (SOC2 / SAML 2.0)',
          authMethod: `${finIdp} SAML 2.0 & FIDO2 YubiKey`,
          clearance: finRole,
          role: 'admin',
          organization: finTenant,
          ipAddress: randomIp,
          tokenHash,
          issuedAt: now,
        };
      } else if (domainType === 'edu') {
        profile = {
          isLoggedIn: true,
          id: `ORCID-${eduOrcid}`,
          name: 'Prof. Alex Vance, Ph.D.',
          email: 'avance@harvard.edu',
          domain: 'edu',
          domainLabel: '🎓 Academic & Research (EduGAIN / ORCID)',
          authMethod: 'Shibboleth SSO & ORCID Verified iD',
          clearance: eduRole,
          role: 'editor',
          organization: eduInst,
          ipAddress: randomIp,
          tokenHash,
          issuedAt: now,
        };
      } else {
        profile = {
          isLoggedIn: true,
          id: `USR-${Math.floor(Math.random() * 89999) + 10000}`,
          name: 'Alex Vance',
          email: genEmail,
          domain: 'general',
          domainLabel: '🎨 Enterprise OAuth & Magic Link',
          authMethod: 'Google Workspace OIDC Single Sign-On',
          clearance: 'Standard Enterprise Workspace Member',
          role: genRole,
          organization: 'Global Creative Enterprise',
          ipAddress: randomIp,
          tokenHash,
          issuedAt: now,
        };
      }

      setAuthSuccessMsg(`✅ Authenticated successfully as ${profile.name}!`);
      onAuthenticate(profile);

      setTimeout(() => {
        setAuthSuccessMsg('');
        onClose();
      }, 1200);
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className={`max-w-4xl w-full rounded-3xl border-2 shadow-2xl overflow-hidden flex flex-col max-h-[90vh] transition-all ${
        theme.isLight
          ? 'bg-white border-slate-200 text-slate-900 shadow-slate-900/10'
          : 'bg-[#111422] border-[#292e44] text-white shadow-black/80'
      }`}>
        {/* Modal Top Sticky Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-transparent">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black tracking-tight font-display">
                  🔑 Enterprise IAM Access &amp; Identity Portal
                </h2>
                <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-blue-500/15 text-blue-600 dark:text-blue-400 border border-blue-500/30 uppercase">
                  ZERO TRUST AUTH
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Select domain-specific authentication provider to issue verified cryptographic session token.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Identity Banner if logged in */}
        {currentUser.isLoggedIn && (
          <div className="px-6 py-3 bg-emerald-500/15 border-b border-emerald-500/30 text-emerald-800 dark:text-emerald-300 text-xs font-bold flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <BadgeCheck className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>
                Active Session: <strong className="text-slate-900 dark:text-white">{currentUser.name}</strong> ({currentUser.domainLabel}) — {currentUser.clearance}
              </span>
            </div>
            <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              Token ID: {currentUser.id}
            </span>
          </div>
        )}

        {/* 5 Domain Tab Selector */}
        <div className="p-4 bg-slate-50 dark:bg-[#0b0d18] border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-x-auto">
          {[
            { id: 'gov', label: '🏛️ Public Sector & Defense', desc: 'CAC / PIV & PKI Hardware', icon: Building2, color: 'text-amber-500' },
            { id: 'health', label: '🩺 Healthcare & Clinical', desc: 'HIPAA & EPCS Biometric', icon: Stethoscope, color: 'text-rose-500' },
            { id: 'fin', label: '💰 Financial & M&A', desc: 'SAML 2.0 & FIDO2 YubiKey', icon: DollarSign, color: 'text-emerald-500' },
            { id: 'edu', label: '🎓 Academic & Research', desc: 'EduGAIN & ORCID SSO', icon: GraduationCap, color: 'text-sky-500' },
            { id: 'general', label: '🎨 Enterprise & Creative', desc: 'Google / OIDC Magic Link', icon: Globe, color: 'text-purple-500' },
          ].map((tab) => {
            const isSelected = activeTab === tab.id;
            const IconComp = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 min-w-[160px] p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-600/20 font-black'
                    : 'bg-white dark:bg-[#141829] border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-blue-400'
                }`}
              >
                <div className="flex items-center gap-2">
                  <IconComp className={`w-4 h-4 ${isSelected ? 'text-white' : tab.color}`} />
                  <span className="text-xs font-bold truncate">{tab.label}</span>
                </div>
                <p className={`text-[10px] mt-1 truncate ${isSelected ? 'text-blue-100' : 'text-slate-500 dark:text-slate-400'}`}>
                  {tab.desc}
                </p>
              </button>
            );
          })}
        </div>

        {/* Modal Main Form Content */}
        <div className="p-6 sm:p-8 flex-1 overflow-y-auto space-y-6">
          
          {/* TAB 1: PUBLIC SECTOR & DEFENSE (CAC / PIV) */}
          {activeTab === 'gov' && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-800 dark:text-amber-300 text-xs flex items-start gap-3">
                <Cpu className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-extrabold text-slate-900 dark:text-white text-sm">🏛️ DoD CAC / PIV Smart Card &amp; Federal PKI Auth</h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">
                    Compliant with FIPS 140-3, OMB M-19-17, and FedRAMP High. Connects to Active USB Smart Card Reader.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Detected Smart Card Certificate:
                  </label>
                  <select
                    value={govCert}
                    onChange={(e) => setGovCert(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono focus:outline-none focus:border-amber-500"
                  >
                    <option value="DoD CA-59 (PIV-AUTH) - EDIPI #1084920412">DoD CA-59 (PIV-AUTH) - EDIPI #1084920412</option>
                    <option value="GSA Federal PKI - Card #942185-CIV">GSA Federal PKI - Card #942185-CIV</option>
                    <option value="DHS PIV Token #849120-CYBER">DHS PIV Token #849120-CYBER</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Department Security Clearance:
                  </label>
                  <select
                    value={govClearance}
                    onChange={(e) => setGovClearance(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold focus:outline-none focus:border-amber-500"
                  >
                    <option value="TOP SECRET / CUI">TOP SECRET / CUI</option>
                    <option value="SECRET / FOUO">SECRET / FOUO</option>
                    <option value="CUI / RESTRICTED">CUI / RESTRICTED</option>
                    <option value="UNCLASSIFIED">UNCLASSIFIED</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Smart Card PIN (6-8 Digits):
                  </label>
                  <input
                    type="password"
                    value={govPivPin}
                    onChange={(e) => setGovPivPin(e.target.value)}
                    placeholder="Enter PIN..."
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Agency / Command Organization:
                  </label>
                  <input
                    type="text"
                    value={govOrg}
                    onChange={(e) => setGovOrg(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-medium focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="pt-3">
                <button
                  type="button"
                  disabled={isAuthenticating}
                  onClick={() => handleRunAuth('gov')}
                  className="w-full py-3.5 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-500 text-white font-black text-xs rounded-2xl shadow-xl shadow-amber-600/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <KeyRound className="w-4 h-4" />
                  <span>{isAuthenticating ? 'VERIFYING CAC/PIV HARDWARE TOKEN...' : 'VERIFY CAC SMART CARD & ISSUE FIPS 140-3 SESSION'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: HEALTHCARE & CLINICAL (HIPAA / EPCS) */}
          {activeTab === 'health' && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-800 dark:text-rose-300 text-xs flex items-start gap-3">
                <Stethoscope className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-extrabold text-slate-900 dark:text-white text-sm">🩺 HIPAA / EPCS Certified Biometric &amp; EHR Login</h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">
                    Compliant with DEA 21 CFR Part 1311 for Electronic Prescribing of Controlled Substances (EPCS) &amp; HIPAA Privacy Shield.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Clinician National Provider ID (NPI):
                  </label>
                  <input
                    type="text"
                    value={healthNpi}
                    onChange={(e) => setHealthNpi(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Health Network / EHR Integration:
                  </label>
                  <select
                    value={healthSystem}
                    onChange={(e) => setHealthSystem(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold focus:outline-none focus:border-rose-500"
                  >
                    <option value="Epic Hyperspace / Mayo Clinic SSO">Epic Hyperspace / Mayo Clinic SSO</option>
                    <option value="Cerner Millennium / Kaiser Permanente">Cerner Millennium / Kaiser Permanente</option>
                    <option value="AthenaHealth Clinical EHR">AthenaHealth Clinical EHR</option>
                    <option value="Allscripts Sunrise Hospital Gateway">Allscripts Sunrise Hospital Gateway</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    EPCS Hardware Token 6-Digit OTP:
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    value={healthEpcsCode}
                    onChange={(e) => setHealthEpcsCode(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono tracking-widest focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Clinical Practitioner Role:
                  </label>
                  <select
                    value={healthRole}
                    onChange={(e) => setHealthRole(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold focus:outline-none focus:border-rose-500"
                  >
                    <option value="Attending Physician / EPCS Level 3">Attending Physician / EPCS Level 3</option>
                    <option value="Clinical Pharmacist / Auditor">Clinical Pharmacist / Auditor</option>
                    <option value="Chief Medical Information Officer">Chief Medical Information Officer</option>
                  </select>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-100 dark:bg-[#161a29] border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-bold">
                  <Fingerprint className="w-5 h-5 animate-pulse" />
                  <span>Biometric Facial &amp; Fingerprint ID Match Verified</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-black">
                  DEA 21 CFR Compliant
                </span>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  disabled={isAuthenticating}
                  onClick={() => handleRunAuth('health')}
                  className="w-full py-3.5 bg-gradient-to-r from-rose-600 via-pink-600 to-rose-700 hover:from-rose-500 hover:to-pink-500 text-white font-black text-xs rounded-2xl shadow-xl shadow-rose-600/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Fingerprint className="w-4 h-4" />
                  <span>{isAuthenticating ? 'AUTHENTICATING EPCS BIOMETRIC...' : 'AUTHENTICATE EPCS & ISSUE HIPAA CLINICAL TOKEN'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: FINANCIAL & M&A (SAML 2.0 / OKTA) */}
          {activeTab === 'fin' && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 text-xs flex items-start gap-3">
                <DollarSign className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-extrabold text-slate-900 dark:text-white text-sm">💰 OAuth2 / SAML 2.0 Enterprise SSO (Okta, Azure AD)</h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">
                    Compliant with SOC2 Type II, SEC Rule 17a-4, FIDO2 WebAuthn &amp; YubiKey MFA hardware Enforcer.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Identity Provider (IdP):
                  </label>
                  <select
                    value={finIdp}
                    onChange={(e) => setFinIdp(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Okta Universal Directory">Okta Universal Directory</option>
                    <option value="Microsoft Azure AD / Entra ID">Microsoft Azure AD / Entra ID</option>
                    <option value="Ping Identity / PingFederate">Ping Identity / PingFederate</option>
                    <option value="OneLogin Enterprise SSO">OneLogin Enterprise SSO</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Enterprise Tenant Domain:
                  </label>
                  <input
                    type="text"
                    value={finTenant}
                    onChange={(e) => setFinTenant(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    FIDO2 YubiKey / WebAuthn Touch Code:
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    value={finMfaCode}
                    onChange={(e) => setFinMfaCode(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono tracking-widest focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    M&amp;A Financial Role:
                  </label>
                  <select
                    value={finRole}
                    onChange={(e) => setFinRole(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold focus:outline-none focus:border-emerald-500"
                  >
                    <option value="M&A Senior Partner / Administrator">M&A Senior Partner / Administrator</option>
                    <option value="Investment Banking Compliance Lead">Investment Banking Compliance Lead</option>
                    <option value="Corporate Audit & Tax Lead">Corporate Audit & Tax Lead</option>
                  </select>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  disabled={isAuthenticating}
                  onClick={() => handleRunAuth('fin')}
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs rounded-2xl shadow-xl shadow-emerald-600/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isAuthenticating ? 'VERIFYING SAML 2.0 & FIDO2 TOKEN...' : 'SIGN IN VIA OKTA / AZURE SAML 2.0 & YUBIKEY'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: ACADEMIC & RESEARCH (EduGAIN / ORCID) */}
          {activeTab === 'edu' && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className="p-4 rounded-2xl bg-sky-500/10 border border-sky-500/30 text-sky-800 dark:text-sky-300 text-xs flex items-start gap-3">
                <GraduationCap className="w-5 h-5 text-sky-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-extrabold text-slate-900 dark:text-white text-sm">🎓 Shibboleth / EduGAIN / ORCID Researcher Auth</h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">
                    SAML EduGAIN Federation for worldwide research institutions, IEEE/APA publications, and ORCID iD verification.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    University / Research Institution:
                  </label>
                  <select
                    value={eduInst}
                    onChange={(e) => setEduInst(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold focus:outline-none focus:border-sky-500"
                  >
                    <option value="Harvard University / EduGAIN Federation">Harvard University / EduGAIN Federation</option>
                    <option value="Massachusetts Institute of Technology (MIT)">Massachusetts Institute of Technology (MIT)</option>
                    <option value="Oxford University Research Network">Oxford University Research Network</option>
                    <option value="ETH Zürich Scientific Institute">ETH Zürich Scientific Institute</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Verified ORCID iD Number:
                  </label>
                  <input
                    type="text"
                    value={eduOrcid}
                    onChange={(e) => setEduOrcid(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Academic Fellowship / Peer Review Designation:
                  </label>
                  <select
                    value={eduRole}
                    onChange={(e) => setEduRole(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold focus:outline-none focus:border-sky-500"
                  >
                    <option value="Principal Investigator (PI)">Principal Investigator (PI)</option>
                    <option value="Peer Reviewer & Editorial Board">Peer Reviewer & Editorial Board</option>
                    <option value="Postdoctoral Research Fellow">Postdoctoral Research Fellow</option>
                  </select>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  disabled={isAuthenticating}
                  onClick={() => handleRunAuth('edu')}
                  className="w-full py-3.5 bg-gradient-to-r from-sky-600 via-indigo-600 to-sky-700 hover:from-sky-500 hover:to-indigo-500 text-white font-black text-xs rounded-2xl shadow-xl shadow-sky-600/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <GraduationCap className="w-4 h-4" />
                  <span>{isAuthenticating ? 'AUTHENTICATING VIA SHIBBOLETH...' : 'AUTHENTICATE VIA EDUGAIN SSO & VERIFY ORCID iD'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 5: GENERAL ENTERPRISE & CREATIVE */}
          {activeTab === 'general' && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/30 text-purple-800 dark:text-purple-300 text-xs flex items-start gap-3">
                <Globe className="w-5 h-5 text-purple-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-extrabold text-slate-900 dark:text-white text-sm">🎨 Enterprise OAuth2 &amp; Passwordless Magic Link</h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">
                    Fast 1-click authentication using Google Workspace, Apple ID, or work email passwordless magic link.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Enterprise Work Email Address:
                  </label>
                  <input
                    type="email"
                    value={genEmail}
                    onChange={(e) => setGenEmail(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-medium focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-1.5">
                    Default Workspace Role:
                  </label>
                  <select
                    value={genRole}
                    onChange={(e) => setGenRole(e.target.value as any)}
                    className="w-full text-xs p-2.5 rounded-xl border bg-slate-50 dark:bg-[#0b0d18] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold focus:outline-none focus:border-purple-500"
                  >
                    <option value="admin">Administrator (Full Access)</option>
                    <option value="editor">Editor (Create &amp; Modify)</option>
                    <option value="viewer">Viewer (Read Only)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  disabled={isAuthenticating}
                  onClick={() => handleRunAuth('general')}
                  className="py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs rounded-2xl shadow-lg shadow-purple-600/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Zap className="w-4 h-4 text-amber-300" />
                  <span>1-Click Google Workspace SSO</span>
                </button>

                <button
                  type="button"
                  disabled={isAuthenticating}
                  onClick={() => handleRunAuth('general')}
                  className="py-3 bg-slate-900 hover:bg-black text-white font-black text-xs rounded-2xl border border-slate-700 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Mail className="w-4 h-4 text-purple-400" />
                  <span>Send Passwordless Magic Link</span>
                </button>
              </div>
            </div>
          )}

          {/* Success Notification Alert */}
          {authSuccessMsg && (
            <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-800 dark:text-emerald-200 font-extrabold text-xs flex items-center gap-2 shadow-xl animate-in fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
              <span>{authSuccessMsg}</span>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 dark:bg-[#0d0f19] border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs font-mono text-slate-500">
          <span>🔒 TLS 1.3 Strict Encrypted Tunnel</span>
          <span>Zero-Knowledge Identity Vault</span>
        </div>
      </div>
    </div>
  );
};
