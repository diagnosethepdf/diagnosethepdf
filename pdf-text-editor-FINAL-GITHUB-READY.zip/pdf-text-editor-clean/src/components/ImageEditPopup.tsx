/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { ImageEditOverride } from '../types';
import { X, Trash2, Upload, RefreshCw, FileImage, Check, Link2, Link2Off, Maximize2, Palette } from 'lucide-react';

interface ImageEditPopupProps {
  imageId: string;
  pageIdx: number;
  rect: DOMRect;
  existingEdit?: ImageEditOverride;
  origTransform: number[];
  origWidth: number;
  origHeight: number;
  onSave: (override: ImageEditOverride) => void;
  onDelete: () => void;
  onCancel: () => void;
  isDiagram?: boolean;
  diagType?: 'grid-horizontal' | 'grid-vertical' | 'table-cell' | 'checkbox' | 'icon-bullet' | 'diagram-generic';
  diagLabel?: string;
  onAddTextOverImage?: () => void;
}

const PRESET_COLORS = [
  '#ffffff', '#000000', '#f3f4f6', '#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#14b8a6'
];

export default function ImageEditPopup({
  imageId,
  pageIdx,
  rect,
  existingEdit,
  origTransform,
  origWidth,
  origHeight,
  onSave,
  onDelete,
  onCancel,
  isDiagram = false,
  diagType,
  diagLabel,
  onAddTextOverImage,
}: ImageEditPopupProps) {
  const popupRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [imgType, setImgType] = useState<'png' | 'jpeg'>('png');
  const [width, setWidth] = useState(Math.round(origWidth));
  const [height, setHeight] = useState(Math.round(origHeight));
  const [lockAspectRatio, setLockAspectRatio] = useState(true);
  const [outlineColor, setOutlineColor] = useState('#3b82f6');
  const [outlineWidth, setOutlineWidth] = useState(0);
  const [bgColor, setBgColor] = useState('#ffffff');
  const [bgColor2, setBgColor2] = useState('#e1ebff');
  const [bgStyle, setBgStyle] = useState<'solid' | 'split-h' | 'split-v' | 'gradient-h' | 'gradient-v' | 'transparent'>('solid');
  const [bgSplitRatio, setBgSplitRatio] = useState(0.5);
  
  const [pos, setPos] = useState({ left: 0, top: 0 });

  const getBackgroundStyle = () => {
    if (bgStyle === 'transparent') {
      return { background: 'transparent' };
    }
    if (bgStyle === 'solid') {
      return { backgroundColor: bgColor };
    }
    const percent = Math.round(bgSplitRatio * 100);
    if (bgStyle === 'split-h') {
      return {
        background: `linear-gradient(to bottom, ${bgColor} ${percent}%, ${bgColor2} ${percent}%)`,
      };
    }
    if (bgStyle === 'split-v') {
      return {
        background: `linear-gradient(to right, ${bgColor} ${percent}%, ${bgColor2} ${percent}%)`,
      };
    }
    if (bgStyle === 'gradient-h') {
      return {
        background: `linear-gradient(to right, ${bgColor}, ${bgColor2})`,
      };
    }
    if (bgStyle === 'gradient-v') {
      return {
        background: `linear-gradient(to bottom, ${bgColor}, ${bgColor2})`,
      };
    }
    return { backgroundColor: bgColor };
  };

  useEffect(() => {
    // Position calculation with strict boundaries check
    const popupWidth = 295;
    const popupHeight = 410;

    let left = rect.left;
    let top = rect.bottom + 8;

    if (left + popupWidth > window.innerWidth - 12) {
      left = window.innerWidth - popupWidth - 12;
    }
    left = Math.max(12, left);

    if (top + popupHeight > window.innerHeight - 12) {
      const topAbove = rect.top - popupHeight - 8;
      if (topAbove >= 12) {
        top = topAbove;
      } else {
        top = Math.max(12, window.innerHeight - popupHeight - 12);
      }
    }
    top = Math.max(12, top);

    setPos({ left, top });

    if (existingEdit) {
      setPreviewUrl(existingEdit.imageBytes || null);
      setImgType(existingEdit.imageType);
      setWidth(Math.round(existingEdit.width));
      setHeight(Math.round(existingEdit.height));
      setOutlineColor(existingEdit.outlineColor || '#3b82f6');
      setOutlineWidth(existingEdit.outlineWidth || 0);
      setBgColor(existingEdit.bgColor || '#ffffff');
      setBgColor2(existingEdit.bgColor2 || '#e1ebff');
      setBgStyle(existingEdit.bgStyle || 'solid');
      setBgSplitRatio(existingEdit.bgSplitRatio !== undefined ? existingEdit.bgSplitRatio : 0.5);
    } else {
      setPreviewUrl(null);
      setWidth(Math.round(origWidth));
      setHeight(Math.round(origHeight));
      setOutlineColor('#3b82f6');
      setOutlineWidth(0);
      setBgColor('#ffffff');
      setBgColor2('#e1ebff');
      setBgStyle('solid');
      setBgSplitRatio(0.5);
    }
  }, [imageId, pageIdx, rect, existingEdit, origWidth, origHeight]);

  // Click outside listener
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      const target = e.target as HTMLElement;
      // Ignore click-outside handling if clicking another run or image element
      if (target.closest('.run') || target.closest('.image-element')) {
        return;
      }
      if (popupRef.current && !popupRef.current.contains(e.target as Node)) {
        onCancel();
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onCancel]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const type = file.type === 'image/png' ? 'png' : 'jpeg';
      setImgType(type);

      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPreviewUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleWidthChange = (val: number) => {
    setWidth(val);
    if (lockAspectRatio) {
      const ratio = origHeight / origWidth;
      setHeight(Math.round(val * ratio));
    }
  };

  const handleHeightChange = (val: number) => {
    setHeight(val);
    if (lockAspectRatio) {
      const ratio = origWidth / origHeight;
      setWidth(Math.round(val * ratio));
    }
  };

  const handleApply = () => {
    onSave({
      pageIdx,
      imageBytes: previewUrl || undefined,
      imageType: imgType,
      transform: origTransform,
      width,
      height,
      outlineColor: outlineWidth > 0 ? outlineColor : undefined,
      outlineWidth: outlineWidth > 0 ? outlineWidth : undefined,
      bgColor,
      bgColor2,
      bgStyle,
      bgSplitRatio,
    });
  };

  return (
    <motion.div
      ref={popupRef}
      initial={{ opacity: 0, scale: 0.95, y: 10 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: 10 }}
      transition={{ type: 'spring', duration: 0.25 }}
      style={{
        position: 'fixed',
        left: `${pos.left}px`,
        top: `${pos.top}px`,
        zIndex: 100,
      }}
      className="popup w-[295px] max-w-[90vw] bg-[#1a1c24] border border-[#2c2f3d] rounded-2xl shadow-2xl overflow-hidden font-sans text-xs text-[#e8e9ec]"
    >
      <div className="flex items-center justify-between px-4 py-3 bg-[#232631] border-b border-[#2c2f3d]">
        <div className="flex items-center gap-1.5 text-xs font-semibold tracking-wider text-[#9297a3] uppercase font-display">
          <Palette className="w-3.5 h-3.5 text-[#5b8cff]" />
          {isDiagram ? (diagLabel || 'Format Table/Shape') : 'Format Image'}
        </div>
        <button
          onClick={onCancel}
          className="text-[#9297a3] hover:text-white transition-colors p-1 rounded-md hover:bg-[#2c2f3d]/50"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 max-h-[480px] overflow-y-auto custom-scrollbar">
        {/* Upload Box / Preview Area */}
        <div className="w-full h-28 bg-[#121319] border border-[#2c2f3d] rounded-lg flex flex-col items-center justify-center overflow-hidden relative group">
          {previewUrl ? (
            <div className="relative w-full h-full flex items-center justify-center p-2" style={getBackgroundStyle()}>
              <img
                src={previewUrl}
                alt="Replacement Preview"
                className="max-w-full max-h-full object-contain relative z-10"
                style={{
                  border: outlineWidth > 0 ? `${outlineWidth}px solid ${outlineColor}` : 'none'
                }}
                referrerPolicy="no-referrer"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center gap-1.5 transition-opacity text-xs font-semibold text-white z-20"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Change Image
              </button>
            </div>
          ) : isDiagram ? (
            <div className="w-full h-full p-3 flex flex-col items-center justify-center text-center gap-1 bg-[#121319]" style={{ ...getBackgroundStyle(), border: outlineWidth > 0 ? `${outlineWidth}px solid ${outlineColor}` : 'none' }}>
              <span className="text-[10px] font-bold text-[#5b8cff] uppercase tracking-wider relative z-10">{diagLabel || 'Detected Vector Shape'}</span>
              <span className="text-[9px] text-zinc-500 leading-normal max-w-[240px] relative z-10">
                You can style this vector's fill, border color, or outline width below, or replace it with an image.
              </span>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="mt-1 px-2 py-0.5 rounded bg-[#232631] text-[9px] text-white hover:bg-[#2c2f3d] transition-colors border border-zinc-700 font-semibold relative z-10"
              >
                Replace with Image
              </button>
            </div>
          ) : (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full h-full flex flex-col items-center justify-center gap-2 text-[#9297a3] hover:text-[#5b8cff] transition-colors"
            >
              <Upload className="w-6 h-6 animate-bounce" />
              <span className="text-xs font-semibold text-white">Upload / Drag Image</span>
              <span className="text-[10px] opacity-70 font-mono">PNG or JPEG format</span>
            </button>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png, image/jpeg"
            onChange={handleFileChange}
            className="hidden"
          />
        </div>

        {(previewUrl || isDiagram) && (
          <>
            {/* Dimensions Control Area */}
            <div className="space-y-3 bg-[#111217] p-3 rounded-lg border border-[#232631]">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold tracking-wider text-[#9297a3] uppercase flex items-center gap-1.5">
                  <Maximize2 className="w-3 h-3 text-[#5b8cff]" />
                  Size & Stretch Controls
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setLockAspectRatio(!lockAspectRatio);
                    if (!lockAspectRatio) {
                      // re-sync height on lock
                      const ratio = origHeight / origWidth;
                      setHeight(Math.round(width * ratio));
                    }
                  }}
                  className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold transition-all ${
                    lockAspectRatio
                      ? 'bg-[#5b8cff]/10 text-[#5b8cff] border border-[#5b8cff]/20'
                      : 'bg-zinc-800 text-zinc-400 border border-transparent'
                  }`}
                >
                  {lockAspectRatio ? <Link2 className="w-3 h-3" /> : <Link2Off className="w-3 h-3" />}
                  {lockAspectRatio ? 'Locked Aspect' : 'Free Stretch'}
                </button>
              </div>

              {/* Width Slider */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-400">Width</span>
                  <span className="font-mono text-[#5b8cff] font-bold">{width}px</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max={Math.round(origWidth * 4)}
                  value={width}
                  onChange={(e) => handleWidthChange(parseInt(e.target.value))}
                  className="w-full accent-[#5b8cff] h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                />
              </div>

              {/* Height Slider */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-400">Height</span>
                  <span className="font-mono text-[#5b8cff] font-bold">{height}px</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max={Math.round(origHeight * 4)}
                  value={height}
                  onChange={(e) => handleHeightChange(parseInt(e.target.value))}
                  className="w-full accent-[#5b8cff] h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>

            {/* Styling Border/Background Customizer */}
            <div className="space-y-3 bg-[#111217] p-3 rounded-lg border border-[#232631]">
              <span className="text-[10px] font-bold tracking-wider text-[#9297a3] uppercase flex items-center gap-1.5">
                <Palette className="w-3 h-3 text-[#5b8cff]" />
                Frame Styles & Fills
              </span>

              {/* Background Style Selection */}
              <div className="space-y-1">
                <span className="text-zinc-400 text-xs">Background Style / Shading</span>
                <select
                  value={bgStyle}
                  onChange={(e) => setBgStyle(e.target.value as any)}
                  className="w-full bg-[#1b1c24] border border-[#2c2f3d] rounded px-2.5 py-1.5 text-xs text-white outline-none focus:border-[#5b8cff] transition-colors"
                >
                  <option value="solid">Solid Background (1 Color)</option>
                  <option value="split-h">Horizontal Split (2 Colors / Zebra)</option>
                  <option value="split-v">Vertical Split (2 Colors / Column)</option>
                  <option value="gradient-h">Horizontal Gradient</option>
                  <option value="gradient-v">Vertical Gradient</option>
                  <option value="transparent">Transparent / Transparent PNG Only</option>
                </select>
              </div>

              {bgStyle !== 'transparent' && (
                <div className="space-y-2.5 pt-1.5 border-t border-zinc-800/40">
                  {/* First Color */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-zinc-400">{bgStyle === 'solid' ? 'Fill Color' : 'First Color (Left/Top)'}</span>
                      <input
                        type="color"
                        value={bgColor}
                        onChange={(e) => setBgColor(e.target.value)}
                        className="w-5 h-5 bg-transparent border-0 cursor-pointer rounded overflow-hidden"
                      />
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {PRESET_COLORS.map((col) => (
                        <button
                          key={`bg1-${col}`}
                          type="button"
                          onClick={() => setBgColor(col)}
                          className={`w-4 h-4 rounded-full border transition-all ${
                            bgColor === col ? 'scale-125 border-white ring-1 ring-black' : 'border-zinc-700 hover:scale-110'
                          }`}
                          style={{ backgroundColor: col }}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Second Color (if not solid) */}
                  {bgStyle !== 'solid' && (
                    <div className="space-y-1 pt-1.5 border-t border-zinc-800/40">
                      <div className="flex justify-between text-xs">
                        <span className="text-zinc-400">Second Color (Right/Bottom)</span>
                        <input
                          type="color"
                          value={bgColor2}
                          onChange={(e) => setBgColor2(e.target.value)}
                          className="w-5 h-5 bg-transparent border-0 cursor-pointer rounded overflow-hidden"
                        />
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {PRESET_COLORS.map((col) => (
                          <button
                            key={`bg2-${col}`}
                            type="button"
                            onClick={() => setBgColor2(col)}
                            className={`w-4 h-4 rounded-full border transition-all ${
                              bgColor2 === col ? 'scale-125 border-white ring-1 ring-black' : 'border-zinc-700 hover:scale-110'
                            }`}
                            style={{ backgroundColor: col }}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Split Ratio Slider (only for split styles) */}
                  {(bgStyle === 'split-h' || bgStyle === 'split-v') && (
                    <div className="space-y-1 pt-1.5 border-t border-zinc-800/40">
                      <div className="flex justify-between text-xs">
                        <span className="text-zinc-400">Split Point Ratio</span>
                        <span className="font-mono text-[#5b8cff]">{Math.round(bgSplitRatio * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="90"
                        step="5"
                        value={Math.round(bgSplitRatio * 100)}
                        onChange={(e) => setBgSplitRatio(parseInt(e.target.value) / 100)}
                        className="w-full accent-[#5b8cff] h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Outline / Border Width Slider */}
              <div className="space-y-1.5 pt-1.5 border-t border-zinc-800">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-400">Outline Width</span>
                  <span className="font-mono text-[#5b8cff]">{outlineWidth}px</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="12"
                  value={outlineWidth}
                  onChange={(e) => setOutlineWidth(parseInt(e.target.value))}
                  className="w-full accent-[#5b8cff] h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                />
              </div>

              {/* Outline Border Color */}
              {outlineWidth > 0 && (
                <div className="space-y-1.5 animate-fadeIn">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-400">Outline Color</span>
                    <input
                      type="color"
                      value={outlineColor}
                      onChange={(e) => setOutlineColor(e.target.value)}
                      className="w-5 h-5 bg-transparent border-0 cursor-pointer rounded overflow-hidden"
                    />
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_COLORS.map((col) => (
                      <button
                        key={`ol-${col}`}
                        type="button"
                        onClick={() => setOutlineColor(col)}
                        className={`w-4 h-4 rounded-full border transition-all ${
                          outlineColor === col ? 'scale-125 border-white ring-1 ring-black' : 'border-zinc-700 hover:scale-110'
                        }`}
                        style={{ backgroundColor: col }}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </>
        )}

        {/* Add Text Over Image Section */}
        {onAddTextOverImage && (
          <div className="bg-[#111217] p-3 rounded-lg border border-[#232631] space-y-2 mt-2">
            <span className="text-[10px] font-bold tracking-wider text-white uppercase flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#5b8cff] animate-pulse" />
              Image Text Editing Option
            </span>
            <p className="text-[10px] text-[#9297a3] leading-relaxed">
              If this image contains printed/written text, you can overlay editable text directly over it.
            </p>
            <button
              type="button"
              onClick={onAddTextOverImage}
              className="w-full py-2 text-xs font-bold bg-[#5b8cff]/15 hover:bg-[#5b8cff]/30 text-[#5b8cff] border border-[#5b8cff]/40 rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Palette className="w-3.5 h-3.5" />
              Add Editable Text Overlay Here
            </button>
          </div>
        )}

        {/* Action Button Row */}
        <div className="flex items-center gap-2 border-t border-[#2c2f3d]/50 pt-3.5">
          <button
            onClick={onDelete}
            title="Delete image from PDF"
            className="px-3 py-2 text-xs font-semibold rounded-lg bg-[#3a2020]/30 border border-[#6b2c2c]/40 text-[#f08585] hover:bg-[#3a2020]/70 transition-all flex items-center justify-center"
          >
            <Trash2 className="w-4 h-4" />
          </button>

          <button
            onClick={onCancel}
            className="flex-1 py-2 text-xs font-semibold rounded-lg bg-transparent border border-[#2c2f3d] text-[#9297a3] hover:text-white hover:bg-[#2c2f3d]/30 transition-all"
          >
            Cancel
          </button>

          <button
            onClick={handleApply}
            disabled={!isDiagram && !previewUrl}
            className="flex-1 flex items-center justify-center gap-1 py-2 text-xs font-bold rounded-lg bg-[#5b8cff] text-white hover:bg-[#3f6de0] active:scale-95 disabled:opacity-30 disabled:pointer-events-none transition-all shadow-md shadow-[#5b8cff]/10"
          >
            <Check className="w-3.5 h-3.5" />
            Apply Styles
          </button>
        </div>
      </div>
    </motion.div>
  );
}
