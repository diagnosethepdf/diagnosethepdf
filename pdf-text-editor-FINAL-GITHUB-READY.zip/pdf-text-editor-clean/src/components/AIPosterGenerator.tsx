import React, { useState, useRef } from 'react';
import { 
  Sparkles, 
  Palette, 
  Layout, 
  Type, 
  Download, 
  FileText, 
  Image as ImageIcon, 
  Wand2, 
  Layers, 
  Sliders, 
  Check, 
  Copy, 
  RefreshCw,
  Plus,
  Trash2,
  Move,
  Eye,
  ArrowRight,
  Send,
  Zap,
  Crown,
  AlignCenter,
  AlignLeft,
  AlignRight,
  Maximize2,
  Minimize2,
  Sparkle,
  Shield,
  Frame,
  Upload,
  X,
  SlidersHorizontal,
  Grid
} from 'lucide-react';
import html2canvas from 'html2canvas';
import { PDFDocument } from 'pdf-lib';

export interface PosterData {
  title: string;
  titleFontSize: number;
  titleColor: string;
  titleTracking: string;
  titleFontFamily: string;
  titleAlign: 'left' | 'center' | 'right';
  titleUppercase: boolean;

  subtitle: string;
  subtitleFontSize: number;
  subtitleColor: string;
  subtitleFontFamily: string;

  descriptionBody: string;
  bodyFontSize: number;
  bodyColor: string;

  dateLocation: string;
  dateFontSize: number;
  dateColor: string;

  speaker: string;
  speakerColor: string;

  showBadge: boolean;
  badgeText: string;
  badgeBgColor: string;
  badgeTextColor: string;
  badgeBorderColor: string;

  showCta: boolean;
  ctaText: string;
  ctaBgColor: string;
  ctaTextColor: string;

  // Background & Framing
  bgType: 'preset' | 'solid' | 'gradient' | 'image';
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  bgColor: string;
  bgGradientStart: string;
  bgGradientEnd: string;
  bgGradientAngle: number;
  bgGradientType: 'linear' | 'radial';
  bgImageUrl?: string;
  bgImageOpacity: number;
  bgImageFit: 'cover' | 'contain';
  bgPattern: 'gold-dust' | 'radial-glow' | 'cyber-grid' | 'marble-glass' | 'starry-night' | 'mesh-gradient' | 'vintage-grain' | 'none';
  
  // Hero Image / Logo Upload inside Poster
  showHeroImage: boolean;
  heroImageUrl?: string;
  heroImageSize: number;
  heroImageRadius: number;
  heroImageBorderColor: string;
  heroImageBorderWidth: number;
  heroImageOpacity: number;
  heroImagePosition: 'top' | 'above-title' | 'center' | 'below-title';

  // Luxury Corner Frame Styling
  cornerStyle: 'gold-ornate' | 'cyber-diamond' | 'royal-hairline' | 'art-deco' | 'modern-glass' | 'vintage-floral' | 'sleek-double' | 'clean-none';
  cornerRadius: number;
  borderWidth: number;
  borderColor: string;

  designTips?: string;
}

interface AIPosterGeneratorProps {
  onLoadPosterToWorkspace?: (pdfBytes: Uint8Array, filename: string) => void;
  theme?: any;
}

// 10+ Handcrafted Ready-To-Use Layout Presets
const READY_TEMPLATES: Array<{
  id: string;
  name: string;
  badge: string;
  icon: string;
  data: PosterData;
}> = [
  {
    id: 'gold-executive',
    name: '24K Gold Executive Gala',
    badge: '👑 ROYAL LUXURY',
    icon: '👑',
    data: {
      title: 'EXECUTIVE LEADERSHIP GALA 2026',
      titleFontSize: 28,
      titleColor: '#ffffff',
      titleTracking: 'tracking-wider',
      titleFontFamily: 'font-serif',
      titleAlign: 'center',
      titleUppercase: true,

      subtitle: 'Breakthrough Autonomous AI Vector Systems & Global Governance',
      subtitleFontSize: 13,
      subtitleColor: '#fcd34d',
      subtitleFontFamily: 'font-sans',

      descriptionBody: 'Join industry pioneers, chief executives, and lead AI researchers for a 3-day high-level summit in San Francisco.',
      bodyFontSize: 11,
      bodyColor: '#cbd5e1',

      dateLocation: 'NOVEMBER 18-20, 2026 | VENETIAN BALLROOM, SAN FRANCISCO',
      dateFontSize: 11,
      dateColor: '#e2e8f0',

      speaker: 'KEYNOTE BY DR. SARAH VANCE & GLOBAL LEADERS',
      speakerColor: '#e0a84f',

      showBadge: true,
      badgeText: '👑 OFFICIAL VIP PASS',
      badgeBgColor: '#e0a84f25',
      badgeTextColor: '#e0a84f',
      badgeBorderColor: '#e0a84f',

      showCta: true,
      ctaText: 'RESERVE PASS • TICKETS AVAILABLE AT GLOWPDF.AI',
      ctaBgColor: '#e0a84f',
      ctaTextColor: '#0d0f1a',

      bgType: 'gradient',
      primaryColor: '#e0a84f',
      secondaryColor: '#fcd34d',
      accentColor: '#fbbf24',
      bgColor: '#0c0f1d',
      bgGradientStart: '#0f1226',
      bgGradientEnd: '#060812',
      bgGradientAngle: 135,
      bgGradientType: 'linear',
      bgImageOpacity: 0.8,
      bgImageFit: 'cover',
      bgPattern: 'gold-dust',

      showHeroImage: false,
      heroImageSize: 120,
      heroImageRadius: 16,
      heroImageBorderColor: '#e0a84f',
      heroImageBorderWidth: 2,
      heroImageOpacity: 1,
      heroImagePosition: 'above-title',

      cornerStyle: 'gold-ornate',
      cornerRadius: 16,
      borderWidth: 3,
      borderColor: '#e0a84f'
    }
  },
  {
    id: 'cyberpunk-tech',
    name: 'Cyberpunk AI & Robotics',
    badge: '🚀 NEON TECH',
    icon: '🚀',
    data: {
      title: 'VECTOR ROBOTICS & AI SUMMIT',
      titleFontSize: 26,
      titleColor: '#38bdf8',
      titleTracking: 'tracking-widest',
      titleFontFamily: 'font-mono',
      titleAlign: 'center',
      titleUppercase: true,

      subtitle: 'Autonomous Neural Agents & Real-Time Cybernetics',
      subtitleFontSize: 13,
      subtitleColor: '#c084fc',
      subtitleFontFamily: 'font-sans',

      descriptionBody: 'Experience live robotics demos, neural core benchmarks, and keynote addresses from leading AI engineers.',
      bodyFontSize: 11,
      bodyColor: '#94a3b8',

      dateLocation: 'OCTOBER 24-26, 2026 | TOKYO TECH METROPOLIS',
      dateFontSize: 11,
      dateColor: '#7dd3fc',

      speaker: 'FEATURED SPEAKER: PROF. KENJI SATO',
      speakerColor: '#38bdf8',

      showBadge: true,
      badgeText: '⚡ NEXT-GEN TECH PASS',
      badgeBgColor: '#38bdf820',
      badgeTextColor: '#38bdf8',
      badgeBorderColor: '#38bdf8',

      showCta: true,
      ctaText: 'REGISTER FOR DEMO DAY →',
      ctaBgColor: '#a855f7',
      ctaTextColor: '#ffffff',

      bgType: 'gradient',
      primaryColor: '#a855f7',
      secondaryColor: '#38bdf8',
      accentColor: '#c084fc',
      bgColor: '#080512',
      bgGradientStart: '#110a24',
      bgGradientEnd: '#05030a',
      bgGradientAngle: 145,
      bgGradientType: 'linear',
      bgImageOpacity: 0.8,
      bgImageFit: 'cover',
      bgPattern: 'cyber-grid',

      showHeroImage: false,
      heroImageSize: 110,
      heroImageRadius: 12,
      heroImageBorderColor: '#38bdf8',
      heroImageBorderWidth: 2,
      heroImageOpacity: 1,
      heroImagePosition: 'above-title',

      cornerStyle: 'cyber-diamond',
      cornerRadius: 12,
      borderWidth: 2,
      borderColor: '#38bdf8'
    }
  },
  {
    id: 'minimalist-art',
    name: 'Minimalist Fine Art Gallery',
    badge: '🎨 SWISS CLEAN',
    icon: '🎨',
    data: {
      title: 'MONOCHROME GRAPHICS EXPOSITION',
      titleFontSize: 24,
      titleColor: '#0f172a',
      titleTracking: 'tracking-widest',
      titleFontFamily: 'font-sans',
      titleAlign: 'center',
      titleUppercase: true,

      subtitle: 'A Retrospective of Modern Vector Geometry & Structural Form',
      subtitleFontSize: 12,
      subtitleColor: '#475569',
      subtitleFontFamily: 'font-serif',

      descriptionBody: 'Featuring over 120 curated works exploring spatial tension, typography contrast, and digital architecture.',
      bodyFontSize: 11,
      bodyColor: '#64748b',

      dateLocation: 'DECEMBER 01 - JANUARY 15 | MUSEUM OF MODERN DESIGN',
      dateFontSize: 10,
      dateColor: '#334155',

      speaker: 'CURATED BY ELENA ROSTOVA',
      speakerColor: '#0f172a',

      showBadge: true,
      badgeText: 'FREE GALLERY ENTRY',
      badgeBgColor: '#f1f5f9',
      badgeTextColor: '#0f172a',
      badgeBorderColor: '#cbd5e1',

      showCta: true,
      ctaText: 'EXPLORE CATALOGUE ONLINE',
      ctaBgColor: '#0f172a',
      ctaTextColor: '#ffffff',

      bgType: 'solid',
      primaryColor: '#0f172a',
      secondaryColor: '#475569',
      accentColor: '#94a3b8',
      bgColor: '#f8fafc',
      bgGradientStart: '#ffffff',
      bgGradientEnd: '#f1f5f9',
      bgGradientAngle: 180,
      bgGradientType: 'linear',
      bgImageOpacity: 1,
      bgImageFit: 'cover',
      bgPattern: 'vintage-grain',

      showHeroImage: false,
      heroImageSize: 100,
      heroImageRadius: 8,
      heroImageBorderColor: '#0f172a',
      heroImageBorderWidth: 1,
      heroImageOpacity: 1,
      heroImagePosition: 'above-title',

      cornerStyle: 'royal-hairline',
      cornerRadius: 8,
      borderWidth: 2,
      borderColor: '#0f172a'
    }
  },
  {
    id: 'symphony-concert',
    name: 'Royal Symphony Concert',
    badge: '🎵 MUSIC GALA',
    icon: '🎵',
    data: {
      title: 'TOKYO PHILHARMONIC GALA 2026',
      titleFontSize: 26,
      titleColor: '#60a5fa',
      titleTracking: 'tracking-wider',
      titleFontFamily: 'font-serif',
      titleAlign: 'center',
      titleUppercase: true,

      subtitle: 'Beethoven, Tchaikovsky & Live Orchestra Visual Synthesis',
      subtitleFontSize: 13,
      subtitleColor: '#38bdf8',
      subtitleFontFamily: 'font-serif',

      descriptionBody: 'An unforgettable evening of classical masterpieces performed under 8K immersive laser illumination.',
      bodyFontSize: 11,
      bodyColor: '#94a3b8',

      dateLocation: 'SATURDAY, DEC 12 @ 8:00 PM | ROYAL OPERA CENTER',
      dateFontSize: 11,
      dateColor: '#e2e8f0',

      speaker: 'CONDUCTED BY MAESTRO MARCUS CHEN',
      speakerColor: '#60a5fa',

      showBadge: true,
      badgeText: '🎼 LIVE SYMPHONY PASS',
      badgeBgColor: '#3b82f620',
      badgeTextColor: '#60a5fa',
      badgeBorderColor: '#3b82f6',

      showCta: true,
      ctaText: 'RESERVE CONCERT SEATS',
      ctaBgColor: '#3b82f6',
      ctaTextColor: '#ffffff',

      bgType: 'gradient',
      primaryColor: '#3b82f6',
      secondaryColor: '#60a5fa',
      accentColor: '#38bdf8',
      bgColor: '#060a17',
      bgGradientStart: '#0a122e',
      bgGradientEnd: '#040610',
      bgGradientAngle: 135,
      bgGradientType: 'radial',
      bgImageOpacity: 0.8,
      bgImageFit: 'cover',
      bgPattern: 'radial-glow',

      showHeroImage: false,
      heroImageSize: 120,
      heroImageRadius: 100,
      heroImageBorderColor: '#60a5fa',
      heroImageBorderWidth: 2,
      heroImageOpacity: 1,
      heroImagePosition: 'above-title',

      cornerStyle: 'royal-hairline',
      cornerRadius: 16,
      borderWidth: 2,
      borderColor: '#3b82f6'
    }
  },
  {
    id: 'medical-science',
    name: 'Healthcare & Medical Symposium',
    badge: '🏥 MEDICAL ADVANCE',
    icon: '🏥',
    data: {
      title: 'GLOBAL CARDIOLOGY INNOVATIONS',
      titleFontSize: 25,
      titleColor: '#34d399',
      titleTracking: 'tracking-wider',
      titleFontFamily: 'font-sans',
      titleAlign: 'center',
      titleUppercase: true,

      subtitle: 'Breakthroughs in AI Electrophysiology & Precision Diagnostics',
      subtitleFontSize: 12,
      subtitleColor: '#a7f3d0',
      subtitleFontFamily: 'font-sans',

      descriptionBody: 'Connecting world-leading surgeons, clinical researchers, and medical AI innovators to discuss future care.',
      bodyFontSize: 11,
      bodyColor: '#cbd5e1',

      dateLocation: 'OCTOBER 14-16, 2026 | JOHNS HOPKINS AUDITORIUM',
      dateFontSize: 11,
      dateColor: '#e2e8f0',

      speaker: 'KEYNOTE: DR. ELIZABETH VANE, MD',
      speakerColor: '#34d399',

      showBadge: true,
      badgeText: '🏥 CME ACCREDITED SYMPOSIUM',
      badgeBgColor: '#10b98120',
      badgeTextColor: '#34d399',
      badgeBorderColor: '#10b981',

      showCta: true,
      ctaText: 'REGISTER MEDICAL DELEGATE',
      ctaBgColor: '#10b981',
      ctaTextColor: '#041712',

      bgType: 'gradient',
      primaryColor: '#10b981',
      secondaryColor: '#34d399',
      accentColor: '#a7f3d0',
      bgColor: '#05140f',
      bgGradientStart: '#0a221a',
      bgGradientEnd: '#030a08',
      bgGradientAngle: 135,
      bgGradientType: 'linear',
      bgImageOpacity: 0.8,
      bgImageFit: 'cover',
      bgPattern: 'marble-glass',

      showHeroImage: false,
      heroImageSize: 100,
      heroImageRadius: 16,
      heroImageBorderColor: '#34d399',
      heroImageBorderWidth: 2,
      heroImageOpacity: 1,
      heroImagePosition: 'above-title',

      cornerStyle: 'art-deco',
      cornerRadius: 14,
      borderWidth: 2,
      borderColor: '#10b981'
    }
  },
  {
    id: 'hollywood-premiere',
    name: 'Cinematic Movie Premiere',
    badge: '🎬 HOLLYWOOD CRIMSON',
    icon: '🎬',
    data: {
      title: 'CHRONOS: END OF TIME',
      titleFontSize: 30,
      titleColor: '#f43f5e',
      titleTracking: 'tracking-widest',
      titleFontFamily: 'font-display',
      titleAlign: 'center',
      titleUppercase: true,

      subtitle: 'In IMAX 3D & Dolby Atmos Worldwide',
      subtitleFontSize: 13,
      subtitleColor: '#fb7185',
      subtitleFontFamily: 'font-sans',

      descriptionBody: 'An epic sci-fi thriller exploring time dilation, quantum consciousness, and human survival.',
      bodyFontSize: 11,
      bodyColor: '#cbd5e1',

      dateLocation: 'RED CARPET PREMIERE | NOV 05 | MANN CHINESE THEATRE',
      dateFontSize: 11,
      dateColor: '#fda4af',

      speaker: 'STARRING ETHAN HAWKE & LILY COLLINS',
      speakerColor: '#f43f5e',

      showBadge: true,
      badgeText: '🎬 OFFICIAL WORLD PREMIERE',
      badgeBgColor: '#f43f5e25',
      badgeTextColor: '#f43f5e',
      badgeBorderColor: '#f43f5e',

      showCta: true,
      ctaText: 'WATCH EXCLUSIVE TRAILER',
      ctaBgColor: '#f43f5e',
      ctaTextColor: '#ffffff',

      bgType: 'gradient',
      primaryColor: '#f43f5e',
      secondaryColor: '#fb7185',
      accentColor: '#fda4af',
      bgColor: '#120509',
      bgGradientStart: '#200a12',
      bgGradientEnd: '#080204',
      bgGradientAngle: 180,
      bgGradientType: 'radial',
      bgImageOpacity: 0.8,
      bgImageFit: 'cover',
      bgPattern: 'starry-night',

      showHeroImage: false,
      heroImageSize: 130,
      heroImageRadius: 16,
      heroImageBorderColor: '#f43f5e',
      heroImageBorderWidth: 2,
      heroImageOpacity: 1,
      heroImagePosition: 'above-title',

      cornerStyle: 'sleek-double',
      cornerRadius: 16,
      borderWidth: 3,
      borderColor: '#f43f5e'
    }
  },
  {
    id: 'fashion-jewelry',
    name: 'Rose Gold Fashion & Jewelry',
    badge: '🍷 LUXURY SILK',
    icon: '🍷',
    data: {
      title: 'HAUTE COUTURE WINTER GALA',
      titleFontSize: 26,
      titleColor: '#fda4af',
      titleTracking: 'tracking-wider',
      titleFontFamily: 'font-serif',
      titleAlign: 'center',
      titleUppercase: true,

      subtitle: 'Unveiling the 2027 Diamond & Silk Collection',
      subtitleFontSize: 12,
      subtitleColor: '#fb7185',
      subtitleFontFamily: 'font-serif',

      descriptionBody: 'An exclusive runway exhibition presenting hand-crafted jewelry, silk gowns, and high fashion artistry.',
      bodyFontSize: 11,
      bodyColor: '#e2e8f0',

      dateLocation: 'DECEMBER 18 | RITZ-CARLTON GRAND BALLROOM PARIS',
      dateFontSize: 11,
      dateColor: '#fecdd3',

      speaker: 'CREATIVE DIRECTOR: ISABELLE DU PONT',
      speakerColor: '#fda4af',

      showBadge: true,
      badgeText: '🍷 BY PRIVATE INVITATION ONLY',
      badgeBgColor: '#f43f5e20',
      badgeTextColor: '#fda4af',
      badgeBorderColor: '#f43f5e',

      showCta: true,
      ctaText: 'REQUEST RUNWAY INVITATION',
      ctaBgColor: '#f43f5e',
      ctaTextColor: '#ffffff',

      bgType: 'gradient',
      primaryColor: '#f43f5e',
      secondaryColor: '#fb7185',
      accentColor: '#fda4af',
      bgColor: '#140810',
      bgGradientStart: '#240d1c',
      bgGradientEnd: '#0a0308',
      bgGradientAngle: 135,
      bgGradientType: 'linear',
      bgImageOpacity: 0.8,
      bgImageFit: 'cover',
      bgPattern: 'gold-dust',

      showHeroImage: false,
      heroImageSize: 110,
      heroImageRadius: 100,
      heroImageBorderColor: '#fda4af',
      heroImageBorderWidth: 2,
      heroImageOpacity: 1,
      heroImagePosition: 'above-title',

      cornerStyle: 'vintage-floral',
      cornerRadius: 18,
      borderWidth: 2,
      borderColor: '#fda4af'
    }
  },
  {
    id: 'eco-green-summit',
    name: 'Eco Green Future Forum',
    badge: '🌿 SUSTAINABLE ENERGY',
    icon: '🌿',
    data: {
      title: 'CLEANTECH & CLIMATE FORUM',
      titleFontSize: 26,
      titleColor: '#a7f3d0',
      titleTracking: 'tracking-wider',
      titleFontFamily: 'font-sans',
      titleAlign: 'center',
      titleUppercase: true,

      subtitle: 'Accelerating Net-Zero Infrastructure & Green Grid Tech',
      subtitleFontSize: 12,
      subtitleColor: '#34d399',
      subtitleFontFamily: 'font-sans',

      descriptionBody: 'Bringing together clean energy investors, policy makers, and sustainability pioneers.',
      bodyFontSize: 11,
      bodyColor: '#cbd5e1',

      dateLocation: 'SEPTEMBER 28-30 | COPENHAGEN ENERGY COMPLEX',
      dateFontSize: 11,
      dateColor: '#e2e8f0',

      speaker: 'KEYNOTE BY DR. LARS LINDQVIST',
      speakerColor: '#a7f3d0',

      showBadge: true,
      badgeText: '🌿 100% CARBON NEUTRAL EVENT',
      badgeBgColor: '#10b98120',
      badgeTextColor: '#a7f3d0',
      badgeBorderColor: '#10b981',

      showCta: true,
      ctaText: 'JOIN SUSTAINABILITY SUMMIT',
      ctaBgColor: '#10b981',
      ctaTextColor: '#031710',

      bgType: 'gradient',
      primaryColor: '#10b981',
      secondaryColor: '#34d399',
      accentColor: '#a7f3d0',
      bgColor: '#03140e',
      bgGradientStart: '#072419',
      bgGradientEnd: '#020b08',
      bgGradientAngle: 135,
      bgGradientType: 'linear',
      bgImageOpacity: 0.8,
      bgImageFit: 'cover',
      bgPattern: 'mesh-gradient',

      showHeroImage: false,
      heroImageSize: 110,
      heroImageRadius: 16,
      heroImageBorderColor: '#34d399',
      heroImageBorderWidth: 2,
      heroImageOpacity: 1,
      heroImagePosition: 'above-title',

      cornerStyle: 'modern-glass',
      cornerRadius: 16,
      borderWidth: 2,
      borderColor: '#10b981'
    }
  }
];

export const AIPosterGenerator: React.FC<AIPosterGeneratorProps> = ({
  onLoadPosterToWorkspace
}) => {
  // Option States
  const [description, setDescription] = useState<string>(
    'AI & Vector Robotics Conference 2026 featuring Keynote by Dr. Sarah Vance at San Francisco Convention Center on November 18. Early bird tickets available.'
  );
  const [category, setCategory] = useState<string>('Tech Conference & Summit');
  const [aspectRatio, setAspectRatio] = useState<'A4' | '9:16' | '3:4' | '1:1' | '16:9'>('A4');
  const [colorTheme, setColorTheme] = useState<string>('24K Gold & Obsidian Luxury');
  const [typography, setTypography] = useState<string>('Playfair High-Class Serif');
  const [graphicStyle, setGraphicStyle] = useState<string>('Royal Gold Filigree');

  // AI Agent & Canva Editor State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatingStep, setGeneratingStep] = useState<number>(0);
  const [posterData, setPosterData] = useState<PosterData | null>(READY_TEMPLATES[0].data);
  const [activeTab, setActiveTab] = useState<'options' | 'canva'>('canva');
  const [activeSubTab, setActiveSubTab] = useState<'text' | 'hero' | 'frame' | 'bg' | 'templates' | 'layers'>('text');
  const [customLayers, setCustomLayers] = useState<Array<{ id: string; text: string; color: string; size: number }>>([]);

  const posterCanvasRef = useRef<HTMLDivElement>(null);
  const heroImageInputRef = useRef<HTMLInputElement>(null);
  const bgImageInputRef = useRef<HTMLInputElement>(null);

  // Pre-configured Sample Prompts
  const SAMPLE_PROMPTS = [
    {
      label: '👑 24K Gold Luxury Summit',
      desc: 'Global Executive AI Leadership Gala 2026. Keynote by Dr. Sarah Vance at Grand Venetian Ballroom San Francisco on Nov 18.',
      cat: 'Corporate Product Launch',
      color: '24K Gold & Obsidian Luxury'
    },
    {
      label: '🚀 Tech & Robotics Summit',
      desc: 'AI & Vector Robotics Conference 2026 featuring Keynote by Dr. Sarah Vance at San Francisco Convention Center on November 18.',
      cat: 'Tech Conference & Summit',
      color: 'Cyber Amethyst & Neon'
    },
    {
      label: '🏥 Medical Innovation Gala',
      desc: 'Global Cardiology Innovations Symposium 2026. Breakthroughs in AI diagnostics & electrophysiology at Johns Hopkins Auditorium.',
      cat: 'Healthcare & Medical Symposium',
      color: 'Emerald Executive & Brass'
    },
    {
      label: '🎵 Royal Symphony Night',
      desc: 'Tokyo Philharmonic Grand Neon Symphony 2026. Live Performances by LaserPulse & EchoGrid at Royal Opera Center.',
      cat: 'Music Festival & Concert',
      color: 'Royal Sapphire & Diamond'
    }
  ];

  // Handle Hero Image Upload
  const handleHeroImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && posterData) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setPosterData({
          ...posterData,
          showHeroImage: true,
          heroImageUrl: result
        });
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Background Image Upload
  const handleBgImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && posterData) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setPosterData({
          ...posterData,
          bgType: 'image',
          bgImageUrl: result
        });
      };
      reader.readAsDataURL(file);
    }
  };

  // AI Agent Generation Flow
  const handleGeneratePoster = async () => {
    setIsGenerating(true);
    setGeneratingStep(1);

    setTimeout(() => setGeneratingStep(2), 600);
    setTimeout(() => setGeneratingStep(3), 1200);

    const preset = READY_TEMPLATES.find(p => p.name.includes(colorTheme.split(' ')[0]))?.data || READY_TEMPLATES[0].data;

    try {
      const res = await fetch('/api/generate-poster', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description,
          category,
          aspectRatio,
          colorTheme,
          typography,
          graphicStyle
        })
      });

      const data = await res.json();
      if (data.success && data.poster) {
        setPosterData({
          ...preset,
          title: data.poster.title || 'EXECUTIVE LEADERSHIP GALA 2026',
          subtitle: data.poster.subtitle || 'Breakthrough Autonomous AI Vector Systems & Global Governance',
          descriptionBody: data.poster.descriptionBody || 'Join industry pioneers, chief executives, and lead AI researchers for a 3-day high-level summit.',
          dateLocation: data.poster.dateLocation || 'NOVEMBER 18-20, 2026 | VENETIAN BALLROOM, SAN FRANCISCO',
          speaker: data.poster.speaker || 'KEYNOTE BY DR. SARAH VANCE & GLOBAL LEADERS',
          badgeText: data.poster.badgeText || 'OFFICIAL VIP PASS',
          ctaText: data.poster.ctaText || 'REGISTER NOW • PASSES AVAILABLE AT GLOWPDF.AI',
          primaryColor: data.poster.primaryColor || preset.primaryColor,
          secondaryColor: data.poster.secondaryColor || preset.secondaryColor,
          bgColor: data.poster.bgColor || preset.bgColor,
          bgGradientStart: data.poster.bgColor || preset.bgGradientStart,
          bgGradientEnd: data.poster.primaryColor ? `${data.poster.primaryColor}20` : preset.bgGradientEnd
        });
      } else {
        throw new Error('Fallback trigger');
      }
    } catch (e) {
      console.warn('Using client synthesis poster fallback:', e);
      setPosterData({
        ...preset,
        title: description ? description.substring(0, 36).toUpperCase() : 'EXECUTIVE LEADERSHIP GALA 2026',
        subtitle: 'Breakthrough Autonomous AI Vector Systems & Global Governance',
        descriptionBody: 'Join industry pioneers, chief executives, and lead AI researchers for a 3-day high-level summit.',
        dateLocation: 'NOVEMBER 18-20, 2026 | VENETIAN BALLROOM, SAN FRANCISCO',
        speaker: 'KEYNOTE BY DR. SARAH VANCE & GLOBAL LEADERS',
        badgeText: 'VIP INVITATION ONLY',
        ctaText: 'RESERVE PASS • TICKETS AVAILABLE AT GLOWPDF.AI'
      });
    } finally {
      setGeneratingStep(4);
      setTimeout(() => {
        setIsGenerating(false);
        setActiveTab('canva');
      }, 400);
    }
  };

  // Convert Canva Poster to HTML Canvas element
  const renderPosterCanvas = async (): Promise<HTMLCanvasElement | null> => {
    if (!posterCanvasRef.current) return null;
    return await html2canvas(posterCanvasRef.current, {
      scale: 2.5,
      useCORS: true,
      allowTaint: true,
      backgroundColor: null
    });
  };

  // Download as PNG
  const downloadAsPNG = async () => {
    const canvas = await renderPosterCanvas();
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `Poster_${posterData?.title?.replace(/[^a-zA-Z0-9]/g, '_') || 'AI_Design'}.png`;
    a.click();
  };

  // Download as JPEG
  const downloadAsJPEG = async () => {
    const canvas = await renderPosterCanvas();
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `Poster_${posterData?.title?.replace(/[^a-zA-Z0-9]/g, '_') || 'AI_Design'}.jpg`;
    a.click();
  };

  // Download as PDF Poster
  const downloadAsPDF = async () => {
    const canvas = await renderPosterCanvas();
    if (!canvas) return;
    const imgData = canvas.toDataURL('image/jpeg', 0.95);

    const pdfDoc = await PDFDocument.create();
    const widthPt = aspectRatio === '9:16' ? 472 : aspectRatio === '16:9' ? 841.89 : 595.28;
    const heightPt = aspectRatio === '9:16' ? 841.89 : aspectRatio === '16:9' ? 472 : 841.89;

    const page = pdfDoc.addPage([widthPt, heightPt]);
    const embeddedImg = await pdfDoc.embedJpg(imgData);

    page.drawImage(embeddedImg, {
      x: 0,
      y: 0,
      width: widthPt,
      height: heightPt
    });

    const pdfBytes = await pdfDoc.save();
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Poster_${posterData?.title?.replace(/[^a-zA-Z0-9]/g, '_') || 'AI_Design'}.pdf`;
    a.click();
  };

  // Send Poster to Workspace Diagnosis
  const handleSendToWorkspace = async () => {
    const canvas = await renderPosterCanvas();
    if (!canvas) return;
    const imgData = canvas.toDataURL('image/jpeg', 0.95);

    const pdfDoc = await PDFDocument.create();
    const page = pdfDoc.addPage([595.28, 841.89]);
    const embeddedImg = await pdfDoc.embedJpg(imgData);
    page.drawImage(embeddedImg, { x: 0, y: 0, width: 595.28, height: 841.89 });

    const pdfBytes = await pdfDoc.save();
    if (onLoadPosterToWorkspace) {
      onLoadPosterToWorkspace(pdfBytes, `Poster_${posterData?.title?.substring(0, 15) || 'Design'}.pdf`);
    }
  };

  // Aspect ratio dimension classes for preview canvas
  const getCanvasAspectClass = () => {
    switch (aspectRatio) {
      case '9:16':
        return 'w-[360px] h-[640px]';
      case '3:4':
        return 'w-[420px] h-[560px]';
      case '1:1':
        return 'w-[480px] h-[480px]';
      case '16:9':
        return 'w-[640px] h-[360px]';
      case 'A4':
      default:
        return 'w-[450px] h-[636px]';
    }
  };

  // Compute Background Style
  const getPosterBackgroundStyle = () => {
    if (!posterData) return {};

    let bgStyle: React.CSSProperties = {
      backgroundColor: posterData.bgColor
    };

    if (posterData.bgType === 'gradient') {
      if (posterData.bgGradientType === 'radial') {
        bgStyle.backgroundImage = `radial-gradient(circle at center, ${posterData.bgGradientStart} 0%, ${posterData.bgGradientEnd} 100%)`;
      } else {
        bgStyle.backgroundImage = `linear-gradient(${posterData.bgGradientAngle || 135}deg, ${posterData.bgGradientStart} 0%, ${posterData.bgGradientEnd} 100%)`;
      }
    } else if (posterData.bgType === 'image' && posterData.bgImageUrl) {
      bgStyle.backgroundImage = `url(${posterData.bgImageUrl})`;
      bgStyle.backgroundSize = posterData.bgImageFit || 'cover';
      bgStyle.backgroundPosition = 'center';
    } else if (posterData.bgPattern === 'gold-dust') {
      bgStyle.backgroundImage = `radial-gradient(circle at 50% 20%, ${posterData.primaryColor}35 0%, transparent 60%), radial-gradient(circle at 80% 80%, ${posterData.secondaryColor}25 0%, transparent 50%)`;
    } else if (posterData.bgPattern === 'radial-glow') {
      bgStyle.backgroundImage = `radial-gradient(circle at center, ${posterData.secondaryColor}40 0%, ${posterData.bgColor} 80%)`;
    } else if (posterData.bgPattern === 'cyber-grid') {
      bgStyle.backgroundImage = `linear-gradient(to right, #ffffff08 1px, transparent 1px), linear-gradient(to bottom, #ffffff08 1px, transparent 1px)`;
      bgStyle.backgroundSize = '24px 24px';
    } else if (posterData.bgPattern === 'marble-glass') {
      bgStyle.backgroundImage = `linear-gradient(${posterData.bgGradientAngle || 135}deg, ${posterData.primaryColor}15, ${posterData.bgColor} 70%)`;
    } else if (posterData.bgPattern === 'starry-night') {
      bgStyle.backgroundImage = `radial-gradient(circle at 20% 20%, ${posterData.primaryColor}40 0%, transparent 40%), radial-gradient(circle at 80% 70%, ${posterData.secondaryColor}30 0%, transparent 50%)`;
    } else if (posterData.bgPattern === 'mesh-gradient') {
      bgStyle.backgroundImage = `radial-gradient(at 0% 0%, ${posterData.primaryColor}35 0px, transparent 50%), radial-gradient(at 100% 100%, ${posterData.secondaryColor}35 0px, transparent 50%)`;
    } else if (posterData.bgPattern === 'vintage-grain') {
      bgStyle.backgroundImage = `radial-gradient(circle at 50% 50%, ${posterData.primaryColor}10, ${posterData.bgColor} 90%)`;
    }

    return bgStyle;
  };

  return (
    <div className="w-full flex flex-col gap-6 text-slate-100">
      {/* Hidden File Inputs for Image Uploads */}
      <input
        ref={heroImageInputRef}
        type="file"
        accept="image/*"
        onChange={handleHeroImageUpload}
        className="hidden"
      />
      <input
        ref={bgImageInputRef}
        type="file"
        accept="image/*"
        onChange={handleBgImageUpload}
        className="hidden"
      />

      {/* Header Banner */}
      <div className="p-6 rounded-3xl border border-[#2c3044] bg-gradient-to-r from-[#171a29] via-[#121422] to-[#1a182c] shadow-2xl relative overflow-hidden flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4 relative z-10">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#e0a84f] via-[#a855f7] to-[#38bdf8] p-0.5 shadow-lg shadow-[#e0a84f]/20 flex items-center justify-center shrink-0">
            <div className="w-full h-full bg-[#0d0e17] rounded-[14px] flex items-center justify-center">
              <Crown className="w-6 h-6 text-[#e0a84f] animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-xl font-black tracking-tight text-white font-display flex items-center gap-2">
                <span>AI Luxury Poster Generator &amp; Canva Studio</span>
              </h2>
              <span className="text-[10px] font-mono font-black px-2.5 py-0.5 rounded-full bg-gradient-to-r from-[#e0a84f]/20 to-[#a855f7]/20 text-[#e0a84f] border border-[#e0a84f]/30 uppercase tracking-wider">
                24K LUXURY STUDIO
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              Generate posters with AI or instant layout presets, custom image uploads, background gradients, textures, typography, and filigree corner frames.
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 bg-[#0d0f18] p-1.5 rounded-2xl border border-[#272a3a]">
          <button
            onClick={() => setActiveTab('options')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'options'
                ? 'bg-[#5b8cff] text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5" />
            AI Generator Prompt
          </button>
          <button
            onClick={() => setActiveTab('canva')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'canva'
                ? 'bg-gradient-to-r from-[#e0a84f] to-[#a855f7] text-white shadow-md shadow-[#e0a84f]/20 font-black'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Crown className="w-3.5 h-3.5 text-amber-300" />
            Canva Luxury Studio
          </button>
        </div>
      </div>

      {/* Main View Mode */}
      {activeTab === 'options' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Form Controls */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            {/* Instant Ready-To-Use Layout Gallery */}
            <div className="p-6 rounded-2xl border border-[#262a3b] bg-[#131623] shadow-xl flex flex-col gap-4">
              <div className="flex items-center justify-between border-b border-slate-700/40 pb-3">
                <div className="flex items-center gap-2">
                  <Grid className="w-4 h-4 text-[#e0a84f]" />
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Instant Ready Poster Layouts (No AI Required)
                  </h3>
                </div>
                <span className="text-[10px] text-[#e0a84f] font-mono font-bold">
                  1-CLICK APPLY
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
                {READY_TEMPLATES.map((tmpl) => (
                  <button
                    key={tmpl.id}
                    type="button"
                    onClick={() => {
                      setPosterData(tmpl.data);
                      setActiveTab('canva');
                    }}
                    className="p-3 rounded-xl border border-[#232738] bg-[#0d0f18] hover:border-[#e0a84f] hover:bg-[#141726] transition-all text-left flex flex-col gap-1.5 cursor-pointer group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-base">{tmpl.icon}</span>
                      <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#e0a84f]/15 text-[#e0a84f] border border-[#e0a84f]/20">
                        {tmpl.badge}
                      </span>
                    </div>
                    <span className="text-xs font-bold text-slate-200 group-hover:text-white line-clamp-1">
                      {tmpl.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Description Prompt Input */}
            <div className="p-6 rounded-2xl border border-[#262a3b] bg-[#131623] shadow-xl flex flex-col gap-4">
              <div className="flex items-center justify-between border-b border-slate-700/40 pb-3">
                <div className="flex items-center gap-2">
                  <Type className="w-4 h-4 text-[#e0a84f]" />
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Step 1: Describe Poster Vision for AI
                  </h3>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">
                  Natural Language Prompt
                </span>
              </div>

              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your event, product, conference, or announcement details..."
                rows={4}
                className="w-full text-xs p-4 rounded-xl border border-[#2a2e42] bg-[#0c0e18] text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#e0a84f] leading-relaxed font-medium transition-all"
              />

              {/* Sample Prompts */}
              <div>
                <span className="text-[10px] font-bold uppercase text-slate-400 block mb-2">
                  💡 Quick Sample Ideas:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {SAMPLE_PROMPTS.map((sample, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setDescription(sample.desc);
                        setCategory(sample.cat);
                        setColorTheme(sample.color);
                      }}
                      className="p-2.5 rounded-xl border border-[#232738] bg-[#181b2a] hover:border-[#e0a84f] text-left transition-all text-xs group cursor-pointer"
                    >
                      <span className="font-bold text-[#e0a84f] group-hover:text-white block mb-0.5">
                        {sample.label}
                      </span>
                      <p className="text-[10px] text-slate-400 line-clamp-2 leading-tight">
                        {sample.desc}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Poster Configuration Grid */}
            <div className="p-6 rounded-2xl border border-[#262a3b] bg-[#131623] shadow-xl flex flex-col gap-5">
              <div className="flex items-center justify-between border-b border-slate-700/40 pb-3">
                <div className="flex items-center gap-2">
                  <Palette className="w-4 h-4 text-[#5b8cff]" />
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Step 2: Style &amp; Format Settings
                  </h3>
                </div>
                <span className="text-[10px] text-[#5b8cff] font-mono font-bold">
                  PRECISION CONTROL
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Category */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-bold text-slate-300">
                    Poster Category &amp; Intent
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-[#2a2e42] bg-[#0c0e18] text-slate-100 focus:outline-none focus:border-[#5b8cff]"
                  >
                    <option value="Tech Conference & Summit">🚀 Tech Conference &amp; Summit</option>
                    <option value="Academic & Scientific Research">🎓 Academic &amp; Scientific Research</option>
                    <option value="Music Festival & Concert">🎵 Music Festival &amp; Concert</option>
                    <option value="Healthcare & Medical Symposium">🏥 Healthcare &amp; Medical Symposium</option>
                    <option value="Corporate Product Launch">💼 Corporate Product Launch</option>
                    <option value="Movie & Entertainment">🎬 Movie &amp; Entertainment</option>
                    <option value="Art Exhibition & Gallery">🎨 Art Exhibition &amp; Gallery</option>
                    <option value="Retail & Commercial Promo">🛍️ Retail &amp; Commercial Promo</option>
                  </select>
                </div>

                {/* Aspect Ratio */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-bold text-slate-300">
                    Poster Dimension / Format
                  </label>
                  <select
                    value={aspectRatio}
                    onChange={(e) => setAspectRatio(e.target.value as any)}
                    className="w-full text-xs p-2.5 rounded-xl border border-[#2a2e42] bg-[#0c0e18] text-slate-100 focus:outline-none focus:border-[#5b8cff]"
                  >
                    <option value="A4">📜 Standard Poster A4 / A3 (Portrait)</option>
                    <option value="9:16">📱 Social Story / Mobile Full (9:16)</option>
                    <option value="3:4">🖼️ Classic Frame Portrait (3:4)</option>
                    <option value="1:1">🔳 Square Promo Box (1:1)</option>
                    <option value="16:9">🖥️ Landscape Stage Banner (16:9)</option>
                  </select>
                </div>

                {/* Color Palette */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-bold text-slate-300">
                    Aesthetic Palette Preset
                  </label>
                  <select
                    value={colorTheme}
                    onChange={(e) => setColorTheme(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-[#2a2e42] bg-[#0c0e18] text-slate-100 focus:outline-none focus:border-[#e0a84f]"
                  >
                    {READY_TEMPLATES.map((p) => (
                      <option key={p.id} value={p.name}>
                        {p.icon} {p.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Typography Theme */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-bold text-slate-300">
                    Typography Hierarchy Style
                  </label>
                  <select
                    value={typography}
                    onChange={(e) => setTypography(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-[#2a2e42] bg-[#0c0e18] text-slate-100 focus:outline-none focus:border-[#5b8cff]"
                  >
                    <option value="Playfair High-Class Serif">High-Class Editorial Serif</option>
                    <option value="Modern Display Sans">Sans Bold Modern Sans-Serif</option>
                    <option value="Cyber Monospace">Mono Cyber Monospace Console</option>
                    <option value="Heavy Poster Display">Display Heavy Impact Poster Display</option>
                  </select>
                </div>
              </div>

              {/* Action Submission Button */}
              <div className="pt-2">
                <button
                  type="button"
                  disabled={isGenerating}
                  onClick={handleGeneratePoster}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#e0a84f] via-[#a855f7] to-[#3b82f6] hover:from-[#f0b85f] hover:via-[#b86dfc] hover:to-[#60a5fa] text-white font-black text-sm tracking-wider uppercase shadow-xl shadow-[#e0a84f]/20 cursor-pointer flex items-center justify-center gap-2.5 active:scale-98 transition-all"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin text-white" />
                      <span>Synthesizing Poster Layout...</span>
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-5 h-5 text-white" />
                      <span>🤖 Generate AI Poster with Agent</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: AI Agent Status */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            <div className="p-6 rounded-2xl border border-[#262a3b] bg-[#131623] shadow-xl flex flex-col gap-4">
              <div className="flex items-center gap-2 border-b border-slate-700/40 pb-3">
                <Zap className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  AI Agent Status Deck
                </h3>
              </div>

              {isGenerating ? (
                <div className="py-8 flex flex-col items-center justify-center text-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#e0a84f] to-[#a855f7] p-0.5 animate-bounce">
                    <div className="w-full h-full bg-[#0e1019] rounded-[14px] flex items-center justify-center">
                      <Sparkles className="w-8 h-8 text-[#e0a84f] animate-pulse" />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-white">
                      {generatingStep === 1 && '🧠 Analyzing Poster Description...'}
                      {generatingStep === 2 && '🎨 Synthesizing Metallic Filigree & Color...'}
                      {generatingStep === 3 && '✏️ Formatting Vector Typography...'}
                      {generatingStep === 4 && '📐 Mounting Canva Canvas Layout...'}
                    </h4>
                    <p className="text-[11px] text-slate-400 font-mono">
                      Neural Model: Gemini 2.5 Vector Engine
                    </p>
                  </div>

                  <div className="w-full space-y-2 pt-2">
                    {[
                      'Description & Intent Parser',
                      'Graphic Composition Synthesis',
                      'Typography Grid Alignment',
                      'Canva Layer Assembly'
                    ].map((stepLabel, idx) => {
                      const isDone = generatingStep > idx + 1;
                      const isCurrent = generatingStep === idx + 1;
                      return (
                        <div key={idx} className="flex items-center justify-between text-xs p-2 rounded-lg bg-[#0c0e18] border border-[#222536]">
                          <span className={isCurrent ? 'text-white font-bold' : isDone ? 'text-slate-300' : 'text-slate-500'}>
                            {stepLabel}
                          </span>
                          {isDone ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : isCurrent ? (
                            <RefreshCw className="w-3.5 h-3.5 text-[#5b8cff] animate-spin" />
                          ) : (
                            <span className="w-2 h-2 rounded-full bg-slate-700" />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="py-6 flex flex-col items-center justify-center text-center gap-3">
                  <div className="p-4 rounded-2xl bg-[#0c0e18] border border-[#222536] text-slate-400">
                    <Crown className="w-10 h-10 text-[#e0a84f]" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-200">
                    Ready for AI Synthesis
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed px-2">
                    Click "Generate AI Poster with Agent" or choose any template from the ready layout gallery above to jump straight into editing.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* ================= CANVA LUXURY POSTER STUDIO STAGE ================= */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left / Center Column: Live Canva Canvas Stage */}
          <div className="lg:col-span-7 flex flex-col items-center justify-center gap-4">
            {/* Canva Export Action Toolbar */}
            <div className="w-full p-4 rounded-2xl border border-[#262a3b] bg-[#131623] shadow-xl flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4 text-[#e0a84f]" />
                <span className="text-xs font-black text-white">
                  Canva Studio ({aspectRatio})
                </span>
              </div>

              {/* Export Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={downloadAsPDF}
                  className="px-3 py-1.5 text-xs font-bold rounded-xl bg-[#5b8cff] text-white hover:bg-[#3f6de0] transition-all cursor-pointer flex items-center gap-1.5 shadow-md shadow-[#5b8cff]/10"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Poster
                </button>
                <button
                  onClick={downloadAsPNG}
                  className="px-3 py-1.5 text-xs font-bold rounded-xl bg-[#1e2235] text-slate-200 hover:text-white border border-[#2f3448] hover:border-[#5b8cff] transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-pink-400" />
                  PNG Image
                </button>
                <button
                  onClick={downloadAsJPEG}
                  className="px-3 py-1.5 text-xs font-bold rounded-xl bg-[#1e2235] text-slate-200 hover:text-white border border-[#2f3448] hover:border-[#5b8cff] transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  JPEG Image
                </button>
                {onLoadPosterToWorkspace && (
                  <button
                    onClick={handleSendToWorkspace}
                    className="px-3.5 py-1.5 text-xs font-bold rounded-xl bg-gradient-to-r from-[#e0a84f] to-[#a855f7] text-white hover:from-[#f0b85f] transition-all cursor-pointer flex items-center gap-1.5 shadow-md shadow-[#e0a84f]/20 font-black"
                  >
                    <Send className="w-3.5 h-3.5" />
                    Send to Diagnosis →
                  </button>
                )}
              </div>
            </div>

            {/* Poster Canvas Stage Container */}
            <div className="w-full flex items-center justify-center p-6 rounded-3xl border border-[#222536] bg-[#07080e] shadow-2xl overflow-auto min-h-[620px] relative">
              {/* Actual Poster Card Frame */}
              <div
                ref={posterCanvasRef}
                style={{
                  ...getPosterBackgroundStyle(),
                  borderRadius: `${posterData?.cornerRadius || 16}px`,
                  borderWidth: `${posterData?.borderWidth || 3}px`,
                  borderColor: posterData?.borderColor || '#e0a84f'
                }}
                className={`relative shadow-2xl p-8 flex flex-col justify-between overflow-hidden transition-all duration-300 ${getCanvasAspectClass()}`}
              >
                {/* ELEGANT LUXURY CORNER ACCENTS / FILIGREE / BRACKETS */}
                {posterData?.cornerStyle === 'gold-ornate' && (
                  <>
                    <div className="absolute top-2 left-2 w-10 h-10 border-t-2 border-l-2 border-[#e0a84f] pointer-events-none flex items-start justify-start p-1">
                      <div className="w-2 h-2 bg-[#e0a84f] rotate-45 shadow-sm shadow-[#e0a84f]" />
                    </div>
                    <div className="absolute top-2 right-2 w-10 h-10 border-t-2 border-r-2 border-[#e0a84f] pointer-events-none flex items-start justify-end p-1">
                      <div className="w-2 h-2 bg-[#e0a84f] rotate-45 shadow-sm shadow-[#e0a84f]" />
                    </div>
                    <div className="absolute bottom-2 left-2 w-10 h-10 border-b-2 border-l-2 border-[#e0a84f] pointer-events-none flex items-end justify-start p-1">
                      <div className="w-2 h-2 bg-[#e0a84f] rotate-45 shadow-sm shadow-[#e0a84f]" />
                    </div>
                    <div className="absolute bottom-2 right-2 w-10 h-10 border-b-2 border-r-2 border-[#e0a84f] pointer-events-none flex items-end justify-end p-1">
                      <div className="w-2 h-2 bg-[#e0a84f] rotate-45 shadow-sm shadow-[#e0a84f]" />
                    </div>
                    <div className="absolute inset-3 border border-[#e0a84f]/30 pointer-events-none rounded-lg" />
                  </>
                )}

                {posterData?.cornerStyle === 'cyber-diamond' && (
                  <>
                    <div className="absolute top-0 left-0 w-8 h-8 bg-gradient-to-br from-[#38bdf8] to-transparent pointer-events-none" style={{ clipPath: 'polygon(0 0, 100% 0, 0 100%)' }} />
                    <div className="absolute top-0 right-0 w-8 h-8 bg-gradient-to-bl from-[#38bdf8] to-transparent pointer-events-none" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%)' }} />
                    <div className="absolute bottom-0 left-0 w-8 h-8 bg-gradient-to-tr from-[#38bdf8] to-transparent pointer-events-none" style={{ clipPath: 'polygon(0 0, 0 100%, 100% 100%)' }} />
                    <div className="absolute bottom-0 right-0 w-8 h-8 bg-gradient-to-tl from-[#38bdf8] to-transparent pointer-events-none" style={{ clipPath: 'polygon(100% 0, 100% 100%, 0 100%)' }} />
                  </>
                )}

                {posterData?.cornerStyle === 'royal-hairline' && (
                  <>
                    <div className="absolute inset-2 border border-white/20 pointer-events-none" />
                    <div className="absolute inset-4 border border-white/10 pointer-events-none" />
                  </>
                )}

                {posterData?.cornerStyle === 'art-deco' && (
                  <>
                    <div className="absolute top-2 left-2 w-8 h-8 border-t-2 border-l-2 border-[#10b981]" />
                    <div className="absolute top-2 right-2 w-8 h-8 border-t-2 border-r-2 border-[#10b981]" />
                    <div className="absolute bottom-2 left-2 w-8 h-8 border-b-2 border-l-2 border-[#10b981]" />
                    <div className="absolute bottom-2 right-2 w-8 h-8 border-b-2 border-r-2 border-[#10b981]" />
                  </>
                )}

                {posterData?.cornerStyle === 'modern-glass' && (
                  <>
                    <div className="absolute inset-0 bg-white/5 backdrop-blur-[2px] pointer-events-none" />
                    <div className="absolute top-3 left-3 w-3 h-3 rounded-full bg-white/30" />
                    <div className="absolute top-3 right-3 w-3 h-3 rounded-full bg-white/30" />
                    <div className="absolute bottom-3 left-3 w-3 h-3 rounded-full bg-white/30" />
                    <div className="absolute bottom-3 right-3 w-3 h-3 rounded-full bg-white/30" />
                  </>
                )}

                {posterData?.cornerStyle === 'vintage-floral' && (
                  <>
                    <div className="absolute top-2 left-2 w-8 h-8 border-t-2 border-l-2 border-pink-400 rounded-tl-xl pointer-events-none" />
                    <div className="absolute top-2 right-2 w-8 h-8 border-t-2 border-r-2 border-pink-400 rounded-tr-xl pointer-events-none" />
                    <div className="absolute bottom-2 left-2 w-8 h-8 border-b-2 border-l-2 border-pink-400 rounded-bl-xl pointer-events-none" />
                    <div className="absolute bottom-2 right-2 w-8 h-8 border-b-2 border-r-2 border-pink-400 rounded-br-xl pointer-events-none" />
                  </>
                )}

                {posterData?.cornerStyle === 'sleek-double' && (
                  <>
                    <div className="absolute inset-1.5 border-2 border-[#f43f5e] pointer-events-none rounded-[14px]" />
                    <div className="absolute inset-3 border border-white/20 pointer-events-none rounded-[12px]" />
                  </>
                )}

                {/* Top Section: Badge Pill & Speaker */}
                <div className="relative z-10 flex flex-col items-center gap-2 text-center">
                  {posterData?.showBadge && posterData?.badgeText && (
                    <div
                      style={{
                        backgroundColor: posterData.badgeBgColor || `${posterData.primaryColor}25`,
                        borderColor: posterData.badgeBorderColor || posterData.primaryColor,
                        color: posterData.badgeTextColor || posterData.primaryColor
                      }}
                      className="px-4 py-1 rounded-full border text-[10px] font-mono font-black tracking-widest uppercase shadow-md transition-all cursor-pointer hover:scale-105"
                    >
                      {posterData.badgeText}
                    </div>
                  )}

                  {posterData?.speaker && (
                    <span
                      style={{ color: posterData.speakerColor || '#cbd5e1' }}
                      className="text-[11px] font-bold tracking-wider uppercase cursor-pointer hover:opacity-80"
                    >
                      {posterData.speaker}
                    </span>
                  )}
                </div>

                {/* HERO IMAGE / LOGO LAYER (Position: ABOVE TITLE OR TOP) */}
                {posterData?.showHeroImage && posterData?.heroImageUrl && (posterData.heroImagePosition === 'top' || posterData.heroImagePosition === 'above-title') && (
                  <div className="relative z-10 my-2 flex justify-center items-center">
                    <img
                      src={posterData.heroImageUrl}
                      alt="Poster Hero Visual"
                      style={{
                        width: `${posterData.heroImageSize}px`,
                        maxHeight: '180px',
                        objectFit: 'cover',
                        borderRadius: `${posterData.heroImageRadius}px`,
                        borderColor: posterData.heroImageBorderColor,
                        borderWidth: `${posterData.heroImageBorderWidth}px`,
                        opacity: posterData.heroImageOpacity
                      }}
                      className="shadow-xl transition-all"
                    />
                  </div>
                )}

                {/* Center Section: Main Title & Subtitle */}
                <div className="relative z-10 my-auto text-center flex flex-col items-center gap-3">
                  <h1
                    style={{
                      fontSize: `${posterData?.titleFontSize || 28}px`,
                      color: posterData?.titleColor || '#ffffff',
                      textAlign: posterData?.titleAlign || 'center'
                    }}
                    className={`font-black leading-tight drop-shadow-lg transition-all ${posterData?.titleFontFamily || 'font-display'} ${posterData?.titleTracking || 'tracking-wider'} ${posterData?.titleUppercase ? 'uppercase' : ''}`}
                  >
                    {posterData?.title || 'EXECUTIVE LEADERSHIP GALA 2026'}
                  </h1>

                  {/* HERO IMAGE / LOGO LAYER (Position: BELOW TITLE) */}
                  {posterData?.showHeroImage && posterData?.heroImageUrl && posterData.heroImagePosition === 'below-title' && (
                    <div className="my-2 flex justify-center items-center">
                      <img
                        src={posterData.heroImageUrl}
                        alt="Poster Hero Visual"
                        style={{
                          width: `${posterData.heroImageSize}px`,
                          maxHeight: '160px',
                          objectFit: 'cover',
                          borderRadius: `${posterData.heroImageRadius}px`,
                          borderColor: posterData.heroImageBorderColor,
                          borderWidth: `${posterData.heroImageBorderWidth}px`,
                          opacity: posterData.heroImageOpacity
                        }}
                        className="shadow-xl transition-all"
                      />
                    </div>
                  )}

                  <p
                    style={{
                      fontSize: `${posterData?.subtitleFontSize || 13}px`,
                      color: posterData?.subtitleColor || posterData?.secondaryColor || '#5b8cff'
                    }}
                    className={`font-semibold leading-snug max-w-sm transition-all ${posterData?.subtitleFontFamily || 'font-sans'}`}
                  >
                    {posterData?.subtitle}
                  </p>

                  <p
                    style={{
                      fontSize: `${posterData?.bodyFontSize || 11}px`,
                      color: posterData?.bodyColor || '#94a3b8'
                    }}
                    className="leading-relaxed max-w-xs transition-all"
                  >
                    {posterData?.descriptionBody}
                  </p>

                  {/* Custom Added Layers */}
                  {customLayers.map((layer) => (
                    <div
                      key={layer.id}
                      style={{ color: layer.color, fontSize: `${layer.size}px` }}
                      className="font-bold cursor-pointer hover:opacity-80"
                    >
                      {layer.text}
                    </div>
                  ))}
                </div>

                {/* Bottom Section: Date, Location & CTA Button */}
                <div className="relative z-10 flex flex-col items-center gap-3 text-center pt-4 border-t border-slate-700/40">
                  <div
                    style={{
                      fontSize: `${posterData?.dateFontSize || 11}px`,
                      color: posterData?.dateColor || '#cbd5e1'
                    }}
                    className="font-mono font-bold tracking-wider transition-all"
                  >
                    {posterData?.dateLocation}
                  </div>

                  {posterData?.showCta && posterData?.ctaText && (
                    <button
                      type="button"
                      style={{
                        backgroundColor: posterData.ctaBgColor || posterData.primaryColor,
                        color: posterData.ctaTextColor || '#ffffff'
                      }}
                      className="px-6 py-2.5 rounded-xl font-black text-xs tracking-wider uppercase shadow-lg shadow-black/40 cursor-pointer hover:scale-105 active:scale-95 transition-all"
                    >
                      {posterData.ctaText}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Real-Time Canva Layer Controls */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <div className="p-6 rounded-2xl border border-[#262a3b] bg-[#131623] shadow-xl flex flex-col gap-4">
              {/* Control Sub-Tabs */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 p-1 rounded-xl bg-[#0c0e18] border border-[#23273a]">
                <button
                  type="button"
                  onClick={() => setActiveSubTab('text')}
                  className={`py-1.5 rounded-lg text-[10px] font-bold transition-all text-center ${
                    activeSubTab === 'text' ? 'bg-[#5b8cff] text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Text
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSubTab('hero')}
                  className={`py-1.5 rounded-lg text-[10px] font-bold transition-all text-center ${
                    activeSubTab === 'hero' ? 'bg-[#f43f5e] text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Images
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSubTab('frame')}
                  className={`py-1.5 rounded-lg text-[10px] font-bold transition-all text-center ${
                    activeSubTab === 'frame' ? 'bg-[#e0a84f] text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Frame
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSubTab('bg')}
                  className={`py-1.5 rounded-lg text-[10px] font-bold transition-all text-center ${
                    activeSubTab === 'bg' ? 'bg-[#a855f7] text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Colors/BG
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSubTab('templates')}
                  className={`py-1.5 rounded-lg text-[10px] font-bold transition-all text-center ${
                    activeSubTab === 'templates' ? 'bg-[#10b981] text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Presets
                </button>
                <button
                  type="button"
                  onClick={() => setActiveSubTab('layers')}
                  className={`py-1.5 rounded-lg text-[10px] font-bold transition-all text-center ${
                    activeSubTab === 'layers' ? 'bg-[#38bdf8] text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Layers
                </button>
              </div>

              {/* Editable Fields based on SubTab */}
              {posterData && (
                <div className="flex flex-col gap-3.5 max-h-[520px] overflow-y-auto pr-1">
                  {/* TEXT & FONT SUBTAB */}
                  {activeSubTab === 'text' && (
                    <>
                      {/* Title Controls */}
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-2">
                        <label className="text-[10px] font-bold text-[#e0a84f] uppercase flex items-center justify-between">
                          <span>Main Title Headline</span>
                          <span>{posterData.titleFontSize}px</span>
                        </label>
                        <input
                          type="text"
                          value={posterData.title}
                          onChange={(e) => setPosterData({ ...posterData, title: e.target.value })}
                          className="w-full text-xs font-bold p-2 rounded-lg border border-[#2c3044] bg-[#141724] text-white focus:outline-none focus:border-[#e0a84f]"
                        />
                        <div className="grid grid-cols-2 gap-2 pt-1">
                          <div>
                            <span className="text-[9px] text-slate-400 block mb-0.5">Font Style</span>
                            <select
                              value={posterData.titleFontFamily}
                              onChange={(e) => setPosterData({ ...posterData, titleFontFamily: e.target.value })}
                              className="w-full text-xs p-1.5 rounded-lg border border-[#2c3044] bg-[#141724] text-white"
                            >
                              <option value="font-serif">High-Class Serif</option>
                              <option value="font-sans">Modern Sans</option>
                              <option value="font-mono">Cyber Mono</option>
                              <option value="font-display">Heavy Display</option>
                            </select>
                          </div>
                          <div>
                            <span className="text-[9px] text-slate-400 block mb-0.5">Letter Spacing</span>
                            <select
                              value={posterData.titleTracking}
                              onChange={(e) => setPosterData({ ...posterData, titleTracking: e.target.value })}
                              className="w-full text-xs p-1.5 rounded-lg border border-[#2c3044] bg-[#141724] text-white"
                            >
                              <option value="tracking-normal">Normal</option>
                              <option value="tracking-wide">Wide</option>
                              <option value="tracking-wider">Wider</option>
                              <option value="tracking-widest">Widest</option>
                            </select>
                          </div>
                        </div>
                        <div className="flex items-center justify-between pt-1">
                          <div className="flex-1 mr-3">
                            <span className="text-[9px] text-slate-400 block mb-0.5">Font Size</span>
                            <input
                              type="range"
                              min={16}
                              max={48}
                              value={posterData.titleFontSize}
                              onChange={(e) => setPosterData({ ...posterData, titleFontSize: Number(e.target.value) })}
                              className="w-full accent-[#e0a84f]"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <input
                              type="color"
                              value={posterData.titleColor}
                              onChange={(e) => setPosterData({ ...posterData, titleColor: e.target.value })}
                              className="w-7 h-7 rounded border-none bg-transparent cursor-pointer"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Subtitle Controls */}
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-2">
                        <label className="text-[10px] font-bold text-[#5b8cff] uppercase flex items-center justify-between">
                          <span>Subtitle / Tagline</span>
                          <span>{posterData.subtitleFontSize}px</span>
                        </label>
                        <input
                          type="text"
                          value={posterData.subtitle}
                          onChange={(e) => setPosterData({ ...posterData, subtitle: e.target.value })}
                          className="w-full text-xs p-2 rounded-lg border border-[#2c3044] bg-[#141724] text-white focus:outline-none focus:border-[#5b8cff]"
                        />
                        <div className="flex items-center justify-between pt-1">
                          <div className="flex-1 mr-3">
                            <input
                              type="range"
                              min={10}
                              max={24}
                              value={posterData.subtitleFontSize}
                              onChange={(e) => setPosterData({ ...posterData, subtitleFontSize: Number(e.target.value) })}
                              className="w-full accent-[#5b8cff]"
                            />
                          </div>
                          <input
                            type="color"
                            value={posterData.subtitleColor}
                            onChange={(e) => setPosterData({ ...posterData, subtitleColor: e.target.value })}
                            className="w-7 h-7 rounded border-none bg-transparent cursor-pointer"
                          />
                        </div>
                      </div>

                      {/* Body Description */}
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-2">
                        <label className="text-[10px] font-bold text-slate-300 uppercase">
                          Description Body Text
                        </label>
                        <textarea
                          value={posterData.descriptionBody}
                          onChange={(e) => setPosterData({ ...posterData, descriptionBody: e.target.value })}
                          rows={2}
                          className="w-full text-xs p-2 rounded-lg border border-[#2c3044] bg-[#141724] text-slate-200 focus:outline-none focus:border-[#5b8cff]"
                        />
                      </div>

                      {/* Date & Location */}
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-2">
                        <label className="text-[10px] font-bold text-emerald-400 uppercase">
                          Date, Time &amp; Venue
                        </label>
                        <input
                          type="text"
                          value={posterData.dateLocation}
                          onChange={(e) => setPosterData({ ...posterData, dateLocation: e.target.value })}
                          className="w-full text-xs p-2 rounded-lg border border-[#2c3044] bg-[#141724] text-white focus:outline-none focus:border-emerald-400"
                        />
                      </div>

                      {/* Speaker & Badge & CTA */}
                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2.5 rounded-xl border border-[#242738] bg-[#0c0e18]">
                          <label className="text-[9px] font-bold text-amber-400 uppercase block mb-1">
                            Keynote Speaker
                          </label>
                          <input
                            type="text"
                            value={posterData.speaker}
                            onChange={(e) => setPosterData({ ...posterData, speaker: e.target.value })}
                            className="w-full text-xs p-1.5 rounded-lg border border-[#2c3044] bg-[#141724] text-white"
                          />
                        </div>
                        <div className="p-2.5 rounded-xl border border-[#242738] bg-[#0c0e18]">
                          <label className="text-[9px] font-bold text-pink-400 uppercase block mb-1">
                            Top Badge Pill
                          </label>
                          <input
                            type="text"
                            value={posterData.badgeText}
                            onChange={(e) => setPosterData({ ...posterData, badgeText: e.target.value })}
                            className="w-full text-xs p-1.5 rounded-lg border border-[#2c3044] bg-[#141724] text-white"
                          />
                        </div>
                      </div>

                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-2">
                        <label className="text-[10px] font-bold text-purple-400 uppercase">
                          Call to Action Button Text
                        </label>
                        <input
                          type="text"
                          value={posterData.ctaText}
                          onChange={(e) => setPosterData({ ...posterData, ctaText: e.target.value })}
                          className="w-full text-xs p-2 rounded-lg border border-[#2c3044] bg-[#141724] text-white"
                        />
                      </div>
                    </>
                  )}

                  {/* HERO & LOGO IMAGES SUBTAB */}
                  {activeSubTab === 'hero' && (
                    <>
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-3">
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] font-bold text-pink-400 uppercase flex items-center gap-1.5">
                            <ImageIcon className="w-3.5 h-3.5" />
                            Hero Image / Event Logo Upload
                          </label>
                          {posterData.heroImageUrl && (
                            <button
                              type="button"
                              onClick={() => setPosterData({ ...posterData, showHeroImage: false, heroImageUrl: undefined })}
                              className="text-[10px] text-red-400 hover:underline flex items-center gap-1 cursor-pointer"
                            >
                              <X className="w-3 h-3" /> Remove
                            </button>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => heroImageInputRef.current?.click()}
                          className="w-full py-3 px-4 rounded-xl border-2 border-dashed border-[#2c3044] hover:border-pink-400 bg-[#141724] text-slate-300 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <Upload className="w-4 h-4 text-pink-400" />
                          <span>{posterData.heroImageUrl ? 'Replace Hero Image' : 'Upload Custom Image / Logo'}</span>
                        </button>

                        {posterData.heroImageUrl && (
                          <div className="space-y-3 pt-2">
                            <div>
                              <div className="flex items-center justify-between text-[10px] font-bold text-slate-300 mb-1">
                                <span>Image Size</span>
                                <span>{posterData.heroImageSize}px</span>
                              </div>
                              <input
                                type="range"
                                min={50}
                                max={300}
                                value={posterData.heroImageSize}
                                onChange={(e) => setPosterData({ ...posterData, heroImageSize: Number(e.target.value) })}
                                className="w-full accent-pink-400"
                              />
                            </div>

                            <div>
                              <div className="flex items-center justify-between text-[10px] font-bold text-slate-300 mb-1">
                                <span>Corner Radius</span>
                                <span>{posterData.heroImageRadius}px</span>
                              </div>
                              <input
                                type="range"
                                min={0}
                                max={100}
                                value={posterData.heroImageRadius}
                                onChange={(e) => setPosterData({ ...posterData, heroImageRadius: Number(e.target.value) })}
                                className="w-full accent-pink-400"
                              />
                            </div>

                            <div>
                              <span className="text-[10px] font-bold text-slate-300 block mb-1">Image Position</span>
                              <div className="grid grid-cols-2 gap-1.5">
                                {[
                                  { id: 'above-title', label: 'Above Title' },
                                  { id: 'below-title', label: 'Below Title' },
                                  { id: 'top', label: 'Top Header' }
                                ].map((pos) => (
                                  <button
                                    key={pos.id}
                                    type="button"
                                    onClick={() => setPosterData({ ...posterData, heroImagePosition: pos.id as any })}
                                    className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all border ${
                                      posterData.heroImagePosition === pos.id
                                        ? 'bg-pink-500/20 border-pink-400 text-white'
                                        : 'bg-[#141724] border-[#2c3044] text-slate-400'
                                    }`}
                                  >
                                    {pos.label}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Background Image Upload Option */}
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-3">
                        <label className="text-[10px] font-bold text-purple-400 uppercase flex items-center gap-1.5">
                          <ImageIcon className="w-3.5 h-3.5" />
                          Custom Canvas Background Image
                        </label>

                        <button
                          type="button"
                          onClick={() => bgImageInputRef.current?.click()}
                          className="w-full py-3 px-4 rounded-xl border-2 border-dashed border-[#2c3044] hover:border-purple-400 bg-[#141724] text-slate-300 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <Upload className="w-4 h-4 text-purple-400" />
                          <span>{posterData.bgImageUrl ? 'Change Background Image' : 'Upload Custom BG Image'}</span>
                        </button>
                      </div>
                    </>
                  )}

                  {/* CORNERS & FRAME SUBTAB */}
                  {activeSubTab === 'frame' && (
                    <>
                      {/* Corner Accents Selection */}
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-2">
                        <label className="text-[10px] font-bold text-[#e0a84f] uppercase block">
                          👑 Luxury Corner Style &amp; Filigree
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          {[
                            { id: 'gold-ornate', label: '👑 24K Gold Filigree' },
                            { id: 'cyber-diamond', label: '💎 Cyber Diamond' },
                            { id: 'royal-hairline', label: '⚜️ Royal Hairline' },
                            { id: 'art-deco', label: '🏛️ Art Deco Brackets' },
                            { id: 'modern-glass', label: '✨ Glass Dot Matrix' },
                            { id: 'vintage-floral', label: '🌹 Vintage Floral' },
                            { id: 'sleek-double', label: '🔴 Crimson Double' },
                            { id: 'clean-none', label: '🚫 Clean (No Filigree)' }
                          ].map((corner) => (
                            <button
                              key={corner.id}
                              type="button"
                              onClick={() => setPosterData({ ...posterData, cornerStyle: corner.id as any })}
                              className={`p-2 rounded-xl border text-xs font-bold transition-all text-left ${
                                posterData.cornerStyle === corner.id
                                  ? 'border-[#e0a84f] bg-[#e0a84f]/20 text-white'
                                  : 'border-[#232738] bg-[#141724] text-slate-400 hover:text-white'
                              }`}
                            >
                              {corner.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Border Thickness & Radius */}
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-3">
                        <div>
                          <div className="flex items-center justify-between text-[10px] font-bold text-slate-300 mb-1">
                            <span>Border Thickness</span>
                            <span>{posterData.borderWidth}px</span>
                          </div>
                          <input
                            type="range"
                            min={0}
                            max={10}
                            value={posterData.borderWidth}
                            onChange={(e) => setPosterData({ ...posterData, borderWidth: Number(e.target.value) })}
                            className="w-full accent-[#e0a84f]"
                          />
                        </div>

                        <div>
                          <div className="flex items-center justify-between text-[10px] font-bold text-slate-300 mb-1">
                            <span>Corner Radius</span>
                            <span>{posterData.cornerRadius}px</span>
                          </div>
                          <input
                            type="range"
                            min={0}
                            max={32}
                            value={posterData.cornerRadius}
                            onChange={(e) => setPosterData({ ...posterData, cornerRadius: Number(e.target.value) })}
                            className="w-full accent-[#e0a84f]"
                          />
                        </div>

                        <div className="flex items-center justify-between pt-1">
                          <span className="text-[10px] font-bold text-slate-300">Border Accent Color</span>
                          <input
                            type="color"
                            value={posterData.borderColor}
                            onChange={(e) => setPosterData({ ...posterData, borderColor: e.target.value })}
                            className="w-7 h-7 rounded border-none bg-transparent cursor-pointer"
                          />
                        </div>
                      </div>
                    </>
                  )}

                  {/* COLORS & BG SUBTAB */}
                  {activeSubTab === 'bg' && (
                    <>
                      {/* Background Type Mode */}
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-2">
                        <label className="text-[10px] font-bold text-purple-400 uppercase block">
                          Canvas Background Mode
                        </label>
                        <div className="grid grid-cols-3 gap-1.5">
                          {[
                            { id: 'gradient', label: 'Gradient' },
                            { id: 'solid', label: 'Solid Color' },
                            { id: 'preset', label: 'Texture Overlay' }
                          ].map((mode) => (
                            <button
                              key={mode.id}
                              type="button"
                              onClick={() => setPosterData({ ...posterData, bgType: mode.id as any })}
                              className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all border ${
                                posterData.bgType === mode.id
                                  ? 'bg-purple-500/20 border-purple-400 text-white'
                                  : 'bg-[#141724] border-[#2c3044] text-slate-400'
                              }`}
                            >
                              {mode.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Custom Gradient Colors */}
                      {posterData.bgType === 'gradient' && (
                        <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-3">
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-slate-300">Gradient Start</span>
                            <input
                              type="color"
                              value={posterData.bgGradientStart}
                              onChange={(e) => setPosterData({ ...posterData, bgGradientStart: e.target.value })}
                              className="w-7 h-7 rounded border-none bg-transparent cursor-pointer"
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-slate-300">Gradient End</span>
                            <input
                              type="color"
                              value={posterData.bgGradientEnd}
                              onChange={(e) => setPosterData({ ...posterData, bgGradientEnd: e.target.value })}
                              className="w-7 h-7 rounded border-none bg-transparent cursor-pointer"
                            />
                          </div>
                          <div>
                            <div className="flex items-center justify-between text-[10px] font-bold text-slate-300 mb-1">
                              <span>Gradient Angle</span>
                              <span>{posterData.bgGradientAngle}°</span>
                            </div>
                            <input
                              type="range"
                              min={0}
                              max={360}
                              value={posterData.bgGradientAngle}
                              onChange={(e) => setPosterData({ ...posterData, bgGradientAngle: Number(e.target.value) })}
                              className="w-full accent-purple-400"
                            />
                          </div>
                        </div>
                      )}

                      {/* Background Pattern */}
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-2">
                        <label className="text-[10px] font-bold text-[#a855f7] uppercase block">
                          Background Texture Pattern
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          {[
                            { id: 'gold-dust', label: '✨ Luxury Gold Particles' },
                            { id: 'radial-glow', label: '🌟 Center Radial Spotlight' },
                            { id: 'cyber-grid', label: '🌐 High-Tech Cyber Mesh' },
                            { id: 'marble-glass', label: '🏛️ Obsidian Marble' },
                            { id: 'starry-night', label: '🌌 Starry Cosmos' },
                            { id: 'mesh-gradient', label: '🔮 Abstract Mesh' },
                            { id: 'vintage-grain', label: '📜 Minimalist Grain' },
                            { id: 'none', label: '🖤 Pure Solid Tint' }
                          ].map((pat) => (
                            <button
                              key={pat.id}
                              type="button"
                              onClick={() => setPosterData({ ...posterData, bgPattern: pat.id as any })}
                              className={`p-2 rounded-xl border text-xs font-bold transition-all text-left ${
                                posterData.bgPattern === pat.id
                                  ? 'border-[#a855f7] bg-[#a855f7]/20 text-white'
                                  : 'border-[#232738] bg-[#141724] text-slate-400 hover:text-white'
                              }`}
                            >
                              {pat.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Color Palette Tweaker */}
                      <div className="p-3.5 rounded-xl border border-[#242738] bg-[#0c0e18] flex flex-col gap-3">
                        <label className="text-[10px] font-bold text-slate-300 uppercase">
                          Accent &amp; Canvas Color Tints
                        </label>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-slate-300">Primary Color</span>
                          <input
                            type="color"
                            value={posterData.primaryColor}
                            onChange={(e) => setPosterData({ ...posterData, primaryColor: e.target.value })}
                            className="w-7 h-7 rounded border-none bg-transparent cursor-pointer"
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-slate-300">Secondary Color</span>
                          <input
                            type="color"
                            value={posterData.secondaryColor}
                            onChange={(e) => setPosterData({ ...posterData, secondaryColor: e.target.value })}
                            className="w-7 h-7 rounded border-none bg-transparent cursor-pointer"
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-slate-300">Canvas Base Color</span>
                          <input
                            type="color"
                            value={posterData.bgColor}
                            onChange={(e) => setPosterData({ ...posterData, bgColor: e.target.value, bgGradientStart: e.target.value })}
                            className="w-7 h-7 rounded border-none bg-transparent cursor-pointer"
                          />
                        </div>
                      </div>
                    </>
                  )}

                  {/* LAYOUT PRESETS SUBTAB */}
                  {activeSubTab === 'templates' && (
                    <div className="flex flex-col gap-2">
                      <span className="text-[10px] font-bold text-emerald-400 uppercase block">
                        Switch Layout Preset Instantly
                      </span>
                      <div className="grid grid-cols-2 gap-2">
                        {READY_TEMPLATES.map((tmpl) => (
                          <button
                            key={tmpl.id}
                            type="button"
                            onClick={() => setPosterData(tmpl.data)}
                            className="p-3 rounded-xl border border-[#232738] bg-[#0c0e18] hover:border-emerald-400 transition-all text-left cursor-pointer flex flex-col gap-1"
                          >
                            <span className="text-xs font-bold text-white flex items-center gap-1.5">
                              <span>{tmpl.icon}</span> {tmpl.name}
                            </span>
                            <span className="text-[9px] text-slate-400">{tmpl.badge}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* CUSTOM LAYERS SUBTAB */}
                  {activeSubTab === 'layers' && (
                    <div className="flex flex-col gap-3">
                      <label className="text-[10px] font-bold text-[#38bdf8] uppercase block">
                        Custom Text &amp; Sticker Layers
                      </label>

                      {customLayers.map((layer, idx) => (
                        <div key={layer.id} className="p-3 rounded-xl border border-[#232738] bg-[#0c0e18] flex flex-col gap-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold text-slate-300">Layer #{idx + 1}</span>
                            <button
                              type="button"
                              onClick={() => setCustomLayers(customLayers.filter(l => l.id !== layer.id))}
                              className="text-red-400 hover:text-red-300 p-1 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <input
                            type="text"
                            value={layer.text}
                            onChange={(e) => {
                              const updated = [...customLayers];
                              updated[idx].text = e.target.value;
                              setCustomLayers(updated);
                            }}
                            className="w-full text-xs p-1.5 rounded-lg border border-[#2c3044] bg-[#141724] text-white"
                          />
                          <div className="flex items-center justify-between">
                            <input
                              type="range"
                              min={10}
                              max={24}
                              value={layer.size}
                              onChange={(e) => {
                                const updated = [...customLayers];
                                updated[idx].size = Number(e.target.value);
                                setCustomLayers(updated);
                              }}
                              className="w-2/3 accent-[#38bdf8]"
                            />
                            <input
                              type="color"
                              value={layer.color}
                              onChange={(e) => {
                                const updated = [...customLayers];
                                updated[idx].color = e.target.value;
                                setCustomLayers(updated);
                              }}
                              className="w-6 h-6 rounded bg-transparent cursor-pointer"
                            />
                          </div>
                        </div>
                      ))}

                      <button
                        type="button"
                        onClick={() => {
                          setCustomLayers([
                            ...customLayers,
                            { id: `layer_${Date.now()}`, text: '★ VIP SESSION ACCESS', color: '#e0a84f', size: 12 }
                          ]);
                        }}
                        className="py-2.5 px-3 rounded-xl border border-[#2c3044] bg-[#141724] hover:border-[#38bdf8] text-slate-200 hover:text-white text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5 text-[#38bdf8]" />
                        Add New Text Layer
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
