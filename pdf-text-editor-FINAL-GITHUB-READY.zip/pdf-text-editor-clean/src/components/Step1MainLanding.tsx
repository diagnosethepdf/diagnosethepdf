import React, { useState } from 'react';
import { GlowLogo } from './GlowLogo';
import {
  Sparkles,
  Upload,
  Search,
  FileText,
  RotateCcw,
  Palette,
  User,
  Unlock,
  CheckCircle2,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Activity,
  HardDrive,
  Bot,
  Globe,
  Scissors,
  Layers,
  Lock,
  Image as ImageIcon,
  Scan,
  Crop,
  Hash,
  Building2,
  GraduationCap,
  DollarSign,
  Film,
  Stethoscope,
  FolderArchive,
  FormInput,
  FileSignature,
  LayoutGrid,
  Sliders,
  RefreshCw,
  ShieldCheck,
  Shield,
  CheckSquare,
  Sun,
  Moon,
  Feather,
  Compass,
  Check,
  Zap,
  Tag,
  Maximize2,
  Minimize2,
  Eye,
  ShieldAlert
} from 'lucide-react';
import { GlowTheme } from '../App';
import { IAMUserProfile } from './EnterpriseIamPortalModal';
import { MasterAdminConfig } from '../data/adminStore';

interface Step1Props {
  onSelectTool: (toolId: string) => void;
  onGoToStep?: (step: 1 | 2 | 3) => void;
  originalFileName: string;
  pdfDoc: any;
  pagesCount: number;
  onFileUploadClick: () => void;
  handleClearPDF: () => void;
  glowTheme: GlowTheme;
  setGlowTheme: (theme: GlowTheme) => void;
  role: 'admin' | 'user';
  setRole: (role: 'admin' | 'user') => void;
  theme: any;
  activeTab?: string;
  currentUser?: IAMUserProfile;
  onOpenIamModal?: () => void;
  onOpenPreview?: () => void;
  adminConfig?: MasterAdminConfig;
  onOpenBulkAutoSigner?: () => void;
  onOpenBulkSigner?: () => void;
}

export const Step1MainLanding: React.FC<Step1Props> = ({
  onSelectTool,
  onGoToStep,
  originalFileName,
  pdfDoc,
  pagesCount,
  onFileUploadClick,
  handleClearPDF,
  glowTheme,
  setGlowTheme,
  role,
  setRole,
  theme,
  activeTab = 'editor',
  currentUser,
  onOpenIamModal,
  onOpenPreview,
  adminConfig,
  onOpenBulkAutoSigner,
  onOpenBulkSigner
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showThemeDropdown, setShowThemeDropdown] = useState(false);
  const [selectedFilterCategory, setSelectedFilterCategory] = useState<'all' | 'ai' | 'core' | 'industry' | 'vault'>('all');
  const [activePageSection, setActivePageSection] = useState<'all' | 'section1' | 'section2' | 'section3' | 'section4'>('all');
  const [isExpandedGrid, setIsExpandedGrid] = useState<boolean>(false);

  const isRoseVelvet = glowTheme === 'rose-velvet';

  const disabledSections = adminConfig?.disabledSections || [];
  const isSection1Visible = role === 'admin' || !disabledSections.includes('section1');
  const isSection2Visible = role === 'admin' || !disabledSections.includes('section2');
  const isSection3Visible = role === 'admin' || !disabledSections.includes('section3');
  const isSection4Visible = role === 'admin' || !disabledSections.includes('section4');

  const sectionScaleFactor = adminConfig?.sectionScale || 1.0;
  const sectionScaleStyle = { 
    transform: `scale(${sectionScaleFactor})`, 
    transformOrigin: 'top center',
    transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
  };

  const getSubheadingBoxClass = (defaultLight: string, defaultDark: string) => {
    if (isRoseVelvet) {
      return 'bg-[#4d0c24]/80 border border-[#fbcfe8]/20 text-white shadow-md';
    }
    return theme.isLight ? defaultLight : defaultDark;
  };

  const getInnerCardClass = (toolId: string, borderActive: string, bgActive: string, borderDefaultLight: string, hoverBorder: string, bgDefaultDark: string) => {
    const isActive = activeTab === toolId;
    if (isRoseVelvet) {
      return isActive
        ? 'border-[#ec4899] bg-[#ec4899]/15 text-white shadow-lg'
        : 'bg-[#831843]/40 border-[#fbcfe8]/20 hover:border-[#ec4899] text-white';
    }
    if (isActive) {
      return `${borderActive} ${bgActive}`;
    }
    return theme.isLight
      ? `bg-white ${borderDefaultLight} ${hoverBorder}`
      : `${bgDefaultDark} border-slate-800 ${hoverBorder}`;
  };

  const getListBtnBg = (defaultClass: string) => {
    if (isRoseVelvet) {
      return 'bg-[#831843]/60 text-white border-[#fbcfe8]/20 hover:bg-[#831843] hover:border-[#ec4899]';
    }
    return defaultClass;
  };

  const getToolBadgeStyle = (defaultBgText: string) => {
    if (isRoseVelvet) {
      return 'bg-[#ec4899]/20 text-pink-200 border border-[#ec4899]/30';
    }
    return defaultBgText;
  };

  const getToolArrowStyle = (defaultText: string) => {
    if (isRoseVelvet) {
      return 'text-[#ec4899]';
    }
    return defaultText;
  };

  const getToolTitleStyle = (defaultHover: string) => {
    if (isRoseVelvet) {
      return 'text-white group-hover:text-pink-300 transition-colors';
    }
    return `text-slate-900 dark:text-white ${defaultHover}`;
  };

  const getToolFooterStyle = (defaultText: string) => {
    if (isRoseVelvet) {
      return 'text-pink-300 border-t border-[#fbcfe8]/10';
    }
    return `${defaultText} border-t border-slate-100 dark:border-slate-800`;
  };

  const handleToolClick = (toolId: string) => {
    onSelectTool(toolId);
    const target = document.getElementById('workspace-editor');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const matchesSearch = (text: string, tags: string[] = []) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    if (text.toLowerCase().includes(q)) return true;
    return tags.some((t) => t.toLowerCase().includes(q));
  };

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-500 ${theme.bg}`}>
      {/* 🧭 STEP NAVIGATION CONTROL BAR (FORWARD & BACKWARD AT EVERY STEP) */}
      <div className="w-full bg-slate-900/95 dark:bg-[#0f121e]/95 backdrop-blur-xl border-b border-slate-700/80 px-4 md:px-8 py-2 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-white z-50">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-slate-400 font-bold uppercase tracking-wider text-[11px]">🧭 STEP NAVIGATION:</span>
          <div className="flex items-center gap-1.5 bg-slate-800/90 p-1 rounded-xl border border-slate-700">
            <button
              type="button"
              disabled
              className="px-3 py-1 rounded-lg bg-blue-600 text-white font-extrabold text-[11px] flex items-center gap-1 cursor-default shadow-sm"
            >
              <span>1️⃣ STEP 1: MAIN LANDING (ACTIVE)</span>
            </button>
            <span className="text-slate-500 font-bold">➔</span>
            <button
              type="button"
              onClick={() => onGoToStep?.(2)}
              className="px-3 py-1 rounded-lg bg-slate-700/80 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer"
            >
              <span>2️⃣ STEP 2: SUB-DIRECTORY</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <span className="text-slate-500 font-bold">➔</span>
            <button
              type="button"
              onClick={() => onGoToStep?.(3)}
              className="px-3 py-1 rounded-lg bg-slate-700/80 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer"
            >
              <span>3️⃣ STEP 3: WORKSPACE EDITOR ({activeTab.toUpperCase()})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 🎨 1. TOP STICKY HEADER WITH INTERACTIVE THEME SWITCHER */}
      <header className={`sticky top-0 z-50 border-b px-4 md:px-8 py-3.5 backdrop-blur-2xl shadow-lg transition-all ${theme.headerBg}`}>
        <div className="max-w-[1850px] mx-auto flex flex-wrap items-center justify-between gap-4">
          
          {/* Brand Logo & Status */}
          <div className="flex items-center gap-3">
            <div className="p-1.5 rounded-xl bg-slate-900/90 dark:bg-white/10 border border-slate-700/50 dark:border-white/25 text-cyan-400 shadow-md backdrop-blur-md flex items-center justify-center shrink-0">
              <GlowLogo size="xs" />
            </div>
            <div className="flex flex-col justify-center">
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-black tracking-tight leading-none font-display">
                  <span className="bg-gradient-to-r from-cyan-500 via-indigo-500 to-fuchsia-500 dark:from-cyan-300 dark:via-indigo-300 dark:to-fuchsia-400 bg-clip-text text-transparent font-black">
                    {adminConfig?.uiTextOverrides?.brandingLogoText || 'GlowPDF'}
                  </span>
                  {!adminConfig?.uiTextOverrides?.brandingLogoText && (
                    <span className="text-slate-900 dark:text-white font-extrabold ml-1.5">
                      Suite
                    </span>
                  )}
                </h1>
                <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-blue-500/15 text-blue-600 dark:text-blue-400 border border-blue-500/30 uppercase tracking-wider">
                  {adminConfig?.uiTextOverrides?.brandingBadgeLabel || 'ALL-IN-ONE DIRECTORY'}
                </span>
              </div>
              <p className="text-[11px] font-bold bg-gradient-to-r from-amber-500 via-fuchsia-500 to-cyan-500 dark:from-amber-300 dark:via-fuchsia-300 dark:to-cyan-300 bg-clip-text text-transparent tracking-wide flex items-center gap-1 mt-0.5">
                {adminConfig?.uiTextOverrides?.brandingHeaderTitle || '✨ Makes your documents glow'}
              </p>
            </div>
          </div>

          {/* Center Document Active Status Badge & File Upload Button */}
          <div className={`flex items-center gap-3 p-1.5 px-3.5 rounded-2xl border shadow-sm transition-all ${
            theme.isLight ? 'bg-white/90 border-slate-200' : 'bg-[#121524]/90 border-slate-800'
          }`}>
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${pdfDoc ? 'bg-emerald-500 animate-ping' : 'bg-amber-400'}`} />
              <span className="text-[9px] font-mono font-black uppercase px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-700 dark:text-blue-300 border border-blue-500/30">
                .PDF
              </span>
              {pdfDoc ? (
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[220px]">
                    📄 {originalFileName}
                  </span>
                  <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                    {pagesCount} {pagesCount === 1 ? 'Page' : 'Pages'} Active in Memory
                  </span>
                </div>
              ) : (
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  No Active PDF Loaded
                </span>
              )}
            </div>

            {/* ✍️ Prominent Bulk PDF Signer Button */}
            <button
              onClick={() => {
                if (onOpenBulkSigner) onOpenBulkSigner();
                if (onOpenBulkAutoSigner) onOpenBulkAutoSigner();
                if (onSelectTool) onSelectTool('bulk-auto-signer');
              }}
              title="Open Bulk PDF Auto-Signer Workspace"
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-extrabold text-xs cursor-pointer flex items-center gap-2 shadow-lg shadow-blue-500/25 transition-all hover:scale-105 active:scale-95 border border-blue-400/30"
            >
              <FileSignature className="w-4 h-4 text-cyan-200" />
              <span>Bulk PDF Signer</span>
            </button>

            {/* 🔑 Prominent Enterprise IAM Login Button */}
            <button
              onClick={onOpenIamModal}
              title="Open Enterprise Identity & Access Management Portal"
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-extrabold text-xs cursor-pointer flex items-center gap-2 shadow-lg shadow-blue-500/25 transition-all hover:scale-105 active:scale-95 border border-blue-400/30"
            >
              <ShieldCheck className="w-4 h-4 text-blue-200 animate-pulse" />
              <span>{currentUser?.isLoggedIn ? `🔑 IAM: ${currentUser.name.split(' ')[0]}` : '🔑 Enterprise Login'}</span>
            </button>

            {pdfDoc && onOpenPreview && (
              <button
                onClick={onOpenPreview}
                className="px-3.5 py-2 rounded-xl bg-purple-600/15 hover:bg-purple-600/25 text-purple-700 dark:text-purple-300 border border-purple-500/30 text-xs font-bold cursor-pointer flex items-center gap-1.5 transition-all hover:scale-105 active:scale-95 shadow-2xs"
                title="Preview Active PDF Document"
              >
                <Eye className="w-4 h-4 text-purple-500" />
                <span>Preview PDF</span>
              </button>
            )}

            <button
              onClick={onFileUploadClick}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer flex items-center gap-2 shadow-md shadow-blue-500/20 transition-all hover:scale-105 active:scale-95"
            >
              <Upload className="w-4 h-4" />
              <span>{pdfDoc ? '📁 Change PDF' : '📁 Upload PDF File'}</span>
            </button>

            {pdfDoc && (
              <button
                onClick={handleClearPDF}
                title="Clear Active PDF Memory"
                className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/20 cursor-pointer transition-all"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* 🎨 Theme Switcher & GO WITH ROSEE GLOW Toggle */}
          <div className="flex items-center gap-3">
            {/* GO WITH ROSEE GLOW Toggle Button */}
            <button
              type="button"
              onClick={() => {
                if (isRoseVelvet) {
                  setGlowTheme('light-slate');
                  try { localStorage.setItem('glowpdf_theme', 'light-slate'); } catch (e) {}
                } else {
                  setGlowTheme('rose-velvet');
                  try { localStorage.setItem('glowpdf_theme', 'rose-velvet'); } catch (e) {}
                }
              }}
              className={`px-3.5 py-2 rounded-xl text-white transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer flex items-center gap-2 shrink-0 border ${
                isRoseVelvet
                  ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 border-rose-300 shadow-[0_0_20px_rgba(244,63,94,0.9)] ring-2 ring-rose-300/80'
                  : 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 hover:from-rose-500 hover:to-pink-500 border-rose-300/40 shadow-[0_0_15px_rgba(244,63,94,0.6)]'
              }`}
              title={isRoseVelvet ? 'Click to exit Rosee Glow and return to normal theme' : 'Click to activate Rosee Glow theme'}
            >
              <Sparkles className="w-4 h-4 text-white animate-pulse shrink-0 drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
              <span className="text-white font-extrabold tracking-wider uppercase text-xs">
                {isRoseVelvet ? '✓ ROSEE GLOW ACTIVE (CLICK TO EXIT)' : '✨ GO WITH ROSEE GLOW'}
              </span>
            </button>

            {/* Theme Switcher Symbol Button with Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowThemeDropdown(!showThemeDropdown)}
                className={`px-3 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-2 font-bold text-xs shadow-xs border ${
                  theme.isLight
                    ? 'bg-white border-slate-300 text-slate-800 hover:bg-slate-50'
                    : 'bg-[#151824] border-slate-700 text-white hover:bg-[#1e2336]'
                }`}
                title="Select Theme"
              >
                <span className="text-base">🎨</span>
                <span className="hidden md:inline font-extrabold">Theme</span>
              </button>

              {showThemeDropdown && (
                <div className={`absolute right-0 mt-2 w-56 rounded-2xl shadow-2xl border p-2 z-50 grid grid-cols-1 gap-1 max-h-80 overflow-y-auto ${
                  theme.isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-[#141724] border-[#2b304a] text-white'
                }`}>
                  <div className="px-2 py-1 text-[10px] font-black uppercase tracking-wider opacity-60">Select Aesthetic Theme</div>
                  {[
                    { id: 'light-slate', label: 'Light Studio', symbol: '🌟' },
                    { id: 'cyberpunk-neon', label: 'Dark Neon', symbol: '⚡' },
                    { id: 'solar-amber', label: 'Warm Solar', symbol: '☀️' },
                    { id: 'standard', label: 'Minimal Paper', symbol: '📄' },
                    { id: 'sepia-warm', label: 'Sepia Warm', symbol: '📜' },
                    { id: 'midnight', label: 'Midnight', symbol: '🌙' },
                    { id: 'nordic-frost', label: 'Nordic Frost', symbol: '❄️' },
                    { id: 'warm-cream', label: 'Warm Cream', symbol: '☕' },
                    { id: 'cosmic-dark', label: 'Cosmic Dark', symbol: '🌌' },
                    { id: 'matrix-green', label: 'Matrix Green', symbol: '💚' },
                    { id: 'crimson-cyber', label: 'Crimson Cyber', symbol: '🔴' },
                    { id: 'vibrant-dusk', label: 'Vibrant Dusk', symbol: '🌇' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => {
                        setGlowTheme(t.id as any);
                        try { localStorage.setItem('glowpdf_theme', t.id); } catch (_) {}
                        setShowThemeDropdown(false);
                      }}
                      className={`w-full px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer text-left ${
                        glowTheme === t.id
                          ? (theme.isLight ? 'bg-blue-600 text-white font-extrabold shadow-sm' : 'bg-purple-600 text-white font-extrabold shadow-sm')
                          : (theme.isLight ? 'hover:bg-slate-100 text-slate-700' : 'hover:bg-[#1e2235] text-slate-200')
                      }`}
                    >
                      <span className="text-base">{t.symbol}</span>
                      <span>{t.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Role Switcher */}
            <button
              onClick={() => setRole(role === 'admin' ? 'user' : 'admin')}
              className={`px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-all flex items-center gap-1.5 cursor-pointer ${
                role === 'admin'
                  ? 'bg-purple-500/15 text-purple-700 dark:text-purple-300 border-purple-500/30'
                  : 'bg-blue-500/15 text-blue-700 dark:text-blue-300 border-blue-500/30'
              }`}
            >
              {role === 'admin' ? <Unlock className="w-3.5 h-3.5 text-purple-500" /> : <User className="w-3.5 h-3.5 text-blue-500" />}
              <span className="uppercase tracking-wider">{role}</span>
            </button>

            {/* Admin Console Toggle */}
            <button
              type="button"
              onClick={() => {
                if (onSelectTool) {
                  onSelectTool('admin-panel');
                }
              }}
              className="px-3 py-1.5 rounded-xl text-xs font-extrabold border bg-amber-500/15 hover:bg-amber-500/25 text-amber-700 dark:text-amber-300 border-amber-500/30 transition-all flex items-center gap-1.5 cursor-pointer hover:scale-105 active:scale-95 shadow-2xs"
              title="Open Admin Control Panel"
            >
              <Shield className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span className="uppercase tracking-wider">Admin Console</span>
            </button>

            {/* Document Vault Symbol (Top Right Header - Symbol Only) */}
            <button
              type="button"
              onClick={() => {
                if (onSelectTool) {
                  onSelectTool('doc-vault');
                }
              }}
              className="p-2 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-600 dark:text-purple-400 border border-purple-500/30 transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-xs flex items-center justify-center shrink-0"
              title="Document Vault"
            >
              <FolderArchive className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            </button>
          </div>
        </div>
      </header>

      {/* MAIN LANDING DIRECTORY CONTAINER */}
      <main className="flex-1 max-w-[1850px] w-full mx-auto p-4 md:p-8 flex flex-col gap-10">
        
        {/* TOP SEARCH & PAGE SECTION NAVIGATOR BAR */}
        <div className={`p-3 md:p-4 rounded-2xl border shadow-md backdrop-blur-2xl flex flex-col lg:flex-row items-center justify-between gap-3 ${
          theme.isLight ? 'bg-white/95 border-blue-200/80 shadow-blue-900/5' : 'bg-[#121524]/95 border-slate-800 shadow-black/40'
        }`}>
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <span className="text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded-md bg-blue-500/15 text-blue-600 dark:text-blue-400 border border-blue-500/30">
                PAGE VIEW SELECTOR
              </span>
              <span className="text-[9px] font-mono font-bold text-slate-500 dark:text-slate-400">
                {activePageSection === 'all' ? 'PAGE 1: ALL SECTIONS OVERVIEW' : `PAGE SECTION: ${activePageSection.toUpperCase()}`}
              </span>
            </div>
            <h2 className="text-base md:text-lg font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <span>🗺️ Main Directory &amp; Single-Page Facilities</span>
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 max-w-2xl">
              Switch page sections below to view Section 1, Section 2, Section 3 (Boxes 3.1–3.5), or Section 4 on a single clean page view.
            </p>
          </div>

          {/* Page Section Tab Controls */}
          <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
            {/* Live Search Input */}
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="🔍 Search 30+ tools &amp; standards..."
                className="w-full text-xs pl-10 pr-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-[#181c2e] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-blue-500 font-medium"
              />
            </div>

            {/* Compact / Larger Box Size View Toggle Button */}
            <button
              type="button"
              onClick={() => setIsExpandedGrid((prev) => !prev)}
              className={`px-3 py-2 rounded-2xl border transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold shrink-0 ${
                isExpandedGrid
                  ? 'bg-blue-600/15 text-blue-600 dark:text-blue-400 border-blue-500/40 shadow-xs ring-1 ring-blue-500/30'
                  : 'bg-slate-50 dark:bg-[#181c2e] border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title={isExpandedGrid ? "Switch to Compact Box View" : "Switch to Larger Box View (Increase Grid Size & Roomier Padding)"}
            >
              {isExpandedGrid ? (
                <>
                  <Minimize2 className="w-4 h-4 text-blue-500" />
                  <span className="hidden sm:inline">Compact Grid</span>
                </>
              ) : (
                <>
                  <Maximize2 className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                  <span className="hidden sm:inline">Larger Boxes</span>
                </>
              )}
            </button>

            {/* Page Section Buttons */}
            <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-[#181c2e] border border-slate-300 dark:border-slate-700 text-xs font-bold overflow-x-auto w-full sm:w-auto">
              <button
                type="button"
                onClick={() => { setActivePageSection('all'); setSelectedFilterCategory('all'); }}
                className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                  activePageSection === 'all'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>📄 All Sections</span>
              </button>

              <button
                type="button"
                onClick={() => { setActivePageSection('section3'); setSelectedFilterCategory('industry'); }}
                className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                  activePageSection === 'section3'
                    ? 'bg-purple-600 text-white shadow-md font-extrabold ring-2 ring-purple-400/50'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>🟣 Sec 3 (3.1–3.5)</span>
              </button>

              <button
                type="button"
                onClick={() => { setActivePageSection('section1'); setSelectedFilterCategory('ai'); }}
                className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                  activePageSection === 'section1'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>🟢 Sec 1 (AI)</span>
              </button>

              <button
                type="button"
                onClick={() => { setActivePageSection('section2'); setSelectedFilterCategory('core'); }}
                className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                  activePageSection === 'section2'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>🛠️ Sec 2 (Core)</span>
              </button>

              <button
                type="button"
                onClick={() => { setActivePageSection('section4'); setSelectedFilterCategory('vault'); }}
                className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                  activePageSection === 'section4'
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>🟡 Sec 4 (Vault)</span>
              </button>
            </div>
          </div>
        </div>

        {/* ================= 🟣 SECTION 3: 🏢 INDUSTRY-SPECIFIC COMPLIANCE & SPECIALIZED HUBS ================= */}
        {isSection3Visible && (activePageSection === 'all' || activePageSection === 'section3') && (selectedFilterCategory === 'all' || selectedFilterCategory === 'industry') && (
          <div 
            style={sectionScaleStyle}
            className={`p-6 md:p-8 rounded-3xl border-2 shadow-xl backdrop-blur-xl flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-200 ${
            theme.sectionalBoxBg
          } ${isRoseVelvet ? 'border-[#ec4899]/30 shadow-pink-950/40' : theme.isLight ? 'border-purple-300/80 shadow-purple-900/10' : 'border-purple-500/30 shadow-black/50'}`}>
            {/* Main Section Heading Box Header */}
            <div className={`flex flex-wrap items-center justify-between gap-3 border-b pb-4 ${
              isRoseVelvet ? 'border-[#ec4899]/20' : 'border-cyan-500/20'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                  isRoseVelvet ? 'bg-[#ec4899]/10 border border-[#ec4899]/30 text-pink-400' : 'bg-cyan-500/10 border border-cyan-500/30 text-cyan-400'
                }`}>
                  <Building2 className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                    <span className={isRoseVelvet ? 'text-[#fbcfe8]' : 'text-cyan-400'}>🟣 SECTION 3:</span> 🏢 Industry Compliance &amp; Specialized Hubs
                  </h3>
                  <p className={`text-xs font-medium ${isRoseVelvet ? 'text-[#fbcfe8]/80' : 'text-slate-200'}`}>
                    Tailored compliance tools for Government, Academia, Financial M&amp;A, Prepress, and Healthcare
                  </p>
                </div>
              </div>
              <span className={`text-[10px] font-mono font-bold px-3 py-1 rounded-full uppercase tracking-widest border ${
                isRoseVelvet ? 'bg-[#ec4899]/10 text-pink-300 border-[#ec4899]/30' : 'bg-purple-500/15 text-purple-600 dark:text-purple-400 border-purple-500/30'
              }`}>
                5 SPECIALIZED HUBS UNLOCKED
              </span>
            </div>

            {/* Subheading Boxes inside Section 3 */}
            <div className={isExpandedGrid ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-5"}>
              
              {/* SUBHEADING 3.1: 🏛️ Government & Defense */}
              <div className={`p-4 rounded-2xl border flex flex-col justify-between gap-3 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-amber-100/70 via-orange-50/80 to-amber-50/90 border-amber-300/80', 'bg-[#1a1622]/80 border-amber-500/20')
              }`}>
                <div>
                  <div className={`flex items-center justify-between border-b pb-2 mb-3 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-amber-500/20'}`}>
                    <div className="flex items-center gap-1.5">
                      <Building2 className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-amber-600 dark:text-amber-400'}`} />
                      <h4 className="text-xs font-extrabold text-white dark:text-white">
                        3.1 🏛️ Gov &amp; Defense
                      </h4>
                    </div>
                    <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-amber-500/20 text-amber-600 dark:text-amber-400'}`}>
                      FIPS 140-3
                    </span>
                  </div>
                  <p className={`text-[10px] mb-3 leading-relaxed ${isRoseVelvet ? 'text-pink-200/80' : 'text-slate-500 dark:text-slate-400'}`}>
                    Military cryptography, FOIA redactor, CUI banners &amp; VPAT 508.
                  </p>
                  
                  {/* Functions / Tags */}
                  <div className="flex flex-col gap-1.5">
                    {[
                      { name: 'FIPS 140-3', tab: 'gov-fips', bg: 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-800' },
                      { name: 'FOIA Redactor', tab: 'gov-foia', bg: 'bg-rose-100 text-rose-900 border-rose-300 dark:bg-rose-950 dark:text-rose-200 dark:border-rose-800' },
                      { name: 'CUI Banners', tab: 'gov-cui', bg: 'bg-orange-100 text-orange-900 border-orange-300 dark:bg-orange-950 dark:text-orange-200 dark:border-orange-800' },
                      { name: 'Section 508 VPAT', tab: 'gov-508', bg: 'bg-yellow-100 text-yellow-900 border-yellow-300 dark:bg-yellow-950 dark:text-yellow-200 dark:border-yellow-800' },
                      { name: 'PIV/CAC Smart Card', tab: 'gov-piv', bg: 'bg-emerald-100 text-emerald-900 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-200 dark:border-emerald-800' },
                    ].map((t) => (
                      <button
                        key={t.tab}
                        type="button"
                        onClick={() => handleToolClick(t.tab)}
                        className={`text-[10px] font-bold px-2.5 py-1.5 rounded-xl border flex items-center justify-between transition-transform hover:scale-[1.02] cursor-pointer ${t.bg}`}
                      >
                        <span>{t.name}</span>
                        <ArrowRight className="w-3 h-3 opacity-60" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* SUBHEADING 3.2: 🎓 Academic & Scientific Research */}
              <div className={`p-4 rounded-2xl border flex flex-col justify-between gap-3 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-sky-100/70 via-blue-50/80 to-indigo-50/90 border-sky-300/80', 'bg-[#121c29]/80 border-sky-500/20')
              }`}>
                <div>
                  <div className={`flex items-center justify-between border-b pb-2 mb-3 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-sky-500/20'}`}>
                    <div className="flex items-center gap-1.5">
                      <GraduationCap className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-sky-600 dark:text-sky-400'}`} />
                      <h4 className="text-xs font-extrabold text-white dark:text-white">
                        3.2 🎓 Academic &amp; Research
                      </h4>
                    </div>
                    <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-sky-500/20 text-sky-600 dark:text-sky-400'}`}>
                      IEEE / APA
                    </span>
                  </div>
                  <p className={`text-[10px] mb-3 leading-relaxed ${isRoseVelvet ? 'text-pink-200/80' : 'text-slate-500 dark:text-slate-400'}`}>
                    LaTeX extraction, BibTeX builders, plagiarism shield &amp; DOI.
                  </p>

                  {/* Functions / Tags */}
                  <div className="flex flex-col gap-1.5">
                    {[
                      { name: 'LaTeX Extractor', tab: 'edu-latex', bg: 'bg-sky-100 text-sky-900 border-sky-300 dark:bg-sky-950 dark:text-sky-200 dark:border-sky-800' },
                      { name: 'BibTeX Builder', tab: 'edu-bibtex', bg: 'bg-indigo-100 text-indigo-900 border-indigo-300 dark:bg-indigo-950 dark:text-indigo-200 dark:border-indigo-800' },
                      { name: 'AI Plagiarism Shield', tab: 'edu-turnitin', bg: 'bg-purple-100 text-purple-900 border-purple-300 dark:bg-purple-950 dark:text-purple-200 dark:border-purple-800' },
                      { name: 'DOI Injector', tab: 'edu-arxiv', bg: 'bg-teal-100 text-teal-900 border-teal-300 dark:bg-teal-950 dark:text-teal-200 dark:border-teal-800' },
                      { name: 'Double-Blind', tab: 'edu-anonymizer', bg: 'bg-blue-100 text-blue-900 border-blue-300 dark:bg-blue-950 dark:text-blue-200 dark:border-blue-800' },
                    ].map((t) => (
                      <button
                        key={t.tab}
                        type="button"
                        onClick={() => handleToolClick(t.tab)}
                        className={`text-[10px] font-bold px-2.5 py-1.5 rounded-xl border flex items-center justify-between transition-transform hover:scale-[1.02] cursor-pointer ${getListBtnBg(t.bg)}`}
                      >
                        <span>{t.name}</span>
                        <ArrowRight className="w-3 h-3 opacity-60" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* SUBHEADING 3.3: 💰 Financial & Corporate M&A */}
              <div className={`p-4 rounded-2xl border flex flex-col justify-between gap-3 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-emerald-100/70 via-teal-50/80 to-green-50/90 border-emerald-300/80', 'bg-[#12221b]/80 border-emerald-500/20')
              }`}>
                <div>
                  <div className={`flex items-center justify-between border-b pb-2 mb-3 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-emerald-500/20'}`}>
                    <div className="flex items-center gap-1.5">
                      <DollarSign className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-emerald-600 dark:text-emerald-400'}`} />
                      <h4 className="text-xs font-extrabold text-white dark:text-white">
                        3.3 💰 Financial &amp; M&amp;A
                      </h4>
                    </div>
                    <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'}`}>
                      SEC iXBRL
                    </span>
                  </div>
                  <p className={`text-[10px] mb-3 leading-relaxed ${isRoseVelvet ? 'text-pink-200/80' : 'text-slate-500 dark:text-slate-400'}`}>
                    iXBRL tags, AML redactor, invoice to Excel &amp; SOC2 logs.
                  </p>

                  {/* Functions / Tags */}
                  <div className="flex flex-col gap-1.5">
                    {[
                      { name: 'iXBRL Tagging', tab: 'fin-xbrl', bg: 'bg-emerald-100 text-emerald-900 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-200 dark:border-emerald-800' },
                      { name: 'AML Redactor', tab: 'fin-aml', bg: 'bg-lime-100 text-lime-900 border-lime-300 dark:bg-lime-950 dark:text-lime-200 dark:border-lime-800' },
                      { name: 'Invoice to Excel', tab: 'fin-invoice', bg: 'bg-green-100 text-green-900 border-green-300 dark:bg-green-950 dark:text-green-200 dark:border-green-800' },
                      { name: 'RFC 3161 Timestamp', tab: 'fin-timestamp', bg: 'bg-teal-100 text-teal-900 border-teal-300 dark:bg-teal-950 dark:text-teal-200 dark:border-teal-800' },
                      { name: 'SOC2 Audit', tab: 'fin-soc2', bg: 'bg-emerald-100 text-emerald-900 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-200 dark:border-emerald-800' },
                    ].map((t) => (
                      <button
                        key={t.tab}
                        type="button"
                        onClick={() => handleToolClick(t.tab)}
                        className={`text-[10px] font-bold px-2.5 py-1.5 rounded-xl border flex items-center justify-between transition-transform hover:scale-[1.02] cursor-pointer ${getListBtnBg(t.bg)}`}
                      >
                        <span>{t.name}</span>
                        <ArrowRight className="w-3 h-3 opacity-60" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* SUBHEADING 3.4: 🎨 Creative & Prepress */}
              <div className={`p-4 rounded-2xl border flex flex-col justify-between gap-3 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-fuchsia-100/70 via-pink-50/80 to-purple-50/90 border-fuchsia-300/80', 'bg-[#221326]/80 border-fuchsia-500/20')
              }`}>
                <div>
                  <div className={`flex items-center justify-between border-b pb-2 mb-3 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-fuchsia-500/20'}`}>
                    <div className="flex items-center gap-1.5">
                      <Film className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-fuchsia-600 dark:text-fuchsia-400'}`} />
                      <h4 className="text-xs font-extrabold text-white dark:text-white">
                        3.4 🎨 Prepress &amp; Print
                      </h4>
                    </div>
                    <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-fuchsia-500/20 text-fuchsia-600 dark:text-fuchsia-400'}`}>
                      CMYK ISO
                    </span>
                  </div>
                  <p className={`text-[10px] mb-3 leading-relaxed ${isRoseVelvet ? 'text-pink-200/80' : 'text-slate-500 dark:text-slate-400'}`}>
                    CMYK preflight, bleed cropper, font vectorizer &amp; booklet.
                  </p>

                  {/* Functions / Tags */}
                  <div className="flex flex-col gap-1.5">
                    {[
                      { name: 'CMYK Preflight', tab: 'media-cmyk', bg: 'bg-fuchsia-100 text-fuchsia-900 border-fuchsia-300 dark:bg-fuchsia-950 dark:text-fuchsia-200 dark:border-fuchsia-800' },
                      { name: 'Bleed/Crop Gen', tab: 'media-bleed', bg: 'bg-pink-100 text-pink-900 border-pink-300 dark:bg-pink-950 dark:text-pink-200 dark:border-pink-800' },
                      { name: 'Font Vectorizer', tab: 'media-font', bg: 'bg-rose-100 text-rose-900 border-rose-300 dark:bg-rose-950 dark:text-rose-200 dark:border-rose-800' },
                      { name: 'Booklet Layout', tab: 'media-bundle', bg: 'bg-[#fae8ff] text-purple-900 border-purple-300 dark:bg-purple-950 dark:text-purple-200 dark:border-purple-800' },
                    ].map((t) => (
                      <button
                        key={t.tab}
                        type="button"
                        onClick={() => handleToolClick(t.tab)}
                        className={`text-[10px] font-bold px-2.5 py-1.5 rounded-xl border flex items-center justify-between transition-transform hover:scale-[1.02] cursor-pointer ${getListBtnBg(t.bg)}`}
                      >
                        <span>{t.name}</span>
                        <ArrowRight className="w-3 h-3 opacity-60" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* SUBHEADING 3.5: 🩺 Healthcare & HIPAA (18 Safe Harbor PHI Features) */}
              <div className={`p-5 rounded-2xl border flex flex-col justify-between gap-4 col-span-1 md:col-span-2 xl:col-span-5 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-rose-100/70 via-red-50/80 to-pink-50/90 border-rose-300/80', 'bg-[#261318]/90 border-rose-500/30')
              }`}>
                <div>
                  <div className={`flex flex-wrap items-center justify-between border-b pb-3 mb-4 gap-2 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-rose-500/20'}`}>
                    <div className="flex items-center gap-2">
                      <Stethoscope className={`w-5 h-5 animate-pulse ${isRoseVelvet ? 'text-pink-400' : 'text-rose-600 dark:text-rose-400'}`} />
                      <div>
                        <h4 className="text-sm font-extrabold text-white dark:text-white flex items-center gap-2 flex-wrap">
                          <span>3.5 🩺 Healthcare &amp; HIPAA Safe Harbor Suite</span>
                          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300 border-[#ec4899]/30' : 'bg-rose-500/20 text-rose-600 dark:text-rose-400 border-rose-500/30'}`}>
                            ALL 18 PHI IDENTIFIERS INCLUDED
                          </span>
                        </h4>
                        <p className={`text-[11px] mt-0.5 ${isRoseVelvet ? 'text-pink-200/80' : 'text-slate-500 dark:text-slate-400'}`}>
                          Complete 18 Protected Health Information (PHI) Safe Harbor de-identification &amp; clinical data exchange engines.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleToolClick('health-hipaa')}
                        className={`px-3 py-1.5 text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5 ${isRoseVelvet ? 'bg-[#ec4899] hover:bg-[#db2777] text-white' : 'bg-rose-600 hover:bg-rose-500 text-white'}`}
                      >
                        <Shield className="w-3.5 h-3.5" />
                        <span>Launch 18 PHI De-Identifier</span>
                      </button>
                    </div>
                  </div>

                  {/* Main Healthcare Tool Suites */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4">
                    {[
                      { name: '1. HIPAA 18 PHI De-ID', tab: 'health-hipaa', desc: '18 Safe Harbor PHI Redactor', bg: 'bg-rose-100/90 text-rose-950 border-rose-300 dark:bg-rose-950/80 dark:text-rose-100 dark:border-rose-800' },
                      { name: '2. HL7 / FHIR Exchange', tab: 'health-fhir', desc: 'FHIR R4 JSON Bundle Convert', bg: 'bg-orange-100/90 text-orange-950 border-orange-300 dark:bg-orange-950/80 dark:text-orange-100 dark:border-orange-800' },
                      { name: '3. DICOM Scan Viewer', tab: 'health-dicom', desc: 'Radiological Vector Scans', bg: 'bg-amber-100/90 text-amber-950 border-amber-300 dark:bg-amber-950/80 dark:text-amber-100 dark:border-amber-800' },
                      { name: '4. 21 CFR Part 11 Audit', tab: 'health-audit', desc: 'Clinical Trial Audit Trails', bg: 'bg-red-100/90 text-red-950 border-red-300 dark:bg-red-950/80 dark:text-red-100 dark:border-red-800' },
                    ].map((t) => (
                      <button
                        key={t.tab}
                        type="button"
                        onClick={() => handleToolClick(t.tab)}
                        className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all hover:scale-[1.02] cursor-pointer shadow-sm ${getListBtnBg(t.bg)}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black">{t.name}</span>
                          <ArrowRight className="w-3.5 h-3.5 opacity-70" />
                        </div>
                        <span className="text-[10px] opacity-80 mt-1 font-medium">{t.desc}</span>
                      </button>
                    ))}
                  </div>

                  {/* ALL 18 PHI IDENTIFIERS BOXES GRID */}
                  <div className="mt-4 pt-3 border-t border-rose-500/20">
                    <div className="flex items-center justify-between mb-2.5">
                      <span className="text-xs font-mono font-black text-rose-600 dark:text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                        <CheckSquare className="w-3.5 h-3.5" />
                        18 Safe Harbor Protected Health Information (PHI) Identifiers:
                      </span>
                      <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400">
                        18 / 18 Active Diagnostics
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                      {[
                        { num: '01', title: 'Patient Names', tag: 'Names & Relatives' },
                        { num: '02', title: 'Geographic Data', tag: 'Addresses & ZIPs' },
                        { num: '03', title: 'Clinical Dates', tag: 'Birth/Discharge' },
                        { num: '04', title: 'Phone Numbers', tag: 'Landline & Mobile' },
                        { num: '05', title: 'Fax Numbers', tag: 'Telefax Data' },
                        { num: '06', title: 'Email Addresses', tag: 'Patient Emails' },
                        { num: '07', title: 'Social Security', tag: 'SSN (9 Digits)' },
                        { num: '08', title: 'Medical Records', tag: 'MRN Identifier' },
                        { num: '09', title: 'Health Plan IDs', tag: 'Beneficiary No.' },
                        { num: '10', title: 'Account Numbers', tag: 'Billing Records' },
                        { num: '11', title: 'Licenses / Certs', tag: 'Medical Certs' },
                        { num: '12', title: 'Vehicle Serial', tag: 'VIN & License Plate' },
                        { num: '13', title: 'Device Serials', tag: 'UDI & Implant ID' },
                        { num: '14', title: 'Web URLs', tag: 'Patient Portals' },
                        { num: '15', title: 'IP Addresses', tag: 'Network Logs' },
                        { num: '16', title: 'Biometrics', tag: 'Finger/Voice Prints' },
                        { num: '17', title: 'Full-Face Photos', tag: 'Patient Imagery' },
                        { num: '18', title: 'Unique Identifiers', tag: 'Any Unique Code' },
                      ].map((item) => (
                        <div
                          key={item.num}
                          onClick={() => handleToolClick('health-hipaa')}
                          className="p-2 rounded-xl bg-white/80 dark:bg-[#18111c] border border-rose-300 dark:border-rose-900/60 hover:border-rose-500 text-left transition-all hover:scale-[1.02] cursor-pointer flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[9px] font-mono font-black text-rose-600 dark:text-rose-400 bg-rose-500/10 px-1.5 py-0.2 rounded">
                              #{item.num}
                            </span>
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          </div>
                          <span className="text-[10px] font-extrabold text-slate-900 dark:text-slate-100 line-clamp-1">
                            {item.title}
                          </span>
                          <span className="text-[8px] font-mono text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                            {item.tag}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* SUBHEADING 3.6: 🔄 Converter Corner & Multi-Format Document Converters */}
              <div className={`p-5 rounded-2xl border flex flex-col justify-between gap-4 col-span-1 md:col-span-2 xl:col-span-5 ${
                theme.isLight ? 'bg-emerald-50/40 border-emerald-200/90' : 'bg-[#13231f]/90 border-emerald-500/30'
              }`}>
                <div>
                  <div className="flex flex-wrap items-center justify-between border-b border-emerald-500/20 pb-3 mb-4 gap-2">
                    <div className="flex items-center gap-2">
                      <RefreshCw className="w-5 h-5 text-emerald-600 dark:text-emerald-400 animate-pulse" />
                      <div>
                        <h4 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                          <span>3.6 🔄 Converter Corner &amp; Multi-Format Document Suite</span>
                          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                            ALL 8 TWO-WAY CONVERTERS UNLOCKED
                          </span>
                        </h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                          High-fidelity binary ArrayBuffer conversions between PDF, Word, Excel, Google Docs, Text, and Lossless Images.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleToolClick('convert')}
                        className="px-3 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Launch Converter Studio</span>
                      </button>
                    </div>
                  </div>

                  {/* 8 Converter Tool Cards Grid */}
                  <div className="space-y-4">
                    {/* GROUP 1: From PDF Converters */}
                    <div>
                      <span className="text-[10px] font-mono font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block mb-2">
                        Group 1: "From PDF" Converters (Export PDF Content)
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                        <div
                          onClick={() => handleToolClick('convert')}
                          className="p-3 rounded-xl bg-white/80 dark:bg-[#151c27] border border-emerald-200 dark:border-emerald-800/60 hover:border-emerald-500 text-left transition-all hover:scale-[1.02] cursor-pointer flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[9px] font-mono font-extrabold px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-600 dark:text-blue-400">
                              .DOCX
                            </span>
                            <ArrowRight className="w-3.5 h-3.5 text-emerald-500" />
                          </div>
                          <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                            PDF to Word (.docx)
                          </span>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                            Convert PDF text, layout, and structured paragraphs into editable Word documents.
                          </span>
                        </div>

                        <div
                          onClick={() => handleToolClick('convert')}
                          className="p-3 rounded-xl bg-white/80 dark:bg-[#151c27] border border-emerald-200 dark:border-emerald-800/60 hover:border-emerald-500 text-left transition-all hover:scale-[1.02] cursor-pointer flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[9px] font-mono font-extrabold px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                              .XLSX
                            </span>
                            <ArrowRight className="w-3.5 h-3.5 text-emerald-500" />
                          </div>
                          <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                            PDF to Excel (.xlsx)
                          </span>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                            Detect and extract tabular data into native spreadsheet worksheets with clear row/column mapping.
                          </span>
                        </div>

                        <div
                          onClick={() => handleToolClick('convert')}
                          className="p-3 rounded-xl bg-white/80 dark:bg-[#151c27] border border-emerald-200 dark:border-emerald-800/60 hover:border-emerald-500 text-left transition-all hover:scale-[1.02] cursor-pointer flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[9px] font-mono font-extrabold px-1.5 py-0.5 rounded bg-purple-500/15 text-purple-600 dark:text-purple-400">
                              .TXT
                            </span>
                            <ArrowRight className="w-3.5 h-3.5 text-emerald-500" />
                          </div>
                          <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                            PDF to Text / Google Docs (.txt)
                          </span>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                            Extract plain structured text and prose into raw text/Google Docs format.
                          </span>
                        </div>

                        <div
                          onClick={() => handleToolClick('convert')}
                          className="p-3 rounded-xl bg-white/80 dark:bg-[#151c27] border border-emerald-200 dark:border-emerald-800/60 hover:border-emerald-500 text-left transition-all hover:scale-[1.02] cursor-pointer flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[9px] font-mono font-extrabold px-1.5 py-0.5 rounded bg-pink-500/15 text-pink-600 dark:text-pink-400">
                              .JPG/.PNG
                            </span>
                            <ArrowRight className="w-3.5 h-3.5 text-emerald-500" />
                          </div>
                          <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                            PDF to Image (.jpg / .png)
                          </span>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                            Render and download PDF pages as high-resolution images.
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* GROUP 2: To PDF & Office Formats */}
                    <div>
                      <span className="text-[10px] font-mono font-bold text-sky-600 dark:text-sky-400 uppercase tracking-wider block mb-2">
                        Group 2: "To PDF &amp; Office Formats" Converters (Generate PDF &amp; Office Files)
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                        <div
                          onClick={() => handleToolClick('convert')}
                          className="p-3 rounded-xl bg-white/80 dark:bg-[#151c27] border border-sky-200 dark:border-sky-800/60 hover:border-sky-500 text-left transition-all hover:scale-[1.02] cursor-pointer flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[9px] font-mono font-extrabold px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-600 dark:text-blue-400">
                              WORD ➔ PDF
                            </span>
                            <ArrowRight className="w-3.5 h-3.5 text-sky-500" />
                          </div>
                          <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                            Word to PDF (.docx → .pdf)
                          </span>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                            Render .docx files directly into high-fidelity PDF documents.
                          </span>
                        </div>

                        <div
                          onClick={() => handleToolClick('convert')}
                          className="p-3 rounded-xl bg-white/80 dark:bg-[#151c27] border border-sky-200 dark:border-sky-800/60 hover:border-sky-500 text-left transition-all hover:scale-[1.02] cursor-pointer flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[9px] font-mono font-extrabold px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                              EXCEL ➔ PDF
                            </span>
                            <ArrowRight className="w-3.5 h-3.5 text-sky-500" />
                          </div>
                          <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                            Excel to PDF (.xlsx → .pdf)
                          </span>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                            Convert spreadsheet tables and charts into printable PDF pages.
                          </span>
                        </div>

                        <div
                          onClick={() => handleToolClick('convert')}
                          className="p-3 rounded-xl bg-white/80 dark:bg-[#151c27] border border-sky-200 dark:border-sky-800/60 hover:border-sky-500 text-left transition-all hover:scale-[1.02] cursor-pointer flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[9px] font-mono font-extrabold px-1.5 py-0.5 rounded bg-pink-500/15 text-pink-600 dark:text-pink-400">
                              IMAGE ➔ PDF
                            </span>
                            <ArrowRight className="w-3.5 h-3.5 text-sky-500" />
                          </div>
                          <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                            Image to PDF (.jpg / .png → .pdf)
                          </span>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                            Bundle image files into a single structured PDF.
                          </span>
                        </div>

                        <div
                          onClick={() => handleToolClick('convert')}
                          className="p-3 rounded-xl bg-white/80 dark:bg-[#151c27] border border-sky-200 dark:border-sky-800/60 hover:border-sky-500 text-left transition-all hover:scale-[1.02] cursor-pointer flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[9px] font-mono font-extrabold px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-600 dark:text-amber-400">
                              OFFICE ➔ JPEG
                            </span>
                            <ArrowRight className="w-3.5 h-3.5 text-sky-500" />
                          </div>
                          <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                            Office to JPEG (.docx / .xlsx → .jpg)
                          </span>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                            Export document pages or spreadsheet tables as image files.
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ================= 🟢 SECTION 1: 🤖 AI DOCUMENT INTELLIGENCE & HEALTH DIAGNOSTICS ================= */}
        {isSection1Visible && (activePageSection === 'all' || activePageSection === 'section1') && (selectedFilterCategory === 'all' || selectedFilterCategory === 'ai') && (
          <div 
            style={sectionScaleStyle}
            className={`p-6 md:p-8 rounded-3xl border-2 shadow-xl backdrop-blur-xl flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-200 ${
            theme.sectionalBoxBg
          } ${isRoseVelvet ? 'border-[#ec4899]/30 shadow-pink-950/40' : theme.isLight ? 'border-emerald-300/80 shadow-emerald-900/10' : 'border-emerald-500/30 shadow-black/50'}`}>
            {/* Main Section Heading Box Header */}
            <div className={`flex flex-wrap items-center justify-between gap-3 border-b pb-4 ${
              isRoseVelvet ? 'border-[#ec4899]/20' : 'border-amber-500/20'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                  isRoseVelvet ? 'bg-[#ec4899]/10 border border-[#ec4899]/30 text-pink-400' : 'bg-amber-500/10 border border-amber-500/30 text-amber-400'
                }`}>
                  <Bot className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                    <span className={isRoseVelvet ? 'text-[#fbcfe8]' : 'text-amber-400'}>🟢 SECTION 1:</span> 🤖 AI Document Intelligence &amp; Health Diagnostics
                  </h3>
                  <p className={`text-xs font-medium ${isRoseVelvet ? 'text-[#fbcfe8]/80' : 'text-slate-200'}`}>
                    Neural AI document chat, executive summarizers, WebGPU translation, and deep PDF vector diagnostics
                  </p>
                </div>
              </div>
              <span className={`text-[10px] font-mono font-bold px-3 py-1 rounded-full uppercase tracking-widest border ${
                isRoseVelvet ? 'bg-[#ec4899]/10 text-pink-300 border-[#ec4899]/30' : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
              }`}>
                AI ENGINE READY
              </span>
            </div>

            {/* Subheading Boxes inside Section 1 */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* SUBHEADING 1.1: 🩺 PDF Health & Diagnostics */}
              <div className={`p-5 rounded-2xl border flex flex-col gap-4 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-emerald-100/70 via-teal-50/80 to-green-50/90 border-emerald-300/80', 'bg-[#151d20]/80 border-emerald-500/20')
              }`}>
                <div className={`flex items-center justify-between border-b pb-2.5 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-emerald-500/20'}`}>
                  <div className="flex items-center gap-2">
                    <Activity className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-emerald-600 dark:text-emerald-400'}`} />
                    <h4 className="text-sm font-extrabold text-white dark:text-white">
                      1.1 🩺 PDF Health &amp; Vector Diagnostics
                    </h4>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-md ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300'}`}>
                    2 UTILITIES
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Function 1.1.1: Health Diagnosis */}
                  {matchesSearch('Comprehensive PDF Health Diagnosis Corrupted stream recovery vector syntax audit', ['recovery', 'diagnostics', 'health']) && (
                    <div
                      onClick={() => handleToolClick('doc-analytics')}
                      className={`group p-4 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-lg ${
                        getInnerCardClass('doc-analytics', 'border-emerald-500', 'bg-emerald-500/10', 'border-emerald-200', 'hover:border-emerald-500', 'bg-[#121524]')
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-2">
                          <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${getToolBadgeStyle('bg-emerald-500/15 text-emerald-600')}`}>
                            DIAGNOSTICS
                          </span>
                          <ArrowRight className={`w-3.5 h-3.5 group-hover:translate-x-1 transition-transform ${getToolArrowStyle('text-emerald-500')}`} />
                        </div>
                        <h5 className={`text-xs font-extrabold transition-colors ${getToolTitleStyle('group-hover:text-emerald-600')}`}>
                          🩺 Comprehensive PDF &amp; PHI Health Diagnosis
                        </h5>
                        <p className={`text-[10px] mt-1 leading-snug ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                          Vector syntax audit, stream buffer recovery, layer breakdown &amp; 18 PHI Safe Harbor health diagnostics.
                        </p>
                      </div>
                      <span className={`text-[10px] font-bold mt-3 pt-2 ${getToolFooterStyle('text-emerald-600 dark:text-emerald-400')}`}>
                        Launch Health Audit →
                      </span>
                    </div>
                  )}

                  {/* Function 1.1.2: Visual Compare */}
                  {matchesSearch('Visual PDF Compare side by side diff pixel text analyzer', ['compare', 'diff', 'pixel']) && (
                    <div
                      onClick={() => handleToolClick('pdf-compare')}
                      className={`group p-4 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-lg ${
                        getInnerCardClass('pdf-compare', 'border-emerald-500', 'bg-emerald-500/10', 'border-emerald-200', 'hover:border-emerald-500', 'bg-[#121524]')
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-2">
                          <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${getToolBadgeStyle('bg-emerald-500/15 text-emerald-600')}`}>
                            COMPARISON
                          </span>
                          <ArrowRight className={`w-3.5 h-3.5 group-hover:translate-x-1 transition-transform ${getToolArrowStyle('text-emerald-500')}`} />
                        </div>
                        <h5 className={`text-xs font-extrabold transition-colors ${getToolTitleStyle('group-hover:text-emerald-600')}`}>
                          📊 Visual PDF Compare
                        </h5>
                        <p className={`text-[10px] mt-1 leading-snug ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                          Side-by-side pixel &amp; text diff analysis with revision overlay.
                        </p>
                      </div>
                      <span className={`text-[10px] font-bold mt-3 pt-2 ${getToolFooterStyle('text-emerald-600 dark:text-emerald-400')}`}>
                        Compare Documents →
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* SUBHEADING 1.2: 🤖 Neural AI Chat, Summarizer & Translation */}
              <div className={`p-5 rounded-2xl border flex flex-col gap-4 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-indigo-100/70 via-purple-50/80 to-blue-50/90 border-indigo-300/80', 'bg-[#16172b]/80 border-indigo-500/20')
              }`}>
                <div className={`flex items-center justify-between border-b pb-2.5 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-indigo-500/20'}`}>
                  <div className="flex items-center gap-2">
                    <Bot className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-indigo-600 dark:text-indigo-400'}`} />
                    <h4 className="text-sm font-extrabold text-white dark:text-white">
                      1.2 🤖 Neural AI Chat, Summaries &amp; Translation
                    </h4>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-md ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-indigo-500/20 text-indigo-700 dark:text-indigo-300'}`}>
                    3 UTILITIES
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Function 1.2.1: Local AI Chat */}
                  {matchesSearch('Local AI Interactive Q&A chat document assistant', ['chat', 'ai', 'qa']) && (
                    <div
                      onClick={() => handleToolClick('chat')}
                      className={`group p-3.5 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-lg ${
                        getInnerCardClass('chat', 'border-indigo-500', 'bg-indigo-500/10', 'border-indigo-200', 'hover:border-indigo-500', 'bg-[#121524]')
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1.5">
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${getToolBadgeStyle('bg-indigo-500/15 text-indigo-600')}`}>
                            AI CHAT
                          </span>
                          <ArrowRight className={`w-3 h-3 group-hover:translate-x-0.5 transition-transform ${getToolArrowStyle('text-indigo-500')}`} />
                        </div>
                        <h5 className={`text-[11px] font-extrabold transition-colors ${getToolTitleStyle('group-hover:text-indigo-600')}`}>
                          💬 Interactive AI Q&amp;A
                        </h5>
                        <p className={`text-[10px] mt-1 leading-tight ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                          Ask questions, extract clauses &amp; search citations.
                        </p>
                      </div>
                      <span className={`text-[9px] font-bold mt-2.5 pt-1.5 ${getToolFooterStyle('text-indigo-600 dark:text-indigo-400')}`}>
                        Open Chat Studio →
                      </span>
                    </div>
                  )}

                  {/* Function 1.2.2: Document Summarizer */}
                  {matchesSearch('Document Summarizer executive bullet points action items', ['summarizer', 'summary', 'bullets']) && (
                    <div
                      onClick={() => handleToolClick('summarizer')}
                      className={`group p-3.5 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-lg ${
                        getInnerCardClass('summarizer', 'border-indigo-500', 'bg-indigo-500/10', 'border-indigo-200', 'hover:border-indigo-500', 'bg-[#121524]')
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1.5">
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${getToolBadgeStyle('bg-indigo-500/15 text-indigo-600')}`}>
                            SUMMARY
                          </span>
                          <ArrowRight className={`w-3 h-3 group-hover:translate-x-0.5 transition-transform ${getToolArrowStyle('text-indigo-500')}`} />
                        </div>
                        <h5 className={`text-[11px] font-extrabold transition-colors ${getToolTitleStyle('group-hover:text-indigo-600')}`}>
                          📝 AI Summarizer
                        </h5>
                        <p className={`text-[10px] mt-1 leading-tight ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                          Executive bullets, key deliverables &amp; clause breakdowns.
                        </p>
                      </div>
                      <span className={`text-[9px] font-bold mt-2.5 pt-1.5 ${getToolFooterStyle('text-indigo-600 dark:text-indigo-400')}`}>
                        Summarize Now →
                      </span>
                    </div>
                  )}

                  {/* Function 1.2.3: WebGPU Layout Translator */}
                  {matchesSearch('WebGPU Neural Layout Translator multi language preserve vector positions', ['translator', 'translate', 'webgpu']) && (
                    <div
                      onClick={() => handleToolClick('translator')}
                      className={`group p-3.5 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-lg ${
                        getInnerCardClass('translator', 'border-indigo-500', 'bg-indigo-500/10', 'border-indigo-200', 'hover:border-indigo-500', 'bg-[#121524]')
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1.5">
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${getToolBadgeStyle('bg-indigo-500/15 text-indigo-600')}`}>
                            TRANSLATE
                          </span>
                          <ArrowRight className={`w-3 h-3 group-hover:translate-x-0.5 transition-transform ${getToolArrowStyle('text-indigo-500')}`} />
                        </div>
                        <h5 className={`text-[11px] font-extrabold transition-colors ${getToolTitleStyle('group-hover:text-indigo-600')}`}>
                          🌐 Layout Translator
                        </h5>
                        <p className={`text-[10px] mt-1 leading-tight ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                          WebGPU translation maintaining vector geometry &amp; fonts.
                        </p>
                      </div>
                      <span className={`text-[9px] font-bold mt-2.5 pt-1.5 ${getToolFooterStyle('text-indigo-600 dark:text-indigo-400')}`}>
                        Translate PDF →
                      </span>
                    </div>
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* 🧭 STEP NAVIGATION CONTROL BAR (FORWARD & BACKWARD AT EVERY STEP) */}
        <div className="w-full bg-slate-900/90 dark:bg-[#0f121e]/90 backdrop-blur-xl border-b border-slate-700/80 px-4 md:px-8 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-slate-400 font-bold uppercase tracking-wider text-[11px]">🧭 STEP NAVIGATION:</span>
            <div className="flex items-center gap-1.5 bg-slate-800/90 p-1 rounded-xl border border-slate-700">
              <button
                type="button"
                disabled
                className="px-3 py-1 rounded-lg bg-blue-600 text-white font-extrabold text-[11px] flex items-center gap-1 cursor-default shadow-sm"
              >
                <span>1️⃣ STEP 1: MAIN FACILITIES (ACTIVE)</span>
              </button>
              <span className="text-slate-500 font-bold">➔</span>
              <button
                type="button"
                onClick={() => onGoToStep?.(2)}
                className="px-3 py-1 rounded-lg bg-slate-700/80 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer"
              >
                <span>2️⃣ STEP 2: SUB-DIRECTORY</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
              <span className="text-slate-500 font-bold">➔</span>
              <button
                type="button"
                onClick={() => onGoToStep?.(3)}
                className="px-3 py-1 rounded-lg bg-slate-700/80 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer"
              >
                <span>3️⃣ STEP 3: WORKSPACE EDITOR</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-slate-400 text-[11px]">
            <span className="font-bold text-emerald-400">🟢 ALL 18 CORE PDF PRODUCTION FACILITIES UNLOCKED</span>
          </div>
        </div>

        {/* ================= 🔵 SECTION 2: 🛠️ CORE PDF PRODUCTION FACILITIES ================= */}
        {isSection2Visible && (activePageSection === 'all' || activePageSection === 'section2') && (selectedFilterCategory === 'all' || selectedFilterCategory === 'core') && (
          <div 
            style={sectionScaleStyle}
            className={`p-6 md:p-8 rounded-3xl border-2 shadow-xl backdrop-blur-xl flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-200 ${
            theme.sectionalBoxBg
          } ${isRoseVelvet ? 'border-[#ec4899]/30 shadow-pink-950/40' : theme.isLight ? 'border-blue-300/80 shadow-blue-900/10' : 'border-blue-500/30 shadow-black/50'}`}>
            {/* Main Section Heading Box Header */}
            <div className={`flex flex-wrap items-center justify-between gap-3 border-b pb-4 ${
              isRoseVelvet ? 'border-[#ec4899]/20' : 'border-cyan-500/20'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                  isRoseVelvet ? 'bg-[#ec4899]/10 border border-[#ec4899]/30 text-pink-400' : 'bg-cyan-500/10 border border-cyan-500/30 text-cyan-400'
                }`}>
                  <Sliders className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                    <span className={isRoseVelvet ? 'text-[#fbcfe8]' : 'text-cyan-400'}>🔵 SECTION 2:</span> 🛠️ Core PDF Production Facilities (18 Facilities)
                  </h3>
                  <p className={`text-xs font-medium ${isRoseVelvet ? 'text-[#fbcfe8]/80' : 'text-slate-200'}`}>
                    Comprehensive suite for editing, compressing, binding, encrypting, redacting, signing, and converting PDFs
                  </p>
                </div>
              </div>
              <span className={`text-[10px] font-mono font-bold px-3 py-1 rounded-full uppercase tracking-widest border ${
                isRoseVelvet ? 'bg-[#ec4899]/10 text-pink-300 border-[#ec4899]/30' : 'bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30'
              }`}>
                18 CORE UTILITIES UNLOCKED
              </span>
            </div>

            {/* Subheading Boxes inside Section 2 */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5">
              
              {/* SUBHEADING 2.1: 🗜️ Compression & File Size */}
              <div className={`p-4 rounded-2xl border flex flex-col gap-3 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-blue-100/70 via-sky-50/80 to-indigo-50/90 border-blue-300/80', 'bg-[#181d30]/90 border-slate-800 shadow-inner')
              }`}>
                <div className={`flex items-center justify-between border-b pb-2 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-slate-200 dark:border-slate-800'}`}>
                  <div className="flex items-center gap-1.5">
                    <Sliders className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-blue-600 dark:text-blue-400'}`} />
                    <h4 className="text-xs font-extrabold text-white dark:text-white">
                      2.1 🗜️ Size Reduction
                    </h4>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-blue-500/20 text-blue-600 dark:text-blue-400'}`}>
                    1 TOOL
                  </span>
                </div>

                <div className="flex flex-col gap-2.5">
                  {[
                    { id: 'compress', title: '🗜️ Compress PDF', sub: 'Target KB slider & image DPI resampler', tag: 'SIZE REDUCTION', icon: Sliders, color: 'text-blue-600' }
                  ].map((tool) => {
                    if (!matchesSearch(tool.title + ' ' + tool.sub, [tool.tag])) return null;
                    const IconComponent = tool.icon;
                    return (
                      <div
                        key={tool.id}
                        onClick={() => handleToolClick(tool.id)}
                        className={`group p-3 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-md ${
                          getInnerCardClass(tool.id, 'border-blue-500', 'bg-blue-500/10', 'border-slate-200', 'hover:border-blue-500', 'bg-[#121524]')
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${getToolBadgeStyle('bg-blue-500/15 text-blue-600')}`}>
                            {tool.tag}
                          </span>
                          <ArrowRight className={`w-3 h-3 group-hover:translate-x-0.5 transition-transform ${getToolArrowStyle('text-blue-500')}`} />
                        </div>
                        <h5 className={`text-[11px] font-extrabold transition-colors flex items-center gap-1 ${getToolTitleStyle('group-hover:text-blue-600')}`}>
                          <IconComponent className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-pink-300' : tool.color}`} />
                          <span>{tool.title}</span>
                        </h5>
                        <p className={`text-[10px] mt-1 leading-tight ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                          {tool.sub}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* SUBHEADING 2.2: 🔀 Merging, Split & Layout */}
              <div className={`p-4 rounded-2xl border flex flex-col gap-3 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-indigo-100/70 via-purple-50/80 to-blue-50/90 border-indigo-300/80', 'bg-[#18192e]/80 border-indigo-500/20')
              }`}>
                <div className={`flex items-center justify-between border-b pb-2 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-indigo-500/20'}`}>
                  <div className="flex items-center gap-1.5">
                    <Layers className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-indigo-600 dark:text-indigo-400'}`} />
                    <h4 className="text-xs font-extrabold text-white dark:text-white">
                      2.2 🔀 Merging &amp; Layout
                    </h4>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-indigo-500/20 text-indigo-600 dark:text-indigo-400'}`}>
                    4 TOOLS
                  </span>
                </div>

                <div className="flex flex-col gap-2.5">
                  {[
                    { id: 'merge-console', title: '🔀 Merge Documents', sub: 'Multi-file vector stitcher & binder', tag: 'STITCHER', icon: Layers, color: 'text-indigo-600' },
                    { id: 'reorder', title: '✂️ Split & Re-order', sub: 'Visual page range cutter & reorder', tag: 'REORDER', icon: Scissors, color: 'text-purple-600' },
                    { id: 'crop-margins', title: '✂️ Crop Margins', sub: 'Page boundary & print bleed cropper', tag: 'CROPPING', icon: Crop, color: 'text-sky-600' },
                    { id: 'toc', title: '📑 Table of Contents', sub: 'Bookmark & outline generator', tag: 'OUTLINE', icon: FileText, color: 'text-blue-500' },
                  ].map((tool) => {
                    if (!matchesSearch(tool.title + ' ' + tool.sub, [tool.tag])) return null;
                    const IconComponent = tool.icon;
                    return (
                      <div
                        key={tool.id}
                        onClick={() => handleToolClick(tool.id)}
                        className={`group p-3 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-md ${
                          getInnerCardClass(tool.id, 'border-indigo-500', 'bg-indigo-500/10', 'border-slate-200', 'hover:border-indigo-500', 'bg-[#121524]')
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${getToolBadgeStyle('bg-indigo-500/15 text-indigo-600')}`}>
                            {tool.tag}
                          </span>
                          <ArrowRight className={`w-3 h-3 group-hover:translate-x-0.5 transition-transform ${getToolArrowStyle('text-indigo-500')}`} />
                        </div>
                        <h5 className={`text-[11px] font-extrabold transition-colors flex items-center gap-1 ${getToolTitleStyle('group-hover:text-indigo-600')}`}>
                          <IconComponent className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-pink-300' : tool.color}`} />
                          <span>{tool.title}</span>
                        </h5>
                        <p className={`text-[10px] mt-1 leading-tight ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                          {tool.sub}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* SUBHEADING 2.3: 🔒 Security & Privacy */}
              <div className={`p-4 rounded-2xl border flex flex-col gap-3 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-rose-100/70 via-pink-50/80 to-red-50/90 border-rose-300/80', 'bg-[#22161b]/80 border-rose-500/20')
              }`}>
                <div className={`flex items-center justify-between border-b pb-2 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-rose-500/20'}`}>
                  <div className="flex items-center gap-1.5">
                    <Lock className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-rose-600 dark:text-rose-400'}`} />
                    <h4 className="text-xs font-extrabold text-white dark:text-white">
                      2.3 🔒 Security &amp; Privacy
                    </h4>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-rose-500/20 text-rose-600 dark:text-rose-400'}`}>
                    4 TOOLS
                  </span>
                </div>

                <div className="flex flex-col gap-2.5">
                  {[
                    { id: 'protect', title: '🔒 Protect & Encrypt', sub: 'AES-256 password & permissions', tag: 'SECURITY', icon: Lock, color: 'text-rose-600' },
                    { id: 'unlock', title: '🔓 Unlock PDF', sub: 'Remove owner passwords & lock flags', tag: 'DECRYPT', icon: Unlock, color: 'text-amber-600' },
                    { id: 'sanitize-purge', title: '🧼 Sanitize & Purge', sub: 'Wipe metadata, attachments & annotations', tag: 'PRIVACY', icon: ShieldAlert, color: 'text-red-600' },
                    { id: 'smart-redact', title: '🎭 Smart Redactor', sub: 'Automated SSN, Email & PII blackout', tag: 'REDACTION', icon: ShieldCheck, color: 'text-rose-600' },
                  ].map((tool) => {
                    if (!matchesSearch(tool.title + ' ' + tool.sub, [tool.tag])) return null;
                    const IconComponent = tool.icon;
                    return (
                      <div
                        key={tool.id}
                        onClick={() => handleToolClick(tool.id)}
                        className={`group p-3 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-md ${
                          getInnerCardClass(tool.id, 'border-rose-500', 'bg-rose-500/10', 'border-slate-200', 'hover:border-rose-500', 'bg-[#121524]')
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${getToolBadgeStyle('bg-rose-500/15 text-rose-600')}`}>
                            {tool.tag}
                          </span>
                          <ArrowRight className={`w-3 h-3 group-hover:translate-x-0.5 transition-transform ${getToolArrowStyle('text-rose-500')}`} />
                        </div>
                        <h5 className={`text-[11px] font-extrabold transition-colors flex items-center gap-1 ${getToolTitleStyle('group-hover:text-rose-600')}`}>
                          <IconComponent className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-pink-300' : tool.color}`} />
                          <span>{tool.title}</span>
                        </h5>
                        <p className={`text-[10px] mt-1 leading-tight ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                          {tool.sub}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* SUBHEADING 2.4: ✍️ Signatures, Forms & Stamp */}
              <div className={`p-4 rounded-2xl border flex flex-col gap-3 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-fuchsia-100/70 via-purple-50/80 to-pink-50/90 border-fuchsia-300/80', 'bg-[#221529]/80 border-fuchsia-500/20')
              }`}>
                <div className={`flex items-center justify-between border-b pb-2 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-fuchsia-500/20'}`}>
                  <div className="flex items-center gap-1.5">
                    <FileSignature className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-fuchsia-600 dark:text-fuchsia-400'}`} />
                    <h4 className="text-xs font-extrabold text-white dark:text-white">
                      2.4 ✍️ Sign, Forms &amp; Stamps
                    </h4>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-fuchsia-500/20 text-fuchsia-600 dark:text-fuchsia-400'}`}>
                    4 TOOLS
                  </span>
                </div>

                <div className="flex flex-col gap-2.5">
                  {[
                    { id: 'digital-signer', title: '✍️ Digital Signer', sub: 'PKI X.509 signature verification', tag: 'SIGNATURE', icon: FileSignature, color: 'text-violet-600' },
                    { id: 'create-form', title: '📝 Form Builder', sub: 'AcroForm text fields & checkboxes', tag: 'FORMS', icon: FormInput, color: 'text-pink-600' },
                    { id: 'bates-stamping', title: '🔢 Page & Bates Numbers', sub: 'Legal stamping & page numbering', tag: 'NUMBERING', icon: Hash, color: 'text-fuchsia-600' },
                    { id: 'watermark-engine', title: '🏷️ Watermark Engine', sub: 'Text, logo & angle overlays', tag: 'WATERMARK', icon: Tag, color: 'text-teal-600' },
                  ].map((tool) => {
                    if (!matchesSearch(tool.title + ' ' + tool.sub, [tool.tag])) return null;
                    const IconComponent = tool.icon;
                    return (
                      <div
                        key={tool.id}
                        onClick={() => handleToolClick(tool.id)}
                        className={`group p-3 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-md ${
                          getInnerCardClass(tool.id, 'border-fuchsia-500', 'bg-fuchsia-500/10', 'border-slate-200', 'hover:border-fuchsia-500', 'bg-[#121524]')
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${getToolBadgeStyle('bg-fuchsia-500/15 text-fuchsia-600')}`}>
                            {tool.tag}
                          </span>
                          <ArrowRight className={`w-3 h-3 group-hover:translate-x-0.5 transition-transform ${getToolArrowStyle('text-fuchsia-500')}`} />
                        </div>
                        <h5 className={`text-[11px] font-extrabold transition-colors flex items-center gap-1 ${getToolTitleStyle('group-hover:text-fuchsia-600')}`}>
                          <IconComponent className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-pink-300' : tool.color}`} />
                          <span>{tool.title}</span>
                        </h5>
                        <p className={`text-[10px] mt-1 leading-tight ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                          {tool.sub}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* SUBHEADING 2.5: 🖼️ Conversions & Extraction */}
              <div className={`p-4 rounded-2xl border flex flex-col gap-3 shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-emerald-100/70 via-teal-50/80 to-cyan-50/90 border-emerald-300/80', 'bg-[#14221f]/80 border-emerald-500/20')
              }`}>
                <div className={`flex items-center justify-between border-b pb-2 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-emerald-500/20'}`}>
                  <div className="flex items-center gap-1.5">
                    <Scan className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-emerald-600 dark:text-emerald-400'}`} />
                    <h4 className="text-xs font-extrabold text-white dark:text-white">
                      2.5 🖼️ Convert &amp; Extract
                    </h4>
                  </div>
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'}`}>
                    5 TOOLS
                  </span>
                </div>

                <div className="flex flex-col gap-2.5">
                  {[
                    { id: 'image-converter', title: '🖼️ Image Converter', sub: 'PDF to PNG/JPG & Image to PDF', tag: 'CONVERT', icon: ImageIcon, color: 'text-cyan-600' },
                    { id: 'asset-extractor', title: '📷 Asset Extractor', sub: 'Embedded high-res image & font ripper', tag: 'EXTRACTION', icon: ImageIcon, color: 'text-yellow-600' },
                    { id: 'ocr-scanner', title: '🔍 Neural OCR Engine', sub: 'Scanned document text layer', tag: 'OCR TEXT', icon: Scan, color: 'text-emerald-600' },
                    { id: 'doc-vault', title: '📜 Vault & Audit', sub: 'Immutable audit log & security', tag: 'AUDIT VAULT', icon: HardDrive, color: 'text-indigo-500' },
                  ].map((tool) => {
                    if (!matchesSearch(tool.title + ' ' + tool.sub, [tool.tag])) return null;
                    const IconComponent = tool.icon;
                    return (
                      <div
                        key={tool.id}
                        onClick={() => handleToolClick(tool.id)}
                        className={`group p-3 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-md ${
                          getInnerCardClass(tool.id, 'border-emerald-500', 'bg-emerald-500/10', 'border-slate-200', 'hover:border-emerald-500', 'bg-[#121524]')
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${getToolBadgeStyle('bg-emerald-500/15 text-emerald-600')}`}>
                            {tool.tag}
                          </span>
                          <ArrowRight className={`w-3 h-3 group-hover:translate-x-0.5 transition-transform ${getToolArrowStyle('text-emerald-500')}`} />
                        </div>
                        <h5 className={`text-[11px] font-extrabold transition-colors flex items-center gap-1 ${getToolTitleStyle('group-hover:text-emerald-600')}`}>
                          <IconComponent className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-pink-300' : tool.color}`} />
                          <span>{tool.title}</span>
                        </h5>
                        <p className={`text-[10px] mt-1 leading-tight ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                          {tool.sub}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ================= 🟡 SECTION 4: 📂 STORAGE VAULT & INTERACTIVE ENGAGEMENT TOOLS ================= */}
        {isSection4Visible && (activePageSection === 'all' || activePageSection === 'section4') && (selectedFilterCategory === 'all' || selectedFilterCategory === 'vault') && (
          <div 
            style={sectionScaleStyle}
            className={`p-6 md:p-8 rounded-3xl border-2 shadow-xl backdrop-blur-xl flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-200 ${
            theme.sectionalBoxBg
          } ${isRoseVelvet ? 'border-[#ec4899]/30 shadow-pink-950/40' : theme.isLight ? 'border-amber-300/80 shadow-amber-900/10' : 'border-amber-500/30 shadow-black/50'}`}>
            {/* Main Section Heading Box Header */}
            <div className={`flex flex-wrap items-center justify-between gap-3 border-b pb-4 ${
              isRoseVelvet ? 'border-[#ec4899]/20' : 'border-amber-500/20'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                  isRoseVelvet ? 'bg-[#ec4899]/10 border border-[#ec4899]/30 text-pink-400' : 'bg-amber-500/10 border border-amber-500/30 text-amber-400'
                }`}>
                  <FolderArchive className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                    <span className={isRoseVelvet ? 'text-[#fbcfe8]' : 'text-amber-400'}>🟡 SECTION 4:</span> 📂 Storage Vault &amp; Interactive Canvas Tools
                  </h3>
                  <p className={`text-xs font-medium ${isRoseVelvet ? 'text-[#fbcfe8]/80' : 'text-slate-200'}`}>
                    Local IndexedDB persistent vault storage, AcroForm E-Sign builder, and drag-and-drop page canvas
                  </p>
                </div>
              </div>
              <span className={`text-[10px] font-mono font-bold px-3 py-1 rounded-full uppercase tracking-widest border ${
                isRoseVelvet ? 'bg-[#ec4899]/10 text-pink-300 border-[#ec4899]/30' : 'bg-amber-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
              }`}>
                PERSISTENT VAULT READY
              </span>
            </div>

            {/* Subheading Boxes inside Section 4 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* SUBHEADING 4.1: 📂 Personal Document Vault */}
              <div className={`p-5 rounded-2xl border flex flex-col justify-between shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-amber-100/70 via-orange-50/80 to-yellow-50/90 border-amber-300/80', 'bg-[#1e1a14]/80 border-amber-500/20')
              }`}>
                <div>
                  <div className={`flex items-center justify-between border-b pb-2 mb-3 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-amber-500/20'}`}>
                    <div className="flex items-center gap-2">
                      <FolderArchive className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-amber-600 dark:text-amber-400'}`} />
                      <h4 className="text-xs font-extrabold text-white dark:text-white">
                        4.1 📂 Personal Local Vault
                      </h4>
                    </div>
                    <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-amber-500/20 text-amber-600 dark:text-amber-400'}`}>
                      INDEXEDDB
                    </span>
                  </div>
                  <p className={`text-xs mb-4 leading-relaxed ${isRoseVelvet ? 'text-pink-200/70' : 'text-slate-600 dark:text-slate-400'}`}>
                    IndexedDB persistent local saving, revision snapshots, PIN security, and offline cache.
                  </p>

                  <div
                    onClick={() => handleToolClick('doc-vault')}
                    className={`group p-4 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-lg ${
                      getInnerCardClass('doc-vault', 'border-amber-500', 'bg-amber-500/10', 'border-amber-200', 'hover:border-amber-500', 'bg-[#121524]')
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-2">
                        <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${getToolBadgeStyle('bg-amber-500/15 text-amber-600')}`}>
                          LOCAL VAULT
                        </span>
                        <ArrowRight className={`w-3.5 h-3.5 group-hover:translate-x-1 transition-transform ${getToolArrowStyle('text-amber-500')}`} />
                      </div>
                      <h5 className={`text-xs font-extrabold transition-colors ${getToolTitleStyle('group-hover:text-amber-600')}`}>
                        📂 Personal Vault Storage
                      </h5>
                      <p className={`text-[10px] mt-1 leading-snug ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                        Local encrypted database for saved documents &amp; revision history.
                      </p>
                    </div>
                    <span className={`text-[10px] font-bold mt-3 pt-2 ${getToolFooterStyle('text-amber-600 dark:text-amber-400')}`}>
                      Open Document Vault →
                    </span>
                  </div>
                </div>
              </div>

              {/* SUBHEADING 4.2: 🖊️ E-Sign & Interactive Form Studio */}
              <div className={`p-5 rounded-2xl border flex flex-col justify-between shadow-sm ${
                getSubheadingBoxClass('bg-gradient-to-br from-purple-100/70 via-fuchsia-50/80 to-indigo-50/90 border-purple-300/80', 'bg-[#1b1424]/80 border-purple-500/20')
              }`}>
                <div>
                  <div className={`flex items-center justify-between border-b pb-2 mb-3 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-purple-500/20'}`}>
                    <div className="flex items-center gap-2">
                      <FileSignature className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-purple-600 dark:text-purple-400'}`} />
                      <h4 className="text-xs font-extrabold text-white dark:text-white">
                        4.2 🖊️ E-Sign &amp; Form Studio
                      </h4>
                    </div>
                    <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-purple-500/20 text-purple-600 dark:text-purple-400'}`}>
                      ACROFORM
                    </span>
                  </div>
                  <p className={`text-xs mb-4 leading-relaxed ${isRoseVelvet ? 'text-pink-200/70' : 'text-slate-600 dark:text-slate-400'}`}>
                    Biometric signature pad, interactive text inputs, checkboxes, radio buttons, and overlay fields.
                  </p>

                  <div
                    onClick={() => handleToolClick('create-form')}
                    className={`group p-4 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-lg ${
                      getInnerCardClass('create-form', 'border-purple-500', 'bg-purple-500/10', 'border-purple-200', 'hover:border-purple-500', 'bg-[#121524]')
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-2">
                        <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${getToolBadgeStyle('bg-purple-500/15 text-purple-600')}`}>
                          FORM &amp; SIGN
                        </span>
                        <ArrowRight className={`w-3.5 h-3.5 group-hover:translate-x-1 transition-transform ${getToolArrowStyle('text-purple-500')}`} />
                      </div>
                      <h5 className={`text-xs font-extrabold transition-colors ${getToolTitleStyle('group-hover:text-purple-600')}`}>
                        🖊️ Form Builder &amp; E-Sign
                      </h5>
                      <p className={`text-[10px] mt-1 leading-snug ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                        Design interactive form fields &amp; place biometric signatures.
                      </p>
                    </div>
                    <span className={`text-[10px] font-bold mt-3 pt-2 ${getToolFooterStyle('text-purple-600 dark:text-purple-400')}`}>
                      Launch Form Studio →
                    </span>
                  </div>
                </div>
              </div>

              {/* SUBHEADING 4.3: 🗂️ Drag-and-Drop Page Canvas */}
              <div className={`p-5 rounded-2xl border flex flex-col justify-between ${
                getSubheadingBoxClass('bg-slate-50/90 border-slate-200 shadow-sm', 'bg-[#181d30]/90 border-slate-800 shadow-inner')
              }`}>
                <div>
                  <div className={`flex items-center justify-between border-b pb-2 mb-3 ${isRoseVelvet ? 'border-[#ec4899]/20' : 'border-slate-200 dark:border-slate-800'}`}>
                    <div className="flex items-center gap-2">
                      <LayoutGrid className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-400' : 'text-blue-600 dark:text-blue-400'}`} />
                      <h4 className="text-xs font-extrabold text-white dark:text-white">
                        4.3 🗂️ Page Grid Canvas
                      </h4>
                    </div>
                    <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${isRoseVelvet ? 'bg-pink-500/20 text-pink-300' : 'bg-blue-500/20 text-blue-600 dark:text-blue-400'}`}>
                      GRID EDITOR
                    </span>
                  </div>
                  <p className={`text-xs mb-4 leading-relaxed ${isRoseVelvet ? 'text-pink-200/70' : 'text-slate-600 dark:text-slate-400'}`}>
                    Interactive page reordering grid, visual thumbnail drag-and-drop, page rotation &amp; deletion.
                  </p>

                  <div
                    onClick={() => handleToolClick('reorder')}
                    className={`group p-4 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-lg ${
                      getInnerCardClass('reorder', 'border-blue-500', 'bg-blue-500/10', 'border-blue-200', 'hover:border-blue-500', 'bg-[#121524]')
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-2">
                        <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${getToolBadgeStyle('bg-blue-500/15 text-blue-600')}`}>
                          PAGE CANVAS
                        </span>
                        <ArrowRight className={`w-3.5 h-3.5 group-hover:translate-x-1 transition-transform ${getToolArrowStyle('text-blue-500')}`} />
                      </div>
                      <h5 className={`text-xs font-extrabold transition-colors ${getToolTitleStyle('group-hover:text-blue-600')}`}>
                        🗂️ Visual Drag-and-Drop Canvas
                      </h5>
                      <p className={`text-[10px] mt-1 leading-snug ${isRoseVelvet ? 'text-pink-200/60' : 'text-slate-500 dark:text-slate-400'}`}>
                        Rearrange pages, rotate orientation &amp; split range selections.
                      </p>
                    </div>
                    <span className={`text-[10px] font-bold mt-3 pt-2 ${getToolFooterStyle('text-blue-600 dark:text-blue-400')}`}>
                      Open Page Grid Canvas →
                    </span>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Global Persistence Banner */}
        <div className={`p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-4 text-xs ${
          theme.isLight ? 'bg-blue-50/80 border-blue-200 text-slate-800' : 'bg-[#121524] border-slate-800 text-slate-300'
        }`}>
          <div className="flex items-center gap-3">
            <Zap className="w-5 h-5 text-amber-500 animate-pulse shrink-0" />
            <div>
              <p className="font-extrabold text-slate-900 dark:text-white">
                Global State Preserved Across All Directory Operations
              </p>
              <p className="text-slate-500 dark:text-slate-400">
                Active PDF document bytes and page memory remain loaded at all times. Selecting any tool instantly focuses the active editor workspace below.
              </p>
            </div>
          </div>
          <span className="font-mono text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-3 py-1 rounded-lg border border-emerald-300 dark:border-emerald-800">
            MEMORY STATE: READY
          </span>
        </div>
      </main>
    </div>
  );
};
