import React, { useState, useRef, useEffect } from 'react';
import { getAdminConfig, subscribeAdminConfig } from '../data/adminStore';

interface GlowLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'responsive';
  className?: string;
}

export const GlowLogo: React.FC<GlowLogoProps> = ({ size = 'md', className = '' }) => {
  const [adminConfig, setAdminConfig] = useState(() => getAdminConfig());

  useEffect(() => {
    const unsubscribe = subscribeAdminConfig((updated) => {
      setAdminConfig(updated);
    });
    return () => unsubscribe();
  }, []);

  const logoText = adminConfig?.uiTextOverrides?.brandingInsideLogoText || 'GLOW';
  const containerRef = useRef<HTMLDivElement>(null);
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const [modeIndex, setModeIndex] = useState(0); 
  // 0: Base GLOW + Grip Hands
  // 1: Cyber Point + Tech Gestures
  // 2: Cyber Fist + Power Grip
  // 3: Nearly-Death Ultra-Angry Face + Full Black Goggles + Laser Eyes & Rage Claws
  // 4: Cyber Matrix Glitch Face + Matrix Goggles & Cipher Hands
  // 5: Supernova Core Overload + Energy Shield Hands

  const idleTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Reset to 1st state (index 0) if user is idle for 10 seconds (no cursor interaction / activity)
  const resetIdleTimer = () => {
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    idleTimerRef.current = setTimeout(() => {
      setModeIndex(0);
    }, 10000); // 10 seconds
  };

  useEffect(() => {
    resetIdleTimer();
    return () => {
      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    };
  }, [modeIndex]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    resetIdleTimer();
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const xVal = (e.clientX - centerX) / (rect.width / 2);
    const yVal = (e.clientY - centerY) / (rect.height / 2);

    setRotation({
      x: -yVal * 180,
      y: xVal * 180,
    });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotation({ x: 0, y: 0 });
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    resetIdleTimer();
    // Cycle through 6 unique states (0 to 5) on every double click
    setModeIndex(prev => (prev + 1) % 6);
    // Dramatic 360 degree 3D spin on double click
    setRotation(prev => ({ x: prev.x + 360, y: prev.y + 360 }));
  };

  const handleClick = () => {
    resetIdleTimer();
  };

  const dimensions = {
    xs: 'w-8 h-8',
    sm: 'w-10 h-10',
    md: 'w-14 h-14',
    lg: 'w-20 h-20',
    xl: 'w-28 h-28',
    responsive: 'w-14 h-14 sm:w-18 sm:h-18 md:w-22 md:h-22 lg:w-24 lg:h-24',
  }[size];

  const textSize = {
    xs: 'text-[8px]',
    sm: 'text-[9px]',
    md: 'text-[11px]',
    lg: 'text-sm',
    xl: 'text-lg',
    responsive: 'text-xs sm:text-sm',
  }[size];

  const scrollRotation = (scrollY * 0.75) % 360;
  const isAngry = modeIndex === 3;
  const isMatrix = modeIndex === 4;
  const isSupernova = modeIndex === 5;

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      onClick={handleClick}
      onDoubleClick={handleDoubleClick}
      title="Double-click to cycle unique 3D states! (Resets to base after 10s idle)"
      style={{
        perspective: '1400px',
      }}
      className={`relative flex items-center justify-center shrink-0 group select-none cursor-pointer py-2 mx-3 px-2 ${className}`}
    >
      {/* Outer hyper-vibrant glowing aura matching active state */}
      <div className={`absolute -inset-2 ${dimensions} rounded-full ${
        isAngry ? 'bg-gradient-to-r from-red-600 via-rose-500 to-amber-600 animate-bounce' :
        isMatrix ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-green-600 animate-pulse' :
        isSupernova ? 'bg-gradient-to-r from-amber-400 via-yellow-300 to-orange-500 animate-pulse' :
        modeIndex > 0 ? 'bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 animate-pulse' :
        'bg-gradient-to-r from-cyan-400 via-fuchsia-500 to-blue-500 animate-pulse'
      } blur-xl opacity-90 group-hover:opacity-100 transition-all duration-500`} />

      <div className={`absolute inset-0 ${dimensions} rounded-full ${
        isAngry ? 'bg-gradient-to-tr from-red-500 via-amber-600 to-black' :
        isMatrix ? 'bg-gradient-to-tr from-emerald-500 via-teal-900 to-black' :
        isSupernova ? 'bg-gradient-to-tr from-yellow-400 via-orange-600 to-red-900' :
        'bg-gradient-to-tr from-cyan-300 via-purple-500 to-pink-500'
      } blur-md opacity-70 group-hover:opacity-95 animate-ping`} style={{ animationDuration: '2.5s' }} />

      {/* LEFT CYBERNETIC HAND WITH DYNAMIC GESTURES */}
      <div 
        style={{
          transform: isHovered ? 'translateX(-8px) rotate(-14deg)' : 'translateX(0px) rotate(0deg)',
          transition: 'transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
        className="absolute -left-3.5 z-20 flex flex-col items-center pointer-events-none drop-shadow-[0_0_10px_rgba(34,211,238,0.7)]"
      >
        <div className="w-3.5 h-4 bg-gradient-to-r from-slate-900 to-slate-800 border border-cyan-400/60 rounded-l-md flex items-center justify-center">
          <div className="w-0.5 h-2.5 bg-cyan-400/80 rounded-full animate-pulse" />
        </div>
        <div className={`flex flex-col gap-0.5 mt-[-2px] ${isAngry ? 'text-red-500' : isMatrix ? 'text-emerald-400' : isSupernova ? 'text-amber-400' : 'text-cyan-400'}`}>
          {modeIndex === 0 && (
            // Grip
            <>
              <div className="w-3 h-1 bg-gradient-to-r from-cyan-400 to-blue-600 rounded-full -rotate-45 shadow-[0_0_4px_currentColor]" />
              <div className="w-3.5 h-1 bg-gradient-to-r from-cyan-400 to-blue-600 rounded-full -rotate-12 shadow-[0_0_4px_currentColor]" />
              <div className="w-3 h-1 bg-gradient-to-r from-cyan-400 to-blue-600 rounded-full rotate-45 shadow-[0_0_4px_currentColor]" />
            </>
          )}
          {modeIndex === 1 && (
            // Pointing
            <>
              <div className="w-4 h-1 bg-cyan-300 rounded-full rotate-0 shadow-[0_0_6px_cyan]" />
              <div className="w-2 h-1 bg-slate-600 rounded-full rotate-45" />
              <div className="w-1.5 h-1 bg-slate-600 rounded-full rotate-90" />
            </>
          )}
          {modeIndex === 2 && (
            // Cyber Fist
            <>
              <div className="w-3 h-1.5 bg-gradient-to-r from-fuchsia-500 to-pink-600 rounded-md shadow-[0_0_5px_magenta]" />
              <div className="w-3 h-1.5 bg-gradient-to-r from-fuchsia-500 to-pink-600 rounded-md shadow-[0_0_5px_magenta]" />
            </>
          )}
          {modeIndex === 3 && (
            // Rage Claws
            <>
              <div className="w-3.5 h-1 bg-red-500 rounded-full -rotate-30 shadow-[0_0_8px_red]" />
              <div className="w-4 h-1 bg-orange-500 rounded-full rotate-0 shadow-[0_0_8px_orange]" />
              <div className="w-3.5 h-1 bg-red-500 rounded-full rotate-30 shadow-[0_0_8px_red]" />
            </>
          )}
          {modeIndex === 4 && (
            // Matrix Cipher Hand
            <>
              <div className="w-3.5 h-1 bg-emerald-400 rounded-full -rotate-15 shadow-[0_0_6px_emerald]" />
              <div className="w-3.5 h-1 bg-teal-300 rounded-full rotate-15 shadow-[0_0_6px_teal]" />
            </>
          )}
          {modeIndex === 5 && (
            // Supernova Energy Shield Hand
            <>
              <div className="w-4 h-1 bg-amber-400 rounded-full rotate-0 shadow-[0_0_8px_amber]" />
              <div className="w-3.5 h-1 bg-yellow-300 rounded-full rotate-45 shadow-[0_0_6px_yellow]" />
            </>
          )}
        </div>
      </div>

      {/* RIGHT CYBERNETIC HAND WITH DYNAMIC GESTURES */}
      <div 
        style={{
          transform: isHovered ? 'translateX(8px) rotate(14deg)' : 'translateX(0px) rotate(0deg)',
          transition: 'transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
        className="absolute -right-3.5 z-20 flex flex-col items-center pointer-events-none drop-shadow-[0_0_10px_rgba(217,70,239,0.7)]"
      >
        <div className="w-3.5 h-4 bg-gradient-to-l from-slate-900 to-slate-800 border border-fuchsia-400/60 rounded-r-md flex items-center justify-center">
          <div className="w-0.5 h-2.5 bg-fuchsia-400/80 rounded-full animate-pulse" />
        </div>
        <div className={`flex flex-col gap-0.5 mt-[-2px] ${isAngry ? 'text-red-500' : isMatrix ? 'text-emerald-400' : isSupernova ? 'text-amber-400' : 'text-fuchsia-400'}`}>
          {modeIndex === 0 && (
            // Grip
            <>
              <div className="w-3 h-1 bg-gradient-to-l from-fuchsia-400 to-pink-600 rounded-full rotate-45 shadow-[0_0_4px_currentColor]" />
              <div className="w-3.5 h-1 bg-gradient-to-l from-fuchsia-400 to-pink-600 rounded-full rotate-12 shadow-[0_0_4px_currentColor]" />
              <div className="w-3 h-1 bg-gradient-to-l from-fuchsia-400 to-pink-600 rounded-full -rotate-45 shadow-[0_0_4px_currentColor]" />
            </>
          )}
          {modeIndex === 1 && (
            // V-Sign
            <>
              <div className="w-3.5 h-1 bg-fuchsia-300 rounded-full -rotate-12 shadow-[0_0_6px_magenta]" />
              <div className="w-3.5 h-1 bg-fuchsia-300 rounded-full rotate-12 shadow-[0_0_6px_magenta]" />
              <div className="w-1.5 h-1 bg-slate-600 rounded-full rotate-90" />
            </>
          )}
          {modeIndex === 2 && (
            // Cyber Fist
            <>
              <div className="w-3 h-1.5 bg-gradient-to-l from-cyan-400 to-blue-600 rounded-md shadow-[0_0_5px_cyan]" />
              <div className="w-3 h-1.5 bg-gradient-to-l from-cyan-400 to-blue-600 rounded-md shadow-[0_0_5px_cyan]" />
            </>
          )}
          {modeIndex === 3 && (
            // Rage Claws
            <>
              <div className="w-3.5 h-1 bg-red-500 rounded-full rotate-30 shadow-[0_0_8px_red]" />
              <div className="w-4 h-1 bg-orange-500 rounded-full rotate-0 shadow-[0_0_8px_orange]" />
              <div className="w-3.5 h-1 bg-red-500 rounded-full -rotate-30 shadow-[0_0_8px_red]" />
            </>
          )}
          {modeIndex === 4 && (
            // Matrix Cipher Hand
            <>
              <div className="w-3.5 h-1 bg-emerald-400 rounded-full rotate-15 shadow-[0_0_6px_emerald]" />
              <div className="w-3.5 h-1 bg-teal-300 rounded-full -rotate-15 shadow-[0_0_6px_teal]" />
            </>
          )}
          {modeIndex === 5 && (
            // Supernova Shield Hand
            <>
              <div className="w-4 h-1 bg-amber-400 rounded-full rotate-0 shadow-[0_0_8px_amber]" />
              <div className="w-3.5 h-1 bg-yellow-300 rounded-full -rotate-45 shadow-[0_0_6px_yellow]" />
            </>
          )}
        </div>
      </div>

      {/* 3D Transform Circular Orb Wrapper */}
      <div
        style={{
          transform: isHovered
            ? `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) scale(1.12)`
            : `rotateX(${scrollRotation * 0.3}deg) rotateY(${scrollRotation}deg) scale(1)`,
          transformStyle: 'preserve-3d',
          transition: isHovered ? 'transform 0.1s ease-out' : 'transform 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
        className={`relative ${dimensions} rounded-full bg-gradient-to-br from-slate-950 via-slate-900 to-[#0c101d] border-2 ${
          isAngry ? 'border-red-500 shadow-[0_0_35px_rgba(239,68,68,0.9)]' :
          isMatrix ? 'border-emerald-400 shadow-[0_0_35px_rgba(16,185,129,0.9)]' :
          isSupernova ? 'border-amber-400 shadow-[0_0_40px_rgba(251,191,36,0.95)]' :
          'border-cyan-300/80 dark:border-fuchsia-400/80 shadow-[0_0_30px_rgba(34,211,238,0.7)]'
        } group-hover:shadow-[0_0_55px_rgba(217,70,239,0.95)] overflow-hidden transition-all duration-300 z-10`}
      >
        {/* Internal 3D Spherical Glossy Shine */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-cyan-400/35 via-transparent to-fuchsia-500/35 pointer-events-none" />
        <div className="absolute top-1 left-2 right-2 h-1/2 bg-gradient-to-b from-white/30 to-transparent rounded-t-full pointer-events-none" />
        <div className="absolute -top-4 -right-4 w-12 h-12 bg-cyan-300/50 rounded-full blur-md pointer-events-none" />
        <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-fuchsia-500/50 rounded-full blur-md pointer-events-none" />

        {/* Central Content Variants: GLOW text is now written in EVERY face state alongside the face/gesture! */}
        <div className="relative z-10 flex flex-col items-center justify-center w-full h-full gap-0.5" style={{ transform: 'translateZ(25px)' }}>
          {modeIndex === 3 ? (
            /* STATE 3: Angry Face + GLOW text */
            <div className="flex flex-col items-center justify-center gap-0.5 w-full px-0.5 animate-in zoom-in duration-200">
              <div className="flex justify-between w-3.5 px-0.5 -mb-0.5">
                <div className="w-1.5 h-0.5 bg-red-500 rotate-25 shadow-[0_0_4px_red]" />
                <div className="w-1.5 h-0.5 bg-red-500 -rotate-25 shadow-[0_0_4px_red]" />
              </div>
              <div className="flex items-center justify-center gap-0.5 bg-black border border-red-600 px-1 py-0.2 rounded shadow-[0_0_8px_red]">
                <div className="w-1.5 h-1 bg-red-500 rounded-full shadow-[0_0_4px_red]" />
                <div className="w-1.5 h-1 bg-red-500 rounded-full shadow-[0_0_4px_red]" />
              </div>
              <span className="font-black text-[8px] uppercase tracking-wider text-red-400 drop-shadow-[0_0_6px_red]">{logoText}</span>
            </div>
          ) : modeIndex === 4 ? (
            /* STATE 4: Matrix Face + GLOW text */
            <div className="flex flex-col items-center justify-center gap-0.5 w-full px-0.5 animate-in zoom-in duration-200">
              <div className="flex justify-between w-3.5 px-0.5 -mb-0.5">
                <div className="w-1.5 h-0.5 bg-emerald-400 rotate-12" />
                <div className="w-1.5 h-0.5 bg-emerald-400 -rotate-12" />
              </div>
              <div className="flex items-center justify-center gap-0.5 bg-emerald-950 border border-emerald-400 px-1 py-0.2 rounded shadow-[0_0_6px_emerald]">
                <div className="w-1.5 h-1 bg-emerald-400 rounded-sm" />
                <div className="w-1.5 h-1 bg-emerald-400 rounded-sm" />
              </div>
              <span className="font-black text-[8px] uppercase tracking-wider text-emerald-300 drop-shadow-[0_0_6px_emerald]">{logoText}</span>
            </div>
          ) : modeIndex === 5 ? (
            /* STATE 5: Supernova Face + GLOW text */
            <div className="flex flex-col items-center justify-center gap-0.5 w-full px-0.5 animate-in zoom-in duration-200">
              <div className="flex justify-between w-3.5 px-0.5 -mb-0.5">
                <div className="w-1.5 h-0.5 bg-amber-400 rotate-6" />
                <div className="w-1.5 h-0.5 bg-amber-400 -rotate-6" />
              </div>
              <div className="flex items-center justify-center gap-0.5 bg-amber-950 border border-yellow-400 px-1.5 py-0.2 rounded-full shadow-[0_0_8px_amber]">
                <div className="w-1 h-1 bg-yellow-300 rounded-full" />
                <div className="w-1 h-1 bg-yellow-300 rounded-full" />
              </div>
              <span className="font-black text-[8px] uppercase tracking-wider text-amber-300 drop-shadow-[0_0_6px_amber]">{logoText}</span>
            </div>
          ) : modeIndex === 1 ? (
            /* STATE 1: Pointing Gesture + GLOW text */
            <div className="flex flex-col items-center justify-center animate-in zoom-in duration-200">
              <span className="font-mono text-[8px] font-black uppercase text-cyan-300 tracking-wider">POINT</span>
              <span className="font-black text-[9px] uppercase tracking-widest text-white drop-shadow-[0_0_8px_cyan]">{logoText}</span>
            </div>
          ) : modeIndex === 2 ? (
            /* STATE 2: Cyber Fist + GLOW text */
            <div className="flex flex-col items-center justify-center animate-in zoom-in duration-200">
              <span className="font-mono text-[8px] font-black uppercase text-fuchsia-300 tracking-wider">FIST</span>
              <span className="font-black text-[9px] uppercase tracking-widest text-white drop-shadow-[0_0_8px_fuchsia]">{logoText}</span>
            </div>
          ) : (
            /* STATE 0: Standard Base GLOW Logo Text */
            <div className="flex flex-col items-center justify-center animate-in zoom-in duration-200">
              <span className={`font-black tracking-wider uppercase bg-gradient-to-r from-cyan-200 via-white to-fuchsia-200 bg-clip-text text-transparent drop-shadow-[0_0_12px_rgba(255,255,255,0.95)] ${textSize}`}>
                {logoText}
              </span>
              <div className="w-4 h-1 bg-gradient-to-r from-cyan-400 via-fuchsia-400 to-pink-500 rounded-full mt-0.5 shadow-[0_0_8px_rgba(217,70,239,1)] animate-pulse" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
