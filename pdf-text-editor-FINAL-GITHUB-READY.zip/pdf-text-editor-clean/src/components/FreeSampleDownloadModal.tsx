import React, { useState, useEffect } from 'react';
import { X, Download, ShieldCheck, Mail, User, Cpu, Phone, Building2, FileText, CheckCircle2, Sparkles } from 'lucide-react';
import { FreeSampleDownloadConfig } from '../data/adminStore';

interface FreeSampleDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: FreeSampleDownloadConfig;
}

export const FreeSampleDownloadModal: React.FC<FreeSampleDownloadModalProps> = ({
  isOpen,
  onClose,
  config,
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [macAddress, setMacAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [purpose, setPurpose] = useState('');
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // Auto-generate a realistic MAC Address if blank
  useEffect(() => {
    if (!macAddress) {
      const hex = '0123456789ABCDEF';
      let mac = '';
      for (let i = 0; i < 6; i++) {
        mac += hex.charAt(Math.floor(Math.random() * 16)) + hex.charAt(Math.floor(Math.random() * 16));
        if (i < 5) mac += ':';
      }
      setMacAddress(mac);
    }
  }, [macAddress]);

  if (!isOpen) return null;

  const handleDownload = (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);

    setTimeout(() => {
      setIsGenerating(false);
      setDownloadSuccess(true);

      // Create a blob and trigger browser download for the free sample PDF
      const sampleText = `%PDF-1.7
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>
endobj
4 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
5 0 obj
<< /Length 120 >>
stream
BT
/F1 18 Tf
50 700 Td
(GLOWPDF ENTERPRISE SAMPLE SPECIFICATION SHEET) Tj
/F1 12 Tf
0 -30 Td
(Downloaded by: ${fullName || 'Verified Enterprise User'}) Tj
0 -20 Td
(Email: ${email || 'user@glowpdf.com'}) Tj
0 -20 Td
(MAC Address / Hardware ID: ${macAddress}) Tj
0 -20 Td
(Company: ${companyName || 'L&T Infrastructure Group'}) Tj
ET
endstream
endobj
xref
0 6
0000000000 65535 f
0000000009 00000 n
0000000058 00000 n
0000000115 00000 n
0000000216 00000 n
0000000287 00000 n
trailer
<< /Size 6 /Root 1 0 R >>
startxref
450
%%EOF`;

      const blob = new Blob([sampleText], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = config.downloadFileName || 'GlowPDF_Enterprise_Free_Sample.pdf';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white rounded-3xl border-4 border-[#0e4475] shadow-2xl overflow-hidden p-6 sm:p-8 text-slate-900">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-full transition-all cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4 border-b border-slate-200 pb-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 border border-amber-300 text-amber-800 flex items-center justify-center shrink-0 shadow-xs">
            <Sparkles className="w-6 h-6 text-amber-700" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-black text-[#0e4475] tracking-tight">
              {config.modalTitle || 'Download Free Sample Pack'}
            </h2>
            <p className="text-xs text-slate-600 font-medium mt-0.5">
              {config.modalSubtitle || 'Fill out the form below for instant sample download.'}
            </p>
          </div>
        </div>

        {downloadSuccess ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto border-2 border-emerald-300 shadow-sm animate-bounce">
              <CheckCircle2 className="w-9 h-9" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900">
                {config.successMessage || 'Download Started Successfully!'}
              </h3>
              <p className="text-xs text-slate-600 mt-1 max-w-sm mx-auto">
                Your sample PDF file has been generated with embedded MAC fingerprint hardware signature ({macAddress}).
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setDownloadSuccess(false);
                onClose();
              }}
              className="px-6 py-2.5 bg-[#0e4475] hover:bg-[#001f70] text-white font-bold text-xs rounded-full shadow-md transition-all cursor-pointer"
            >
              Close Window
            </button>
          </div>
        ) : (
          <form onSubmit={handleDownload} className="space-y-3.5">
            {/* Full Name */}
            {config.requireName && (
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-blue-700" />
                  <span>Full Name</span>
                  <span className="text-rose-500">*</span>
                </label>
                <input
                  required
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Dr. Alexander Vance"
                  className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 font-medium"
                />
              </div>
            )}

            {/* Email / Mail */}
            {config.requireEmail && (
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-blue-700" />
                  <span>Email / Mail Address</span>
                  <span className="text-rose-500">*</span>
                </label>
                <input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. alexander@enterprise.com"
                  className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 font-medium"
                />
              </div>
            )}

            {/* MAC Address / Device ID */}
            {config.requireMacAddress && (
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Cpu className="w-3.5 h-3.5 text-amber-700" />
                    <span>MAC Address / Device Hardware ID</span>
                    <span className="text-rose-500">*</span>
                  </span>
                  <span className="text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded font-mono font-bold border border-amber-200">
                    AUTO-DETECTED
                  </span>
                </label>
                <input
                  required
                  type="text"
                  value={macAddress}
                  onChange={(e) => setMacAddress(e.target.value)}
                  placeholder="e.g. 00:1B:44:11:3A:B7"
                  className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 bg-amber-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-600"
                />
              </div>
            )}

            {/* Phone Number */}
            {config.requirePhone && (
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-blue-700" />
                  <span>Phone Number</span>
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. +1 (555) 019-2831"
                  className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 font-medium"
                />
              </div>
            )}

            {/* Company Name */}
            {config.requireCompanyName && (
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-blue-700" />
                  <span>Company / Organization Name</span>
                </label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g. L&T Heavy Civil Engineering"
                  className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 font-medium"
                />
              </div>
            )}

            {/* Purpose */}
            {config.requirePurpose && (
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-blue-700" />
                  <span>Purpose of Request</span>
                </label>
                <input
                  type="text"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="e.g. Testing PDF vector compression & ZKD verification"
                  className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 font-medium"
                />
              </div>
            )}

            <div className="pt-3">
              <button
                type="submit"
                disabled={isGenerating}
                className="w-full py-3 bg-[#0e4475] hover:bg-[#001f70] text-white font-black text-xs rounded-xl shadow-lg hover:shadow-xl transition-all cursor-pointer active:scale-95 flex items-center justify-center gap-2"
              >
                {isGenerating ? (
                  <span>Generating Sample PDF...</span>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>{config.buttonLabel || 'Download Free Sample Pack'}</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-500 font-bold mt-2">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>100% Free Sample. Encrypted device hardware signature. No credit card needed.</span>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
