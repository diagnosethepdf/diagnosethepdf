import React, { useEffect, useRef, useState } from 'react';

interface DragPlacementWidgetProps {
  pdfBytes: ArrayBuffer | null;
  pageNumber: number;
  percentX: number;
  percentY: number;
  onChange: (px: number, py: number) => void;
  signerName: string;
}

export const DragPlacementWidget: React.FC<DragPlacementWidgetProps> = ({
  pdfBytes,
  pageNumber,
  percentX,
  percentY,
  onChange,
  signerName,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [pdfWidth, setPdfWidth] = useState<number>(612);
  const [pdfHeight, setPdfHeight] = useState<number>(792);
  const [containerWidth, setContainerWidth] = useState<number>(320);
  const [containerHeight, setContainerHeight] = useState<number>(410);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [, setLoading] = useState<boolean>(false);

  // Load and render PDF page
  useEffect(() => {
    let active = true;
    const renderPage = async () => {
      if (!pdfBytes) {
        // Fallback placeholder defaults to US Letter size ratio
        setPdfWidth(612);
        setPdfHeight(792);
        setContainerWidth(320);
        setContainerHeight(410);
        return;
      }
      
      const { pdfjsLib } = window as any;
      if (!pdfjsLib) return;

      try {
        setLoading(true);
        const doc = await pdfjsLib.getDocument({ data: pdfBytes.slice(0) }).promise;
        const totalPages = doc.numPages;
        const targetPage = Math.max(1, Math.min(pageNumber, totalPages));
        const page = await doc.getPage(targetPage);
        
        const originalViewport = page.getViewport({ scale: 1.0 });
        const pWidth = originalViewport.width || 612;
        const pHeight = originalViewport.height || 792;
        setPdfWidth(pWidth);
        setPdfHeight(pHeight);

        // Calculate aspect ratio fit inside 320x410
        const scaleX = 320 / pWidth;
        const scaleY = 410 / pHeight;
        const finalScale = Math.min(scaleX, scaleY);
        const fitWidth = pWidth * finalScale;
        const fitHeight = pHeight * finalScale;
        setContainerWidth(fitWidth);
        setContainerHeight(fitHeight);

        if (canvasRef.current) {
          const canvas = canvasRef.current;
          canvas.width = fitWidth;
          canvas.height = fitHeight;
          const context = canvas.getContext('2d');
          if (context) {
            context.clearRect(0, 0, fitWidth, fitHeight);
            const viewport = page.getViewport({ scale: finalScale });
            await page.render({
              canvasContext: context,
              viewport: viewport,
            }).promise;
          }
        }
      } catch (err) {
        console.error('Error rendering page in signature placement widget:', err);
      } finally {
        if (active) setLoading(false);
      }
    };

    renderPage();
    return () => {
      active = false;
    };
  }, [pdfBytes, pageNumber]);

  // Handle Dragging
  const handleStart = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDragging(true);
    updateCoords(e);
  };

  const handleMove = (e: MouseEvent | TouchEvent) => {
    if (!isDragging) return;
    updateCoords(e);
  };

  const handleEnd = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMove);
      window.addEventListener('mouseup', handleEnd);
      window.addEventListener('touchmove', handleMove, { passive: false });
      window.addEventListener('touchend', handleEnd);
    }
    return () => {
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleEnd);
      window.removeEventListener('touchmove', handleMove);
      window.removeEventListener('touchend', handleEnd);
    };
  }, [isDragging]);

  const updateCoords = (e: any) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    
    let clientX = 0;
    let clientY = 0;
    if (e.touches && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const mouseX = clientX - rect.left;
    const mouseY = clientY - rect.top;

    // Display dims of the signature box on screen
    const sigWidthInPoints = 185;
    const sigHeightInPoints = 70;
    const displaySigWidth = sigWidthInPoints * (containerWidth / pdfWidth);
    const displaySigHeight = sigHeightInPoints * (containerHeight / pdfHeight);

    // Position of the grab: center the box on mouse coordinates
    const boxLeft = Math.max(0, Math.min(containerWidth - displaySigWidth, mouseX - displaySigWidth / 2));
    const boxTop = Math.max(0, Math.min(containerHeight - displaySigHeight, mouseY - displaySigHeight / 2));

    // Convert back to percentages
    const px = boxLeft / containerWidth;
    // bottom is 0, top is 1
    const py = (containerHeight - boxTop - displaySigHeight) / containerHeight;

    onChange(px, py);
  };

  // Convert points back to screen pixels for displaying signature box positioning
  const displaySigWidth = 185 * (containerWidth / pdfWidth);
  const displaySigHeight = 70 * (containerHeight / pdfHeight);
  const boxLeft = percentX * containerWidth;
  const boxBottom = percentY * containerHeight;

  return (
    <div className="flex flex-col items-center gap-4 bg-[#0a0c14]/90 border border-[#232635] p-4 rounded-xl w-full">
      <div className="text-center space-y-1">
        <span className="text-[10px] font-bold text-violet-400 uppercase tracking-widest block">
          🎯 Interactive Signature Canvas
        </span>
        <p className="text-[9px] text-[#9297a3]">
          Click and drag the blue seal to decide the exact position on Page {pageNumber}
        </p>
      </div>

      <div
        ref={containerRef}
        onMouseDown={handleStart}
        onTouchStart={handleStart}
        style={{ width: `${containerWidth}px`, height: `${containerHeight}px` }}
        className="relative bg-white rounded shadow-inner cursor-crosshair overflow-hidden border border-zinc-800"
      >
        {pdfBytes ? (
          <canvas ref={canvasRef} className="w-full h-full block" />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-center p-6 bg-slate-100 text-slate-800">
            <span className="text-xs font-bold uppercase text-slate-400 tracking-wider">Empty Document Sheet</span>
            <p className="text-[9px] text-slate-400 mt-1 max-w-[200px]">
              Upload a target PDF to view page content. Showing default US Letter canvas.
            </p>
          </div>
        )}

        {/* Signature draggable box */}
        <div
          style={{
            width: `${displaySigWidth}px`,
            height: `${displaySigHeight}px`,
            left: `${boxLeft}px`,
            bottom: `${boxBottom}px`,
          }}
          className="absolute bg-violet-500/20 border-2 border-violet-500 text-violet-400 rounded p-1 flex flex-col justify-between overflow-hidden shadow-lg shadow-violet-500/10 pointer-events-none select-none"
        >
          <div className="flex items-center justify-between gap-1 border-b border-violet-500/30 pb-0.5">
            <span className="text-[7px] font-extrabold uppercase truncate">🛡️ SEAL SECURE</span>
            <span className="text-[6px] font-mono bg-violet-500/20 px-1 py-0.2 rounded text-[5px]">VERIFIED</span>
          </div>
          <p className="text-[6px] font-medium leading-none truncate mt-0.5 text-zinc-900">
            Name: {signerName.substring(0, 12)}
          </p>
          <div className="flex justify-between items-end text-[5px] text-[#4f46e5] font-mono mt-0.5">
            <span>X: {Math.round(percentX * pdfWidth)}pt</span>
            <span>Y: {Math.round(percentY * pdfHeight)}pt</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 text-center w-full max-w-[280px] bg-[#0d0f1a] p-2 rounded-lg border border-[#202336] text-[10px]">
        <div>
          <span className="text-zinc-500 block text-[8px] uppercase">X-Position</span>
          <span className="text-white font-mono font-bold">{Math.round(percentX * pdfWidth)} pt ({Math.round(percentX * 100)}%)</span>
        </div>
        <div>
          <span className="text-zinc-500 block text-[8px] uppercase">Y-Position</span>
          <span className="text-white font-mono font-bold">{Math.round(percentY * pdfHeight)} pt ({Math.round(percentY * 100)}%)</span>
        </div>
      </div>
    </div>
  );
};
