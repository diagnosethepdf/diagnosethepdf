import React, { useState, useRef, useEffect } from 'react';
import {
  Ruler,
  Upload,
  Layers,
  RotateCcw,
  CheckCircle2,
  FileText,
  Download,
  Trash2,
  Plus,
  Compass,
  Maximize2,
  Grid,
  Sparkles,
  ArrowLeft,
  MousePointer,
  HelpCircle,
  Eye,
  EyeOff,
  Calculator,
  Box,
  MapPin,
  Tag,
  Share2,
} from 'lucide-react';
import {
  CadDrawing,
  CadLayer,
  parseDxfText,
  generateSampleCadDrawing,
} from '../utils/cadParser';

export interface MeasurementItem {
  id: string;
  name: string;
  type: 'linear' | 'area' | 'volume' | 'count' | 'callout';
  category?: string;
  value: number;
  unit: string;
  color: string;
  points: { x: number; y: number }[];
  textLabel?: string;
  heightMultiplier?: number; // for volume (ft/m)
}

interface CadBlueprintSuiteProps {
  onBackToEditor: () => void;
  onUploadFile?: (file: File) => void;
}

export const CadBlueprintSuite: React.FC<CadBlueprintSuiteProps> = ({
  onBackToEditor,
}) => {
  // CAD Drawing State
  const [drawing, setDrawing] = useState<CadDrawing>(() =>
    generateSampleCadDrawing('Architectural_Floor_Plan_Rev3.dxf', 'DXF')
  );

  // Canvas Viewport & Zoom/Pan State
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [zoom, setZoom] = useState<number>(1.0);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 40, y: 40 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Theme Settings
  const [canvasTheme, setCanvasTheme] = useState<'autocad' | 'blueprint' | 'paper'>('autocad');
  const [showGrid, setShowGrid] = useState<boolean>(true);

  // Calibration & Scale
  const [scaleRatioLabel, setScaleRatioLabel] = useState<string>('1/4" = 1\'0"');
  // Pixels per unit (e.g., 20 pixels = 1.0 foot)
  const [pixelsPerUnit, setPixelsPerUnit] = useState<number>(20);
  const [unitName, setUnitName] = useState<string>('ft');
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);
  const [calibratePts, setCalibratePts] = useState<{ x: number; y: number }[]>([]);
  const [calibrateRealDist, setCalibrateRealDist] = useState<string>('10.0');

  // Measurement Tool State
  const [activeTool, setActiveTool] = useState<'pan' | 'linear' | 'area' | 'volume' | 'count' | 'callout' | 'calibrate'>('linear');
  const [activeCountCategory, setActiveCountCategory] = useState<string>('Doors & Openings');
  const [measurements, setMeasurements] = useState<MeasurementItem[]>([
    {
      id: 'm_1',
      name: 'Main Entrance Doorway',
      type: 'linear',
      value: 6.5,
      unit: 'ft',
      color: '#38bdf8',
      points: [{ x: 280, y: 200 }, { x: 280, y: 235 }],
    },
    {
      id: 'm_2',
      name: 'Executive Suite 101 Area',
      type: 'area',
      value: 396.0,
      unit: 'sq ft',
      color: '#facc15',
      points: [
        { x: 60, y: 60 },
        { x: 280, y: 60 },
        { x: 280, y: 250 },
        { x: 60, y: 250 },
      ],
    },
    {
      id: 'm_3',
      name: 'Executive Suite 101 Volume',
      type: 'volume',
      value: 3564.0,
      unit: 'cu ft',
      color: '#a855f7',
      heightMultiplier: 9.0,
      points: [
        { x: 60, y: 60 },
        { x: 280, y: 60 },
        { x: 280, y: 250 },
        { x: 60, y: 250 },
      ],
    },
    {
      id: 'm_4',
      name: 'Duplex Outlet #1',
      type: 'count',
      category: 'Electrical Outlets',
      value: 1,
      unit: 'pcs',
      color: '#4ade80',
      points: [{ x: 100, y: 60 }],
    },
  ]);

  // Current interactive drawing points (for polyline/area/linear)
  const [currentPts, setCurrentPts] = useState<{ x: number; y: number }[]>([]);
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);
  const [wallHeight, setWallHeight] = useState<number>(9.0); // Default 9ft ceiling for volume
  const [calloutText, setCalloutText] = useState<string>('Verify Structural Rebar Spacing');

  // Status message bar
  const [statusText, setStatusText] = useState<string>(
    'Click on canvas to measure linear distance, area, volume, or drop takeoff count markers.'
  );

  // File Upload Handling
  const handleFileUpload = (file: File) => {
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    if (ext === 'dxf') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        if (content) {
          const parsed = parseDxfText(content, file.name);
          setDrawing(parsed);
          setStatusText(`Successfully parsed CAD DXF file: ${file.name} (${parsed.entities.length} vector entities)`);
        }
      };
      reader.readAsText(file);
    } else {
      // DWG, DWF, PDF, SVG, PNG, JPG
      const sample = generateSampleCadDrawing(file.name, ext.toUpperCase() as any);
      setDrawing(sample);
      setStatusText(`Loaded CAD Blueprint document: ${file.name} (${sample.entities.length} layers & vector paths ready)`);
    }
  };

  // Preset Scale Change Handler
  const handleScalePresetChange = (label: string) => {
    setScaleRatioLabel(label);
    switch (label) {
      case '1/4" = 1\'0"':
        setPixelsPerUnit(24);
        setUnitName('ft');
        break;
      case '1/8" = 1\'0"':
        setPixelsPerUnit(12);
        setUnitName('ft');
        break;
      case '1/16" = 1\'0"':
        setPixelsPerUnit(6);
        setUnitName('ft');
        break;
      case '1:50 Metric':
        setPixelsPerUnit(30);
        setUnitName('m');
        break;
      case '1:100 Metric':
        setPixelsPerUnit(15);
        setUnitName('m');
        break;
      case 'Custom Calibration':
        setIsCalibrating(true);
        setActiveTool('calibrate');
        setStatusText('Scale Calibration: Click Point 1 and Point 2 on drawing with a known physical distance.');
        break;
      default:
        setPixelsPerUnit(20);
        setUnitName('ft');
    }
  };

  // Convert canvas pixel distance to calibrated unit value
  const calculateDistance = (p1: { x: number; y: number }, p2: { x: number; y: number }) => {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const pixelDist = Math.sqrt(dx * dx + dy * dy);
    return pixelDist / pixelsPerUnit;
  };

  // Calculate polygon enclosed area (Shoelace formula)
  const calculateArea = (pts: { x: number; y: number }[]) => {
    if (pts.length < 3) return 0;
    let areaPixels = 0;
    for (let i = 0; i < pts.length; i++) {
      const j = (i + 1) % pts.length;
      areaPixels += pts[i].x * pts[j].y;
      areaPixels -= pts[j].x * pts[i].y;
    }
    areaPixels = Math.abs(areaPixels) / 2.0;
    // convert sq pixels to sq units
    const sqUnits = areaPixels / (pixelsPerUnit * pixelsPerUnit);
    return sqUnits;
  };

  // Calculate polygon perimeter
  const calculatePerimeter = (pts: { x: number; y: number }[]) => {
    if (pts.length < 2) return 0;
    let perim = 0;
    for (let i = 0; i < pts.length; i++) {
      const j = (i + 1) % pts.length;
      perim += calculateDistance(pts[i], pts[j]);
    }
    return perim;
  };

  // Layer Visibility Toggle
  const toggleLayerVisibility = (layerName: string) => {
    setDrawing((prev) => ({
      ...prev,
      layers: prev.layers.map((l) =>
        l.name === layerName ? { ...l, visible: !l.visible } : l
      ),
    }));
  };

  // Mouse Canvas Interaction Handlers
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const rawX = e.clientX - rect.left;
    const rawY = e.clientY - rect.top;

    // Convert raw screen pixel to drawing world coordinates
    const worldX = (rawX - pan.x) / zoom;
    const worldY = (rawY - pan.y) / zoom;

    if (e.button === 1 || activeTool === 'pan') {
      // Middle mouse or Pan tool
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
      return;
    }

    if (activeTool === 'calibrate') {
      const newCal = [...calibratePts, { x: worldX, y: worldY }];
      setCalibratePts(newCal);
      if (newCal.length === 2) {
        const pxDist = Math.sqrt(
          Math.pow(newCal[1].x - newCal[0].x, 2) + Math.pow(newCal[1].y - newCal[0].y, 2)
        );
        const realVal = parseFloat(calibrateRealDist) || 10;
        const newPxPerUnit = pxDist / realVal;
        setPixelsPerUnit(newPxPerUnit);
        setScaleRatioLabel(`Calibrated (${realVal} ${unitName} = ${Math.round(pxDist)}px)`);
        setCalibratePts([]);
        setIsCalibrating(false);
        setActiveTool('linear');
        setStatusText(`Scale successfully calibrated! 1 ${unitName} = ${newPxPerUnit.toFixed(2)} pixels.`);
      }
      return;
    }

    if (activeTool === 'count') {
      const newM: MeasurementItem = {
        id: `m_${Date.now()}`,
        name: `${activeCountCategory} Marker #${measurements.filter((m) => m.type === 'count').length + 1}`,
        type: 'count',
        category: activeCountCategory,
        value: 1,
        unit: 'pcs',
        color: '#f43f5e',
        points: [{ x: worldX, y: worldY }],
      };
      setMeasurements((prev) => [...prev, newM]);
      setStatusText(`Placed ${activeCountCategory} count marker at X:${Math.round(worldX)}, Y:${Math.round(worldY)}`);
      return;
    }

    if (activeTool === 'callout') {
      const newM: MeasurementItem = {
        id: `m_${Date.now()}`,
        name: 'Callout Note',
        type: 'callout',
        value: 0,
        unit: '',
        color: '#facc15',
        points: [{ x: worldX, y: worldY }],
        textLabel: calloutText || 'CAD Note',
      };
      setMeasurements((prev) => [...prev, newM]);
      setStatusText(`Added callout annotation: "${calloutText}"`);
      return;
    }

    if (['linear', 'area', 'volume'].includes(activeTool)) {
      const newPts = [...currentPts, { x: worldX, y: worldY }];
      if (activeTool === 'linear' && newPts.length === 2) {
        const distVal = calculateDistance(newPts[0], newPts[1]);
        const newM: MeasurementItem = {
          id: `m_${Date.now()}`,
          name: `Linear Measurement #${measurements.filter((m) => m.type === 'linear').length + 1}`,
          type: 'linear',
          value: parseFloat(distVal.toFixed(2)),
          unit: unitName,
          color: '#38bdf8',
          points: newPts,
        };
        setMeasurements((prev) => [...prev, newM]);
        setCurrentPts([]);
        setStatusText(`Recorded linear distance: ${distVal.toFixed(2)} ${unitName}`);
      } else {
        setCurrentPts(newPts);
      }
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const rawX = e.clientX - rect.left;
    const rawY = e.clientY - rect.top;

    if (isPanning) {
      setPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      });
      return;
    }

    const worldX = (rawX - pan.x) / zoom;
    const worldY = (rawY - pan.y) / zoom;
    setMousePos({ x: worldX, y: worldY });
  };

  const handleCanvasMouseUp = () => {
    setIsPanning(false);
  };

  // Complete Polygon for Area / Volume
  const finishPolygonMeasurement = () => {
    if (currentPts.length < 3) return;
    if (activeTool === 'area') {
      const sqVal = calculateArea(currentPts);
      const newM: MeasurementItem = {
        id: `m_${Date.now()}`,
        name: `Room Area Zone #${measurements.filter((m) => m.type === 'area').length + 1}`,
        type: 'area',
        value: parseFloat(sqVal.toFixed(2)),
        unit: `sq ${unitName}`,
        color: '#facc15',
        points: [...currentPts],
      };
      setMeasurements((prev) => [...prev, newM]);
      setStatusText(`Recorded room area: ${sqVal.toFixed(2)} sq ${unitName}`);
    } else if (activeTool === 'volume') {
      const sqVal = calculateArea(currentPts);
      const cuVal = sqVal * wallHeight;
      const newM: MeasurementItem = {
        id: `m_${Date.now()}`,
        name: `Volume Space (${wallHeight}${unitName} H)`,
        type: 'volume',
        value: parseFloat(cuVal.toFixed(2)),
        unit: `cu ${unitName}`,
        color: '#a855f7',
        heightMultiplier: wallHeight,
        points: [...currentPts],
      };
      setMeasurements((prev) => [...prev, newM]);
      setStatusText(`Recorded volume space: ${cuVal.toFixed(2)} cu ${unitName} (Height: ${wallHeight} ${unitName})`);
    }
    setCurrentPts([]);
  };

  // RENDER CANVAS DRAWING & MEASUREMENTS
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas resolution
    if (containerRef.current) {
      canvas.width = containerRef.current.clientWidth;
      canvas.height = 580;
    }

    // 1. Background Theme Fill
    let bgHex = '#0f172a';
    let gridColor = '#1e293b';
    if (canvasTheme === 'blueprint') {
      bgHex = '#0b2545';
      gridColor = '#134074';
    } else if (canvasTheme === 'paper') {
      bgHex = '#f8fafc';
      gridColor = '#e2e8f0';
    }

    ctx.fillStyle = bgHex;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // 2. Render Grid Lines
    if (showGrid) {
      ctx.strokeStyle = gridColor;
      ctx.lineWidth = 1;
      const gridSize = 40 * zoom;
      const startX = pan.x % gridSize;
      const startY = pan.y % gridSize;

      ctx.beginPath();
      for (let x = startX; x < canvas.width; x += gridSize) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
      }
      for (let y = startY; y < canvas.height; y += gridSize) {
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
      }
      ctx.stroke();
    }

    // Save state before Pan/Zoom transform
    ctx.save();
    ctx.translate(pan.x, pan.y);
    ctx.scale(zoom, zoom);

    // 3. Render CAD Layer Vector Entities
    const visibleLayerNames = new Set(
      drawing.layers.filter((l) => l.visible).map((l) => l.name)
    );

    drawing.entities.forEach((ent) => {
      if (!visibleLayerNames.has(ent.layer)) return;

      ctx.strokeStyle = canvasTheme === 'paper' ? '#0f172a' : ent.color || '#00ffff';
      ctx.fillStyle = canvasTheme === 'paper' ? '#0f172a' : ent.color || '#00ffff';
      ctx.lineWidth = 1.5 / zoom;

      if (ent.type === 'LINE' && ent.x1 !== undefined && ent.y1 !== undefined && ent.x2 !== undefined && ent.y2 !== undefined) {
        ctx.beginPath();
        ctx.moveTo(ent.x1, ent.y1);
        ctx.lineTo(ent.x2, ent.y2);
        ctx.stroke();
      } else if (ent.type === 'CIRCLE' && ent.cx !== undefined && ent.cy !== undefined && ent.radius !== undefined) {
        ctx.beginPath();
        ctx.arc(ent.cx, ent.cy, ent.radius, 0, Math.PI * 2);
        ctx.stroke();
      } else if (ent.type === 'LWPOLYLINE' && ent.points && ent.points.length > 0) {
        ctx.beginPath();
        ctx.moveTo(ent.points[0].x, ent.points[0].y);
        for (let p = 1; p < ent.points.length; p++) {
          ctx.lineTo(ent.points[p].x, ent.points[p].y);
        }
        if (ent.isClosed) ctx.closePath();
        ctx.stroke();
      } else if (ent.type === 'TEXT' && ent.x1 !== undefined && ent.y1 !== undefined && ent.text) {
        ctx.font = `bold ${Math.max(10, ent.height || 12)}px monospace`;
        ctx.fillText(ent.text, ent.x1, ent.y1);
      }
    });

    // 4. Render Recorded Saved Measurements
    measurements.forEach((m) => {
      ctx.strokeStyle = m.color;
      ctx.fillStyle = m.color;
      ctx.lineWidth = 2.5 / zoom;

      if (m.type === 'linear' && m.points.length === 2) {
        const p1 = m.points[0];
        const p2 = m.points[1];
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();

        // End ticks
        const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x);
        const tickLen = 8 / zoom;
        ctx.beginPath();
        ctx.moveTo(p1.x - Math.sin(angle) * tickLen, p1.y + Math.cos(angle) * tickLen);
        ctx.lineTo(p1.x + Math.sin(angle) * tickLen, p1.y - Math.cos(angle) * tickLen);
        ctx.moveTo(p2.x - Math.sin(angle) * tickLen, p2.y + Math.cos(angle) * tickLen);
        ctx.lineTo(p2.x + Math.sin(angle) * tickLen, p2.y - Math.cos(angle) * tickLen);
        ctx.stroke();

        // Distance text label badge
        const midX = (p1.x + p2.x) / 2;
        const midY = (p1.y + p2.y) / 2;
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(midX - 25, midY - 12, 50, 16);
        ctx.fillStyle = m.color;
        ctx.font = 'bold 11px sans-serif';
        ctx.fillText(`${m.value} ${m.unit}`, midX - 22, midY);
      } else if ((m.type === 'area' || m.type === 'volume') && m.points.length >= 3) {
        ctx.beginPath();
        ctx.moveTo(m.points[0].x, m.points[0].y);
        for (let p = 1; p < m.points.length; p++) {
          ctx.lineTo(m.points[p].x, m.points[p].y);
        }
        ctx.closePath();
        ctx.save();
        ctx.globalAlpha = 0.25;
        ctx.fillStyle = m.color;
        ctx.fill();
        ctx.restore();
        ctx.stroke();

        // Center Area / Volume Badge
        const avgX = m.points.reduce((acc, p) => acc + p.x, 0) / m.points.length;
        const avgY = m.points.reduce((acc, p) => acc + p.y, 0) / m.points.length;
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(avgX - 45, avgY - 12, 90, 20);
        ctx.fillStyle = m.color;
        ctx.font = 'bold 11px sans-serif';
        ctx.fillText(`${m.value} ${m.unit}`, avgX - 40, avgY + 2);
      } else if (m.type === 'count' && m.points.length === 1) {
        const pt = m.points[0];
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 10 / zoom, 0, Math.PI * 2);
        ctx.fillStyle = m.color;
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText('✓', pt.x - 3, pt.y + 3);
      } else if (m.type === 'callout' && m.points.length === 1) {
        const pt = m.points[0];
        ctx.fillStyle = '#facc15';
        ctx.fillRect(pt.x, pt.y - 20, 120, 22);
        ctx.fillStyle = '#0f172a';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText(m.textLabel || 'Note', pt.x + 6, pt.y - 6);
      }
    });

    // 5. Render Active Rubberband / Drawing in Progress
    if (currentPts.length > 0) {
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 2 / zoom;
      ctx.beginPath();
      ctx.moveTo(currentPts[0].x, currentPts[0].y);
      for (let p = 1; p < currentPts.length; p++) {
        ctx.lineTo(currentPts[p].x, currentPts[p].y);
      }
      if (mousePos) {
        ctx.lineTo(mousePos.x, mousePos.y);
      }
      ctx.stroke();

      // Live rubberband length display
      if (mousePos && currentPts.length > 0) {
        const lastPt = currentPts[currentPts.length - 1];
        const liveDist = calculateDistance(lastPt, mousePos);
        ctx.fillStyle = '#f43f5e';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText(`${liveDist.toFixed(2)} ${unitName}`, mousePos.x + 12, mousePos.y - 12);
      }
    }

    // 6. Scale Legend Block Stamp (Bottom Right)
    ctx.restore(); // Restore world transform to screen coordinate overlay
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(canvas.width - 240, canvas.height - 75, 230, 65);
    ctx.strokeStyle = '#3b82f6';
    ctx.strokeRect(canvas.width - 240, canvas.height - 75, 230, 65);

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 11px monospace';
    ctx.fillText(`CAD BLUEPRINT SCALE: ${scaleRatioLabel}`, canvas.width - 230, canvas.height - 55);
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px monospace';
    ctx.fillText(`Calibration: 1.0 ${unitName} = ${pixelsPerUnit.toFixed(1)} px`, canvas.width - 230, canvas.height - 38);
    ctx.fillText(`File: ${drawing.filename} (${drawing.fileType})`, canvas.width - 230, canvas.height - 22);
  }, [
    drawing,
    pan,
    zoom,
    canvasTheme,
    showGrid,
    measurements,
    currentPts,
    mousePos,
    scaleRatioLabel,
    pixelsPerUnit,
    unitName,
  ]);

  // Export CSV Measurement Report
  const exportCsvReport = () => {
    let csv = `ID,Name,Type,Category,Value,Unit,Timestamp\n`;
    measurements.forEach((m) => {
      csv += `"${m.id}","${m.name}","${m.type}","${m.category || 'General'}","${m.value}","${m.unit}","${new Date().toISOString()}"\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CAD_Takeoff_Report_${drawing.filename}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Export Stamped Blueprint Image
  const exportStampedBlueprint = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = url;
    link.download = `Stamped_CAD_Blueprint_${drawing.filename}.png`;
    link.click();
  };

  // Live Totals Calculations
  const totalLinear = measurements
    .filter((m) => m.type === 'linear')
    .reduce((acc, m) => acc + m.value, 0);

  const totalArea = measurements
    .filter((m) => m.type === 'area')
    .reduce((acc, m) => acc + m.value, 0);

  const totalVolume = measurements
    .filter((m) => m.type === 'volume')
    .reduce((acc, m) => acc + m.value, 0);

  const totalCounts = measurements.filter((m) => m.type === 'count').length;

  return (
    <div className="w-full max-w-7xl mx-auto bg-[#0d1017] text-slate-100 rounded-3xl border border-[#212638] shadow-2xl p-6 sm:p-8 space-y-6 my-6 text-left animate-fadeIn">
      {/* Top Navigation Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#212638] pb-5">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-cyan-500/10 text-cyan-400 rounded-2xl border border-cyan-500/20 shadow-inner">
            <Ruler className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                CAD &amp; Blueprint Measurement Suite
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                Vector Precision 2.0
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Support for DXF, DWG, PDF, SVG &amp; Image blueprints with real-time linear, area, volume &amp; count takeoff calculations.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* File Upload Button */}
          <label className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold bg-[#181d2a] hover:bg-[#252c3f] border border-[#2d364f] text-emerald-400 rounded-xl transition-all cursor-pointer shadow-sm active:scale-95">
            <Upload className="w-4 h-4 text-emerald-400" />
            <span>Upload CAD / Blueprint</span>
            <input
              type="file"
              accept=".dxf,.dwg,.dwf,.pdf,.svg,.png,.jpg,.jpeg"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) handleFileUpload(e.target.files[0]);
              }}
            />
          </label>

          {/* Quick Demo Sample Button */}
          <button
            type="button"
            onClick={() => {
              const sample = generateSampleCadDrawing('Architectural_Floor_Plan_Rev3.dxf', 'DXF');
              setDrawing(sample);
              setStatusText('Loaded sample architectural CAD floorplan blueprint.');
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold bg-[#181d2a] hover:bg-[#252c3f] border border-[#2d364f] text-amber-400 rounded-xl transition-all cursor-pointer shadow-sm active:scale-95"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Load Demo Blueprint</span>
          </button>

          <button
            type="button"
            onClick={onBackToEditor}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold bg-[#181d2a] hover:bg-[#252c3f] border border-[#2d364f] text-slate-300 hover:text-white rounded-xl transition-all cursor-pointer shadow-sm active:scale-95"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Main Platform</span>
          </button>
        </div>
      </div>

      {/* Main CAD Suite Layout Grid (Controls + Canvas + Layers) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* LEFT COLUMN: Tool Palette & Scale Calibration (3 cols) */}
        <div className="lg:col-span-3 space-y-4">
          {/* Active Measurement Tool Switcher */}
          <div className="bg-[#141824] border border-[#232a3d] rounded-2xl p-4 space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Compass className="w-4 h-4" />
              <span>Measurement Tools</span>
            </h3>

            <div className="grid grid-cols-2 gap-1.5">
              {[
                { id: 'linear', label: '📐 Linear', icon: Ruler, desc: 'Distance A to B' },
                { id: 'area', label: '⬛ Area', icon: SquareIcon, desc: 'Closed polygon sq ft' },
                { id: 'volume', label: '📦 Volume', icon: Box, desc: 'Cubic volume cu ft' },
                { id: 'count', label: '🔘 Takeoff', icon: MapPin, desc: 'Count symbol items' },
                { id: 'callout', label: '💬 Callout', icon: Tag, desc: 'Drop text label note' },
                { id: 'pan', label: '✋ Pan View', icon: MousePointer, desc: 'Drag viewport' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    setActiveTool(t.id as any);
                    setCurrentPts([]);
                  }}
                  className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                    activeTool === t.id
                      ? 'bg-cyan-600 text-white border-cyan-400 shadow-md font-bold'
                      : 'bg-[#0f121c] border-[#222838] text-slate-300 hover:bg-[#1a2030] hover:text-white'
                  }`}
                >
                  <div className="text-xs font-bold flex items-center gap-1.5">
                    <span>{t.label}</span>
                  </div>
                  <span className="text-[10px] opacity-75 block mt-0.5">{t.desc}</span>
                </button>
              ))}
            </div>

            {/* Sub-tool options depending on selected tool */}
            {activeTool === 'volume' && (
              <div className="mt-2 p-2.5 bg-[#0f121c] border border-[#222838] rounded-xl space-y-1">
                <label className="text-[10px] font-bold text-slate-300 block">
                  Ceiling / Slab Height ({unitName}):
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={wallHeight}
                  onChange={(e) => setWallHeight(parseFloat(e.target.value) || 1)}
                  className="w-full bg-[#181d2a] border border-[#2d364f] rounded-lg px-2 py-1 text-xs text-white font-mono"
                />
              </div>
            )}

            {activeTool === 'count' && (
              <div className="mt-2 p-2.5 bg-[#0f121c] border border-[#222838] rounded-xl space-y-1">
                <label className="text-[10px] font-bold text-slate-300 block">
                  Takeoff Category Symbol:
                </label>
                <select
                  value={activeCountCategory}
                  onChange={(e) => setActiveCountCategory(e.target.value)}
                  className="w-full bg-[#181d2a] border border-[#2d364f] rounded-lg px-2 py-1 text-xs text-white"
                >
                  {['Doors & Openings', 'Electrical Outlets', 'Light Fixtures', 'HVAC Vents', 'Structural Columns', 'Plumbing Fixtures'].map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
            )}

            {activeTool === 'callout' && (
              <div className="mt-2 p-2.5 bg-[#0f121c] border border-[#222838] rounded-xl space-y-1">
                <label className="text-[10px] font-bold text-slate-300 block">
                  Callout Note Text:
                </label>
                <input
                  type="text"
                  value={calloutText}
                  onChange={(e) => setCalloutText(e.target.value)}
                  className="w-full bg-[#181d2a] border border-[#2d364f] rounded-lg px-2 py-1 text-xs text-white"
                />
              </div>
            )}

            {/* Polygon Finish Button */}
            {(activeTool === 'area' || activeTool === 'volume') && currentPts.length >= 3 && (
              <button
                type="button"
                onClick={finishPolygonMeasurement}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all cursor-pointer animate-bounce flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Calculate Closed {activeTool.toUpperCase()} ({currentPts.length} points)</span>
              </button>
            )}
          </div>

          {/* Scale Calibration Card */}
          <div className="bg-[#141824] border border-[#232a3d] rounded-2xl p-4 space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Calculator className="w-4 h-4" />
              <span>Architectural Scale</span>
            </h3>

            <div>
              <label className="text-[10px] font-bold text-slate-400 block mb-1">
                Preset Calibration Ratio:
              </label>
              <select
                value={scaleRatioLabel}
                onChange={(e) => handleScalePresetChange(e.target.value)}
                className="w-full bg-[#0f121c] border border-[#222838] rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-amber-500 outline-none"
              >
                {['1/4" = 1\'0"', '1/8" = 1\'0"', '1/16" = 1\'0"', '1:50 Metric', '1:100 Metric', 'Custom Calibration'].map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {/* Custom Calibration controls */}
            <div className="pt-2 border-t border-[#222838] space-y-2">
              <button
                type="button"
                onClick={() => handleScalePresetChange('Custom Calibration')}
                className={`w-full py-1.5 text-xs font-bold rounded-xl border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  isCalibrating
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-extrabold'
                    : 'bg-[#0f121c] border-[#222838] text-amber-300 hover:bg-amber-500/20'
                }`}
              >
                <Compass className="w-3.5 h-3.5" />
                <span>{isCalibrating ? 'Calibrating: Click 2 Points' : '🎯 2-Point Manual Calibration'}</span>
              </button>

              {isCalibrating && (
                <div className="p-2 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-1.5">
                  <span className="text-[10px] text-amber-300 font-bold block">
                    Enter known physical distance between points:
                  </span>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      step="0.1"
                      value={calibrateRealDist}
                      onChange={(e) => setCalibrateRealDist(e.target.value)}
                      className="w-full bg-[#181d2a] border border-[#2d364f] rounded-lg px-2 py-1 text-xs text-white font-mono"
                    />
                    <select
                      value={unitName}
                      onChange={(e) => setUnitName(e.target.value)}
                      className="bg-[#181d2a] border border-[#2d364f] rounded-lg px-2 py-1 text-xs text-white font-mono"
                    >
                      <option value="ft">ft</option>
                      <option value="m">m</option>
                      <option value="in">in</option>
                      <option value="mm">mm</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Theme & Display Options */}
          <div className="bg-[#141824] border border-[#232a3d] rounded-2xl p-4 space-y-2">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Grid className="w-4 h-4" />
              <span>Canvas Display Theme</span>
            </h3>

            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'autocad', label: 'AutoCAD Dark' },
                { id: 'blueprint', label: 'Blueprint' },
                { id: 'paper', label: 'Paper Light' },
              ].map((thm) => (
                <button
                  key={thm.id}
                  type="button"
                  onClick={() => setCanvasTheme(thm.id as any)}
                  className={`py-1.5 text-[10px] font-bold rounded-lg border transition-all cursor-pointer ${
                    canvasTheme === thm.id
                      ? 'bg-blue-600 text-white border-blue-400'
                      : 'bg-[#0f121c] border-[#222838] text-slate-400 hover:text-white'
                  }`}
                >
                  {thm.label}
                </button>
              ))}
            </div>

            <label className="flex items-center justify-between p-2 bg-[#0f121c] border border-[#222838] rounded-xl cursor-pointer mt-2">
              <span className="text-xs font-bold text-slate-300">Show Architectural Grid</span>
              <input
                type="checkbox"
                checked={showGrid}
                onChange={(e) => setShowGrid(e.target.checked)}
                className="w-4 h-4 accent-cyan-500 rounded"
              />
            </label>
          </div>
        </div>

        {/* CENTER COLUMN: Interactive Drawing Viewport Canvas (6 cols) */}
        <div className="lg:col-span-6 space-y-3" ref={containerRef}>
          {/* Viewport Top Bar */}
          <div className="flex items-center justify-between bg-[#141824] border border-[#232a3d] px-4 py-2.5 rounded-2xl text-xs font-bold">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
              <span className="text-white font-mono">{drawing.filename}</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-black bg-blue-500/20 text-blue-300 border border-blue-500/30">
                {drawing.fileType}
              </span>
            </div>

            <div className="flex items-center gap-2 font-mono text-[11px]">
              <button
                type="button"
                onClick={() => setZoom((z) => Math.min(z * 1.25, 4.0))}
                className="px-2 py-1 bg-[#181d2a] hover:bg-[#252c3f] rounded border border-[#2d364f] text-slate-200"
              >
                +
              </button>
              <span>{Math.round(zoom * 100)}%</span>
              <button
                type="button"
                onClick={() => setZoom((z) => Math.max(z / 1.25, 0.25))}
                className="px-2 py-1 bg-[#181d2a] hover:bg-[#252c3f] rounded border border-[#2d364f] text-slate-200"
              >
                -
              </button>
              <button
                type="button"
                onClick={() => {
                  setZoom(1.0);
                  setPan({ x: 40, y: 40 });
                }}
                className="px-2 py-1 bg-[#181d2a] hover:bg-[#252c3f] rounded border border-[#2d364f] text-amber-400"
                title="Reset Fit"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Interactive HTML5 Canvas Container */}
          <div className="relative rounded-2xl overflow-hidden border-2 border-[#232a3d] shadow-2xl bg-slate-950 group">
            <canvas
              ref={canvasRef}
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
              className="w-full h-[580px] cursor-crosshair block"
            />

            {/* Instruction Overlay Banner */}
            <div className="absolute top-3 left-3 right-3 bg-slate-950/80 backdrop-blur-md border border-slate-800 rounded-xl px-3.5 py-2 text-xs font-medium text-slate-300 flex items-center justify-between shadow-lg">
              <span className="font-mono text-cyan-300 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
                {statusText}
              </span>
              {currentPts.length > 0 && (
                <button
                  type="button"
                  onClick={() => setCurrentPts([])}
                  className="px-2 py-0.5 bg-rose-500/20 text-rose-300 rounded hover:bg-rose-500/40 text-[10px] font-bold"
                >
                  Cancel Line
                </button>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Layer Visibility & Takeoff Log (3 cols) */}
        <div className="lg:col-span-3 space-y-4">
          {/* CAD Layers Panel */}
          <div className="bg-[#141824] border border-[#232a3d] rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-[#222838] pb-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
                <Layers className="w-4 h-4" />
                <span>CAD Vector Layers</span>
              </h3>
              <span className="text-[10px] font-mono text-slate-400 font-bold">
                {drawing.layers.length} Layers
              </span>
            </div>

            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {drawing.layers.map((layer) => (
                <div
                  key={layer.name}
                  onClick={() => toggleLayerVisibility(layer.name)}
                  className={`flex items-center justify-between p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                    layer.visible
                      ? 'bg-[#0f121c] border-[#222838] text-slate-200 hover:border-purple-500/50'
                      : 'bg-slate-950/40 border-slate-900 text-slate-600 line-through'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full border border-white/20 shrink-0"
                      style={{ backgroundColor: layer.color }}
                    />
                    <span className="font-mono text-[11px] font-bold truncate max-w-[120px]">
                      {layer.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono text-slate-500">
                      ({layer.entityCount})
                    </span>
                    {layer.visible ? (
                      <Eye className="w-3.5 h-3.5 text-purple-400" />
                    ) : (
                      <EyeOff className="w-3.5 h-3.5 text-slate-600" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Takeoff Summary Cards */}
          <div className="bg-[#141824] border border-[#232a3d] rounded-2xl p-4 space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <FileText className="w-4 h-4" />
              <span>Material Takeoff Totals</span>
            </h3>

            <div className="grid grid-cols-2 gap-2 text-left font-mono">
              <div className="p-2.5 bg-[#0f121c] border border-[#222838] rounded-xl">
                <span className="text-[10px] text-slate-400 block font-sans">Total Length</span>
                <span className="text-sm font-extrabold text-cyan-300">{totalLinear.toFixed(1)} {unitName}</span>
              </div>

              <div className="p-2.5 bg-[#0f121c] border border-[#222838] rounded-xl">
                <span className="text-[10px] text-slate-400 block font-sans">Total Area</span>
                <span className="text-sm font-extrabold text-amber-300">{totalArea.toFixed(1)} sq {unitName}</span>
              </div>

              <div className="p-2.5 bg-[#0f121c] border border-[#222838] rounded-xl">
                <span className="text-[10px] text-slate-400 block font-sans">Total Volume</span>
                <span className="text-sm font-extrabold text-purple-300">{totalVolume.toFixed(1)} cu {unitName}</span>
              </div>

              <div className="p-2.5 bg-[#0f121c] border border-[#222838] rounded-xl">
                <span className="text-[10px] text-slate-400 block font-sans">Count Items</span>
                <span className="text-sm font-extrabold text-rose-300">{totalCounts} pcs</span>
              </div>
            </div>

            {/* Export Buttons */}
            <div className="space-y-2 pt-2 border-t border-[#222838]">
              <button
                type="button"
                onClick={exportCsvReport}
                className="w-full py-2 bg-[#181d2a] hover:bg-[#252c3f] border border-[#2d364f] text-emerald-400 font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV Takeoff Report</span>
              </button>

              <button
                type="button"
                onClick={exportStampedBlueprint}
                className="w-full py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Export Stamped Blueprint Image</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM SECTION: Full Interactive Measurement Log Table */}
      <div className="bg-[#141824] border border-[#232a3d] rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#222838] pb-3">
          <div>
            <h3 className="text-sm font-black text-white uppercase tracking-wider font-mono">
              Recorded Vector Measurements &amp; Symbol Takeoff Log ({measurements.length})
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Click item names to customize labels for engineering estimates and architectural schedules.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setMeasurements([])}
            className="px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear All</span>
          </button>
        </div>

        {measurements.length === 0 ? (
          <div className="py-8 text-center text-slate-500 text-xs font-mono">
            No measurements logged yet. Use the linear, area, volume, or takeoff tools above to measure the blueprint.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="border-b border-[#222838] text-slate-400 uppercase text-[10px]">
                  <th className="py-2 px-3">Type</th>
                  <th className="py-2 px-3">Label Name</th>
                  <th className="py-2 px-3">Category</th>
                  <th className="py-2 px-3">Calculated Value</th>
                  <th className="py-2 px-3">Unit</th>
                  <th className="py-2 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#222838]">
                {measurements.map((m) => (
                  <tr key={m.id} className="hover:bg-[#181d2a]/60 transition-colors">
                    <td className="py-2.5 px-3">
                      <span
                        className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase"
                        style={{ backgroundColor: `${m.color}20`, color: m.color, border: `1px solid ${m.color}40` }}
                      >
                        {m.type}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <input
                        type="text"
                        value={m.name}
                        onChange={(e) => {
                          const val = e.target.value;
                          setMeasurements((prev) =>
                            prev.map((item) => (item.id === m.id ? { ...item, name: val } : item))
                          );
                        }}
                        className="bg-[#0f121c] border border-[#222838] rounded px-2 py-1 text-xs text-white font-bold w-64 focus:outline-none focus:border-cyan-500"
                      />
                    </td>
                    <td className="py-2.5 px-3 text-slate-400">
                      {m.category || (m.type === 'volume' ? `Height: ${m.heightMultiplier}${unitName}` : 'Architectural')}
                    </td>
                    <td className="py-2.5 px-3 font-extrabold text-cyan-300">
                      {m.value}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      {m.unit}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        type="button"
                        onClick={() => setMeasurements((prev) => prev.filter((item) => item.id !== m.id))}
                        className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-all cursor-pointer"
                        title="Delete measurement"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

// Helper Icon for Square
const SquareIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="3" y="3" width="18" height="18" rx="2" />
  </svg>
);
