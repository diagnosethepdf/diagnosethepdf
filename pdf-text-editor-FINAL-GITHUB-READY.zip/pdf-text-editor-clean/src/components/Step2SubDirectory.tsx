import React, { useState } from 'react';
import { SUITES, Suite, SubFeature } from '../data/suites';
import {
  ArrowLeft,
  Upload,
  RotateCcw,
  Sparkles,
  Search,
  ArrowRight,
  CheckCircle2,
  FileText,
  Activity,
  Layers,
  FileSignature
} from 'lucide-react';
import { GlowTheme } from '../App';

interface Step2Props {
  suiteId: string;
  onBackToMain: () => void;
  onSelectSubFeature: (subFeatureId: string) => void;
  onGoToStep?: (step: 1 | 2 | 3) => void;
  originalFileName: string;
  pdfDoc: any;
  pagesCount: number;
  onFileUploadClick: () => void;
  handleClearPDF: () => void;
  theme: any;
  onOpenBulkAutoSigner?: () => void;
  onOpenBulkSigner?: () => void;
}

export const Step2SubDirectory: React.FC<Step2Props> = ({
  suiteId,
  onBackToMain,
  onSelectSubFeature,
  onGoToStep,
  originalFileName,
  pdfDoc,
  pagesCount,
  onFileUploadClick,
  handleClearPDF,
  theme,
  onOpenBulkAutoSigner,
  onOpenBulkSigner
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const suite = SUITES.find((s) => s.id === suiteId) || SUITES[0];
  const Icon = suite.icon;

  const filteredSubFeatures = suite.subFeatures.filter((sub) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      sub.title.toLowerCase().includes(q) ||
      sub.badge.toLowerCase().includes(q) ||
      sub.desc.toLowerCase().includes(q)
    );
  });

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-500 ${theme.bg}`}>
      {/* Top Header & Navigation Bar */}
      <header className={`sticky top-0 z-50 border-b px-6 py-4 backdrop-blur-xl shadow-md transition-all ${theme.headerBg}`}>
        <div className="max-w-[1800px] mx-auto flex flex-wrap items-center justify-between gap-4">
          
          {/* Prominent Back to Main Facilities Button */}
          <button
            onClick={onBackToMain}
            className="px-5 py-2.5 rounded-2xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-extrabold text-xs tracking-wider uppercase shadow-lg cursor-pointer flex items-center gap-2 hover:scale-105 active:scale-95 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>⬅️ Back to Main Facilities</span>
          </button>

          {/* Active Suite Badge Indicator */}
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${suite.gradient} flex items-center justify-center text-white shadow-md`}>
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-black tracking-tight text-slate-900 dark:text-white font-display">
                  {suite.title}
                </h1>
                <span className={`text-[10px] font-mono font-black uppercase px-2 py-0.5 rounded-md border ${suite.badgeColor}`}>
                  {suite.badge}
                </span>
              </div>
              <p className="text-[10px] font-mono uppercase tracking-widest text-slate-500 dark:text-slate-400">
                STEP 2 SUB-CATEGORY DIRECTORY ({suite.subFeatures.length} UTILITIES AVAILABLE)
              </p>
            </div>
          </div>

          {/* Document Status & Upload Action & Bulk Auto-Sign */}
          <div className="flex items-center gap-3 bg-white/80 dark:bg-[#121524]/80 border border-slate-200 dark:border-slate-800 p-1.5 px-3 rounded-2xl shadow-sm">
            <button
              onClick={() => {
                if (onOpenBulkSigner) onOpenBulkSigner();
                if (onOpenBulkAutoSigner) onOpenBulkAutoSigner();
                if (onSelectSubFeature) onSelectSubFeature('bulk-auto-signer');
              }}
              title="Open Bulk PDF Auto-Signer Workspace"
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-black text-xs cursor-pointer flex items-center gap-2 shadow-md shadow-blue-500/25 transition-all hover:scale-105 active:scale-95 border border-blue-400/30 shrink-0"
            >
              <FileSignature className="w-4 h-4 text-cyan-200" />
              <span>Bulk PDF Signer</span>
            </button>
            <div className="flex items-center gap-2">
              <div className={`w-2.5 h-2.5 rounded-full ${pdfDoc ? 'bg-emerald-500 animate-ping' : 'bg-amber-400'}`} />
              {pdfDoc ? (
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[180px]">
                    📄 {originalFileName}
                  </span>
                  <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                    {pagesCount} Pages Ready
                  </span>
                </div>
              ) : (
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  No PDF Uploaded
                </span>
              )}
            </div>

            <button
              onClick={onFileUploadClick}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer flex items-center gap-2 shadow-md shadow-blue-500/20 transition-all hover:scale-105 active:scale-95"
            >
              <Upload className="w-4 h-4" />
              <span>{pdfDoc ? '📁 Change PDF' : '📁 Upload PDF'}</span>
            </button>

            {pdfDoc && (
              <button
                onClick={handleClearPDF}
                title="Wipe active document state"
                className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/20 cursor-pointer transition-all"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Sub-Directory Area */}
      <main className="flex-1 max-w-[1800px] w-full mx-auto p-6 md:p-10 flex flex-col gap-8">
        
        {/* Suite Banner & Search */}
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6 border-b border-slate-200/80 dark:border-slate-800 pb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-widest bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                Step 2: Sub-Category Directory
              </span>
              <span className={`text-xs font-mono font-bold uppercase px-2.5 py-0.5 rounded-full border ${suite.badgeColor}`}>
                {suite.badge}
              </span>
            </div>
            <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight font-display flex items-center gap-3">
              <span>{suite.title} Sub-Facilities</span>
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-3xl">
              {suite.description} Select any utility card below to launch its full interactive PDF Editor Workspace.
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-80 shrink-0">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`🔍 Search ${suite.title} utilities...`}
              className="w-full text-xs pl-10 pr-4 py-3 rounded-2xl bg-white/90 dark:bg-[#121524] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-blue-500 shadow-sm font-medium"
            />
          </div>
        </div>

        {/* SUB-FEATURE CARDS GRID */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {filteredSubFeatures.map((sub) => {
            const SubIcon = sub.icon;
            return (
              <div
                key={sub.id + sub.title}
                onClick={() => onSelectSubFeature(sub.id)}
                className="group relative bg-white/95 dark:bg-[#121525]/95 backdrop-blur-xl border border-slate-200/90 dark:border-slate-800/80 hover:border-blue-500 dark:hover:border-blue-500 shadow-xs hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 rounded-xl p-3 cursor-pointer flex flex-col justify-between overflow-hidden min-h-[135px]"
              >
                <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${suite.gradient}`} />

                <div>
                  {/* Icon & Badge Header */}
                  <div className="flex items-center justify-between gap-1.5 mb-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/10 dark:bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-600 dark:text-blue-400 group-hover:bg-blue-600 group-hover:text-white transition-all duration-200 shadow-xs shrink-0">
                      <SubIcon className="w-4 h-4" />
                    </div>
                    <span className="text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 shrink-0">
                      {sub.badge}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-xs font-black text-slate-900 dark:text-white tracking-tight group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors leading-tight line-clamp-1">
                    {sub.title}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-snug font-medium line-clamp-2">
                    {sub.desc}
                  </p>
                </div>

                {/* Bottom Launch Button */}
                <div className="mt-2.5 pt-1.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[10px] font-bold text-blue-600 dark:text-blue-400">
                  <span>Launch Tool</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
};
