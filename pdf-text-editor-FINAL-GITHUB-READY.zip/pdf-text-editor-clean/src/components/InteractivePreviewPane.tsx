/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  X, ChevronLeft, ChevronRight, Eye, FileSignature, 
  Sparkles, Layers, CheckCircle2, ZoomIn, ZoomOut, AlertCircle, Loader2,
  Maximize2, Sliders, ShieldCheck, Zap, RefreshCw
} from 'lucide-react';
import { PDFDocument } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';
import { UploadedFileItem } from './BulkAutoSignerModal';
import { 
  detectSmartPlacement, 
  getSignatureBaseDimensions, 
  SignatureSizePreset,
  SignaturePlacementResult,
  PlacementConfig,
  PageFormat,
  detectPaperFormat
} from '../utils/pdfSmartPlacer';
import { detectSmartAutoGapPlacement } from '../utils/smartAutoGapEngine';

// Get unified pdfjsLib instance and align worker version safely
const getPdfJsLib = () => {
  const lib = (typeof window !== 'undefined' && (window as any).pdfjsLib) || pdfjsLib;
  if (lib && lib.GlobalWorkerOptions) {
    try {
      const v = lib.version || '3.11.174';
      lib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${v}/pdf.worker.min.js`;
    } catch (e) {
      console.warn('pdfjs worker init fallback:', e);
    }
  }
  return lib;
};

interface InteractivePreviewPaneProps {
  isOpen: boolean;
  onClose: () => void;
  fileItem: UploadedFileItem | null;
  filesList?: UploadedFileItem[];
  currentIndex?: number;
  onSelectPrevious?: () => void;
  onSelectNext?: () => void;
  signatureDataUrl?: string;
  signatureImgDimensions?: { width: number; height: number };
  placementConfig?: PlacementConfig;
  onUpdatePageSelection: (
    id: string, 
    mode: 'smart' | 'page-1' | 'custom' | 'first-and-last' | 'all', 
    customPageInput?: string
  ) => void;
  onUpdateSignatureSize?: (
    id: string,
    preset: SignatureSizePreset,
    customScale?: number
  ) => void;
  signingMethod?: 'template' | 'smart_auto_gap';
  theme?: any;
}

export const InteractivePreviewPane: React.FC<InteractivePreviewPaneProps> = ({
  isOpen,
  onClose,
  fileItem,
  filesList,
  currentIndex,
  onSelectPrevious,
  onSelectNext,
  signatureDataUrl,
  signatureImgDimensions,
  placementConfig,
  onUpdatePageSelection,
  onUpdateSignatureSize,
  signingMethod,
  theme,
}) => {
  const isRoseVelvet = theme?.glowPulse === 'bg-[#ec4899]' || theme?.accentText === 'text-[#ec4899]' || theme?.accentText === 'text-[#f472b6]';
  const [totalPages, setTotalPages] = useState<number>(1);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSelectionMode, setPageSelectionMode] = useState<'smart' | 'page-1' | 'custom' | 'first-and-last' | 'all'>('smart');
  const [customPageInput, setCustomPageInput] = useState<string>('1');
  const [sigSizePreset, setSigSizePreset] = useState<SignatureSizePreset>('medium');
  const [sigCustomScale, setSigCustomScale] = useState<number>(100);
  const [isLoadingPdf, setIsLoadingPdf] = useState<boolean>(true);
  const [zoomScale, setZoomScale] = useState<number>(1.0);
  const [pdfJsDoc, setPdfJsDoc] = useState<any>(null);
  const [pageDimensions, setPageDimensions] = useState<{ width: number; height: number }>({ width: 595, height: 842 });
  const [originalDimensions, setOriginalDimensions] = useState<{ width: number; height: number }>({ width: 595, height: 842 });
  const [placementResult, setPlacementResult] = useState<SignaturePlacementResult | null>(null);
  const [overrideFormat, setOverrideFormat] = useState<PageFormat | null>(null);

  const handleOverrideFormat = (fmt: PageFormat) => {
    setOverrideFormat(fmt);
    let mockW = 595, mockH = 842;
    if (fmt === 'A0') { mockW = 2384; mockH = 3370; }
    else if (fmt === 'A1') { mockW = 1684; mockH = 2384; }
    else if (fmt === 'A2') { mockW = 1190; mockH = 1684; }
    else if (fmt === 'A3') { mockW = 842; mockH = 1191; }
    else if (fmt === 'A4') { mockW = 595; mockH = 842; }
    else if (fmt === 'A5') { mockW = 420; mockH = 595; }
    else if (fmt === 'Letter') { mockW = 612; mockH = 792; }
    else if (fmt === 'Legal') { mockW = 612; mockH = 1008; }
    else if (fmt === 'Tabloid') { mockW = 792; mockH = 1224; }
    else if (fmt === 'Executive') { mockW = 522; mockH = 756; }
    else if (fmt === 'Arch A') { mockW = 648; mockH = 864; }
    else if (fmt === 'Arch B') { mockW = 864; mockH = 1296; }
    else if (fmt === 'Custom') { mockW = originalDimensions.width; mockH = originalDimensions.height; }
    setPageDimensions({ width: mockW, height: mockH });
  };

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [manualPosPx, setManualPosPx] = useState<{ x: number; y: number } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStartOffset, setDragStartOffset] = useState({ x: 0, y: 0 });

  useEffect(() => {
    setManualPosPx(null);
  }, [currentPage, fileItem]);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsDragging(true);
    const rect = e.currentTarget.getBoundingClientRect();
    setDragStartOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const parentRect = canvasRef.current?.parentElement?.getBoundingClientRect();
    if (!parentRect) return;
    setManualPosPx({
      x: e.clientX - parentRect.left - dragStartOffset.x,
      y: e.clientY - parentRect.top - dragStartOffset.y,
    });
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsDragging(false);
    e.currentTarget.releasePointerCapture(e.pointerId);
  };


  // Sync internal state with file item
  useEffect(() => {
    if (fileItem) {
      setPageSelectionMode(fileItem.pageSelectionMode || 'smart');
      setCustomPageInput(fileItem.customPageInput || '1');
      setSigSizePreset(fileItem.signatureSizePreset || 'medium');
      setSigCustomScale(fileItem.signatureCustomScale || 100);
      setCurrentPage(1);
      loadPdfDocument(fileItem);
    }
  }, [fileItem, fileItem?.signedBuffer, fileItem?.status]);

  const loadPdfDocument = async (item: UploadedFileItem) => {
    setIsLoadingPdf(true);
    setPdfJsDoc(null);
    try {
      // Load signed buffer if available (for actual signed PDF preview), else original buffer
      const buffer = item.signedBuffer || (await item.getBuffer());

      // Load using pdf-lib for total pages and dimensions
      const pdfDoc = await PDFDocument.load(buffer, { ignoreEncryption: true });
      const numPages = pdfDoc.getPageCount();
      setTotalPages(numPages);

      const firstPage = pdfDoc.getPage(0);
      const { width, height } = firstPage.getSize();
      setPageDimensions({ width, height });
      setOriginalDimensions({ width, height });

      const detectedFmt = detectPaperFormat(width, height);
      if (detectedFmt === 'A0') {
        console.log(`[Diagnostic Log] Right after page size detection: detectedPageSize=${detectedFmt}, actualPageWidthPt=${width}, actualPageHeightPt=${height}`);
      }

      // Load using pdfjs-dist for rendering canvas
      try {
        const pdfjs = getPdfJsLib();
        const loadingTask = pdfjs.getDocument({ data: new Uint8Array(buffer) });
        const pdf = await loadingTask.promise;
        setPdfJsDoc(pdf);
      } catch (e) {
        console.warn('pdfjs-dist render fallback enabled:', e);
      }
    } catch (err) {
      console.error('Error loading PDF preview:', err);
    } finally {
      setIsLoadingPdf(false);
    }
  };

  // Run Smart Placement Detector whenever dimensions, page, pdfJsDoc, or size change
  useEffect(() => {
    if (!isOpen || !fileItem) return;

    let isMounted = true;

    const runPlacer = async () => {
      const baseDim = getSignatureBaseDimensions(
        sigSizePreset,
        sigCustomScale,
        signatureImgDimensions?.width || 200,
        signatureImgDimensions?.height || 100
      );

      const effectiveMethod = fileItem?.signingMethod || signingMethod || 'template';

      if (effectiveMethod === 'smart_auto_gap') {
        const autoGap = await detectSmartAutoGapPlacement({
          pdfJsDoc,
          pageIndex: currentPage - 1,
          pageWidthPt: pageDimensions.width,
          pageHeightPt: pageDimensions.height,
          sigBaseWidthPt: signatureImgDimensions?.width || 200,
          sigBaseHeightPt: signatureImgDimensions?.height || 100,
        });

        if (isMounted) {
          setPlacementResult({
            x: autoGap.pdfCoords.x,
            y: autoGap.pdfCoords.y,
            width: autoGap.pdfCoords.width,
            height: autoGap.pdfCoords.height,
            cornerName: autoGap.cornerName,
            scaleApplied: 1.0,
            autoShrunk: autoGap.fallback_used,
            cleanGapFound: !autoGap.needsManualReview,
            isTextOverlayFallback: autoGap.fallback_used,
            opacity: autoGap.confidence < 0.6 ? 0.85 : 1.0,
            overlapCount: 0,
            pageFormat: autoGap.pageFormat,
            rotationDegrees: autoGap.orientation,
          });
          if (fileItem) {
            fileItem.detectedPaperFormat = autoGap.pageFormat;
            fileItem.smartAutoGapResult = autoGap;
            fileItem.needsManualReview = autoGap.needsManualReview;
          }
        }
      } else {
        const result = await detectSmartPlacement(
          pdfJsDoc,
          currentPage - 1,
          pageDimensions.width,
          pageDimensions.height,
          baseDim.width,
          baseDim.height,
          placementConfig
        );

        if (isMounted) {
          setPlacementResult(result);
          if (fileItem) {
            fileItem.detectedPaperFormat = result.pageFormat;
          }
        }
      }
    };

    runPlacer();

    return () => {
      isMounted = false;
    };
  }, [
    isOpen,
    fileItem,
    currentPage,
    sigSizePreset,
    sigCustomScale,
    pdfJsDoc,
    pageDimensions,
    signatureImgDimensions,
  ]);

  // Render Page on Canvas
  useEffect(() => {
    if (!isOpen || !fileItem) return;

    let isMounted = true;

    const renderPage = async () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      if (pdfJsDoc) {
        try {
          const page = await pdfJsDoc.getPage(currentPage);
          
          // The target canvas dimensions based on the selected paper format
          const targetW = pageDimensions.width * zoomScale * 1.2;
          const targetH = pageDimensions.height * zoomScale * 1.2;
          
          canvas.width = targetW;
          canvas.height = targetH;
          
          // Clear canvas with white background
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, targetW, targetH);

          const originalViewport = page.getViewport({ scale: 1.0 });
          
          // Scale the PDF to fit exactly inside the new paper format bounds
          const fitScale = Math.min(
            targetW / originalViewport.width,
            targetH / originalViewport.height
          );
          
          const viewport = page.getViewport({ scale: fitScale });
          
          // Center the PDF in the canvas
          const offsetX = (targetW - viewport.width) / 2;
          const offsetY = (targetH - viewport.height) / 2;

          const renderContext = {
            canvasContext: ctx,
            viewport: viewport,
            transform: [1, 0, 0, 1, offsetX, offsetY]
          };
          await page.render(renderContext).promise;
          const detectedFmt = detectPaperFormat(pageDimensions.width, pageDimensions.height);
          if (detectedFmt === 'A0') {
            console.log(`[Diagnostic Log] Right after canvas render: canvas.width=${canvas.width}, canvas.height=${canvas.height}, canvas.clientWidth=${canvas.clientWidth}, canvas.clientHeight=${canvas.clientHeight}`);
          }
          return;
        } catch (err) {
          console.warn('pdfjs-dist page render failed, using fallback preview canvas:', err);
        }
      }

      // Fallback Canvas Renderer if pdfjs worker is blocked
      if (isMounted) {
        const w = pageDimensions.width * zoomScale;
        const h = pageDimensions.height * zoomScale;
        canvas.width = w;
        canvas.height = h;

        // Paper Background
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, w, h);

        // Document Header Mockup
        ctx.fillStyle = '#1e293b';
        ctx.font = `bold ${16 * zoomScale}px sans-serif`;
        ctx.fillText(`DOCUMENT PREVIEW — Page ${currentPage} of ${totalPages}`, 30 * zoomScale, 50 * zoomScale);

        ctx.fillStyle = '#64748b';
        ctx.font = `${11 * zoomScale}px sans-serif`;
        ctx.fillText(`File: ${fileItem.name}`, 30 * zoomScale, 72 * zoomScale);

        // Document Lines
        ctx.fillStyle = '#e2e8f0';
        for (let y = 110; y < h - 120; y += 22 * zoomScale) {
          ctx.fillRect(30 * zoomScale, y, w - 60 * zoomScale, 8 * zoomScale);
        }

        // Footer Zone
        ctx.fillStyle = '#cbd5e1';
        ctx.fillRect(30 * zoomScale, h - 80 * zoomScale, w - 60 * zoomScale, 1 * zoomScale);
        ctx.fillStyle = '#94a3b8';
        ctx.font = `${10 * zoomScale}px sans-serif`;
        ctx.fillText(`Official Auto-Signer Stream Document Page ${currentPage}`, 30 * zoomScale, h - 50 * zoomScale);

        const detectedFmt = detectPaperFormat(pageDimensions.width, pageDimensions.height);
        if (detectedFmt === 'A0') {
          console.log(`[Diagnostic Log] Right after canvas render: canvas.width=${canvas.width}, canvas.height=${canvas.height}, canvas.clientWidth=${canvas.clientWidth}, canvas.clientHeight=${canvas.clientHeight}`);
        }
      }
    };

    renderPage();

    return () => {
      isMounted = false;
    };
  }, [pdfJsDoc, currentPage, zoomScale, isOpen, fileItem, totalPages]);

  if (!isOpen || !fileItem) return null;

  const isSignedDocument = fileItem.status === 'success' || !!fileItem.signedBuffer;

  // Determine if signature stamp applies to CURRENT preview page
  const isSignatureOnCurrentPage = () => {
    if (pageSelectionMode === 'all') return true;
    if (pageSelectionMode === 'first-and-last') return currentPage === 1 || currentPage === totalPages;
    if (pageSelectionMode === 'smart' || pageSelectionMode === 'page-1') return currentPage === 1;
    if (pageSelectionMode === 'custom') {
      const targetPages = customPageInput
        .split(',')
        .map(p => parseInt(p.trim()))
        .filter(p => !isNaN(p));
      return targetPages.includes(currentPage);
    }
    return false;
  };

  const shouldSignCurrent = isSignatureOnCurrentPage();

  const handleModeChange = (mode: 'smart' | 'page-1' | 'custom' | 'first-and-last' | 'all') => {
    setPageSelectionMode(mode);
    onUpdatePageSelection(fileItem.id, mode, customPageInput);
  };

  const handleCustomPageInputChange = (val: string) => {
    setCustomPageInput(val);
    onUpdatePageSelection(fileItem.id, 'custom', val);
  };

  const handleSizePresetChange = (preset: SignatureSizePreset) => {
    setSigSizePreset(preset);
    if (onUpdateSignatureSize) {
      onUpdateSignatureSize(fileItem.id, preset, sigCustomScale);
    }
  };

  const handleCustomScaleChange = (val: number) => {
    setSigCustomScale(val);
    if (onUpdateSignatureSize) {
      onUpdateSignatureSize(fileItem.id, 'custom', val);
    }
  };

  // Calculate overlay pixel bounds on canvas
  const canvasEl = canvasRef.current;
  const canvasWidth = canvasEl?.width || 595 * zoomScale * 1.2;
  const canvasHeight = canvasEl?.height || 842 * zoomScale * 1.2;

  const scaleX = canvasWidth / Math.max(1, pageDimensions.width);
  const scaleY = canvasHeight / Math.max(1, pageDimensions.height);

  const pxWidth = placementResult ? placementResult.width * scaleX : 150;
  const pxHeight = placementResult ? placementResult.height * scaleY : 70;

  // Derive center coordinates for visual overlay positioning
  let centerXPx = 0;
  let centerYPx = 0;

  if (manualPosPx) {
    centerXPx = manualPosPx.x + pxWidth / 2;
    centerYPx = manualPosPx.y + pxHeight / 2;
  } else if (placementResult) {
    // placementResult.x is the anchor (bottom-left)
    // We need the center for CSS rotate to behave identically to UI template editor
    const pdfCenterX = placementResult.x + (placementResult.width / 2);
    const pdfCenterYFromBottom = placementResult.y + (placementResult.height / 2);
    
    centerXPx = pdfCenterX * scaleX;
    centerYPx = (pageDimensions.height - pdfCenterYFromBottom) * scaleY;
  }

  return (
    <div className={`flex-1 flex flex-col overflow-hidden text-slate-100 ${
      isRoseVelvet ? 'bg-[#2e0514]' : 'bg-slate-900'
    }`}>
        {/* Pane Header */}
        <div className={`px-4 py-3 border-b flex items-center justify-between shrink-0 ${
          isRoseVelvet ? 'bg-[#831843] border-[#fbcfe8]/25' : 'bg-gradient-to-r from-blue-950 via-slate-900 to-blue-950 border-blue-500/30'
        }`}>
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl text-white shadow-md ${
              isRoseVelvet ? 'bg-[#ec4899] shadow-pink-500/30' : 'bg-blue-600 shadow-blue-600/30'
            }`}>
              <Eye className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white flex items-center gap-2 flex-wrap">
                Document Previewer
                <span className={`text-[10px] px-2 py-0.5 rounded border font-mono max-w-[200px] truncate ${
                  isRoseVelvet ? 'bg-[#ec4899]/25 text-[#fbcfe8] border-[#ec4899]/40' : 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                }`}>
                  {fileItem.name}
                </span>
                {isSignedDocument && (
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 px-2 py-0.5 rounded text-[10px] font-black flex items-center gap-1 shrink-0">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    ACTUAL SIGNED PDF
                  </span>
                )}
              </h3>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {filesList && filesList.length > 1 && (
              <div className={`flex items-center gap-1 px-2.5 py-1 rounded-xl border ${
                isRoseVelvet ? 'bg-[#4d0c24] border-[#ec4899]/30 text-pink-200' : 'bg-slate-800 border-slate-700 text-slate-200'
              }`}>
                <button
                  type="button"
                  onClick={onSelectPrevious}
                  disabled={!onSelectPrevious || currentIndex === 0}
                  className="p-1 rounded hover:bg-black/30 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer"
                  title="Previous Document in Queue"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-[11px] font-bold font-mono px-1">
                  {(currentIndex ?? 0) + 1} / {filesList.length}
                </span>
                <button
                  type="button"
                  onClick={onSelectNext}
                  disabled={!onSelectNext || currentIndex === filesList.length - 1}
                  className="p-1 rounded hover:bg-black/30 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer"
                  title="Next Document in Queue"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {isSignedDocument && fileItem.signedBuffer && (
              <button
                onClick={() => {
                  const blob = new Blob([fileItem.signedBuffer!], { type: 'application/pdf' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `Signed_${fileItem.name}`;
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                }}
                className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-[11px] flex items-center gap-1 shadow-md transition-all cursor-pointer shrink-0"
                title="Download this signed PDF"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Download Signed PDF</span>
              </button>
            )}
            <button
              onClick={onClose}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer border flex items-center gap-1.5 text-xs font-extrabold ${
                isRoseVelvet ? 'bg-[#4d0c24] hover:bg-[#831843] text-[#fbcfe8] border-[#fbcfe8]/30' : 'bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border-slate-700'
              }`}
              title="Exit Previewer"
            >
              <X className="w-4 h-4" />
              <span>Exit Preview</span>
            </button>
          </div>
        </div>

        {/* Modal Content Grid */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 xl:grid-cols-3 gap-0">
          
          {/* Main Document Viewer Canvas Area (Cols 2) */}
          <div className={`lg:col-span-2 p-4 flex flex-col justify-between overflow-hidden relative border-b lg:border-b-0 lg:border-r ${
            isRoseVelvet ? 'bg-[#2e0514] border-[#fbcfe8]/20' : 'bg-slate-950 border-slate-800'
          }`}>
            
            {/* Paper Format Preview Selector Tab Bar */}
            <div className={`flex items-center gap-1 overflow-x-auto border px-3 py-1.5 rounded-xl text-xs shrink-0 mb-2 z-10 custom-scrollbar ${
              isRoseVelvet ? 'bg-[#4d0c24]/90 border-[#fbcfe8]/20' : 'bg-slate-900/90 border-slate-800'
            }`}>
              <span className={`text-[10px] font-bold mr-1 uppercase tracking-wider shrink-0 ${isRoseVelvet ? 'text-[#fbcfe8]/80' : 'text-slate-400'}`}>Paper Format Preview:</span>
              {(['A0', 'A1', 'A2', 'A3', 'A4', 'A5', 'Letter', 'Legal', 'Tabloid', 'Executive', 'Arch A', 'Arch B', 'Custom'] as PageFormat[]).map((fmt) => {
                const active = (overrideFormat || placementResult?.pageFormat) === fmt;
                return (
                  <button
                    key={fmt}
                    onClick={() => handleOverrideFormat(fmt)}
                    className={`px-2 py-0.5 rounded font-extrabold text-[10px] transition-all cursor-pointer shrink-0 border ${
                      active 
                        ? (isRoseVelvet ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 text-white border-[#fbcfe8]' : 'bg-blue-600 text-white border-blue-400 shadow-sm')
                        : (isRoseVelvet ? 'bg-[#2e0514] text-[#fbcfe8]/60 border-[#fbcfe8]/10 hover:text-white' : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white')
                    }`}
                  >
                    {fmt}
                  </button>
                );
              })}
            </div>

            {/* Viewer Toolbar */}
            <div className={`flex items-center justify-between border px-3 py-2 rounded-xl text-xs font-bold shrink-0 mb-3 z-10 ${
              isRoseVelvet ? 'bg-[#4d0c24]/90 border-[#fbcfe8]/25' : 'bg-slate-900/90 border-slate-800'
            }`}>
              <div className="flex items-center gap-2">
                <button
                  disabled={currentPage <= 1}
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  className={`p-1.5 rounded-lg disabled:opacity-40 cursor-pointer ${
                    isRoseVelvet ? 'bg-[#831843] text-[#fbcfe8] hover:bg-[#b01e5d]' : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                  }`}
                  title="Previous Page"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className={`font-mono ${isRoseVelvet ? 'text-[#fbcfe8]' : 'text-blue-300'}`}>
                  Page {currentPage} of {totalPages}
                </span>
                <button
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  className={`p-1.5 rounded-lg disabled:opacity-40 cursor-pointer ${
                    isRoseVelvet ? 'bg-[#831843] text-[#fbcfe8] hover:bg-[#b01e5d]' : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                  }`}
                  title="Next Page"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Status Badge for Current Page & Format */}
              <div className="flex items-center gap-2">
                {placementResult?.pageFormat && (
                  <span className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold flex items-center gap-1.5 border shadow-sm ${
                    ['A0', 'A1', 'A2', 'A3', 'Tabloid', 'Arch A', 'Arch B'].includes(placementResult.pageFormat)
                      ? (isRoseVelvet ? 'bg-rose-950/90 text-rose-200 border-rose-500/60' : 'bg-purple-950/90 text-purple-200 border-purple-500/60')
                      : (isRoseVelvet ? 'bg-pink-950/90 text-pink-200 border-pink-500/60' : 'bg-cyan-950/90 text-cyan-200 border-cyan-500/60')
                  }`}>
                    <Maximize2 className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-[#fbcfe8]' : 'text-cyan-300'}`} />
                    Format: {placementResult.pageFormat} ({Math.round(pageDimensions.width)}x{Math.round(pageDimensions.height)} pt)
                  </span>
                )}

                {shouldSignCurrent ? (
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-extrabold flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Stamped on Page {currentPage}
                  </span>
                ) : (
                  <span className={`px-2.5 py-1 rounded-lg border text-[11px] font-semibold flex items-center gap-1.5 ${
                    isRoseVelvet ? 'bg-[#2e0514] text-[#fbcfe8]/40 border-[#fbcfe8]/15' : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}>
                    <AlertCircle className="w-3.5 h-3.5 text-slate-500" />
                    Page {currentPage} Skipped
                  </span>
                )}

                <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${
                  isRoseVelvet ? 'bg-[#831843]/60' : 'bg-slate-800'
                }`}>
                  <button
                    onClick={() => setZoomScale((z) => Math.max(0.6, z - 0.1))}
                    className={`p-0.5 cursor-pointer ${isRoseVelvet ? 'hover:text-[#fbcfe8]' : 'hover:text-cyan-300'}`}
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <span className={`text-[10px] font-mono ${isRoseVelvet ? 'text-[#fbcfe8]' : 'text-slate-300'}`}>{Math.round(zoomScale * 100)}%</span>
                  <button
                    onClick={() => setZoomScale((z) => Math.min(1.8, z + 0.1))}
                    className={`p-0.5 cursor-pointer ${isRoseVelvet ? 'hover:text-[#fbcfe8]' : 'hover:text-cyan-300'}`}
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Actual Signed Document Banner */}
            {isSignedDocument && (
              <div className="bg-emerald-950/90 border border-emerald-500/60 text-emerald-200 px-3.5 py-2 rounded-xl text-xs flex items-center justify-between shrink-0 mb-2 shadow-lg z-10">
                <div className="flex items-center gap-2 font-bold">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Actual Signed Document PDF Preview</span>
                </div>
                <span className="text-[10px] font-semibold text-emerald-300/90 bg-emerald-900/60 px-2.5 py-0.5 rounded border border-emerald-500/40 font-mono">
                  Cryptographically Sealed & Certified
                </span>
              </div>
            )}

            {/* Canvas Scrollable Box */}
            <div className={`flex-1 overflow-auto flex items-center justify-center p-2 relative rounded-xl border ${
              isRoseVelvet ? 'bg-[#2e0514]/80 border-[#fbcfe8]/15' : 'bg-slate-950/80 border-slate-800/80'
            }`}>
              {isLoadingPdf ? (
                <div className={`flex flex-col items-center gap-3 py-12 ${isRoseVelvet ? 'text-[#ec4899]' : 'text-blue-400'}`}>
                  <Loader2 className="w-8 h-8 animate-spin" />
                  <p className={`text-xs font-bold ${isRoseVelvet ? 'text-[#fbcfe8]/80' : 'text-slate-300'}`}>Rendering document pages...</p>
                </div>
              ) : (
                <div className={`relative inline-block shadow-2xl rounded border bg-white ${isRoseVelvet ? 'border-[#fbcfe8]/20' : 'border-slate-700'}`}>
                  <canvas ref={canvasRef} className="max-w-full h-auto block rounded" />

                  {/* Exact Live Interactive Signature Overlay Box (for pending/pre-sign documents) */}
                  {shouldSignCurrent && placementResult && !isSignedDocument && (
                    <div 
                      style={{
                        left: `${centerXPx}px`,
                        top: `${centerYPx}px`,
                        width: `${pxWidth}px`,
                        height: `${pxHeight}px`,
                        transform: `translate(-50%, -50%) rotate(${placementResult.rotationDegrees || 0}deg)`,
                        opacity: placementResult.isTextOverlayFallback ? (placementResult.opacity ?? 0.85) : 1.0,
                        cursor: isDragging ? 'grabbing' : 'grab',
                        touchAction: 'none',
                      }}
                      onPointerDown={handlePointerDown}
                      onPointerMove={handlePointerMove}
                      onPointerUp={handlePointerUp}
                      onPointerCancel={handlePointerUp}
                      className={`absolute p-1 rounded-lg border-2 shadow-2xl backdrop-blur-[2px] ${!isDragging ? 'transition-all' : ''} flex flex-col items-center justify-between z-20 group ${
                        placementResult.isTextOverlayFallback
                          ? 'bg-amber-500/20 border-amber-400'
                          : (isRoseVelvet ? 'bg-[#ec4899]/20 border-[#ec4899]' : 'bg-blue-600/20 border-cyan-400')
                      }`}
                    >
                      {/* Live Signature Graphic */}
                      {signatureDataUrl ? (
                        <div className={`w-full h-full flex items-center justify-center p-0.5 bg-white/85 rounded border overflow-hidden ${isRoseVelvet ? 'border-[#fbcfe8]/40' : 'border-blue-300/60'}`}>
                          <img 
                            src={signatureDataUrl} 
                            alt="Signature Stamp" 
                            className="max-w-full max-h-full object-contain" 
                          />
                        </div>
                      ) : (
                        <div className={`w-full h-full border border-dashed rounded flex items-center justify-center text-[10px] font-black ${
                          isRoseVelvet ? 'border-[#fbcfe8]/60 bg-[#4d0c24]/80 text-[#fbcfe8]' : 'border-cyan-300 bg-blue-900/60 text-cyan-200'
                        }`}>
                          [ Signature Stamp ]
                        </div>
                      )}

                      {/* Floating Placement Info Badges */}
                      <div className="absolute -bottom-7 left-1/2 -translate-x-1/2 whitespace-nowrap flex items-center gap-1 z-30">
                        {/* Format Badge */}
                        <span className={`text-[9px] font-black px-2 py-0.5 rounded-md shadow-md flex items-center gap-1 font-mono border ${
                          ['A0', 'A1', 'A2', 'A3', 'Tabloid', 'Arch A', 'Arch B'].includes(placementResult.pageFormat)
                            ? (isRoseVelvet ? 'bg-rose-950/95 text-rose-200 border-rose-500/60' : 'bg-purple-950/95 text-purple-200 border-purple-500/60')
                            : (isRoseVelvet ? 'bg-pink-950/95 text-pink-200 border-pink-500/60' : 'bg-cyan-950/95 text-cyan-200 border-cyan-500/60')
                        }`}>
                          {placementResult.pageFormat} {placementResult.isLandscape ? '(Landscape)' : ''}
                        </span>

                        {placementResult.rotationDegrees ? (
                          <span className={`text-[9px] font-black border px-2 py-0.5 rounded-md shadow-md flex items-center gap-1 font-mono ${
                            isRoseVelvet ? 'bg-[#4d0c24]/95 text-[#fbcfe8] border-[#ec4899]/60' : 'bg-purple-950/95 text-purple-200 border-purple-500/60'
                          }`}>
                            <RefreshCw className="w-3 h-3" />
                            ↻ {placementResult.rotationDegrees}° Rotated
                          </span>
                        ) : null}

                        {placementResult.isTextOverlayFallback ? (
                          <span className={`text-[9px] font-black border px-2 py-0.5 rounded-md shadow-md flex items-center gap-1 font-mono ${
                            isRoseVelvet ? 'bg-[#2e0514]/95 text-amber-300 border-amber-500/60' : 'bg-slate-950/95 text-amber-300 border-amber-500/60'
                          }`}>
                            <Layers className="w-3 h-3 text-amber-400" />
                            Text Overlay Fallback (Opacity: {Math.round((placementResult.opacity || 0.85) * 100)}%)
                          </span>
                        ) : (
                          <span className={`text-[9px] font-black border px-2 py-0.5 rounded-md shadow-md flex items-center gap-1 font-mono ${
                            isRoseVelvet ? 'bg-[#4d0c24]/95 text-pink-200 border-[#ec4899]/60' : 'bg-slate-950/95 text-emerald-300 border-emerald-500/60'
                          }`}>
                            <Sparkles className="w-3 h-3" />
                            Clean Gap: {placementResult.cornerName} ({Math.round(placementResult.width)}pt)
                          </span>
                        )}

                        {placementResult.autoShrunk && (
                          <span className={`text-[9px] font-black border px-2 py-0.5 rounded-md shadow-md flex items-center gap-1 ${
                            isRoseVelvet ? 'bg-rose-950/90 text-amber-300 border-amber-500/50' : 'bg-amber-950/90 text-amber-300 border-amber-500/50'
                          }`}>
                            <Zap className="w-3 h-3" />
                            Auto-Shrunk ({Math.round(placementResult.scaleApplied * 100)}%)
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Quick Page Jump Slider */}
            <div className={`mt-3 flex items-center gap-3 px-4 py-2 rounded-xl border text-xs shrink-0 ${
              isRoseVelvet ? 'bg-[#4d0c24] border-[#fbcfe8]/20' : 'bg-slate-900 border-slate-800'
            }`}>
              <span className={`${isRoseVelvet ? 'text-[#fbcfe8]/80' : 'text-slate-400'} font-medium`}>Page Navigation:</span>
              <input
                type="range"
                min={1}
                max={totalPages}
                value={currentPage}
                onChange={(e) => setCurrentPage(parseInt(e.target.value) || 1)}
                className={`flex-1 cursor-pointer ${isRoseVelvet ? 'accent-[#ec4899]' : 'accent-blue-500'}`}
              />
              <span className={`font-mono font-bold ${isRoseVelvet ? 'text-[#fbcfe8]' : 'text-cyan-300'}`}>{currentPage} / {totalPages}</span>
            </div>

          </div>

          {/* Right Panel: Signature Controls & Options (Col 1) */}
          <div className={`p-5 flex flex-col justify-between space-y-5 overflow-y-auto ${
            isRoseVelvet ? 'bg-[#4d0c24] border-l border-[#fbcfe8]/20' : 'bg-slate-900'
          }`}>
            
            <div className="space-y-5">
              
              {/* 1. SIGNATURE SIZE CONTROLS */}
              <div className={`space-y-3 pb-4 border-b ${isRoseVelvet ? 'border-[#fbcfe8]/15' : 'border-slate-800'}`}>
                <div className="flex items-center gap-2">
                  <Maximize2 className={`w-4 h-4 ${isRoseVelvet ? 'text-[#f472b6]' : 'text-cyan-400'}`} />
                  <h4 className="text-sm font-extrabold text-white">Signature Size</h4>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {/* Medium */}
                  <button
                    onClick={() => handleSizePresetChange('medium')}
                    className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                      sigSizePreset === 'medium'
                        ? (isRoseVelvet ? 'bg-[#ec4899]/30 border-[#ec4899] text-white shadow-md' : 'bg-blue-600/30 border-cyan-400 text-white shadow-md')
                        : (isRoseVelvet ? 'bg-[#2e0514]/60 border-[#fbcfe8]/15 text-[#fbcfe8]/80 hover:border-[#ec4899]/50' : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700')
                    }`}
                  >
                    <p className="text-xs font-black">Medium</p>
                    <p className={`text-[10px] font-mono ${isRoseVelvet ? 'text-[#fbcfe8]/60' : 'text-slate-400'}`}>~150px (Default)</p>
                  </button>

                  {/* Large */}
                  <button
                    onClick={() => handleSizePresetChange('large')}
                    className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                      sigSizePreset === 'large'
                        ? (isRoseVelvet ? 'bg-[#ec4899]/30 border-[#ec4899] text-white shadow-md' : 'bg-blue-600/30 border-cyan-400 text-white shadow-md')
                        : (isRoseVelvet ? 'bg-[#2e0514]/60 border-[#fbcfe8]/15 text-[#fbcfe8]/80 hover:border-[#ec4899]/50' : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700')
                    }`}
                  >
                    <p className={`text-xs font-black ${isRoseVelvet ? 'text-pink-200' : 'text-cyan-200'}`}>Large</p>
                    <p className={`text-[10px] font-mono ${isRoseVelvet ? 'text-[#fbcfe8]/60' : 'text-slate-400'}`}>~250px Width</p>
                  </button>

                  {/* Extra Large */}
                  <button
                    onClick={() => handleSizePresetChange('xlarge')}
                    className={`col-span-2 p-2.5 rounded-xl border text-left cursor-pointer transition-all flex items-center justify-between ${
                      sigSizePreset === 'xlarge'
                        ? (isRoseVelvet ? 'bg-gradient-to-r from-rose-600/40 to-pink-600/40 border-[#ec4899] text-white shadow-md' : 'bg-gradient-to-r from-blue-600/40 to-cyan-600/40 border-cyan-400 text-white shadow-md')
                        : (isRoseVelvet ? 'bg-[#2e0514]/60 border-[#fbcfe8]/15 text-[#fbcfe8]/80 hover:border-[#ec4899]/50' : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700')
                    }`}
                  >
                    <div>
                      <p className={`text-xs font-black flex items-center gap-1.5 ${isRoseVelvet ? 'text-pink-200' : 'text-cyan-100'}`}>
                        <Sparkles className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-[#f472b6]' : 'text-cyan-300'}`} />
                        Extra Large (Full Page Dominant)
                      </p>
                      <p className={`text-[10px] font-mono mt-0.5 ${isRoseVelvet ? 'text-[#fbcfe8]/60' : 'text-slate-400'}`}>~350px Prominent Stamp</p>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                      isRoseVelvet ? 'bg-[#ec4899]/20 text-[#fbcfe8] border-[#ec4899]/30' : 'bg-cyan-500/20 text-cyan-300 border-cyan-400/30'
                    }`}>
                      XL 350px
                    </span>
                  </button>
                </div>

                {/* Custom Percentage Slider */}
                <div className="pt-2">
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-xs font-bold flex items-center gap-1.5 ${isRoseVelvet ? 'text-[#fbcfe8]' : 'text-slate-300'}`}>
                      <Sliders className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-[#f472b6]' : 'text-cyan-400'}`} />
                      Custom Scale:
                    </span>
                    <span className={`text-xs font-mono font-bold ${isRoseVelvet ? 'text-[#fbcfe8]' : 'text-cyan-300'}`}>{sigCustomScale}%</span>
                  </div>
                  <input
                    type="range"
                    min={50}
                    max={200}
                    step={5}
                    value={sigCustomScale}
                    onChange={(e) => {
                      handleSizePresetChange('custom');
                      handleCustomScaleChange(parseInt(e.target.value) || 100);
                    }}
                    className={`w-full cursor-pointer ${isRoseVelvet ? 'accent-[#ec4899]' : 'accent-cyan-400'}`}
                  />
                  <div className={`flex items-center justify-between text-[9px] font-mono mt-1 ${isRoseVelvet ? 'text-[#fbcfe8]/40' : 'text-slate-500'}`}>
                    <span>50% (Compact)</span>
                    <span>100% (Base)</span>
                    <span>200% (Maximum)</span>
                  </div>
                </div>
              </div>

              {/* 2. SMART GAP & ANTI-OVERLAP STATUS */}
              {placementResult && (
                <div className={`p-3 rounded-xl border space-y-2 ${
                  placementResult.cleanGapFound
                    ? (isRoseVelvet ? 'bg-[#2e0514] border-emerald-500/30' : 'bg-slate-950 border-emerald-500/30')
                    : (isRoseVelvet ? 'bg-[#2e0514] border-amber-500/30' : 'bg-slate-950 border-amber-500/30')
                }`}>
                  <div className="flex items-center justify-between text-xs">
                    <span className={`font-bold flex items-center gap-1.5 ${isRoseVelvet ? 'text-[#fbcfe8]' : 'text-slate-300'}`}>
                      {placementResult.cleanGapFound ? (
                        <>
                          <ShieldCheck className="w-4 h-4 text-emerald-400" />
                          Clean Gap Anchored:
                        </>
                      ) : (
                        <>
                          <Layers className="w-4 h-4 text-amber-400" />
                          Text Overlay Fallback:
                        </>
                      )}
                    </span>
                    <span className={`font-mono font-extrabold ${isRoseVelvet ? 'text-pink-200' : 'text-cyan-300'}`}>{placementResult.cornerName}</span>
                  </div>

                  {/* Paper Format Specific Rule Info Box */}
                  <div className={`p-2 rounded-lg border text-[11px] space-y-1 ${
                    isRoseVelvet ? 'bg-[#4d0c24] border-[#fbcfe8]/15' : 'bg-slate-900 border-slate-800'
                  }`}>
                    <div className="flex items-center justify-between font-bold text-slate-200">
                      <span className={`flex items-center gap-1 ${isRoseVelvet ? 'text-[#fbcfe8]' : 'text-cyan-300'}`}>
                        <Maximize2 className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-[#f472b6]' : 'text-cyan-400'}`} />
                        Paper Format Rule: {placementResult.pageFormat}
                      </span>
                      <span className={`text-[10px] font-mono ${isRoseVelvet ? 'text-[#fbcfe8]/60' : 'text-slate-400'}`}>{Math.round(pageDimensions.width)}pt × {Math.round(pageDimensions.height)}pt</span>
                    </div>
                    <p className={`text-[10.5px] leading-snug ${isRoseVelvet ? 'text-[#fbcfe8]/80' : 'text-slate-300'}`}>
                      {placementResult.pageFormat === 'A4' ? (
                        <span>
                          📌 <strong>A4 Rule Active:</strong> Forced top-of-page placement in header area so the signature sits clearly at the top of standard A4 documents.
                        </span>
                      ) : ['A0', 'A1', 'A2', 'A3', 'Tabloid', 'Arch A', 'Arch B'].includes(placementResult.pageFormat) ? (
                        <span>
                          📐 <strong>Architectural Drawing Rule Active:</strong> Signature positioned on left side with 90° clockwise rotation and exact 2″ (~144pt) left & 2″ (~144pt) bottom margin offset.
                        </span>
                      ) : (
                        <span>
                          📄 Standard format smart whitespace placement applied.
                        </span>
                      )}
                    </p>
                  </div>

                  <p className={`text-[11px] leading-relaxed ${isRoseVelvet ? 'text-[#fbcfe8]/60' : 'text-slate-400'}`}>
                    {placementResult.cleanGapFound ? (
                      <span className="text-emerald-400 font-medium">
                        ✨ 100% clean white-space gap detected ({placementResult.cornerName}). Signature anchored neatly without touching document text.
                      </span>
                    ) : (
                      <span className="text-amber-300 font-medium">
                        📄 No clear whitespace gap found in header/margin. Applied Text Overlay Fallback with {Math.round((placementResult.opacity || 0.85) * 100)}% opacity so underlying text remains legible.
                      </span>
                    )}
                  </p>

                  {placementResult.autoShrunk && (
                    <div className="p-2 rounded bg-amber-500/10 border border-amber-500/30 text-[10px] text-amber-200 flex items-start gap-1.5 font-sans">
                      <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                      <span>
                        <strong>Dynamic Auto-Shrink Active:</strong> Scaled to{' '}
                        <strong className="text-white">{Math.round(placementResult.scaleApplied * 100)}%</strong> to fit cleanly inside empty margin space.
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* 3. PAGE STAMPING RULES */}
              <div className="space-y-3">
                <div className={`flex items-center gap-2 pb-2 border-b ${isRoseVelvet ? 'border-[#fbcfe8]/15' : 'border-slate-800'}`}>
                  <FileSignature className={`w-4 h-4 ${isRoseVelvet ? 'text-[#f472b6]' : 'text-cyan-400'}`} />
                  <h4 className="text-sm font-extrabold text-white">Target Pages</h4>
                </div>

                <div className="space-y-2">
                  {/* Smart Auto */}
                  <button
                    onClick={() => handleModeChange('smart')}
                    className={`w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                      pageSelectionMode === 'smart'
                        ? (isRoseVelvet ? 'bg-[#ec4899]/20 border-[#ec4899] text-white' : 'bg-blue-600/20 border-cyan-400 text-white')
                        : (isRoseVelvet ? 'bg-[#2e0514]/60 border-[#fbcfe8]/15 text-[#fbcfe8]/80 hover:border-[#ec4899]/50' : 'bg-slate-950/60 border-slate-800 text-slate-300')
                    }`}
                  >
                    <div className={`mt-0.5 w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${
                      pageSelectionMode === 'smart'
                        ? (isRoseVelvet ? 'border-[#ec4899] bg-[#ec4899]' : 'border-cyan-400 bg-cyan-400')
                        : 'border-slate-600'
                    }`}>
                      {pageSelectionMode === 'smart' && <div className={`w-1 h-1 rounded-full ${isRoseVelvet ? 'bg-white' : 'bg-slate-950'}`} />}
                    </div>
                    <div>
                      <p className="text-xs font-bold flex items-center gap-1">
                        <Sparkles className={`w-3 h-3 ${isRoseVelvet ? 'text-[#f472b6]' : 'text-cyan-300'}`} />
                        Smart Auto (Gap Detect on Page 1)
                      </p>
                    </div>
                  </button>

                  {/* Page 1 Only */}
                  <button
                    onClick={() => handleModeChange('page-1')}
                    className={`w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                      pageSelectionMode === 'page-1'
                        ? (isRoseVelvet ? 'bg-[#ec4899]/20 border-[#ec4899] text-white' : 'bg-blue-600/20 border-cyan-400 text-white')
                        : (isRoseVelvet ? 'bg-[#2e0514]/60 border-[#fbcfe8]/15 text-[#fbcfe8]/80 hover:border-[#ec4899]/50' : 'bg-slate-950/60 border-slate-800 text-slate-300')
                    }`}
                  >
                    <div className={`mt-0.5 w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${
                      pageSelectionMode === 'page-1'
                        ? (isRoseVelvet ? 'border-[#ec4899] bg-[#ec4899]' : 'border-cyan-400 bg-cyan-400')
                        : 'border-slate-600'
                    }`}>
                      {pageSelectionMode === 'page-1' && <div className={`w-1 h-1 rounded-full ${isRoseVelvet ? 'bg-white' : 'bg-slate-950'}`} />}
                    </div>
                    <p className="text-xs font-bold">Page 1 Only</p>
                  </button>

                  {/* First & Last Page */}
                  <button
                    onClick={() => handleModeChange('first-and-last')}
                    className={`w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                      pageSelectionMode === 'first-and-last'
                        ? (isRoseVelvet ? 'bg-[#ec4899]/20 border-[#ec4899] text-white' : 'bg-blue-600/20 border-cyan-400 text-white')
                        : (isRoseVelvet ? 'bg-[#2e0514]/60 border-[#fbcfe8]/15 text-[#fbcfe8]/80 hover:border-[#ec4899]/50' : 'bg-slate-950/60 border-slate-800 text-slate-300')
                    }`}
                  >
                    <div className={`mt-0.5 w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${
                      pageSelectionMode === 'first-and-last'
                        ? (isRoseVelvet ? 'border-[#ec4899] bg-[#ec4899]' : 'border-cyan-400 bg-cyan-400')
                        : 'border-slate-600'
                    }`}>
                      {pageSelectionMode === 'first-and-last' && <div className={`w-1 h-1 rounded-full ${isRoseVelvet ? 'bg-white' : 'bg-slate-950'}`} />}
                    </div>
                    <p className="text-xs font-bold">First & Last Page</p>
                  </button>

                  {/* Specific Pages */}
                  <div
                    className={`w-full p-2.5 rounded-xl border transition-all flex flex-col gap-2 ${
                      pageSelectionMode === 'custom'
                        ? (isRoseVelvet ? 'bg-[#ec4899]/20 border-[#ec4899] text-white' : 'bg-blue-600/20 border-cyan-400 text-white')
                        : (isRoseVelvet ? 'bg-[#2e0514]/60 border-[#fbcfe8]/15 text-[#fbcfe8]/80 hover:border-[#ec4899]/50' : 'bg-slate-950/60 border-slate-800 text-slate-300')
                    }`}
                  >
                    <button
                      onClick={() => handleModeChange('custom')}
                      className="w-full text-left flex items-start gap-2.5 cursor-pointer"
                    >
                      <div className={`mt-0.5 w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${
                        pageSelectionMode === 'custom'
                          ? (isRoseVelvet ? 'border-[#ec4899] bg-[#ec4899]' : 'border-cyan-400 bg-cyan-400')
                          : 'border-slate-600'
                      }`}>
                        {pageSelectionMode === 'custom' && <div className={`w-1 h-1 rounded-full ${isRoseVelvet ? 'bg-white' : 'bg-slate-950'}`} />}
                      </div>
                      <p className="text-xs font-bold">Specific Pages (e.g. 1,2,5)</p>
                    </button>
                    {pageSelectionMode === 'custom' && (
                      <input
                        type="text"
                        placeholder="e.g. 1, 2, 5"
                        value={customPageInput}
                        onChange={(e) => handleCustomPageInputChange(e.target.value)}
                        className="ml-6 px-2.5 py-1 rounded-lg bg-slate-900 border border-cyan-500/50 text-cyan-200 text-xs font-mono focus:outline-none"
                      />
                    )}
                  </div>

                  {/* All Pages */}
                  <button
                    onClick={() => handleModeChange('all')}
                    className={`w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                      pageSelectionMode === 'all'
                        ? (isRoseVelvet ? 'bg-[#ec4899]/20 border-[#ec4899] text-white' : 'bg-blue-600/20 border-cyan-400 text-white')
                        : (isRoseVelvet ? 'bg-[#2e0514]/60 border-[#fbcfe8]/15 text-[#fbcfe8]/80 hover:border-[#ec4899]/50' : 'bg-slate-950/60 border-slate-800 text-slate-300')
                    }`}
                  >
                    <div className={`mt-0.5 w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${
                      pageSelectionMode === 'all'
                        ? (isRoseVelvet ? 'border-[#ec4899] bg-[#ec4899]' : 'border-cyan-400 bg-cyan-400')
                        : 'border-slate-600'
                    }`}>
                      {pageSelectionMode === 'all' && <div className={`w-1 h-1 rounded-full ${isRoseVelvet ? 'bg-white' : 'bg-slate-950'}`} />}
                    </div>
                    <p className="text-xs font-bold">All Pages ({totalPages} Pages)</p>
                  </button>
                </div>
              </div>

            </div>

            {/* Bottom Actions */}
            <div className={`pt-3 border-t space-y-2 ${isRoseVelvet ? 'border-[#fbcfe8]/15' : 'border-slate-800'}`}>
              <button
                onClick={onClose}
                className={`w-full py-2.5 rounded-xl font-extrabold text-xs transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  isRoseVelvet 
                    ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 hover:from-rose-500 hover:to-pink-500 text-white shadow-lg shadow-rose-600/30' 
                    : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/30'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                Done & Apply Settings
              </button>
            </div>

          </div>
        </div>
      </div>
  );
};
