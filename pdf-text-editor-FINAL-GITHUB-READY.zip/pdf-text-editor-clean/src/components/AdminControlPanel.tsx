import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import {
  Shield,
  Type,
  PenTool,
  Image as ImageIcon,
  Sliders,
  Lock,
  RotateCcw,
  Save,
  Check,
  CheckCircle2,
  ShieldCheck,
  FileSignature,
  Plus,
  Trash2,
  ChevronUp,
  ChevronDown,
  ArrowLeft,
  Eye,
  EyeOff,
  Sparkles,
  FileText,
  UserCheck,
  Phone,
  Mail,
  Key,
  Layers,
  Settings,
  Grid,
  Zap,
  Activity,
  AlertTriangle,
  RefreshCw,
  Sun,
  Moon,
  Copy,
  Download,
  Cpu,
  Building2,
  User,
} from 'lucide-react';
import {
  MasterAdminConfig,
  ApprovedCredential,
  getAdminConfig,
  saveAdminConfig,
  resetAdminConfigToDefaults,
  addAuditLog,
  subscribeAdminConfig,
} from '../data/adminStore';
import { MAIN_SECTION_HEADINGS } from '../data/navigationTree';
import { RlzAdminControlPanel } from './RlzAdminControlPanel';

interface AdminControlPanelProps {
  onBack: () => void;
  onNavigateTab?: (tabId: string) => void;
  onSignOut?: () => void;
}

export const AdminControlPanel: React.FC<AdminControlPanelProps> = ({
  onBack,
  onNavigateTab,
  onSignOut,
}) => {
  const [config, setConfig] = useState<MasterAdminConfig>(getAdminConfig());
  const [activeTab, setActiveTab] = useState<
    'typography' | 'canvas' | 'media' | 'suites' | 'login' | 'telemetry' | 'theme' | 'layout_control' | 'content' | 'users' | 'app_control' | 'free_sample'
  >('content');

  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  // VIP Credential Form State
  const [newCredIdentifier, setNewCredIdentifier] = useState('');
  const [newCredType, setNewCredType] = useState<'email' | 'phone' | 'passcode'>('email');
  const [newCredRole, setNewCredRole] = useState<ApprovedCredential['role']>(
    'Approved Practitioner'
  );
  const [newCredNotes, setNewCredNotes] = useState('');
  const [credSearchQuery, setCredSearchQuery] = useState('');

  // Log filter
  const [logSearchQuery, setLogSearchQuery] = useState('');
  const [logCategoryFilter, setLogCategoryFilter] = useState<string>('all');

  // Custom Font URL preview test
  const [fontTestText, setFontTestText] = useState('GlowPDF Typography Testing Stream 2026');

  useEffect(() => {
    const unsubscribe = subscribeAdminConfig((updated) => setConfig(updated));
    return () => unsubscribe();
  }, []);

  const handleUpdate = (updater: (prev: MasterAdminConfig) => MasterAdminConfig) => {
    const updated = updater(config);
    setConfig(updated);
    saveAdminConfig(updated);
  };

  const handleSaveAndCommit = () => {
    saveAdminConfig(config);
    addAuditLog(
      'Committed Admin Settings Sync',
      'system',
      'success',
      'All master admin controls, tool flags, typography overrides, and VIP Whitelist credentials synchronized to storage.',
      'GlowAdmin'
    );
    setSaveSuccessMessage('✅ ALL ADMIN SETTINGS COMMITTED & SYNCED GLOBALLY!');
    setTimeout(() => setSaveSuccessMessage(null), 3500);
  };

  const handleResetDefaults = () => {
    if (
      window.confirm(
        'Are you sure you want to RESET all Admin Control Panel settings to factory defaults?'
      )
    ) {
      resetAdminConfigToDefaults();
      setSaveSuccessMessage('⚠️ App state reset to factory default settings.');
      setTimeout(() => setSaveSuccessMessage(null), 3500);
    }
  };

  // Helper to add VIP Credential
  const handleAddApprovedCredential = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCredIdentifier.trim()) return;

    const newCred: ApprovedCredential = {
      id: `vip-${Date.now()}`,
      identifier: newCredIdentifier.trim(),
      type: newCredType,
      role: newCredRole,
      approvedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      approvedBy: 'GlowAdmin Master',
      notes: newCredNotes.trim() || 'White-listed for unconditional access',
      unconditionalAccess: true,
      isBypassEnabled: true,
      accessStatus: 'active',
    };

    handleUpdate((prev) => ({
      ...prev,
      approvedCredentialsVault: [newCred, ...prev.approvedCredentialsVault],
    }));

    addAuditLog(
      `Approved Credential: ${newCred.identifier}`,
      'login',
      'success',
      `Added ${newCred.role} credential (${newCred.identifier}) to VIP Whitelist Vault with unconditional access.`,
      'GlowAdmin'
    );

    setNewCredIdentifier('');
    setNewCredNotes('');
    setSaveSuccessMessage(`Approved credential saved: ${newCred.identifier}`);
    setTimeout(() => setSaveSuccessMessage(null), 3500);
  };

  const handleToggleBypassCredential = (id: string) => {
    handleUpdate((prev) => ({
      ...prev,
      approvedCredentialsVault: prev.approvedCredentialsVault.map((cred) => {
        if (cred.id === id) {
          const nextState = !cred.isBypassEnabled;
          addAuditLog(
            `Toggled Credential Bypass: ${cred.identifier}`,
            'login',
            nextState ? 'success' : 'warning',
            `Instant Bypass status changed to ${nextState ? 'ACTIVE' : 'STOPPED/DISABLED'}.`,
            'GlowAdmin'
          );
          return { ...cred, isBypassEnabled: nextState };
        }
        return cred;
      }),
    }));
  };

  const handleToggleRevokeCredential = (id: string) => {
    handleUpdate((prev) => ({
      ...prev,
      approvedCredentialsVault: prev.approvedCredentialsVault.map((cred) => {
        if (cred.id === id) {
          const nextStatus = cred.accessStatus === 'revoked' ? 'active' : 'revoked';
          addAuditLog(
            `Updated Credential Access Status: ${cred.identifier}`,
            'login',
            nextStatus === 'revoked' ? 'alert' : 'success',
            `Access status set to ${nextStatus.toUpperCase()}.`,
            'GlowAdmin'
          );
          return { ...cred, accessStatus: nextStatus };
        }
        return cred;
      }),
    }));
  };

  const handleRemoveCredential = (id: string, identifier: string) => {
    if (window.confirm(`Revoke whitelisted credential for "${identifier}"?`)) {
      handleUpdate((prev) => ({
        ...prev,
        approvedCredentialsVault: prev.approvedCredentialsVault.filter((c) => c.id !== id),
      }));
      addAuditLog(
        `Revoked Credential: ${identifier}`,
        'login',
        'warning',
        `Removed ${identifier} from approved VIP Vault.`,
        'GlowAdmin'
      );
    }
  };

  // Move section in hierarchy order
  const handleMoveSection = (index: number, direction: 'up' | 'down') => {
    const list = [...config.sectionOrder];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= list.length) return;

    const temp = list[index];
    list[index] = list[targetIndex];
    list[targetIndex] = temp;

    handleUpdate((prev) => ({ ...prev, sectionOrder: list }));
    addAuditLog(
      'Reordered PDF Suites Hierarchy',
      'suite',
      'info',
      `Moved section ${temp} ${direction}.`,
      'GlowAdmin'
    );
  };

  // Toggle Section Disabled
  const handleToggleSectionDisabled = (sectionId: string) => {
    const isCurrentlyDisabled = config.disabledSections.includes(sectionId);
    const updatedDisabled = isCurrentlyDisabled
      ? config.disabledSections.filter((id) => id !== sectionId)
      : [...config.disabledSections, sectionId];

    handleUpdate((prev) => ({ ...prev, disabledSections: updatedDisabled }));
    addAuditLog(
      `Toggled Section Flag: ${sectionId}`,
      'suite',
      isCurrentlyDisabled ? 'success' : 'alert',
      `Section ${sectionId} is now ${isCurrentlyDisabled ? 'ENABLED' : 'DISABLED/STOPPED'}.`,
      'GlowAdmin'
    );
  };

  // Toggle Tool Disabled
  const handleToggleToolDisabled = (toolId: string) => {
    const isCurrentlyDisabled = config.disabledTools.includes(toolId);
    const updatedDisabled = isCurrentlyDisabled
      ? config.disabledTools.filter((id) => id !== toolId)
      : [...config.disabledTools, toolId];

    handleUpdate((prev) => ({ ...prev, disabledTools: updatedDisabled }));
    addAuditLog(
      `Toggled Tool Flag: ${toolId}`,
      'suite',
      isCurrentlyDisabled ? 'success' : 'alert',
      `Tool ${toolId} is now ${isCurrentlyDisabled ? 'ENABLED' : 'DISABLED/STOPPED'}.`,
      'GlowAdmin'
    );
  };

  const filteredCredentials = config.approvedCredentialsVault.filter(
    (c) =>
      c.identifier.toLowerCase().includes(credSearchQuery.toLowerCase()) ||
      c.role.toLowerCase().includes(credSearchQuery.toLowerCase()) ||
      c.notes.toLowerCase().includes(credSearchQuery.toLowerCase())
  );

  const filteredLogs = (config.auditLogs || []).filter((log) => {
    const matchesQuery =
      log.action.toLowerCase().includes(logSearchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(logSearchQuery.toLowerCase()) ||
      log.user.toLowerCase().includes(logSearchQuery.toLowerCase());
    const matchesCategory =
      logCategoryFilter === 'all' || log.category === logCategoryFilter;
    return matchesQuery && matchesCategory;
  });

  return (
    <div className="w-full max-w-7xl mx-auto space-y-8 pb-32 animate-fadeIn">
      {/* Top Banner Header with Back Button */}
      <div className="bg-[#121522] border border-[#23273a] rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-wrap items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              {/* Back to Workspace Button */}
              <button
                type="button"
                onClick={onBack}
                className="px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white border border-slate-700 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md hover:scale-105 active:scale-95"
                title="Return to main workspace / menu"
              >
                <ArrowLeft className="w-4 h-4 text-slate-300" />
                <span>Return to Workspace</span>
              </button>

              {onSignOut && (
                <button
                  type="button"
                  onClick={onSignOut}
                  className="px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md hover:scale-105 active:scale-95"
                  title="Return to Login Screen"
                >
                  <Lock className="w-4 h-4 text-amber-400" />
                  <span>Login Screen</span>
                </button>
              )}

              <span className="text-[10px] font-black uppercase font-mono px-3 py-1 bg-amber-500/15 text-amber-400 border border-amber-500/30 rounded-full tracking-wider animate-pulse flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-amber-400" />
                MASTER ADMIN CONTROL PANEL
              </span>
            </div>

            <div>
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2.5">
                <span>Central Admin Console</span>
                <span className="text-xs font-mono font-normal px-2.5 py-0.5 rounded-md bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  v2026.4
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
                Real-time centralized governance over PDF text &amp; typography engines, drawing tools,
                file rules, suite reordering, feature flags, theme enforcement, and approved VIP credential access.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleResetDefaults}
              className="px-4 py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md hover:scale-105 active:scale-95"
              title="Reset all settings to default values"
            >
              <RotateCcw className="w-4 h-4 text-rose-400" />
              <span>Reset Defaults</span>
            </button>

            <button
              type="button"
              onClick={handleSaveAndCommit}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-black text-xs transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-purple-500/25 hover:scale-105 active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>COMMIT &amp; SAVE SYNC</span>
            </button>
          </div>
        </div>

        {/* Success Toast Banner */}
        {saveSuccessMessage && (
          <div className="mt-4 p-3 bg-emerald-500/15 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-bold flex items-center justify-between animate-fadeIn">
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{saveSuccessMessage}</span>
            </div>
            <span className="text-[10px] font-mono opacity-80">Synced locally &amp; globally</span>
          </div>
        )}
      </div>

      {/* Main Tab Bar Navigation */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 bg-[#121522] p-2 rounded-2xl border border-[#23273a]">
        {[

          {
            id: 'content',
            label: 'UI Text & Branding CMS',
            icon: FileText,
            badge: 'GLOBAL CMS',
            color: 'text-purple-400',
          },
          {
            id: 'free_sample',
            label: 'Free Sample Form',
            icon: Download,
            badge: 'MAIL/MAC/TEL',
            color: 'text-amber-400',
          },
          {
            id: 'users',
            label: 'User Access',
            icon: UserCheck,
            badge: 'RBAC',
            color: 'text-orange-400',
          },
          {
            id: 'app_control',
            label: 'App Control',
            icon: Sliders,
            badge: 'FLAGS',
            color: 'text-rose-400',
          },
          {
            id: 'typography',
            label: 'Text & Typography',
            icon: Type,
            badge: 'FONT ENGINE',
            color: 'text-blue-400',
          },
          {
            id: 'canvas',
            label: 'Canvas & Tools',
            icon: PenTool,
            badge: 'INTERACTIVE',
            color: 'text-purple-400',
          },
          {
            id: 'media',
            label: 'Media & Shapes',
            icon: ImageIcon,
            badge: 'ASSETS',
            color: 'text-amber-400',
          },
          {
            id: 'suites',
            label: 'Suites & Flags',
            icon: Sliders,
            badge: 'TIER MATRIX',
            color: 'text-emerald-400',
          },
          {
            id: 'login',
            label: 'Login & VIP Vault',
            icon: Key,
            badge: 'BYPASS VAULT',
            color: 'text-pink-400',
          },
          {
            id: 'telemetry',
            label: 'User Telemetry',
            icon: Activity,
            badge: 'TRACKER',
            color: 'text-indigo-400',
          },
          {
            id: 'theme',
            label: 'Theme & Palette',
            icon: Settings,
            badge: '12 THEMES',
            color: 'text-cyan-400',
          },
          {
            id: 'layout_control',
            label: 'Layout & Corners',
            icon: Layers,
            badge: 'SYNC CONTROL',
            color: 'text-amber-400',
          },
        ].map((tab) => {
          const IconComponent = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`p-3 rounded-xl transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 text-center relative ${
                isActive
                  ? 'bg-gradient-to-b from-[#21263d] to-[#181c2e] border border-purple-500/40 text-white shadow-lg'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/40 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-1.5">
                <IconComponent className={`w-4 h-4 ${tab.color}`} />
                <span className="text-xs font-bold">{tab.label}</span>
              </div>
              <span className="text-[9px] font-mono font-black tracking-wider uppercase opacity-75 px-1.5 py-0.5 rounded bg-slate-900/60 border border-slate-800">
                {tab.badge}
              </span>
            </button>
          );
        })}
      </div>

      {/* TAB CONTENT PANELS */}

      {/* TAB 1: TEXT & TYPOGRAPHY ENGINE CONTROLS */}
      {activeTab === 'typography' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-blue-500/10 text-blue-400 rounded-xl">
                <Type className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">1. Text &amp; Typography Engine Controls</h3>
                <p className="text-xs text-slate-400">
                  Enforce font consistency, edit granularity, and font parameter locks across all PDF canvas inline text edits.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Default Font Override Selector */}
              <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-4 space-y-3">
                <label className="text-xs font-bold text-white uppercase tracking-wider block">
                  Default Font Family Override Selector
                </label>
                <select
                  value={config.defaultFontFamilyOverride}
                  onChange={(e) =>
                    handleUpdate((prev) => ({
                      ...prev,
                      defaultFontFamilyOverride: e.target.value,
                    }))
                  }
                  className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white font-bold focus:outline-none focus:border-purple-500"
                >
                  <option value="Standard">⚠️ Standard (Preserve Original Embedded PDF Font)</option>
                  <option value="Calibri">Calibri (Clean Modern Sans)</option>
                  <option value="Arial">Arial (Standard Universal Sans)</option>
                  <option value="Times New Roman">Times New Roman (Classic Serif)</option>
                  <option value="Plus Jakarta Sans">Plus Jakarta Sans (UI Display)</option>
                  <option value="Georgia">Georgia (Elegance Book Serif)</option>
                  <option value="Courier New">Courier New (Monospace Technical)</option>
                  <option value="Custom">Custom Web Font URL (Load Remote Font)</option>
                </select>
                <p className="text-[11px] text-slate-400 leading-normal">
                  Overriding defaults will replace text renders in the editor canvas with this font family.
                </p>
              </div>

              {/* Custom Web Font URL Input */}
              <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-4 space-y-3">
                <label className="text-xs font-bold text-white uppercase tracking-wider block">
                  Custom Web Font URL (Google Fonts / .woff2)
                </label>
                <input
                  type="url"
                  value={config.customFontUrl}
                  onChange={(e) =>
                    handleUpdate((prev) => ({ ...prev, customFontUrl: e.target.value }))
                  }
                  placeholder="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap"
                  className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-purple-500"
                />
                <p className="text-[11px] text-slate-400">
                  Provide a direct stylesheet or font URL. When enabled, canvas text elements dynamically render this font.
                </p>
              </div>

              {/* Global Text Granularity Default Toggle */}
              <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-4 space-y-3">
                <label className="text-xs font-bold text-white uppercase tracking-wider block">
                  Global Text Edit Granularity Default
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'word', label: 'Word-by-Word', desc: 'Atomic word boxes' },
                    { id: 'sentence', label: 'Sentence-by-Sentence', desc: 'Full sentences' },
                    { id: 'line', label: 'Line-by-Line', desc: 'Horizontal line streams' },
                  ].map((g) => (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() =>
                        handleUpdate((prev) => ({
                          ...prev,
                          textGranularity: g.id as MasterAdminConfig['textGranularity'],
                        }))
                      }
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        config.textGranularity === g.id
                          ? 'bg-purple-600/20 border-purple-500 text-white font-bold'
                          : 'bg-[#10121b] border-[#2d3145] text-slate-400 hover:text-white'
                      }`}
                    >
                      <span className="text-xs font-bold block">{g.label}</span>
                      <span className="text-[10px] opacity-70 block mt-0.5">{g.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Typography Preview Box */}
              <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-4 space-y-3">
                <label className="text-xs font-bold text-white uppercase tracking-wider block">
                  Live Typography Rendering Preview
                </label>
                <input
                  type="text"
                  value={fontTestText}
                  onChange={(e) => setFontTestText(e.target.value)}
                  className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none"
                />
                <div
                  className="p-4 bg-[#0d0f17] border border-[#232738] rounded-xl text-center text-white text-base min-h-[60px] flex items-center justify-center font-semibold"
                  style={{
                    fontFamily:
                      config.defaultFontFamilyOverride === 'Standard'
                        ? 'inherit'
                        : config.defaultFontFamilyOverride === 'Custom'
                        ? 'sans-serif'
                        : config.defaultFontFamilyOverride,
                  }}
                >
                  "{fontTestText}"
                </div>
              </div>
            </div>

            {/* Global Text Style Locks */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-purple-300 flex items-center gap-2">
                <Lock className="w-4 h-4 text-purple-400" />
                <span>Global Text Style Locks (Preserve Original PDF Metrics)</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
                {[
                  {
                    key: 'lockPdfFontFamily',
                    label: 'Lock Font Family',
                    desc: 'Preserve extracted PDF font family during inline edits',
                  },
                  {
                    key: 'lockPdfFontSize',
                    label: 'Lock Font Size',
                    desc: 'Prevent text font size auto-scaling drift',
                  },
                  {
                    key: 'lockPdfFontWeight',
                    label: 'Lock Weight / Bold',
                    desc: 'Preserve bold & italic vector weight properties',
                  },
                  {
                    key: 'lockPdfFontColor',
                    label: 'Lock Text Color',
                    desc: 'Retain RGB/CMYK fill vector color values',
                  },
                ].map((item) => {
                  const isChecked = Boolean(config[item.key as keyof MasterAdminConfig]);
                  return (
                    <label
                      key={item.key}
                      className="flex items-start gap-3 p-3 bg-[#10121b] border border-[#2b2f44] rounded-xl cursor-pointer hover:border-purple-500/50 transition-all"
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) =>
                          handleUpdate((prev) => ({
                            ...prev,
                            [item.key]: e.target.checked,
                          }))
                        }
                        className="w-4 h-4 rounded text-purple-500 focus:ring-purple-500 accent-purple-500 mt-0.5"
                      />
                      <div>
                        <span className="text-xs font-bold text-white block">{item.label}</span>
                        <span className="text-[10px] text-slate-400 leading-snug block mt-0.5">
                          {item.desc}
                        </span>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Global Typography Scaling & Formatting */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-purple-300 flex items-center gap-2">
                <Type className="w-4 h-4 text-purple-400" />
                <span>Text Size & Spacing Controls</span>
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { key: 'globalHeading1Size', label: 'Heading 1 Size (px)', min: 16, max: 72 },
                  { key: 'globalHeading2Size', label: 'Heading 2 Size (px)', min: 14, max: 64 },
                  { key: 'globalBodySize', label: 'Body Text Size (px)', min: 10, max: 32 },
                  { key: 'globalLineHeight', label: 'Line Height', min: 1, max: 3, step: 0.1 },
                  { key: 'globalLetterSpacing', label: 'Letter Spacing (px)', min: -2, max: 10, step: 0.5 },
                ].map(item => (
                  <div key={item.key} className="space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-300">
                      <span>{item.label}</span>
                      <span className="text-purple-400">{config[item.key as keyof typeof config]}</span>
                    </div>
                    <input
                      type="range"
                      min={item.min}
                      max={item.max}
                      step={item.step || 1}
                      value={Number(config[item.key as keyof typeof config]) || item.min}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, [item.key]: Number(e.target.value) }))}
                      className="w-full accent-purple-500"
                    />
                  </div>
                ))}
              </div>
              
              <div className="pt-4 border-t border-[#2a2d40]">
                <h4 className="text-[11px] font-bold text-slate-300 mb-3">Text Transform & Weights</h4>
                <div className="flex flex-wrap gap-4">
                  <label className="flex items-center gap-2 text-xs font-bold text-white cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.globalHeadingUppercase}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, globalHeadingUppercase: e.target.checked }))}
                      className="w-4 h-4 accent-purple-500 rounded"
                    />
                    Uppercase Headings
                  </label>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-400">Heading Weight:</span>
                    <select
                      value={config.globalHeadingWeight}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, globalHeadingWeight: e.target.value }))}
                      className="bg-[#10121b] border border-[#2d3145] rounded-lg px-2 py-1 text-xs text-white"
                    >
                      <option value="300">Light (300)</option>
                      <option value="400">Regular (400)</option>
                      <option value="600">SemiBold (600)</option>
                      <option value="700">Bold (700)</option>
                      <option value="900">Black (900)</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-400">Decoration:</span>
                    <select
                      value={config.globalTextDecoration}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, globalTextDecoration: e.target.value as any }))}
                      className="bg-[#10121b] border border-[#2d3145] rounded-lg px-2 py-1 text-xs text-white"
                    >
                      <option value="none">None</option>
                      <option value="underline">Underline</option>
                      <option value="line-through">Strikethrough</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: INTERACTIVE CANVAS & DRAWING TOOLS */}
      {activeTab === 'canvas' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-purple-500/10 text-purple-400 rounded-xl">
                <PenTool className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">2. Interactive Canvas &amp; Drawing Tools Controls</h3>
                <p className="text-xs text-slate-400">
                  Tool visibility permissions, gap &amp; table detection sensitivity sliders, and custom bounding box highlights.
                </p>
              </div>
            </div>

            {/* Tool Visibility & Permissions Toggles */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-purple-300">
                Tool Visibility &amp; Mode Permissions Master Switches
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { key: 'addText', label: 'Add Text' },
                  { key: 'editText', label: 'Edit Text Inline' },
                  { key: 'freehandDraw', label: 'Freehand Pen Draw' },
                  { key: 'shapes', label: 'Shapes & Lines' },
                  { key: 'imageUpload', label: 'Image Upload' },
                  { key: 'signature', label: 'Digital Signature' },
                  { key: 'highlightRedact', label: 'Highlight & Redact' },
                ].map((tool) => {
                  const isEnabled = config.enabledTools[tool.key as keyof typeof config.enabledTools];
                  return (
                    <button
                      key={tool.key}
                      type="button"
                      onClick={() =>
                        handleUpdate((prev) => ({
                          ...prev,
                          enabledTools: {
                            ...prev.enabledTools,
                            [tool.key]: !isEnabled,
                          },
                        }))
                      }
                      className={`p-3 rounded-xl border text-left flex items-center justify-between cursor-pointer transition-all ${
                        isEnabled
                          ? 'bg-purple-600/20 border-purple-500 text-white'
                          : 'bg-[#10121b] border-[#2d3145] text-slate-500'
                      }`}
                    >
                      <span className="text-xs font-bold">{tool.label}</span>
                      <span
                        className={`text-[9px] font-mono font-black px-2 py-0.5 rounded-full ${
                          isEnabled
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {isEnabled ? 'ENABLED' : 'OFF'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Table & Gap Detection Sensitivity Sliders */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-blue-300">
                Table &amp; Gap Detection Sensitivity Sliders
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Gap Detection */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-200">Automated Gap Identifier</span>
                    <span className="text-purple-400 font-mono">{config.gapDetectionThresholdPx} px</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="50"
                    value={config.gapDetectionThresholdPx}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        gapDetectionThresholdPx: parseInt(e.target.value) || 12,
                      }))
                    }
                    className="w-full accent-purple-500"
                  />
                  <p className="text-[10px] text-slate-400">
                    Threshold spacing to group disconnected words into singular bounding boxes.
                  </p>
                </div>

                {/* Table Detection */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-200">Table Grid Line Sensitivity</span>
                    <span className="text-blue-400 font-mono">{config.tableDetectionSensitivityPercent}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={config.tableDetectionSensitivityPercent}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        tableDetectionSensitivityPercent: parseInt(e.target.value) || 75,
                      }))
                    }
                    className="w-full accent-blue-500"
                  />
                  <p className="text-[10px] text-slate-400">
                    Sensitivity for detecting cell borders and matrix grid alignments.
                  </p>
                </div>

                {/* Paragraph Spacing */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-200">Paragraph Spacing Tolerance</span>
                    <span className="text-emerald-400 font-mono">{config.paragraphSpacingTolerancePt} pt</span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="30"
                    value={config.paragraphSpacingTolerancePt}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        paragraphSpacingTolerancePt: parseInt(e.target.value) || 8,
                      }))
                    }
                    className="w-full accent-emerald-500"
                  />
                  <p className="text-[10px] text-slate-400">
                    Vertical line spacing limit to trigger new paragraph breaks.
                  </p>
                </div>
              </div>
            </div>

            {/* Bounding Box & Highlight Customizer */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-amber-300">
                Bounding Box &amp; Highlight Overlay Customizer
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Selection Box Color */}
                <div className="space-y-2 bg-[#10121b] p-3 rounded-xl border border-[#2d3145]">
                  <span className="text-xs font-bold text-slate-200 block">Selection Box Color</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={config.selectionBoxColor}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          selectionBoxColor: e.target.value,
                        }))
                      }
                      className="w-8 h-8 rounded border-none cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={config.selectionBoxColor}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          selectionBoxColor: e.target.value,
                        }))
                      }
                      className="w-full bg-[#161826] border border-[#2d3145] text-xs font-mono text-white rounded px-2 py-1"
                    />
                  </div>
                </div>

                {/* Selection Box Stroke Width */}
                <div className="space-y-2 bg-[#10121b] p-3 rounded-xl border border-[#2d3145]">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-200">Stroke Width</span>
                    <span className="text-purple-400 font-mono">{config.selectionBoxStrokeWidth} px</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="5"
                    value={config.selectionBoxStrokeWidth}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        selectionBoxStrokeWidth: parseInt(e.target.value) || 2,
                      }))
                    }
                    className="w-full accent-purple-500"
                  />
                </div>

                {/* Word Highlight Overlay Color */}
                <div className="space-y-2 bg-[#10121b] p-3 rounded-xl border border-[#2d3145]">
                  <span className="text-xs font-bold text-slate-200 block">Highlight Overlay</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={config.wordHighlightColor}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          wordHighlightColor: e.target.value,
                        }))
                      }
                      className="w-8 h-8 rounded border-none cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={config.wordHighlightColor}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          wordHighlightColor: e.target.value,
                        }))
                      }
                      className="w-full bg-[#161826] border border-[#2d3145] text-xs font-mono text-white rounded px-2 py-1"
                    />
                  </div>
                </div>

                {/* Snap to Grid Toggle */}
                <div className="space-y-2 bg-[#10121b] p-3 rounded-xl border border-[#2d3145] flex flex-col justify-between">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200">Snap-to-Grid</span>
                    <input
                      type="checkbox"
                      checked={config.snapToGridEnabled}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          snapToGridEnabled: e.target.checked,
                        }))
                      }
                      className="w-4 h-4 accent-purple-500 cursor-pointer"
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Grid Spacing:</span>
                    <span className="font-mono text-purple-400">{config.gridSpacingPx} px</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MEDIA & OBJECT MANAGEMENT */}
      {activeTab === 'media' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl">
                <ImageIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">3. Media &amp; Object Management Rules</h3>
                <p className="text-xs text-slate-400">
                  Image upload size limits, format restrictions, auto-compression quality, and shape canvas layer defaults.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Image Upload Rules */}
              <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
                <h4 className="text-xs font-black uppercase tracking-wider text-amber-300">
                  Image Upload Rules &amp; Limits
                </h4>

                {/* Max File Size */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-200">Maximum File Size Limit</span>
                    <span className="text-amber-400 font-mono">{config.maxImageSizeMb} MB</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="100"
                    value={config.maxImageSizeMb}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        maxImageSizeMb: parseInt(e.target.value) || 25,
                      }))
                    }
                    className="w-full accent-amber-500"
                  />
                </div>

                {/* Supported Formats Checkboxes */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-200 block">Supported Image Formats</span>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { key: 'png', label: 'PNG Graphics' },
                      { key: 'jpeg', label: 'JPEG Photos' },
                      { key: 'webp', label: 'WebP Compressed' },
                      { key: 'svg', label: 'SVG Vector Graphics' },
                    ].map((fmt) => {
                      const isFmtChecked = config.supportedImageFormats[fmt.key as keyof typeof config.supportedImageFormats];
                      return (
                        <label
                          key={fmt.key}
                          className="flex items-center gap-2.5 p-2.5 bg-[#10121b] border border-[#2d3145] rounded-lg text-xs font-bold text-white cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={isFmtChecked}
                            onChange={(e) =>
                              handleUpdate((prev) => ({
                                ...prev,
                                supportedImageFormats: {
                                  ...prev.supportedImageFormats,
                                  [fmt.key]: e.target.checked,
                                },
                              }))
                            }
                            className="w-4 h-4 accent-amber-500 cursor-pointer"
                          />
                          <span>{fmt.label}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                {/* Auto Compression Quality */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-200">Auto-Compression Quality</span>
                    <span className="text-emerald-400 font-mono">{config.autoCompressionQualityPercent}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={config.autoCompressionQualityPercent}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        autoCompressionQualityPercent: parseInt(e.target.value) || 85,
                      }))
                    }
                    className="w-full accent-emerald-500"
                  />
                </div>

                {/* Background Removal Toggle */}
                <label className="flex items-center justify-between p-3 bg-[#10121b] border border-[#2d3145] rounded-xl cursor-pointer">
                  <div>
                    <span className="text-xs font-bold text-white block">Auto Background Removal</span>
                    <span className="text-[10px] text-slate-400">
                      Auto-detect and strip solid white image backgrounds
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={config.backgroundRemovalEnabled}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        backgroundRemovalEnabled: e.target.checked,
                      }))
                    }
                    className="w-4 h-4 accent-amber-500 cursor-pointer"
                  />
                </label>
              </div>

              {/* Shape & Canvas Element Defaults */}
              <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
                <h4 className="text-xs font-black uppercase tracking-wider text-blue-300">
                  Shape &amp; Canvas Presets
                </h4>

                <div className="grid grid-cols-2 gap-4">
                  {/* Stroke Color */}
                  <div className="space-y-2 bg-[#10121b] p-3 rounded-xl border border-[#2d3145]">
                    <span className="text-xs font-bold text-slate-200 block">Default Stroke Color</span>
                    <input
                      type="color"
                      value={config.defaultShapeStrokeColor}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          defaultShapeStrokeColor: e.target.value,
                        }))
                      }
                      className="w-full h-8 rounded border-none cursor-pointer bg-transparent"
                    />
                  </div>

                  {/* Fill Color */}
                  <div className="space-y-2 bg-[#10121b] p-3 rounded-xl border border-[#2d3145]">
                    <span className="text-xs font-bold text-slate-200 block">Default Fill Color</span>
                    <input
                      type="color"
                      value={config.defaultShapeFillColor}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          defaultShapeFillColor: e.target.value,
                        }))
                      }
                      className="w-full h-8 rounded border-none cursor-pointer bg-transparent"
                    />
                  </div>
                </div>

                {/* Fill Opacity */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-200">Default Fill Opacity</span>
                    <span className="text-blue-400 font-mono">
                      {Math.round(config.defaultShapeFillOpacity * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={config.defaultShapeFillOpacity}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        defaultShapeFillOpacity: parseFloat(e.target.value) || 0.25,
                      }))
                    }
                    className="w-full accent-blue-500"
                  />
                </div>

                {/* Arrow Head Style */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-200 block">Arrow Head Presets</span>
                  <select
                    value={config.defaultArrowHeadStyle}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        defaultArrowHeadStyle: e.target.value as MasterAdminConfig['defaultArrowHeadStyle'],
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white font-bold focus:outline-none"
                  >
                    <option value="none">None (Plain Stroke)</option>
                    <option value="standard">Standard Line Head</option>
                    <option value="filled">Filled Arrow Head</option>
                    <option value="double">Double End Arrow</option>
                  </select>
                </div>

                {/* Border Radius */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-200">Default Border Radius</span>
                    <span className="text-purple-400 font-mono">{config.defaultBorderRadiusPx} px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="24"
                    value={config.defaultBorderRadiusPx}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        defaultBorderRadiusPx: parseInt(e.target.value) || 6,
                      }))
                    }
                    className="w-full accent-purple-500"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SUITE REORDERING & MODULE FEATURE FLAGS */}
      {activeTab === 'suites' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
                <Sliders className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">4. Suite &amp; Navigation Hierarchy Manager</h3>
                <p className="text-xs text-slate-400">
                  Reorder all 10 PDF Suites, adjust section rankings, and manually stop or disable any tool or suite module.
                </p>
              </div>
            </div>

            {/* Suite Hierarchy Order List */}
            <div className="space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-emerald-300">
                PDF Suites Section Ranking &amp; Master Feature Flags
              </h4>

              <div className="space-y-3">
                {config.sectionOrder.map((secId, index) => {
                  const sectionObj = MAIN_SECTION_HEADINGS.find((s) => s.id === secId);
                  if (!sectionObj) return null;
                  const isSecDisabled = config.disabledSections.includes(secId);

                  return (
                    <div
                      key={secId}
                      className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                        isSecDisabled
                          ? 'bg-[#12131c] border-rose-500/30 opacity-70'
                          : 'bg-[#1a1d2d] border-[#2a2d40] hover:border-purple-500/40'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex flex-col gap-1">
                          <button
                            type="button"
                            disabled={index === 0}
                            onClick={() => handleMoveSection(index, 'up')}
                            className="p-1 rounded bg-[#10121b] border border-[#2d3145] text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer"
                            title="Move section up in hierarchy"
                          >
                            <ChevronUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={index === config.sectionOrder.length - 1}
                            onClick={() => handleMoveSection(index, 'down')}
                            className="p-1 rounded bg-[#10121b] border border-[#2d3145] text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer"
                            title="Move section down in hierarchy"
                          >
                            <ChevronDown className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="w-8 h-8 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center font-mono font-black text-xs shrink-0">
                          #{index + 1}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-white">
                              {sectionObj.title}
                            </span>
                            <span
                              className={`text-[9px] font-mono font-black px-2 py-0.5 rounded-full ${
                                isSecDisabled
                                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              }`}
                            >
                              {isSecDisabled ? 'DISABLED / STOPPED' : 'ACTIVE'}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                            {sectionObj.subtitle}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                        <button
                          type="button"
                          onClick={() => handleToggleSectionDisabled(secId)}
                          className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                            isSecDisabled
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                              : 'bg-rose-500/15 text-rose-300 border-rose-500/30 hover:bg-rose-500/25'
                          }`}
                        >
                          {isSecDisabled ? (
                            <>
                              <Eye className="w-3.5 h-3.5" />
                              <span>ENABLE SUITE</span>
                            </>
                          ) : (
                            <>
                              <EyeOff className="w-3.5 h-3.5" />
                              <span>STOP / DISABLE</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Sub-Tools Feature Flags */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-purple-300">
                Sub-Tool Granular Feature Flags (Stop Any Tool Manually)
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {[
                  { id: 'zkd-pqc-shield', label: 'Quantum Cryptography (ZKD-Vault)' },
                  { id: 'health-hipaa', label: '18 PHI Safe Harbor Diagnostics' },
                  { id: 'ocr-scanner', label: 'AI OCR Text Extraction Engine' },
                  { id: 'smart-redact', label: 'Smart Redaction & Auto-Blackout' },
                  { id: 'pdf-compare', label: 'Side-by-Side Visual Compare' },
                  { id: 'digital-signer', label: 'Digital PKI Signature Engine' },
                  { id: 'doc-analytics', label: 'ATS & Vector Syntax Inspector' },
                  { id: 'watermark-engine', label: 'Dynamic Watermark Overlay' },
                  { id: 'gov-fips', label: 'Gov FIPS 140-3 Encryption' },
                ].map((tool) => {
                  const isToolDisabled = config.disabledTools.includes(tool.id);
                  return (
                    <div
                      key={tool.id}
                      className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                        isToolDisabled
                          ? 'bg-[#10121b] border-rose-500/40 text-rose-300'
                          : 'bg-[#10121b] border-[#2d3145] text-white'
                      }`}
                    >
                      <span className="text-xs font-bold line-clamp-1">{tool.label}</span>
                      <button
                        type="button"
                        onClick={() => handleToggleToolDisabled(tool.id)}
                        className={`text-[9px] font-mono font-black px-2.5 py-1 rounded-lg border transition-all cursor-pointer shrink-0 ${
                          isToolDisabled
                            ? 'bg-rose-500/20 text-rose-400 border-rose-500/30 hover:bg-rose-500/30'
                            : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/30'
                        }`}
                      >
                        {isToolDisabled ? 'DISABLED' : 'ACTIVE'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: LOGIN CONTROLS & SPECIAL APPROVED CREDENTIALS VAULT */}
      {activeTab === 'login' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-pink-500/10 text-pink-400 rounded-xl">
                <Key className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">5. User Login Branding &amp; Whitelist Bypass Vault</h3>
                <p className="text-xs text-slate-400">
                  Manage login branding text, header badges, banners, guest access policies, and whitelisted credentials with instant bypass controls.
                </p>
              </div>
            </div>

            {/* Login Page Text Customizer */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-pink-300">
                Login Page Text, Branding &amp; Banner Customizer
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Console Heading Title
                  </label>
                  <input
                    type="text"
                    value={config.loginHeadingText || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        loginHeadingText: e.target.value,
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Subheading / Tagline
                  </label>
                  <input
                    type="text"
                    value={config.loginSubheadingText || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        loginSubheadingText: e.target.value,
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    App Logo Text
                  </label>
                  <input
                    type="text"
                    value={config.loginLogoText || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        loginLogoText: e.target.value,
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Header Badge Text
                  </label>
                  <input
                    type="text"
                    value={config.loginHeaderBadgeText || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        loginHeaderBadgeText: e.target.value,
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5 lg:col-span-2">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Welcome Banner Notice
                  </label>
                  <input
                    type="text"
                    value={config.loginWelcomeBanner || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        loginWelcomeBanner: e.target.value,
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5 lg:col-span-3">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Callout Banner Text
                  </label>
                  <input
                    type="text"
                    value={config.loginCalloutBannerText || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        loginCalloutBannerText: e.target.value,
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5 lg:col-span-3">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Security Disclaimer Notice
                  </label>
                  <input
                    type="text"
                    value={config.loginDisclaimer || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        loginDisclaimer: e.target.value,
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Guest Access Policies */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-purple-300">
                Guest Access &amp; Passcode Policy
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-200 block">Guest Access Policy</span>
                  <select
                    value={config.guestAccessMode}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        guestAccessMode: e.target.value as MasterAdminConfig['guestAccessMode'],
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white font-bold focus:outline-none"
                  >
                    <option value="allowed">Allowed (Instant 1-Click Guest Access)</option>
                    <option value="passcode_required">Passcode Required (Guest Key Needed)</option>
                    <option value="disabled">Disabled (Strict Whitelisted / Registered Credentials Only)</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-200 block">Guest Access Passcode</span>
                  <input
                    type="text"
                    value={config.guestPasscode}
                    onChange={(e) =>
                      handleUpdate((prev) => ({ ...prev, guestPasscode: e.target.value }))
                    }
                    placeholder="GLOWGUEST2026"
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs font-mono text-amber-300 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* SPECIAL CORNER: APPROVED CREDENTIALS & VIP ACCESS VAULT */}
            <div className="bg-gradient-to-br from-[#1a182b] via-[#151726] to-[#0e1220] border-2 border-pink-500/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />

              <div className="flex items-center justify-between pb-4 border-b border-pink-500/30">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-pink-500/20 text-pink-300 rounded-2xl border border-pink-500/40 shadow-lg">
                    <UserCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-white flex items-center gap-2">
                      <span>SPECIAL CORNER: ADMIN BYPASS &amp; WHITELIST CORNER</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-pink-500/20 text-pink-300 border border-pink-500/30 font-bold uppercase">
                        INSTANT BYPASS VAULT
                      </span>
                    </h4>
                    <p className="text-xs text-slate-300 mt-0.5">
                      Save emails or mobile numbers into the Whitelist Corner. Enable "Approve Instant Bypass" to let whitelisted accounts automatically gain unrestricted access without standard login barriers.
                    </p>
                  </div>
                </div>
              </div>

              {/* Add New Approved Credential Form */}
              <form onSubmit={handleAddApprovedCredential} className="bg-[#10121d] border border-[#2a2e45] rounded-2xl p-4 sm:p-5 space-y-4">
                <h5 className="text-xs font-black uppercase tracking-wider text-pink-300 flex items-center gap-2">
                  <Plus className="w-4 h-4 text-pink-400" />
                  <span>Approve &amp; Whitelist New Credential</span>
                </h5>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-300 uppercase">
                      Identifier (Email / Phone Number)
                    </label>
                    <input
                      required
                      type="text"
                      value={newCredIdentifier}
                      onChange={(e) => setNewCredIdentifier(e.target.value)}
                      placeholder="e.g. user@example.com or +1555..."
                      className="w-full bg-[#181a29] border border-[#30344d] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-300 uppercase">
                      Type
                    </label>
                    <select
                      value={newCredType}
                      onChange={(e) => setNewCredType(e.target.value as ApprovedCredential['type'])}
                      className="w-full bg-[#181a29] border border-[#30344d] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                    >
                      <option value="email">📧 Email Address</option>
                      <option value="phone">📱 Mobile Number</option>
                      <option value="passcode">🔑 Access Passcode</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-300 uppercase">
                      Assigned Role
                    </label>
                    <select
                      value={newCredRole}
                      onChange={(e) => setNewCredRole(e.target.value as ApprovedCredential['role'])}
                      className="w-full bg-[#181a29] border border-[#30344d] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                    >
                      <option value="VIP Master Admin">👑 VIP Master Admin</option>
                      <option value="Approved Practitioner">🩺 Approved Practitioner</option>
                      <option value="Enterprise Verified">🏛️ Enterprise Verified</option>
                      <option value="Bypass User">⚡ Bypass User</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-300 uppercase">
                      Department / Notes
                    </label>
                    <input
                      type="text"
                      value={newCredNotes}
                      onChange={(e) => setNewCredNotes(e.target.value)}
                      placeholder="e.g. Lead Analyst"
                      className="w-full bg-[#181a29] border border-[#30344d] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 hover:from-pink-500 hover:to-indigo-500 text-white font-black text-xs transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-pink-500/20 hover:scale-105 active:scale-95"
                  >
                    <Check className="w-4 h-4" />
                    <span>APPROVE INSTANT BYPASS &amp; SAVE</span>
                  </button>
                </div>
              </form>

              {/* Live Whitelisted Credentials & Bypass Table */}
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                    Whitelisted Accounts Vault ({filteredCredentials.length})
                  </span>
                  <input
                    type="text"
                    value={credSearchQuery}
                    onChange={(e) => setCredSearchQuery(e.target.value)}
                    placeholder="Search whitelist..."
                    className="bg-[#10121d] border border-[#2a2e45] rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none w-full sm:w-64"
                  />
                </div>

                <div className="overflow-x-auto rounded-2xl border border-[#2a2e45]">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-[#10121d] text-slate-400 font-mono text-[10px] uppercase border-b border-[#2a2e45]">
                      <tr>
                        <th className="p-3">Type</th>
                        <th className="p-3">Identifier</th>
                        <th className="p-3">Role</th>
                        <th className="p-3">Bypass Control</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#2a2e45] bg-[#121422]">
                      {filteredCredentials.map((cred) => (
                        <tr key={cred.id} className="hover:bg-[#181a2b] transition-colors">
                          <td className="p-3 font-mono">
                            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] font-bold">
                              {cred.type === 'email' && <Mail className="w-3 h-3 text-blue-400" />}
                              {cred.type === 'phone' && <Phone className="w-3 h-3 text-emerald-400" />}
                              {cred.type === 'passcode' && <Key className="w-3 h-3 text-amber-400" />}
                              {cred.type.toUpperCase()}
                            </span>
                          </td>
                          <td className="p-3 font-mono font-bold text-white">
                            {cred.identifier}
                          </td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 rounded bg-pink-500/15 text-pink-300 border border-pink-500/30 font-bold text-[10px]">
                              {cred.role}
                            </span>
                          </td>
                          <td className="p-3">
                            <button
                              type="button"
                              onClick={() => handleToggleBypassCredential(cred.id)}
                              className={`px-3 py-1 rounded-lg font-mono text-[10px] font-black border transition-all cursor-pointer flex items-center gap-1.5 ${
                                cred.isBypassEnabled
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                              }`}
                            >
                              <Zap className={`w-3 h-3 ${cred.isBypassEnabled ? 'text-amber-400 fill-amber-400 animate-pulse' : 'text-slate-500'}`} />
                              <span>{cred.isBypassEnabled ? 'BYPASS ACTIVE' : 'STOP BYPASS'}</span>
                            </button>
                          </td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                              cred.accessStatus === 'revoked'
                                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                                : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            }`}>
                              {cred.accessStatus === 'revoked' ? 'REVOKED' : 'ACTIVE'}
                            </span>
                          </td>
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => handleToggleRevokeCredential(cred.id)}
                                className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[10px] font-mono font-bold transition-all cursor-pointer"
                                title="Revoke or restore credential"
                              >
                                {cred.accessStatus === 'revoked' ? 'Restore' : 'Revoke'}
                              </button>
                              <button
                                type="button"
                                onClick={() => handleRemoveCredential(cred.id, cred.identifier)}
                                className="p-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 transition-all cursor-pointer"
                                title="Delete from Whitelist Vault"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                      {filteredCredentials.length === 0 && (
                        <tr>
                          <td colSpan={6} className="p-6 text-center text-slate-500 italic">
                            No whitelisted credentials found matching query.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: USER TELEMETRY & TIME TRACKER */}
      {activeTab === 'telemetry' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">6. User Telemetry &amp; Session Time Tracker</h3>
                <p className="text-xs text-slate-400">
                  Track real-time active user sessions, time spent per tool suite, total processed PDF pages, and workspace usage statistics.
                </p>
              </div>
            </div>

            {/* Live Counter Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-[#10121d] border border-[#23273a] rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono uppercase text-slate-400">Active Real-Time Sessions</span>
                <div className="text-2xl font-black text-indigo-400 font-mono flex items-center justify-between">
                  <span>{config.telemetryTracker?.activeRealtimeSessions || 1}</span>
                  <span className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
                </div>
                <p className="text-[10px] text-slate-500">Connected active user streams</p>
              </div>

              <div className="bg-[#10121d] border border-[#23273a] rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono uppercase text-slate-400">Total Documents Processed</span>
                <div className="text-2xl font-black text-emerald-400 font-mono">
                  {config.telemetryTracker?.totalDocsProcessed || 142}
                </div>
                <p className="text-[10px] text-slate-500">PDF operations completed</p>
              </div>

              <div className="bg-[#10121d] border border-[#23273a] rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono uppercase text-slate-400">Total Active Workspace Time</span>
                <div className="text-2xl font-black text-amber-400 font-mono">
                  {config.telemetryTracker?.totalActiveTimeMinutes || 384} mins
                </div>
                <p className="text-[10px] text-slate-500">Cumulative time logged</p>
              </div>

              <div className="bg-[#10121d] border border-[#23273a] rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono uppercase text-slate-400">Memory Footprint</span>
                <div className="text-2xl font-black text-rose-400 font-mono">
                  {(Math.random() * 50 + 200).toFixed(0)} MB
                </div>
                <p className="text-[10px] text-slate-500">Live heap allocation</p>
              </div>
              <div className="bg-[#10121d] border border-[#23273a] rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono uppercase text-slate-400">System Load</span>
                <div className="text-2xl font-black text-cyan-400 font-mono">
                  {(Math.random() * 30 + 10).toFixed(0)} %
                </div>
                <p className="text-[10px] text-slate-500">Current CPU load</p>
              </div>
              <div className="bg-[#10121d] border border-[#23273a] rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono uppercase text-slate-400">WebGL Instances</span>
                <div className="text-2xl font-black text-cyan-400 font-mono">
                  {Math.floor(Math.random() * 5 + 2)}
                </div>
                <p className="text-[10px] text-slate-500">Active render contexts</p>
              </div>
              <div className="bg-[#10121d] border border-[#23273a] rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono uppercase text-slate-400">Registered Accounts</span>
                <div className="text-2xl font-black text-purple-400 font-mono">
                  {config.userRegistry?.length || 3}
                </div>
                <p className="text-[10px] text-slate-500">Active user profiles in vault</p>
              </div>
            </div>

            {/* Time Spent Per Tool Suite Matrix */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-2xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-indigo-300">
                Time Spent Per Tool Suite Breakdown
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {[
                  { name: 'Interactive PDF Editor', time: '142 mins', pct: '37%' },
                  { name: 'AI OCR & Search Engine', time: '88 mins', pct: '23%' },
                  { name: 'Smart Redact & PII Sanitizer', time: '64 mins', pct: '17%' },
                  { name: 'Quantum Cryptography Vault', time: '42 mins', pct: '11%' },
                  { name: 'Digital Signer & Watermarking', time: '30 mins', pct: '8%' },
                  { name: 'CAD & Measurement Suite', time: '18 mins', pct: '4%' },
                ].map((suite, idx) => (
                  <div key={idx} className="p-3 bg-[#10121b] border border-[#23273a] rounded-xl space-y-2">
                    <div className="flex justify-between items-center text-xs font-bold text-white">
                      <span>{suite.name}</span>
                      <span className="text-indigo-400 font-mono">{suite.time}</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500 rounded-full" style={{ width: suite.pct }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: GLOBAL THEME & BOX COLOR PALETTE MANAGER */}
      {activeTab === 'theme' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-xl">
                <Settings className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">7. Global Theme &amp; Box Color Palette Manager</h3>
                <p className="text-xs text-slate-400">
                  Choose from 12 global UI themes, customize container background colors, borders, stroke widths, glow intensities, and monitor live audit logs.
                </p>
              </div>
            </div>

            {/* 12 Themes Selector */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-cyan-300">
                12 System Theme Overrides
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                {[
                  { id: 'light-slate', label: 'Light Studio Slate', bg: 'bg-slate-100', border: 'border-slate-300', text: 'text-slate-900' },
                  { id: 'dark-obsidian', label: 'Dark Obsidian', bg: 'bg-slate-900', border: 'border-purple-500/50', text: 'text-white' },
                  { id: 'cyberpunk-neon', label: 'Cyberpunk Neon', bg: 'bg-black', border: 'border-cyan-400', text: 'text-cyan-300' },
                  { id: 'solar-amber', label: 'Warm Solar Amber', bg: 'bg-amber-950', border: 'border-amber-500', text: 'text-amber-200' },
                  { id: 'emerald-mint', label: 'Emerald Mint', bg: 'bg-emerald-950', border: 'border-emerald-500', text: 'text-emerald-200' },
                  { id: 'royal-indigo', label: 'Royal Indigo', bg: 'bg-indigo-950', border: 'border-indigo-500', text: 'text-indigo-200' },
                  { id: 'sunset-crimson', label: 'Sunset Crimson', bg: 'bg-rose-950', border: 'border-rose-500', text: 'text-rose-200' },
                  { id: 'minimal-paper', label: 'Minimal Paper', bg: 'bg-stone-100', border: 'border-stone-300', text: 'text-stone-900' },
                  { id: 'deep-space', label: 'Deep Space Blue', bg: 'bg-blue-950', border: 'border-blue-500', text: 'text-blue-200' },
                  { id: 'titanium-gray', label: 'Titanium Metallic', bg: 'bg-zinc-800', border: 'border-zinc-500', text: 'text-zinc-100' },
                  { id: 'violet-dream', label: 'Violet Dream', bg: 'bg-purple-950', border: 'border-purple-400', text: 'text-purple-200' },
                  { id: 'high-contrast-wcag', label: 'High-Contrast WCAG', bg: 'bg-black', border: 'border-white', text: 'text-yellow-300' },
                ].map((t) => {
                  const isSelected = config.forcedTheme === t.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() =>
                        handleUpdate((prev) => ({
                          ...prev,
                          forcedTheme: t.id as MasterAdminConfig['forcedTheme'],
                        }))
                      }
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer space-y-2 ${t.bg} ${t.border} ${
                        isSelected ? 'ring-2 ring-cyan-400 shadow-lg scale-105' : 'opacity-80 hover:opacity-100'
                      }`}
                    >
                      <span className={`text-xs font-bold block ${t.text}`}>{t.label}</span>
                      <span className="text-[9px] font-mono opacity-75 block text-slate-400">
                        {isSelected ? '✓ ACTIVE THEME' : 'Select Theme'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Custom Box & Container Palette Manager */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-cyan-300">
                Custom Box &amp; Container Palette Controls
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-200 block">Box Background Color</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={config.customBoxStyle?.boxBgColor || '#141724'}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          customBoxStyle: {
                            ...(prev.customBoxStyle || {
                              boxBgColor: '#141724',
                              boxBorderColor: '#23273a',
                              borderStrokeWidthPx: 1,
                              glowIntensityPercent: 50,
                              borderRadiusStyle: 'curved',
                              autoLegibilityContrast: true,
                            }),
                            boxBgColor: e.target.value,
                          },
                        }))
                      }
                      className="w-10 h-10 rounded-xl cursor-pointer bg-transparent border-0"
                    />
                    <input
                      type="text"
                      value={config.customBoxStyle?.boxBgColor || '#141724'}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          customBoxStyle: {
                            ...(prev.customBoxStyle || {
                              boxBgColor: '#141724',
                              boxBorderColor: '#23273a',
                              borderStrokeWidthPx: 1,
                              glowIntensityPercent: 50,
                              borderRadiusStyle: 'curved',
                              autoLegibilityContrast: true,
                            }),
                            boxBgColor: e.target.value,
                          },
                        }))
                      }
                      className="bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none w-full"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-200 block">Border Stroke Color</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={config.customBoxStyle?.boxBorderColor || '#23273a'}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          customBoxStyle: {
                            ...(prev.customBoxStyle || {
                              boxBgColor: '#141724',
                              boxBorderColor: '#23273a',
                              borderStrokeWidthPx: 1,
                              glowIntensityPercent: 50,
                              borderRadiusStyle: 'curved',
                              autoLegibilityContrast: true,
                            }),
                            boxBorderColor: e.target.value,
                          },
                        }))
                      }
                      className="w-10 h-10 rounded-xl cursor-pointer bg-transparent border-0"
                    />
                    <input
                      type="text"
                      value={config.customBoxStyle?.boxBorderColor || '#23273a'}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          customBoxStyle: {
                            ...(prev.customBoxStyle || {
                              boxBgColor: '#141724',
                              boxBorderColor: '#23273a',
                              borderStrokeWidthPx: 1,
                              glowIntensityPercent: 50,
                              borderRadiusStyle: 'curved',
                              autoLegibilityContrast: true,
                            }),
                            boxBorderColor: e.target.value,
                          },
                        }))
                      }
                      className="bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none w-full"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-200 block">
                    Border Radius Style
                  </label>
                  <select
                    value={config.customBoxStyle?.borderRadiusStyle || 'curved'}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        customBoxStyle: {
                          ...(prev.customBoxStyle || {
                            boxBgColor: '#141724',
                            boxBorderColor: '#23273a',
                            borderStrokeWidthPx: 1,
                            glowIntensityPercent: 50,
                            borderRadiusStyle: 'curved',
                            autoLegibilityContrast: true,
                          }),
                          borderRadiusStyle: e.target.value as any,
                        },
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-bold"
                  >
                    <option value="sharp">Sharp (0px - Technical / CAD)</option>
                    <option value="curved">Curved (12px - Studio Modern)</option>
                    <option value="pill">Pill (28px - Soft Enterprise)</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-200 block">
                    Stroke Width: {config.customBoxStyle?.borderStrokeWidthPx || 1}px
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="8"
                    step="1"
                    value={config.customBoxStyle?.borderStrokeWidthPx || 1}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        customBoxStyle: {
                          ...(prev.customBoxStyle || {
                            boxBgColor: '#141724',
                            boxBorderColor: '#23273a',
                            borderStrokeWidthPx: 1,
                            glowIntensityPercent: 50,
                            borderRadiusStyle: 'curved',
                            autoLegibilityContrast: true,
                          }),
                          borderStrokeWidthPx: parseInt(e.target.value, 10),
                        },
                      }))
                    }
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-200 block">
                    Glow Intensity: {config.customBoxStyle?.glowIntensityPercent || 50}%
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    value={config.customBoxStyle?.glowIntensityPercent || 50}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        customBoxStyle: {
                          ...(prev.customBoxStyle || {
                            boxBgColor: '#141724',
                            boxBorderColor: '#23273a',
                            borderStrokeWidthPx: 1,
                            glowIntensityPercent: 50,
                            borderRadiusStyle: 'curved',
                            autoLegibilityContrast: true,
                          }),
                          glowIntensityPercent: parseInt(e.target.value, 10),
                        },
                      }))
                    }
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>

                <div className="space-y-2 flex flex-col justify-end">
                  <label className="flex items-center justify-between p-3 bg-[#10121b] border border-[#2d3145] rounded-xl cursor-pointer">
                    <span className="text-xs font-bold text-white">Auto High Contrast</span>
                    <input
                      type="checkbox"
                      checked={config.customBoxStyle?.autoLegibilityContrast ?? true}
                      onChange={(e) =>
                        handleUpdate((prev) => ({
                          ...prev,
                          customBoxStyle: {
                            ...(prev.customBoxStyle || {
                              boxBgColor: '#141724',
                              boxBorderColor: '#23273a',
                              borderStrokeWidthPx: 1,
                              glowIntensityPercent: 50,
                              borderRadiusStyle: 'curved',
                              autoLegibilityContrast: true,
                            }),
                            autoLegibilityContrast: e.target.checked,
                          },
                        }))
                      }
                      className="w-4 h-4 accent-cyan-400 cursor-pointer"
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* Live Audit Logs Stream */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-2xl p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#282b3d]">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <h4 className="text-xs font-black uppercase tracking-wider text-white">
                    System Audit Stream ({filteredLogs.length})
                  </h4>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={logCategoryFilter}
                    onChange={(e) => setLogCategoryFilter(e.target.value)}
                    className="bg-[#10121b] border border-[#2d3145] text-xs text-white rounded-lg px-2.5 py-1 focus:outline-none"
                  >
                    <option value="all">All Categories</option>
                    <option value="typography">Typography</option>
                    <option value="canvas">Canvas</option>
                    <option value="media">Media</option>
                    <option value="suite">Suites</option>
                    <option value="login">Login &amp; Vault</option>
                    <option value="system">System</option>
                  </select>

                  <input
                    type="text"
                    value={logSearchQuery}
                    onChange={(e) => setLogSearchQuery(e.target.value)}
                    placeholder="Search logs..."
                    className="bg-[#10121b] border border-[#2d3145] text-xs text-white rounded-lg px-2.5 py-1 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {filteredLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 bg-[#10121b] border border-[#282b3d] rounded-xl text-xs font-mono space-y-1"
                  >
                    <div className="flex items-center justify-between text-[10px]">
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-bold uppercase px-1.5 py-0.5 rounded ${
                            log.severity === 'success'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : log.severity === 'warning'
                              ? 'bg-amber-500/20 text-amber-400'
                              : log.severity === 'alert'
                              ? 'bg-rose-500/20 text-rose-400'
                              : 'bg-blue-500/20 text-blue-400'
                          }`}
                        >
                          {log.severity}
                        </span>
                        <span className="text-slate-400">{log.timestamp}</span>
                        <span className="text-purple-400">[{log.category.toUpperCase()}]</span>
                      </div>
                      <span className="text-slate-500">By: {log.user}</span>
                    </div>
                    <div className="text-white font-bold">{log.action}</div>
                    <div className="text-slate-400 text-[11px] font-sans leading-relaxed">
                      {log.details}
                    </div>
                  </div>
                ))}

                {filteredLogs.length === 0 && (
                  <div className="p-8 text-center text-slate-500 text-xs italic">
                    No activity logs recorded matching criteria.
                  </div>
                )}
              </div>
            </div>

            {/* Box, Container & Palette Styling */}
            <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4 mb-6">
              <h4 className="text-xs font-black uppercase tracking-wider text-cyan-300 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>Box, Container & Palette Styling</span>
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[11px] font-bold text-slate-300">Box Background Color</label>
                  <input
                    type="color"
                    value={config.customBoxStyle?.boxBgColor || '#121522'}
                    onChange={(e) => handleUpdate(prev => ({ ...prev, customBoxStyle: { ...prev.customBoxStyle, boxBgColor: e.target.value } }))}
                    className="w-full h-8 rounded bg-transparent cursor-pointer"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] font-bold text-slate-300">Border Stroke Color</label>
                  <input
                    type="color"
                    value={config.customBoxStyle?.boxBorderColor || '#a855f7'}
                    onChange={(e) => handleUpdate(prev => ({ ...prev, customBoxStyle: { ...prev.customBoxStyle, boxBorderColor: e.target.value } }))}
                    className="w-full h-8 rounded bg-transparent cursor-pointer"
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-[11px] font-bold text-slate-300">
                    <span>Border Stroke Width (px)</span>
                    <span className="text-cyan-400">{config.customBoxStyle?.borderStrokeWidthPx || 2}</span>
                  </div>
                  <input
                    type="range" min="0" max="10"
                    value={config.customBoxStyle?.borderStrokeWidthPx || 2}
                    onChange={(e) => handleUpdate(prev => ({ ...prev, customBoxStyle: { ...prev.customBoxStyle, borderStrokeWidthPx: Number(e.target.value) } }))}
                    className="w-full accent-cyan-500"
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-[11px] font-bold text-slate-300">
                    <span>Neon Glow Intensity (%)</span>
                    <span className="text-cyan-400">{config.customBoxStyle?.glowIntensityPercent || 35}</span>
                  </div>
                  <input
                    type="range" min="0" max="100"
                    value={config.customBoxStyle?.glowIntensityPercent || 35}
                    onChange={(e) => handleUpdate(prev => ({ ...prev, customBoxStyle: { ...prev.customBoxStyle, glowIntensityPercent: Number(e.target.value) } }))}
                    className="w-full accent-cyan-500"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[11px] font-bold text-slate-300">Border Radius Style</label>
                  <div className="flex gap-2">
                    {[
                      { id: 'square', label: 'Square (0px)' },
                      { id: 'curved-8', label: 'Curved (8px)' },
                      { id: 'curved-12', label: 'Curved (12px)' },
                      { id: 'pill', label: 'Pill (Full)' },
                    ].map(rad => (
                      <button
                        key={rad.id} type="button"
                        onClick={() => handleUpdate(prev => ({ ...prev, customBoxStyle: { ...prev.customBoxStyle, borderRadiusStyle: rad.id as any } }))}
                        className={`px-3 py-1.5 text-xs font-bold rounded-lg border ${(config.customBoxStyle?.borderRadiusStyle || 'curved-12') === rad.id ? 'bg-cyan-500/20 border-cyan-500 text-white' : 'border-[#2d3145] text-slate-400'}`}
                      >
                        {rad.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: MAIN PAGE CONTROL & REAL-TIME LAYOUT SYNC */}
      {activeTab === 'layout_control' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">8. Main Page Control &amp; Live Layout Sync</h3>
                <p className="text-xs text-slate-400">
                  Take full control of the main page design, layout visibility, and corner triggers. Toggle individual sections and watch the synced local state update the workspace in real-time.
                </p>
              </div>
            </div>

            {/* Layout Controls & Real-Time Sync Workspace */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left Column: Toggles */}
              <div className="lg:col-span-5 space-y-5 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5">
                <div className="flex items-center justify-between pb-3 border-b border-[#2d3145]">
                  <h4 className="text-xs font-black uppercase tracking-wider text-amber-400">
                    Security &amp; Layout Toggles
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 animate-pulse">
                    🟢 SYNCED
                  </span>
                </div>

                <div className="space-y-4">
                  {/* Floating Corner Admin Toggle */}
                  <div className="flex items-start justify-between p-3.5 bg-[#10121b] border border-[#23273a] hover:border-amber-500/35 rounded-xl transition-all">
                    <div className="space-y-1 pr-4">
                      <span className="text-xs font-bold text-slate-200 block">Floating Corner Admin Button</span>
                      <p className="text-[10px] text-slate-400">
                        Places a quick-floating "Admin Console" button in the bottom-right corner of the login page.
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={config.showFloatingCornerAdminButton}
                        onChange={(e) =>
                          handleUpdate((prev) => ({
                            ...prev,
                            showFloatingCornerAdminButton: e.target.checked,
                          }))
                        }
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500" />
                    </label>
                  </div>

                  {/* Floating AI Assistant Chat Widget */}
                  <div className="flex items-start justify-between p-3.5 bg-[#10121b] border border-[#23273a] hover:border-amber-500/35 rounded-xl transition-all">
                    <div className="space-y-1 pr-4">
                      <span className="text-xs font-bold text-slate-200 block">Floating Corner AI Assistant Widget</span>
                      <p className="text-[10px] text-slate-400">
                        Show a persistent floating assistant badge in the bottom-left corner of screens.
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={config.showFloatingCornerChatAssistant}
                        onChange={(e) =>
                          handleUpdate((prev) => ({
                            ...prev,
                            showFloatingCornerChatAssistant: e.target.checked,
                          }))
                        }
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500" />
                    </label>
                  </div>

                  {/* Header Corner Branding Logo */}
                  <div className="flex items-start justify-between p-3.5 bg-[#10121b] border border-[#23273a] hover:border-amber-500/35 rounded-xl transition-all">
                    <div className="space-y-1 pr-4">
                      <span className="text-xs font-bold text-slate-200 block">Header Corner Branding &amp; Logo</span>
                      <p className="text-[10px] text-slate-400">
                        Displays the corporate badge, logo text, and current platform version in top corners.
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={config.showHeaderCornerBranding}
                        onChange={(e) =>
                          handleUpdate((prev) => ({
                            ...prev,
                            showHeaderCornerBranding: e.target.checked,
                          }))
                        }
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500" />
                    </label>
                  </div>

                  {/* Corner Trim / Registration Marks */}
                  <div className="flex items-start justify-between p-3.5 bg-[#10121b] border border-[#23273a] hover:border-amber-500/35 rounded-xl transition-all">
                    <div className="space-y-1 pr-4">
                      <span className="text-xs font-bold text-slate-200 block">Page Corner Trim Marks</span>
                      <p className="text-[10px] text-slate-400">
                        Render vectors of crop targets, bleed regions, and page index codes in document corners.
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={config.showPageCornerRegistrationMarks}
                        onChange={(e) =>
                          handleUpdate((prev) => ({
                            ...prev,
                            showPageCornerRegistrationMarks: e.target.checked,
                          }))
                        }
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500" />
                    </label>
                  </div>

                  {/* Hide Header Entirely */}
                  <div className="flex items-start justify-between p-3.5 bg-[#10121b] border border-[#23273a] hover:border-amber-500/35 rounded-xl transition-all">
                    <div className="space-y-1 pr-4">
                      <span className="text-xs font-bold text-slate-200 block">Hide Top Header Navigation Bar</span>
                      <p className="text-[10px] text-slate-400">
                        Removes the top menu bar to provide maximum immersion in workspaces.
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={config.hideHeaderEntirely}
                        onChange={(e) =>
                          handleUpdate((prev) => ({
                            ...prev,
                            hideHeaderEntirely: e.target.checked,
                          }))
                        }
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500" />
                    </label>
                  </div>

                  {/* Hide Footer Entirely */}
                  <div className="flex items-start justify-between p-3.5 bg-[#10121b] border border-[#23273a] hover:border-amber-500/35 rounded-xl transition-all">
                    <div className="space-y-1 pr-4">
                      <span className="text-xs font-bold text-slate-200 block">Hide Bottom Footer &amp; Disclaimer</span>
                      <p className="text-[10px] text-slate-400">
                        Removes bottom system notices and cryptographic sandbox disclaimers completely.
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={config.hideFooterEntirely}
                        onChange={(e) =>
                          handleUpdate((prev) => ({
                            ...prev,
                            hideFooterEntirely: e.target.checked,
                          }))
                        }
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500" />
                    </label>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#2d3145] space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-200">
                    <Zap className="w-3.5 h-3.5 animate-bounce" />
                    <span>Instant LocalSync Active</span>
                  </div>
                  <p className="text-[10px] text-slate-400 leading-normal">
                    Adjusting these security properties will dynamically sync layouts across your browser session without rebooting.
                  </p>
                </div>
              </div>

              {/* Right Column: Interactive Live Preview Frame */}
              <div className="lg:col-span-7 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black uppercase tracking-wider text-cyan-300 flex items-center gap-2">
                    <Eye className="w-4 h-4 text-cyan-400" />
                    <span>Interactive Main Page Live Preview (Live Replica)</span>
                  </h4>
                  <span className="text-[10px] font-mono text-slate-400">Scale: 100% reactive</span>
                </div>

                {/* THE SIMULATED REPLICA SCREEN */}
                <div className="w-full rounded-2xl border border-slate-700/80 bg-slate-950/95 overflow-hidden shadow-2xl relative min-h-[460px] flex flex-col justify-between font-sans">
                  
                  {/* Top Header Corner Marks (Simulated) */}
                  {config.showPageCornerRegistrationMarks && (
                    <>
                      <div className="absolute top-1.5 left-1.5 text-[8px] font-mono text-slate-500 select-none z-10 pointer-events-none">[CROP-TL // 3mm]</div>
                      <div className="absolute top-1.5 right-1.5 text-[8px] font-mono text-slate-500 select-none z-10 pointer-events-none">[CROP-TR // 3mm]</div>
                    </>
                  )}

                  {/* SIMULATED HEADER BAR */}
                  {!config.hideHeaderEntirely ? (
                    <div className="bg-[#0f111a] border-b border-[#232635] px-4 py-3 flex items-center justify-between relative transition-all duration-300">
                      {/* Left Header Corner */}
                      <div className="flex items-center gap-2">
                        {config.showHeaderCornerBranding ? (
                          <div className="flex items-center gap-1.5 bg-[#2563eb]/20 px-2 py-0.5 rounded-lg border border-blue-500/30">
                            <span className="w-2 h-2 rounded-full bg-blue-500 animate-ping" />
                            <span className="text-[10px] font-black text-blue-300 uppercase tracking-wider">
                              {config.uiTextOverrides?.brandingLogoText || "GlowPDF"}
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] font-mono text-slate-500 italic">[Logo Corner Hidden]</span>
                        )}
                        <span className="text-[10px] font-bold text-slate-200">Suite Desktop Node</span>
                      </div>

                      {/* Header Center / Right Corner */}
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">v2026.4</span>
                        {config.showHeaderCornerBranding && (
                          <span className="text-[9px] text-amber-400 font-bold bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded">
                            PRO SYSTEM
                          </span>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 bg-red-950/20 border-b border-red-900/30 text-center text-[10px] font-mono text-red-400 transition-all duration-300">
                      🚫 Main Navigation Header Hidden Entirely
                    </div>
                  )}

                  {/* SIMULATED WORKSPACE CANVAS / DIRECTORY */}
                  <div className="p-6 flex-1 flex flex-col justify-center space-y-4 relative">
                    
                    {/* Welcome Banner */}
                    <div className="text-center space-y-1">
                      <h5 className="text-sm font-black text-slate-100 tracking-wide">
                        {config.loginHeadingText || "GlowPDF Master Console"}
                      </h5>
                      <p className="text-[10px] text-slate-400 max-w-sm mx-auto">
                        {config.loginSubheadingText || "✨ Makes your documents glow"}
                      </p>
                    </div>

                    {/* Miniature Dashboard Cards */}
                    <div className="grid grid-cols-2 gap-2.5 max-w-md mx-auto w-full">
                      {[
                        { title: 'Core PDF Editor', desc: 'WYSIWYG layout tool', color: 'border-blue-500/30' },
                        { title: 'AI OCR Reader', desc: 'Scan files instantly', color: 'border-purple-500/30' },
                        { title: 'ZKD Shield', desc: 'Zero-knowledge lock', color: 'border-emerald-500/30' },
                        { title: 'Stamping Engine', desc: 'Apply dynamic markings', color: 'border-amber-500/30' },
                      ].map((item, idx) => (
                        <div
                          key={idx}
                          className={`p-2.5 bg-[#141724] border ${item.color} rounded-xl space-y-1 select-none`}
                        >
                          <span className="text-[10px] font-bold text-slate-100 block">{item.title}</span>
                          <span className="text-[8px] text-slate-400 block">{item.desc}</span>
                        </div>
                      ))}
                    </div>

                    {/* Central Area Indicators */}
                    <div className="text-center">
                      <span className="inline-block text-[9px] font-mono font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-1 rounded-full animate-pulse">
                        🔗 LIVE PREVIEW RUNTIME ACTIVE
                      </span>
                    </div>

                    {/* FLOATING CORNER WIDGETS PREVIEWS (SIMULATED) */}
                    
                    {/* Floating Assistant Widget (Bottom-Left) */}
                    {config.showFloatingCornerChatAssistant && (
                      <div className="absolute bottom-3 left-3 bg-blue-600 hover:bg-blue-500 text-white p-2 rounded-xl flex items-center gap-1.5 shadow-xl border border-blue-400/30 cursor-pointer animate-bounce z-20">
                        <Sparkles className="w-3 h-3 text-cyan-200" />
                        <span className="text-[8px] font-black tracking-wide uppercase pr-1">AI Assistant</span>
                      </div>
                    )}

                    {/* Floating Admin Console Button (Bottom-Right) */}
                    {config.showFloatingCornerAdminButton && (
                      <div className="absolute bottom-3 right-3 bg-amber-500 text-black p-2 rounded-xl flex items-center gap-1.5 shadow-xl border border-amber-300/40 cursor-pointer z-20">
                        <Shield className="w-3 h-3" />
                        <span className="text-[8px] font-black tracking-wide uppercase pr-1">Admin Panel</span>
                      </div>
                    )}
                  </div>

                  {/* SIMULATED FOOTER BAR */}
                  {!config.hideFooterEntirely ? (
                    <div className="bg-[#0b0c13] border-t border-[#1d1f2d] px-4 py-2 text-center text-[9px] font-mono text-slate-500">
                      {config.loginDisclaimer || "GLOWPDF SECURE CRYPTO CONSOLE // ESTABLISHED 2026"}
                    </div>
                  ) : (
                    <div className="p-1.5 bg-slate-900/60 text-center text-[8px] font-mono text-slate-600 border-t border-slate-800">
                      🚫 Main Page Footer &amp; Disclaimer Hidden
                    </div>
                  )}

                  {/* Bottom Header Corner Marks (Simulated) */}
                  {config.showPageCornerRegistrationMarks && (
                    <>
                      <div className="absolute bottom-1.5 left-1.5 text-[8px] font-mono text-slate-500 select-none pointer-events-none">[CROP-BL // 3mm]</div>
                      <div className="absolute bottom-1.5 right-1.5 text-[8px] font-mono text-slate-500 select-none pointer-events-none">[CROP-BR // 3mm]</div>
                    </>
                  )}

                </div>

                {/* HELP CARD */}
                <div className="p-4 bg-slate-900/40 border border-[#2d3145]/40 rounded-xl space-y-1.5">
                  <span className="text-xs font-bold text-cyan-200 block flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                    How syncing works
                  </span>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    This control dashboard operates as a master state controller. Any checkboxes enabled here are synchronized to the local state system immediately. Active pages across this browser tab read the local store configuration dynamically, allowing you to instantly hide standard headers, custom corners, or layout pieces on demand.
                  </p>
                </div>

              </div>

            </div>

            {/* CATEGORY 2: Main Workspace Section Visibility Manager */}
            <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl mt-6">
              <div className="flex items-center justify-between pb-3 border-b border-[#212431]">
                <div className="flex items-center gap-2">
                  <EyeOff className="w-5 h-5 text-rose-400" />
                  <h4 className="text-base font-black uppercase tracking-wider text-rose-300">
                    2. Workspace & Landing Page Visibility & Size Manager
                  </h4>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-3 px-3 py-1 bg-indigo-500/10 border border-indigo-500/30 rounded-lg">
                    <span className="text-[10px] font-bold text-indigo-300 uppercase">Box Size Scale</span>
                    <input 
                      type="range" 
                      min="0.8" 
                      max="1.2" 
                      step="0.05"
                      value={config.sectionScale || 1.0}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, sectionScale: parseFloat(e.target.value) }))}
                      className="w-24 h-1.5 bg-indigo-900/50 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                    />
                    <span className="text-[10px] font-mono font-bold text-indigo-400">{(config.sectionScale || 1.0).toFixed(2)}x</span>
                  </div>
                  <button
                    onClick={() => {
                      handleUpdate(prev => ({ ...prev, disabledSections: [] }));
                      toast.success('All sections restored and visible!');
                    }}
                    className="text-[10px] bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-400 px-3 py-1 rounded-lg border border-emerald-500/30 transition-all font-bold"
                  >
                    Show All Blocks
                  </button>
                </div>
              </div>

              {/* SECTION A: MAIN LANDING PAGE BOXES (THE BIG 4) */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-l-4 border-emerald-500 pl-3">
                  <h5 className="text-xs font-black text-white uppercase tracking-widest flex items-center gap-2">
                    <Grid className="w-3.5 h-3.5 text-emerald-400" />
                    Main Landing Page Section Blocks
                  </h5>
                  <span className="text-[10px] text-slate-500 font-medium lowercase">(The large colored boxes on home screen)</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    { id: 'section1', label: '🟢 SECTION 1: AI & Health Diagnostics', desc: 'Neural chat, summarizers, and PHI audit.' },
                    { id: 'section2', label: '🔵 SECTION 2: Core PDF Production', desc: 'Merge, split, edit, and conversion tools.' },
                    { id: 'section3', label: '🟣 SECTION 3: Industry Compliance', desc: 'Gov, Academic, Financial, and HIPAA.' },
                    { id: 'section4', label: '🟡 SECTION 4: Storage & Whiteboard', desc: 'Vault, engagement tools, and studio.' },
                  ].map((section) => {
                    const isHidden = config.disabledSections?.includes(section.id);
                    return (
                      <div key={section.id} className={`p-4 rounded-xl border-2 transition-all group ${
                        isHidden ? 'bg-rose-950/10 border-rose-500/20' : 'bg-[#1a1d2d] border-[#2a2d40] hover:border-emerald-500/30'
                      }`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="space-y-1">
                            <span className={`text-xs font-bold block ${isHidden ? 'text-rose-300' : 'text-white'}`}>
                              {section.label}
                            </span>
                            <p className="text-[10px] text-slate-400 leading-tight">
                              {section.desc}
                            </p>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer select-none">
                            <input
                              type="checkbox"
                              checked={!isHidden}
                              onChange={(e) => {
                                const checked = e.target.checked;
                                handleUpdate((prev) => {
                                  const currentDisabled = prev.disabledSections || [];
                                  let nextDisabled;
                                  if (checked) {
                                    nextDisabled = currentDisabled.filter(id => id !== section.id);
                                  } else {
                                    nextDisabled = [...currentDisabled.filter(id => id !== section.id), section.id];
                                  }
                                  return { ...prev, disabledSections: nextDisabled };
                                });
                                toast(`${checked ? 'VISIBLE' : 'HIDDEN'}: ${section.id.toUpperCase()}`, { icon: checked ? '👁️' : '🚫' });
                              }}
                              className="sr-only peer"
                            />
                            <div className="w-10 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500" />
                          </label>
                        </div>
                        <div className="mt-2.5 flex items-center gap-1.5 pt-2 border-t border-slate-800/50">
                          {isHidden ? (
                            <span className="text-[9px] font-mono font-bold text-rose-400 flex items-center gap-1">
                              <EyeOff className="w-3 h-3" /> USER ACCESS REMOVED
                            </span>
                          ) : (
                            <span className="text-[9px] font-mono font-bold text-emerald-400 flex items-center gap-1">
                              <Eye className="w-3 h-3" /> PUBLICLY VISIBLE
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* SECTION B: SIDEBAR & NAVIGATOR SECTIONS */}
              <div className="space-y-4 pt-4 border-t border-slate-800/40">
                <div className="flex items-center gap-2 border-l-4 border-indigo-500 pl-3">
                  <h5 className="text-xs font-black text-white uppercase tracking-widest flex items-center gap-2">
                    <Layers className="w-3.5 h-3.5 text-indigo-400" />
                    Sidebar & Navigator Categories
                  </h5>
                  <span className="text-[10px] text-slate-500 font-medium lowercase">(Navigation categories in left sidebar menu)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
                  {MAIN_SECTION_HEADINGS.map((h) => {
                    const isHidden = config.disabledSections?.includes(h.id);
                    return (
                      <div key={h.id} className={`p-3 rounded-xl border transition-all ${
                        isHidden ? 'bg-rose-950/20 border-rose-500/30 shadow-inner' : 'bg-[#10121b] border-[#23273a] hover:border-indigo-500/40'
                      }`}>
                        <div className="flex items-center justify-between gap-3 mb-2">
                          <span className={`text-[10px] font-bold truncate pr-1 ${isHidden ? 'text-rose-300' : 'text-slate-200'}`} title={h.title}>
                            {h.title.split(':').pop()?.trim().substring(0, 20)}...
                          </span>
                          <label className="relative inline-flex items-center cursor-pointer scale-75 origin-right">
                            <input
                              type="checkbox"
                              checked={!isHidden}
                              onChange={(e) => {
                                const checked = e.target.checked;
                                handleUpdate((prev) => {
                                  const currentDisabled = prev.disabledSections || [];
                                  let nextDisabled;
                                  if (checked) {
                                    nextDisabled = currentDisabled.filter(id => id !== h.id);
                                  } else {
                                    nextDisabled = [...currentDisabled.filter(id => id !== h.id), h.id];
                                  }
                                  return { ...prev, disabledSections: nextDisabled };
                                });
                              }}
                              className="sr-only peer"
                            />
                            <div className="w-9 h-5 bg-slate-700 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-500" />
                          </label>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className={`text-[9px] font-mono font-black px-1.5 py-0.5 rounded ${isHidden ? 'bg-rose-500/10 text-rose-400' : 'bg-indigo-500/10 text-indigo-400'}`}>
                            {isHidden ? 'BLOCK' : 'ACTIVE'}
                          </span>
                          <span className="text-[8px] text-slate-500 font-mono">ID: {h.id.substring(0, 10)}...</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-300 uppercase tracking-wide">
                  <AlertTriangle className="w-4 h-4" />
                  Granular Box Control Note
                </div>
                <p className="text-[10px] text-slate-400 leading-relaxed italic">
                  "Hide" rules apply instantly to all non-admin sessions. Admins will still see hidden sections to facilitate management, but regular users will encounter a clean workspace with only approved modules visible. 
                  <span className="text-indigo-400 font-bold ml-1">To hide specific sub-tools, use the "Suites & Features" tab to disable individual utility IDs.</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}



      {/* TAB 9: GLOBAL CONTENT & TYPOGRAPHY MANAGER (UI TEXT & BRANDING CMS) */}
      {activeTab === 'content' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Top Header & Save Banner */}
          <div className="bg-gradient-to-r from-[#141724] via-[#1a1f33] to-[#141724] border border-purple-500/30 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-[#23273a]">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-gradient-to-br from-purple-500/20 to-pink-500/20 text-purple-300 rounded-xl border border-purple-500/30 shadow-inner">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-white tracking-tight flex items-center gap-2">
                    Global Content & Typography Manager
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-950 text-purple-300 border border-purple-700 font-extrabold uppercase">
                      UI Text & Branding CMS
                    </span>
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5 font-medium">
                    Dynamically edit, live-preview, and persist all application copy, logo text, login headings, button labels, and theme captions in real-time across all views.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2.5 w-full md:w-auto shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    const resetOverrides = {};
                    handleUpdate(prev => ({ ...prev, uiTextOverrides: resetOverrides }));
                    const updated = { ...config, uiTextOverrides: resetOverrides };
                    saveAdminConfig(updated);
                    try {
                      localStorage.setItem('app_text_config', JSON.stringify({}));
                    } catch (e) {}
                    toast.success('🔄 Reset all UI text copy to factory defaults!');
                  }}
                  className="px-3.5 py-2 bg-red-950/60 hover:bg-red-900/70 text-red-300 text-xs font-bold rounded-xl transition-all border border-red-500/30 flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Reset to Defaults
                </button>

                <button
                  type="button"
                  onClick={() => {
                    saveAdminConfig(config);
                    try {
                      localStorage.setItem('app_text_config', JSON.stringify(config.uiTextOverrides || {}));
                    } catch (e) {}
                    toast.success('💾 All UI Text & Branding CMS Changes Saved & Synced Globally! All screens updated in real time.');
                  }}
                  className="px-5 py-2 bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs rounded-xl shadow-lg shadow-purple-500/30 transition-all hover:scale-105 active:scale-95 flex items-center gap-2 cursor-pointer border border-purple-400/40"
                >
                  <Save className="w-4 h-4" />
                  💾 Save All Text Changes
                </button>
              </div>
            </div>

            {/* Quick Status Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 pt-1">
              <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
                <CheckCircle2 className="w-4 h-4" />
                Local Storage & Global State Synchronized
              </span>
              <span className="text-[11px] font-mono text-purple-300 bg-purple-950/80 px-2.5 py-1 rounded-lg border border-purple-800">
                Active Text Overrides Count: {Object.keys(config.uiTextOverrides || {}).length} custom keys
              </span>
            </div>
          </div>

          {/* CATEGORY 1: BRANDING & LOGOS */}
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-5 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#212431]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <h4 className="text-sm font-black uppercase tracking-wider text-cyan-300">
                  1. Branding & Logos
                </h4>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">App Header & Main Logo Bar</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Inputs Column */}
              <div className="lg:col-span-7 space-y-4">
                {/* Logo Main Text */}
                <div className="space-y-1.5 p-3.5 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-bold text-white">Logo Main Text</label>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          const val = config.uiTextOverrides?.brandingLogoText || 'GlowPDF';
                          handleUpdate(prev => ({
                            ...prev,
                            loginLogoText: val,
                            uiTextOverrides: {
                              ...prev.uiTextOverrides,
                              brandingLogoText: val,
                              brandingInsideLogoText: val.substring(0, 4).toUpperCase()
                            }
                          }));
                          toast.success('Synced logo text across all modules!');
                        }}
                        className="text-[10px] bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-400 px-2 py-0.5 rounded border border-cyan-500/30 transition-all flex items-center gap-1"
                        title="Sync this text to login pages and headers"
                      >
                        <RefreshCw className="w-3 h-3" /> Sync Everywhere
                      </button>
                      <span className="text-[10px] text-slate-400">Default: "GlowPDF Suite"</span>
                    </div>
                  </div>
                  <input
                    type="text"
                    value={config.uiTextOverrides?.brandingLogoText ?? 'GlowPDF Suite'}
                    onChange={(e) => handleUpdate(prev => ({
                      ...prev,
                      uiTextOverrides: { ...(prev.uiTextOverrides || {}), brandingLogoText: e.target.value }
                    }))}
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-medium"
                    placeholder="e.g. GlowPDF Suite"
                  />
                </div>

                {/* Badge Label */}
                <div className="space-y-1.5 p-3.5 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-bold text-white">Badge Label</label>
                    <span className="text-[10px] text-slate-400">Default: "GLOW"</span>
                  </div>
                  <input
                    type="text"
                    value={config.uiTextOverrides?.brandingBadgeLabel ?? 'GLOW'}
                    onChange={(e) => handleUpdate(prev => ({
                      ...prev,
                      uiTextOverrides: { ...(prev.uiTextOverrides || {}), brandingBadgeLabel: e.target.value.toUpperCase() }
                    }))}
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-medium uppercase"
                    placeholder="e.g. GLOW"
                  />
                </div>

                {/* Inside Logo Text (The text inside the circular GlowLogo) */}
                <div className="space-y-1.5 p-3.5 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-bold text-white">Inside Logo Text (Circular Logo)</label>
                    <span className="text-[10px] text-slate-400">Default: "GLOW"</span>
                  </div>
                  <input
                    type="text"
                    value={config.uiTextOverrides?.brandingInsideLogoText ?? 'GLOW'}
                    onChange={(e) => handleUpdate(prev => ({
                      ...prev,
                      uiTextOverrides: { ...(prev.uiTextOverrides || {}), brandingInsideLogoText: e.target.value.toUpperCase() }
                    }))}
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-medium uppercase"
                    placeholder="e.g. GLOW"
                  />
                </div>

                {/* Rosee Glow Button Text */}
                <div className="space-y-1.5 p-3.5 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-bold text-white">Rosee Glow Button Text</label>
                    <span className="text-[10px] text-slate-400">Default: "✨ GO WITH ROSEE GLOW"</span>
                  </div>
                  <input
                    type="text"
                    value={config.uiTextOverrides?.roseeGlowBtnText ?? '✨ GO WITH ROSEE GLOW'}
                    onChange={(e) => handleUpdate(prev => ({
                      ...prev,
                      uiTextOverrides: { ...(prev.uiTextOverrides || {}), roseeGlowBtnText: e.target.value }
                    }))}
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500 font-medium"
                    placeholder="e.g. ✨ GO WITH ROSEE GLOW"
                  />
                </div>

                {/* Header Workspace Title */}
                <div className="space-y-1.5 p-3.5 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-bold text-white">Header Subtitle Tagline</label>
                    <span className="text-[10px] text-slate-400">Default: "✨ Makes your documents glow"</span>
                  </div>
                  <input
                    type="text"
                    value={config.uiTextOverrides?.brandingHeaderTitle ?? '✨ Makes your documents glow'}
                    onChange={(e) => handleUpdate(prev => ({
                      ...prev,
                      uiTextOverrides: { ...(prev.uiTextOverrides || {}), brandingHeaderTitle: e.target.value }
                    }))}
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-medium"
                    placeholder="e.g. ✨ Makes your documents glow"
                  />
                </div>
              </div>

              {/* Interactive Live Preview Column */}
              <div className="lg:col-span-5 bg-[#0e1017] border border-cyan-500/30 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
                    <span className="text-[10px] font-mono uppercase font-black text-cyan-400 flex items-center gap-1">
                      <Eye className="w-3 h-3" /> Live Header Preview
                    </span>
                    <span className="text-[9px] text-slate-500">Real-Time Render</span>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center border-2 border-white shadow-lg overflow-hidden shrink-0">
                        <span className="text-[10px] font-black text-white tracking-tighter leading-none select-none">
                          {config.uiTextOverrides?.brandingInsideLogoText || 'GLOW'}
                        </span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h1 className="text-sm font-black text-white tracking-tight">
                            {config.uiTextOverrides?.brandingLogoText || 'GlowPDF Suite'}
                          </h1>
                          <span className="text-[9px] font-mono font-black px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 uppercase">
                            {config.uiTextOverrides?.brandingBadgeLabel || 'GLOW'}
                          </span>
                        </div>
                        <p className="text-[11px] font-bold text-cyan-300 mt-0.5">
                          {config.uiTextOverrides?.brandingHeaderTitle || '✨ Makes your documents glow'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <p className="text-[10px] text-slate-500 italic mt-3 text-center">
                  Updates header bar on top left and splash logo cards instantly.
                </p>
              </div>
            </div>
          </div>

          {/* CATEGORY 2: LOGIN & AUTHENTICATION VIEW */}
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-5 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#212431]">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-pink-400" />
                <h4 className="text-sm font-black uppercase tracking-wider text-pink-300">
                  2. Login & Authentication View
                </h4>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Login & Signup Card Copy</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Inputs Column */}
              <div className="lg:col-span-7 space-y-3.5">
                {/* Login Heading */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Login Heading</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.loginHeading ?? 'Welcome Back'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), loginHeading: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-pink-500 font-medium"
                    />
                  </div>

                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Signup Heading</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.loginSignupHeading ?? 'Create Your Account'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), loginSignupHeading: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-pink-500 font-medium"
                    />
                  </div>
                </div>

                {/* Subtitles */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Login Subtitle</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.loginSubtext ?? 'Sign in to access your document workspace'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), loginSubtext: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-pink-500 font-medium"
                    />
                  </div>

                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Signup Subtitle</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.loginSignupSubtext ?? 'Sign up to access all document & media tools'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), loginSignupSubtext: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-pink-500 font-medium"
                    />
                  </div>
                </div>

                {/* Button Labels & Security */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Tab: Sign In</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.loginBtnSignIn ?? 'Sign In'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), loginBtnSignIn: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-pink-500 font-medium"
                    />
                  </div>

                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Tab: Create Account</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.loginBtnSignUp ?? 'Create Account'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), loginBtnSignUp: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-pink-500 font-medium"
                    />
                  </div>

                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Security Footer</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.loginFooterSecurity ?? '256-Bit Encrypted Authentication'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), loginFooterSecurity: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-pink-500 font-medium"
                    />
                  </div>
                </div>
              </div>

              {/* Interactive Live Preview Column */}
              <div className="lg:col-span-5 bg-[#0e1017] border border-pink-500/30 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
                    <span className="text-[10px] font-mono uppercase font-black text-pink-400 flex items-center gap-1">
                      <Eye className="w-3 h-3" /> Live Login Card Preview
                    </span>
                    <span className="text-[9px] text-slate-500">Real-Time Render</span>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3 text-white">
                    <div>
                      <h2 className="text-base font-black text-white">
                        {config.uiTextOverrides?.loginHeading || 'Welcome Back'}
                      </h2>
                      <p className="text-[11px] text-slate-400">
                        {config.uiTextOverrides?.loginSubtext || 'Sign in to access your document workspace'}
                      </p>
                    </div>

                    <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs font-bold gap-1">
                      <div className="flex-1 py-1 text-center bg-sky-600 text-white rounded font-extrabold text-[11px]">
                        {config.uiTextOverrides?.loginBtnSignIn || 'Sign In'}
                      </div>
                      <div className="flex-1 py-1 text-center text-slate-400 text-[11px]">
                        {config.uiTextOverrides?.loginBtnSignUp || 'Create Account'}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{config.uiTextOverrides?.loginFooterSecurity || '256-Bit Encrypted Authentication'}</span>
                    </div>
                  </div>
                </div>

                <p className="text-[10px] text-slate-500 italic mt-3 text-center">
                  Renders live on the main sign in / signup card.
                </p>
              </div>
            </div>
          </div>

          {/* CATEGORY 3: BULK AUTO-SIGNER & WORKSPACE */}
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-5 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#212431]">
              <div className="flex items-center gap-2">
                <FileSignature className="w-4 h-4 text-amber-400" />
                <h4 className="text-sm font-black uppercase tracking-wider text-amber-300">
                  3. Bulk Auto-Signer & Workspace
                </h4>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Workspace Modal Titles & Actions</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Inputs Column */}
              <div className="lg:col-span-7 space-y-3.5">
                <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                  <label className="text-[11px] font-bold text-white block">Auto-Signer Modal Title</label>
                  <input
                    type="text"
                    value={config.uiTextOverrides?.autoSignerTitle ?? 'Bulk Auto-Signer & Document Workspace'}
                    onChange={(e) => handleUpdate(prev => ({
                      ...prev,
                      uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerTitle: e.target.value }
                    }))}
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                  />
                </div>

                <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                  <label className="text-[11px] font-bold text-white block">Auto-Signer Subtitle Description</label>
                  <input
                    type="text"
                    value={config.uiTextOverrides?.autoSignerSubtext ?? 'High-capacity streaming algorithm: Batch sign up to 10,000+ PDFs without memory crashes.'}
                    onChange={(e) => handleUpdate(prev => ({
                      ...prev,
                      uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerSubtext: e.target.value }
                    }))}
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">3 TB Demo Batch Button Text</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerDemoBtn ?? '⚡ Load 3 TB Demo Batch (200,000 Files)'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerDemoBtn: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>

                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Engine Status Badge Text</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerStatusBadge ?? 'RAM-Capped Engine Ready'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerStatusBadge: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>
                </div>

                {/* New Bulk Signer Text Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Stats Label</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerStatsLabel ?? 'Live High-Capacity Analytics'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerStatsLabel: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Queue Label</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerQueueLabel ?? 'Document Queue'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerQueueLabel: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Settings Label</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerSettingsLabel ?? 'Signature Placement Settings'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerSettingsLabel: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Security Hardware Note</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerSecurityNote ?? 'FIPS 140-2 Level 3 HSM Protected'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerSecurityNote: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Processed Label</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerProcessedLabel ?? 'Processed'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerProcessedLabel: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Failed Label</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerFailedLabel ?? 'Failed / Error'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerFailedLabel: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Throughput Label</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerSpeedLabel ?? 'Throughput Speed'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerSpeedLabel: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>
                </div>

                {/* Additional Text Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Import Section Label</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerImportLabel ?? 'Import / Test Scale Queue:'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerImportLabel: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Universal Acceptance Note</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.autoSignerUniversalNote ?? 'Universal Document Acceptance Activated'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), autoSignerUniversalNote: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>
                </div>
              </div>

              {/* Interactive Live Preview Column */}
              <div className="lg:col-span-5 bg-[#0e1017] border border-amber-500/30 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
                    <span className="text-[10px] font-mono uppercase font-black text-amber-400 flex items-center gap-1">
                      <Eye className="w-3 h-3" /> Live Auto-Signer Header Preview
                    </span>
                    <span className="text-[9px] text-slate-500">Real-Time Render</span>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h2 className="text-sm font-black text-white">
                        {config.uiTextOverrides?.autoSignerTitle || 'Bulk Auto-Signer & Document Workspace'}
                      </h2>
                      <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                        {config.uiTextOverrides?.autoSignerStatusBadge || 'RAM-Capped Engine Ready'}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400">
                      {config.uiTextOverrides?.autoSignerSubtext || 'Extreme-scale batch document processor with DOM virtualization'}
                    </p>

                    <div className="pt-2">
                      <div className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 text-white font-black text-[11px] text-center shadow">
                        {config.uiTextOverrides?.autoSignerDemoBtn || '⚡ Load 3 TB Demo Batch (200,000 Files)'}
                      </div>
                    </div>
                  </div>
                </div>

                <p className="text-[10px] text-slate-500 italic mt-3 text-center">
                  Updates the Bulk Auto-Signer modal instantly.
                </p>
              </div>
            </div>
          </div>

          {/* CATEGORY 4: THEME & GLOW ACCENTS */}
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-5 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#212431]">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-rose-400" />
                <h4 className="text-sm font-black uppercase tracking-wider text-rose-300">
                  4. Theme & Glow Accents
                </h4>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Special Theme Shortcut Captions</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Inputs Column */}
              <div className="lg:col-span-7 space-y-3.5">
                <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                  <label className="text-[11px] font-bold text-white block">Rosee Glow Button Caption</label>
                  <input
                    type="text"
                    value={config.uiTextOverrides?.roseeGlowBtnText ?? '✨ GO WITH ROSEE GLOW'}
                    onChange={(e) => handleUpdate(prev => ({
                      ...prev,
                      uiTextOverrides: { ...(prev.uiTextOverrides || {}), roseeGlowBtnText: e.target.value }
                    }))}
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-500 font-medium"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Header Admin Console Shortcut</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.headerAdminBtnText ?? 'Admin Console'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), headerAdminBtnText: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-rose-500 font-medium"
                    />
                  </div>

                  <div className="space-y-1 p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl">
                    <label className="text-[11px] font-bold text-white block">Explore Subtext Arrow</label>
                    <input
                      type="text"
                      value={config.uiTextOverrides?.quickExploreSubtext ?? 'Please go and explore ➔'}
                      onChange={(e) => handleUpdate(prev => ({
                        ...prev,
                        uiTextOverrides: { ...(prev.uiTextOverrides || {}), quickExploreSubtext: e.target.value }
                      }))}
                      className="w-full bg-[#10121b] border border-[#2d3145] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-rose-500 font-medium"
                    />
                  </div>
                </div>
              </div>

              {/* Interactive Live Preview Column */}
              <div className="lg:col-span-5 bg-[#0e1017] border border-rose-500/30 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
                    <span className="text-[10px] font-mono uppercase font-black text-rose-400 flex items-center gap-1">
                      <Eye className="w-3 h-3" /> Live Rosee Glow Button Preview
                    </span>
                    <span className="text-[9px] text-slate-500">Real-Time Render</span>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center">
                    <div className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 text-white border border-rose-300/40 shadow-[0_0_15px_rgba(244,63,94,0.6)] flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-white animate-pulse shrink-0 drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
                      <span className="text-white font-extrabold tracking-wider uppercase text-xs">
                        {config.uiTextOverrides?.roseeGlowBtnText || '✨ GO WITH ROSEE GLOW'}
                      </span>
                    </div>
                  </div>
                </div>

                <p className="text-[10px] text-slate-500 italic mt-3 text-center">
                  Updates Rosee Glow shortcut button beside Welcome Back.
                </p>
              </div>
            </div>
          </div>

          {/* Bottom Save All Bar */}
          <div className="p-4 rounded-2xl bg-[#141724] border border-purple-500/30 flex items-center justify-between">
            <span className="text-xs text-slate-300 font-medium">
              Save changes to sync local storage schema (`app_text_config`) and global React context instantaneously.
            </span>

            <button
              type="button"
              onClick={() => {
                saveAdminConfig(config);
                try {
                  localStorage.setItem('app_text_config', JSON.stringify(config.uiTextOverrides || {}));
                } catch (e) {}
                toast.success('💾 All UI Text & Branding CMS Changes Saved & Synced Globally!');
              }}
              className="px-6 py-2.5 bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs rounded-xl shadow-lg shadow-purple-500/30 transition-all hover:scale-105 active:scale-95 flex items-center gap-2 cursor-pointer border border-purple-400/40"
            >
              <Save className="w-4 h-4" />
              💾 Save All Text Changes
            </button>
          </div>
        </div>
      )}

      {/* TAB 10: USER ACCESS & RBAC */}
      {activeTab === 'users' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-orange-500/10 text-orange-400 rounded-xl">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black text-white tracking-wide">User Management & RBAC</h3>
                <p className="text-xs text-slate-400">Manage users, assign roles, and configure feature access matrices.</p>
              </div>
            </div>

            <div className="space-y-6">
              <h4 className="text-xs font-black uppercase tracking-wider text-orange-300">Feature Access Control Rules</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-[#2a2d40]">
                      <th className="p-2 text-[10px] uppercase text-slate-400 font-bold">Role</th>
                      <th className="p-2 text-[10px] uppercase text-slate-400 font-bold text-center">PDF Viewing</th>
                      <th className="p-2 text-[10px] uppercase text-slate-400 font-bold text-center">Media Studio</th>
                      <th className="p-2 text-[10px] uppercase text-slate-400 font-bold text-center">Max Upload (MB)</th>
                      <th className="p-2 text-[10px] uppercase text-slate-400 font-bold text-center">Whiteboard</th>
                      <th className="p-2 text-[10px] uppercase text-slate-400 font-bold text-center">AI Cleanup</th>
                    </tr>
                  </thead>
                  <tbody>
                    {['Basic User', 'Pro User', 'Teacher'].map(role => {
                      const rules = config.roleFeatureAccess?.[role] || { pdfViewing: true, mediaStudio: false, maxUploadMb: 5, whiteboardStudio: false, aiBackgroundRemoval: false };
                      return (
                        <tr key={role} className="border-b border-[#2a2d40] hover:bg-[#1a1d2d]/50">
                          <td className="p-2 text-xs font-bold text-white">{role}</td>
                          <td className="p-2 text-center">
                            <input type="checkbox" checked={rules.pdfViewing} onChange={(e) => handleUpdate(prev => ({ ...prev, roleFeatureAccess: { ...prev.roleFeatureAccess, [role]: { ...prev.roleFeatureAccess?.[role], pdfViewing: e.target.checked } } }))} className="accent-orange-500" />
                          </td>
                          <td className="p-2 text-center">
                            <input type="checkbox" checked={rules.mediaStudio} onChange={(e) => handleUpdate(prev => ({ ...prev, roleFeatureAccess: { ...prev.roleFeatureAccess, [role]: { ...prev.roleFeatureAccess?.[role], mediaStudio: e.target.checked } } }))} className="accent-orange-500" />
                          </td>
                          <td className="p-2 text-center">
                            <input type="number" value={rules.maxUploadMb} onChange={(e) => handleUpdate(prev => ({ ...prev, roleFeatureAccess: { ...prev.roleFeatureAccess, [role]: { ...prev.roleFeatureAccess?.[role], maxUploadMb: Number(e.target.value) } } }))} className="w-16 bg-[#10121b] border border-[#2d3145] rounded px-1 py-0.5 text-xs text-white text-center" />
                          </td>
                          <td className="p-2 text-center">
                            <input type="checkbox" checked={rules.whiteboardStudio} onChange={(e) => handleUpdate(prev => ({ ...prev, roleFeatureAccess: { ...prev.roleFeatureAccess, [role]: { ...prev.roleFeatureAccess?.[role], whiteboardStudio: e.target.checked } } }))} className="accent-orange-500" />
                          </td>
                          <td className="p-2 text-center">
                            <input type="checkbox" checked={rules.aiBackgroundRemoval} onChange={(e) => handleUpdate(prev => ({ ...prev, roleFeatureAccess: { ...prev.roleFeatureAccess, [role]: { ...prev.roleFeatureAccess?.[role], aiBackgroundRemoval: e.target.checked } } }))} className="accent-orange-500" />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <h4 className="text-xs font-black uppercase tracking-wider text-orange-300 mt-8">User Management Directory</h4>
              <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-[#10121b]">
                    <tr>
                      <th className="p-3 text-[10px] uppercase text-slate-400 font-bold">User</th>
                      <th className="p-3 text-[10px] uppercase text-slate-400 font-bold">Role</th>
                      <th className="p-3 text-[10px] uppercase text-slate-400 font-bold">Status</th>
                      <th className="p-3 text-[10px] uppercase text-slate-400 font-bold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {config.userRegistry.map(user => (
                      <tr key={user.id} className="border-t border-[#2a2d40]">
                        <td className="p-3">
                          <div className="text-xs font-bold text-white">{user.fullName}</div>
                          <div className="text-[10px] text-slate-400">{user.emailOrPhone}</div>
                        </td>
                        <td className="p-3">
                          <select className="bg-[#10121b] border border-[#2d3145] rounded-lg px-2 py-1 text-xs text-white">
                            <option>Basic User</option>
                            <option>Pro User</option>
                            <option>Teacher</option>
                            <option>Super Admin</option>
                          </select>
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-1 rounded text-[9px] font-bold uppercase ${user.status === 'active' || user.status === 'bypassed' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                            {user.status}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          <button type="button" className="text-[10px] font-bold text-blue-400 hover:text-blue-300 mr-2">Impersonate</button>
                          <button type="button" className="text-[10px] font-bold text-red-400 hover:text-red-300">Suspend</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 11: APP CONTROL & EMERGENCY SWITCHES */}
      {activeTab === 'app_control' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Master Admin Toggle Hub */}
          <RlzAdminControlPanel />

          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-rose-500/10 text-rose-400 rounded-xl">
                <Sliders className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black text-white tracking-wide">App Control & Emergency Switches</h3>
                <p className="text-xs text-slate-400">Toggle features instantly, trigger maintenance mode, or configure limit switches.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="text-xs font-black uppercase tracking-wider text-rose-300">Global Feature Toggles</h4>
                {[
                  { key: 'documentVault', label: 'Document Vault' },
                  { key: 'mediaStudio', label: 'Media Studio (Photo & Video)' },
                  { key: 'interactiveWhiteboard', label: 'Interactive Teaching Whiteboard' },
                  { key: 'aiCleanupTools', label: 'AI Cleanup Tools' },
                                    { key: 'publicRegistrations', label: 'Public User Registrations' },
                  { key: 'autoSilenceCutting', label: 'Auto-Silence Cutting & AI Scene Detection' },
                  { key: 'aiSpeechToTextCaptions', label: 'AI Speech-to-Text Auto-Captions' },
                  { key: 'highResVideoFrameExtraction', label: 'High-Res Video Frame Extraction' },
                  { key: 'photoToVideoKenBurns', label: 'Photo-to-Video Ken Burns Engine' },
                  { key: 'highBitrate4KRender', label: '4K / High Bitrate Render Pipelines' },
                ].map(flag => (
                  <label key={flag.key} className="flex items-center justify-between p-3 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl cursor-pointer hover:border-rose-500/50 transition-all">
                    <span className="text-xs font-bold text-white">{flag.label}</span>
                    <input
                      type="checkbox"
                      checked={config.featureFlags?.[flag.key as keyof typeof config.featureFlags] ?? true}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, featureFlags: { ...prev.featureFlags, [flag.key]: e.target.checked } }))}
                      className="w-4 h-4 accent-rose-500 rounded"
                    />
                  </label>
                ))}
              </div>

              <div className="space-y-4">
                <h4 className="text-xs font-black uppercase tracking-wider text-red-400">Maintenance & Kill Switches</h4>
                <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl space-y-4">
                  <label className="flex items-center justify-between cursor-pointer">
                    <div>
                      <span className="text-xs font-bold text-red-400 block">Maintenance Mode</span>
                      <span className="text-[10px] text-red-400/70">Locks public app, keeps /admin open</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={config.maintenanceMode}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, maintenanceMode: e.target.checked }))}
                      className="w-4 h-4 accent-red-500 rounded"
                    />
                  </label>
                  <label className="flex items-center justify-between cursor-pointer">
                    <div>
                      <span className="text-xs font-bold text-red-400 block">Kill 4K Video Pipeline</span>
                      <span className="text-[10px] text-red-400/70">Disables heavy video processing instantly</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={config.killSwitches?.videoRenderPipeline}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, killSwitches: { ...prev.killSwitches, videoRenderPipeline: e.target.checked } }))}
                      className="w-4 h-4 accent-red-500 rounded"
                    />
                  </label>
                  <label className="flex items-center justify-between cursor-pointer">
                    <div>
                      <span className="text-xs font-bold text-red-400 block">Kill AI Speech-to-Text</span>
                      <span className="text-[10px] text-red-400/70">Pauses AI compute requests</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={config.killSwitches?.aiSpeechToText}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, killSwitches: { ...prev.killSwitches, aiSpeechToText: e.target.checked } }))}
                      className="w-4 h-4 accent-red-500 rounded"
                    />
                  </label>
                </div>

                <h4 className="text-xs font-black uppercase tracking-wider text-rose-300 mt-6">Upload Limits</h4>
                <div className="p-4 bg-[#1a1d2d] border border-[#2a2d40] rounded-xl space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-[11px] font-bold text-slate-300">
                      <span>PDF Max Upload (MB)</span>
                      <span className="text-rose-400">{config.maxUploadLimits?.pdfMaxMb || 50} MB</span>
                    </div>
                    <input
                      type="range" min="1" max="200"
                      value={config.maxUploadLimits?.pdfMaxMb || 50}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, maxUploadLimits: { ...prev.maxUploadLimits, pdfMaxMb: Number(e.target.value) } }))}
                      className="w-full accent-rose-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[11px] font-bold text-slate-300">
                      <span>Video Max Upload (MB)</span>
                      <span className="text-rose-400">{config.maxUploadLimits?.videoMaxMb || 500} MB</span>
                    </div>
                    <input
                      type="range" min="10" max="2000" step="10"
                      value={config.maxUploadLimits?.videoMaxMb || 500}
                      onChange={(e) => handleUpdate(prev => ({ ...prev, maxUploadLimits: { ...prev.maxUploadLimits, videoMaxMb: Number(e.target.value) } }))}
                      className="w-full accent-rose-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 12: FREE SAMPLE DOWNLOAD & LEAD CAPTURE CONTROL */}
      {activeTab === 'free_sample' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-[#141724] border border-[#23273a] rounded-2xl p-6 space-y-6 shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-[#212431]">
              <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl">
                <Download className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black text-white tracking-wide">Free Sample Download & Lead Form Controls</h3>
                <p className="text-xs text-slate-400">Configure required fields (Mail, Full Name, MAC Address / Device ID, Phone, Company) and titles for the Free Sample Download modal.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Feature Toggle & Titles */}
              <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
                <h4 className="text-xs font-black uppercase tracking-wider text-amber-300">
                  Modal Heading, Subtitle & Button Labels
                </h4>

                <label className="flex items-center justify-between p-3 bg-[#10121b] border border-[#2d3145] rounded-xl cursor-pointer">
                  <div>
                    <span className="text-xs font-bold text-white block">Enable Free Sample Download Feature</span>
                    <span className="text-[10px] text-slate-400">Displays "Download Free Sample Pack" button on header & login page</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={config.freeSampleDownloadConfig?.enabled ?? true}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        freeSampleDownloadConfig: {
                          ...prev.freeSampleDownloadConfig,
                          enabled: e.target.checked,
                        },
                      }))
                    }
                    className="w-4 h-4 accent-amber-500 rounded"
                  />
                </label>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Button Label Text
                  </label>
                  <input
                    type="text"
                    value={config.freeSampleDownloadConfig?.buttonLabel || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        freeSampleDownloadConfig: {
                          ...prev.freeSampleDownloadConfig,
                          buttonLabel: e.target.value,
                        },
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Modal Title
                  </label>
                  <input
                    type="text"
                    value={config.freeSampleDownloadConfig?.modalTitle || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        freeSampleDownloadConfig: {
                          ...prev.freeSampleDownloadConfig,
                          modalTitle: e.target.value,
                        },
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Modal Subtitle Description
                  </label>
                  <textarea
                    rows={2}
                    value={config.freeSampleDownloadConfig?.modalSubtitle || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        freeSampleDownloadConfig: {
                          ...prev.freeSampleDownloadConfig,
                          modalSubtitle: e.target.value,
                        },
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Download File Name
                  </label>
                  <input
                    type="text"
                    value={config.freeSampleDownloadConfig?.downloadFileName || ''}
                    onChange={(e) =>
                      handleUpdate((prev) => ({
                        ...prev,
                        freeSampleDownloadConfig: {
                          ...prev.freeSampleDownloadConfig,
                          downloadFileName: e.target.value,
                        },
                      }))
                    }
                    className="w-full bg-[#10121b] border border-[#2d3145] rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Form Input Field Toggles */}
              <div className="bg-[#1a1d2d] border border-[#2a2d40] rounded-xl p-5 space-y-4">
                <h4 className="text-xs font-black uppercase tracking-wider text-amber-300">
                  Required Form Input Fields (Mail, Name, MAC Address, Tel, Company)
                </h4>

                <div className="space-y-3">
                  {[
                    { key: 'requireEmail', label: '✉️ Email / Mail Address', desc: 'Require user to enter valid corporate email address' },
                    { key: 'requireName', label: '👤 Full Name', desc: 'Require user full name' },
                    { key: 'requireMacAddress', label: '💻 MAC Address / Device Hardware ID', desc: 'Require or auto-detect device MAC address fingerprint' },
                    { key: 'requirePhone', label: '📞 Phone / Mobile Number', desc: 'Require phone number for SMS OTP verification' },
                    { key: 'requireCompanyName', label: '🏢 Company / Organization', desc: 'Require enterprise organization name' },
                    { key: 'requirePurpose', label: '📝 Purpose / Use Case', desc: 'Require project description' },
                  ].map((field) => (
                    <label
                      key={field.key}
                      className="flex items-center justify-between p-3 bg-[#10121b] border border-[#2d3145] rounded-xl cursor-pointer hover:border-amber-500/50 transition-all"
                    >
                      <div>
                        <span className="text-xs font-bold text-white block">{field.label}</span>
                        <span className="text-[10px] text-slate-400">{field.desc}</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={
                          config.freeSampleDownloadConfig?.[
                            field.key as keyof typeof config.freeSampleDownloadConfig
                          ] as boolean
                        }
                        onChange={(e) =>
                          handleUpdate((prev) => ({
                            ...prev,
                            freeSampleDownloadConfig: {
                              ...prev.freeSampleDownloadConfig,
                              [field.key]: e.target.checked,
                            },
                          }))
                        }
                        className="w-4 h-4 accent-amber-500 rounded"
                      />
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
