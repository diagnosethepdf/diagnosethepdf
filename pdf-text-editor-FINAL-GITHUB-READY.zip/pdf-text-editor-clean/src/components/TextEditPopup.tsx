/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { PDFTextRun, TextEditOverride } from '../types';
import { sampleColors } from '../utils/colorSampler';
import { getStandardTextWidth, cleanFontFamilyName } from '../utils/textMetrics';
import {
  X,
  Save,
  Palette,
  Type,
  Bold,
  Italic,
  Underline,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Sliders,
  RefreshCw,
  Layers,
} from 'lucide-react';

interface TextEditPopupProps {
  runId: string;
  pageIdx: number;
  runInfo: PDFTextRun;
  rect: DOMRect;
  existingEdit?: TextEditOverride;
  pageObj: any;
  scale: number;
  onSave: (override: TextEditOverride) => void;
  onCancel: () => void;
}

function guessPreciseFamily(fontFamily: string | undefined, fallback: 'sans' | 'serif' | 'mono'): string {
  if (!fontFamily) return fallback;
  const f = fontFamily.toLowerCase();
  if (f.includes('calibri')) return 'calibri';
  if (f.includes('arial')) return 'arial';
  if (f.includes('times')) return 'times';
  if (f.includes('georgia')) return 'georgia';
  if (f.includes('courier')) return 'courier';
  if (f.includes('mono') || f.includes('console') || f.includes('code')) return 'mono';
  if (f.includes('serif')) return 'serif';
  if (f.includes('sans') || f.includes('helvetica') || f.includes('tahoma') || f.includes('verdana')) return 'sans';
  return fallback;
}

export default function TextEditPopup({
  runId,
  pageIdx,
  runInfo,
  rect,
  existingEdit,
  pageObj,
  scale,
  onSave,
  onCancel,
}: TextEditPopupProps) {
  const popupRef = useRef<HTMLDivElement | null>(null);
  const textAreaRef = useRef<HTMLTextAreaElement | null>(null);

  const origSize = runInfo.fontHeightPx;
  const defaultSizePt = parseFloat(origSize.toFixed(1));

  // Form states
  const [text, setText] = useState('');
  const [findSub, setFindSub] = useState('');
  const [replaceSub, setReplaceSub] = useState('');
  const [family, setFamily] = useState<string>('sans');
  const [sizePt, setSizePt] = useState(defaultSizePt);
  const [bold, setBold] = useState(false);
  const [italic, setItalic] = useState(false);
  const [underline, setUnderline] = useState(false);
  const [strikethrough, setStrikethrough] = useState(false);
  
  const [bgMode, setBgMode] = useState<'auto' | 'custom' | 'transparent'>('auto');
  const [textColor, setTextColor] = useState('#000000');
  const [bgColor, setBgColor] = useState('#ffffff');
  const [sampledBgHex, setSampledBgHex] = useState('#ffffff');
  const [sampledInkHex, setSampledInkHex] = useState('#000000');

  const [alignment, setAlignment] = useState<'left' | 'center' | 'right' | 'justify'>('left');
  const [stretch, setStretch] = useState(1.0);
  const [isAutoFit, setIsAutoFit] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  // Placement coordinates
  const [pos, setPos] = useState({ left: 0, top: 0 });

  const originalScaleX = Math.hypot(runInfo.transform[0], runInfo.transform[1]);
  const originalScaleY = Math.hypot(runInfo.transform[2], runInfo.transform[3]);
  const baseAspectScale = originalScaleY !== 0 ? originalScaleX / originalScaleY : 1.0;

  // Calculate stretch factor (default 1.0 for natural text aspect ratio without warping font)
  let computedStretch = 1.0;
  if (isAutoFit && text.trim() !== '') {
    const measuredWidth = getStandardTextWidth(text, family, bold, italic, sizePt);
    const originalTargetWidth = runInfo.width;
    if (measuredWidth > 0) {
      computedStretch = originalTargetWidth / measuredWidth;
      computedStretch = Math.max(0.2, Math.min(3.0, computedStretch));
    } else {
      computedStretch = 1.0;
    }
  } else if (!isAutoFit) {
    computedStretch = stretch;
  }

  useEffect(() => {
    // Popup position calculation with strict viewport bounds check
    const popupWidth = 310;
    const popupHeight = 390;
    
    let left = rect.left;
    let top = rect.bottom + 6;

    // Horizontally clamp inside screen bounds
    if (left + popupWidth > window.innerWidth - 12) {
      left = window.innerWidth - popupWidth - 12;
    }
    left = Math.max(12, left);

    // Vertically clamp inside screen bounds: try below, then above, then clamp
    if (top + popupHeight > window.innerHeight - 12) {
      const topAbove = rect.top - popupHeight - 6;
      if (topAbove >= 12) {
        top = topAbove;
      } else {
        top = Math.max(12, window.innerHeight - popupHeight - 12);
      }
    }
    top = Math.max(12, top);

    setPos({ left, top });

    // Sample colors
    const sampled = sampleColors(pageIdx, runInfo, pageObj, scale);
    setSampledBgHex(sampled.bg);
    setSampledInkHex(sampled.ink);

    const isGenericFont = (fn?: string) => !fn || /^g_[a-z0-9_]+$/i.test(fn) || /^font_/i.test(fn) || /^f_\d+/i.test(fn);

    if (existingEdit) {
      setText(existingEdit.newText);
      setFamily(existingEdit.family);
      setSizePt(parseFloat((origSize * existingEdit.sizeMul).toFixed(1)));
      setBold(existingEdit.bold);
      setItalic(existingEdit.italic);
      setUnderline(!!existingEdit.underline);
      setStrikethrough(!!existingEdit.strikethrough);
      
      setBgMode(existingEdit.bgMode || (existingEdit.noCover ? 'transparent' : 'auto'));
      setTextColor(existingEdit.color);
      setBgColor(existingEdit.bg);
      setAlignment(existingEdit.alignment || 'left');

      if (existingEdit.stretch !== undefined && Math.abs(existingEdit.stretch - 1.0) > 0.01) {
        setStretch(existingEdit.stretch);
        setIsAutoFit(false);
      } else {
        setStretch(1.0);
        setIsAutoFit(false);
      }
    } else {
      setText(runInfo.str);
      const initialFamily = (runInfo.fontFamily && !isGenericFont(runInfo.fontFamily))
        ? cleanFontFamilyName(runInfo.fontFamily)
        : (runInfo.familyGuess || 'sans');
      setFamily(initialFamily);
      setSizePt(defaultSizePt);
      setBold(!!runInfo.boldGuess);
      setItalic(!!runInfo.italicGuess);
      setUnderline(false);
      setStrikethrough(false);
      
      setBgMode('auto');
      setTextColor(sampled.ink);
      setBgColor(sampled.bg);
      setAlignment('left');
      setStretch(1.0);
      setIsAutoFit(false);
    }

    // Auto-focus text input for immediate direct editing without forcing full selection
    const timer = setTimeout(() => {
      if (textAreaRef.current) {
        textAreaRef.current.focus();
      }
    }, 60);

    return () => clearTimeout(timer);
  }, [runId, pageIdx, runInfo, rect, existingEdit]);

  // Click outside listener
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      const target = e.target as HTMLElement;
      if (target.closest('.run') || target.closest('.image-element')) {
        return;
      }
      if (popupRef.current && !popupRef.current.contains(e.target as Node)) {
        onCancel();
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onCancel]);

  const resetToOriginals = () => {
    setText(runInfo.str);
    const isGenericFont = (fn?: string) => !fn || /^g_[a-z0-9_]+$/i.test(fn) || /^font_/i.test(fn) || /^f_\d+/i.test(fn);
    const initialFamily = (runInfo.fontFamily && !isGenericFont(runInfo.fontFamily))
      ? runInfo.fontFamily
      : (runInfo.familyGuess || 'sans');
    setFamily(initialFamily);
    setSizePt(defaultSizePt);
    setBold(runInfo.boldGuess);
    setItalic(runInfo.italicGuess);
    setUnderline(false);
    setStrikethrough(false);
    setBgMode('auto');
    setTextColor(sampledInkHex);
    setBgColor(sampledBgHex);
    setAlignment('left');
    setStretch(1.0);
    setIsAutoFit(false);
  };

  const handleSave = () => {
    const sizeMul = sizePt / origSize;
    const activeBg = bgMode === 'auto' ? sampledBgHex : bgColor;
    const noCover = bgMode === 'transparent';

    onSave({
      pageIdx,
      newText: text,
      family: family as any,
      bold,
      italic,
      underline,
      strikethrough,
      noCover,
      sizeMul,
      color: textColor,
      bg: activeBg,
      bgMode,
      alignment,
      transform: runInfo.transform,
      width: runInfo.width,
      height: runInfo.height,
      stretch: computedStretch,
    });
  };

  return (
    <motion.div
      ref={popupRef}
      initial={{ opacity: 0, scale: 0.95, y: 10 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: 10 }}
      transition={{ type: 'spring', duration: 0.2 }}
      style={{
        position: 'fixed',
        left: `${pos.left}px`,
        top: `${pos.top}px`,
        zIndex: 100,
      }}
      className="popup w-[295px] max-w-[90vw] bg-[#161822]/98 border border-[#2e334a] rounded-2xl shadow-2xl backdrop-blur-xl overflow-hidden font-sans text-xs text-slate-200"
    >
      {/* Title Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#1f2333] border-b border-[#2e334a]">
        <div className="flex items-center gap-1.5 text-[10px] font-bold tracking-wide text-blue-400 uppercase font-mono">
          <Type className="w-3.5 h-3.5 text-blue-400" />
          <span>Direct Text Editor</span>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={resetToOriginals}
            className="p-1 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-[#2e334a] transition-all"
            title="Reset to 1:1 Auto-Matched PDF Defaults"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={onCancel}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-[#2e334a] transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-2.5 space-y-2.5 max-h-[calc(100vh-100px)] sm:max-h-[380px] overflow-y-auto custom-scrollbar">
        
        {/* 1:1 Preserved Badge */}
        <div className="bg-[#10121a] border border-[#282d42] p-1.5 rounded-xl flex items-center justify-between text-[9px] text-slate-400 font-mono">
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-slate-300 font-bold">1:1 Preserved:</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full border border-slate-600" style={{ backgroundColor: sampledInkHex }} />
              {sampledInkHex}
            </span>
            <span>on</span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full border border-slate-600" style={{ backgroundColor: sampledBgHex }} />
              {sampledBgHex}
            </span>
          </div>
        </div>

        {/* Text Area */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-[9px] font-mono font-bold text-blue-400 uppercase flex items-center gap-1">
              <span>✏️ Edit Text Content:</span>
            </label>
            <span className="text-[8px] font-mono text-slate-400">Press Enter for New Line</span>
          </div>
          <textarea
            ref={textAreaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="w-full min-h-[72px] bg-[#0d0f16] border-2 border-blue-500/80 rounded-xl px-2.5 py-1.5 text-white text-xs font-sans focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-blue-400 resize-y transition-all shadow-inner leading-relaxed"
            placeholder="Type replacement text (Enter creates line break)..."
          />
          <div className="flex items-center justify-between mt-1 text-[9px] font-mono text-slate-400">
            <button
              type="button"
              onClick={() => {
                if (textAreaRef.current) {
                  const start = textAreaRef.current.selectionStart;
                  const end = textAreaRef.current.selectionEnd;
                  const newText = text.substring(0, start) + '\n' + text.substring(end);
                  setText(newText);
                  setTimeout(() => {
                    if (textAreaRef.current) {
                      textAreaRef.current.selectionStart = textAreaRef.current.selectionEnd = start + 1;
                      textAreaRef.current.focus();
                    }
                  }, 10);
                } else {
                  setText(text + '\n');
                }
              }}
              className="px-2 py-0.5 rounded bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 font-bold transition-all cursor-pointer flex items-center gap-1 shadow-xs"
              title="Add line break to match document line formatting"
            >
              <span>↩ Insert Line Break</span>
            </button>
            <span>Supports Multi-line Formatting</span>
          </div>
        </div>

        {/* Formatting Controls Toolbar */}
        <div className="bg-[#10121a] border border-[#282d42] p-2.5 rounded-xl space-y-2.5">
          
          {/* Auto-Detected Source Font & Size Indicator */}
          <div className="flex items-center justify-between p-2 rounded-lg bg-[#181a26] border border-[#2e334a] text-slate-300">
            <div className="flex items-center gap-2">
              <Type className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <div className="text-[10px] font-bold text-white flex items-center gap-1.5">
                  <span>Font:</span>
                  <span className="text-emerald-400 font-mono">
                    {runInfo.fontFamily
                      ? runInfo.fontFamily.replace(/^[A-Z0-9]{6}\+/i, '').replace(/[-_]/g, ' ')
                      : (runInfo.familyGuess ? runInfo.familyGuess.toUpperCase() : 'Standard PDF Font')}
                  </span>
                </div>
                <div className="text-[9px] text-slate-400 font-mono">
                  Auto Source Size: <strong className="text-slate-200">{defaultSizePt} pt</strong>
                </div>
              </div>
            </div>
            <span className="px-2 py-0.5 text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full">
              Auto-Detected
            </span>
          </div>

          {/* Style Buttons & Alignments */}
          <div className="flex items-center justify-between gap-2 border-t border-[#232738] pt-2">
            
            {/* Bold, Italic, Underline, Strikethrough */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setBold(!bold)}
                className={`p-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                  bold ? 'bg-blue-600 text-white border-blue-400' : 'bg-[#181a26] border-[#2e334a] text-slate-400 hover:text-white'
                }`}
                title="Toggle Bold"
              >
                <Bold className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => setItalic(!italic)}
                className={`p-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                  italic ? 'bg-blue-600 text-white border-blue-400' : 'bg-[#181a26] border-[#2e334a] text-slate-400 hover:text-white'
                }`}
                title="Toggle Italic"
              >
                <Italic className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => setUnderline(!underline)}
                className={`p-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                  underline ? 'bg-blue-600 text-white border-blue-400' : 'bg-[#181a26] border-[#2e334a] text-slate-400 hover:text-white'
                }`}
                title="Toggle Underline"
              >
                <Underline className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => setStrikethrough(!strikethrough)}
                className={`p-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                  strikethrough ? 'bg-blue-600 text-white border-blue-400' : 'bg-[#181a26] border-[#2e334a] text-slate-400 hover:text-white'
                }`}
                title="Toggle Strikethrough"
              >
                <Strikethrough className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Alignment Options */}
            <div className="flex items-center gap-1 bg-[#181a26] border border-[#2e334a] p-0.5 rounded-lg">
              <button
                type="button"
                onClick={() => setAlignment('left')}
                className={`p-1 rounded ${alignment === 'left' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                title="Align Left"
              >
                <AlignLeft className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setAlignment('center')}
                className={`p-1 rounded ${alignment === 'center' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                title="Align Center"
              >
                <AlignCenter className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setAlignment('right')}
                className={`p-1 rounded ${alignment === 'right' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                title="Align Right"
              >
                <AlignRight className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setAlignment('justify')}
                className={`p-1 rounded ${alignment === 'justify' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                title="Justify"
              >
                <AlignJustify className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Color Pickers & Background Overlay Controls */}
        <div className="bg-[#10121a] border border-[#282d42] p-2.5 rounded-xl space-y-2.5">
          
          {/* Text Color Picker */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[9px] font-mono font-bold text-slate-400 uppercase">Text Color</label>
              <div className="flex items-center gap-1">
                <input
                  type="color"
                  value={textColor}
                  onChange={(e) => setTextColor(e.target.value)}
                  className="w-5 h-5 bg-transparent border-0 cursor-pointer rounded"
                />
                <span className="text-[10px] font-mono text-slate-300">{textColor}</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 pt-0.5">
              {['#000000', '#1e293b', '#2563eb', '#dc2626', '#059669', '#d97706', '#7c3aed'].map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setTextColor(c)}
                  className={`w-5 h-5 rounded-md border cursor-pointer transition-transform hover:scale-110 ${
                    textColor === c ? 'border-white ring-2 ring-blue-500' : 'border-slate-700'
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          {/* Background Overlay Control Modes */}
          <div className="border-t border-[#232738] pt-2">
            <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase mb-1">Background Overlay</label>
            <div className="grid grid-cols-3 gap-1 mb-2">
              <button
                type="button"
                onClick={() => setBgMode('auto')}
                className={`px-2 py-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer border ${
                  bgMode === 'auto'
                    ? 'bg-emerald-600 text-white border-emerald-400 shadow-md'
                    : 'bg-[#181a26] border-[#2e334a] text-slate-400 hover:text-white'
                }`}
                title="Auto-Match Canvas Background Color"
              >
                Auto Canvas
              </button>

              <button
                type="button"
                onClick={() => setBgMode('custom')}
                className={`px-2 py-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer border ${
                  bgMode === 'custom'
                    ? 'bg-blue-600 text-white border-blue-400 shadow-md'
                    : 'bg-[#181a26] border-[#2e334a] text-slate-400 hover:text-white'
                }`}
                title="Custom Background Fill / Highlight"
              >
                Custom Fill
              </button>

              <button
                type="button"
                onClick={() => setBgMode('transparent')}
                className={`px-2 py-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer border ${
                  bgMode === 'transparent'
                    ? 'bg-purple-600 text-white border-purple-400 shadow-md'
                    : 'bg-[#181a26] border-[#2e334a] text-slate-400 hover:text-white'
                }`}
                title="Transparent (No Cover)"
              >
                Transparent
              </button>
            </div>

            {bgMode === 'custom' && (
              <div className="flex items-center justify-between gap-2 pt-1">
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={bgColor}
                    onChange={(e) => setBgColor(e.target.value)}
                    className="w-5 h-5 bg-transparent border-0 cursor-pointer rounded"
                  />
                  <span className="text-[10px] font-mono text-slate-300">{bgColor}</span>
                </div>
                <div className="flex items-center gap-1">
                  {['#fef08a', '#bbf7d0', '#bfdbfe', '#fbcfe8', '#ffffff'].map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setBgColor(c)}
                      className={`w-4 h-4 rounded border cursor-pointer ${bgColor === c ? 'border-white ring-1 ring-blue-500' : 'border-slate-700'}`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Surgical Text Swap Tool */}
        <div className="bg-[#10121a] border border-[#282d42] p-2.5 rounded-xl space-y-2">
          <span className="text-[10px] font-mono font-bold uppercase text-amber-400 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            Surgical Text Swap
          </span>
          <div className="grid grid-cols-2 gap-2">
            <input
              type="text"
              value={findSub}
              onChange={(e) => setFindSub(e.target.value)}
              placeholder="Find exact string..."
              className="bg-[#181a26] border border-[#2e334a] rounded-lg px-2 py-1 text-xs text-white focus:outline-none focus:border-amber-400 placeholder-slate-600"
            />
            <input
              type="text"
              value={replaceSub}
              onChange={(e) => setReplaceSub(e.target.value)}
              placeholder="Replace with..."
              className="bg-[#181a26] border border-[#2e334a] rounded-lg px-2 py-1 text-xs text-white focus:outline-none focus:border-amber-400 placeholder-slate-600"
            />
          </div>
          <button
            type="button"
            onClick={() => {
              if (findSub) {
                setText(text.replaceAll(findSub, replaceSub));
              }
            }}
            disabled={!findSub}
            className="w-full py-1 text-xs font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 disabled:opacity-30 rounded-lg transition-all cursor-pointer"
          >
            Surgical Replace in Block
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-1">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-2 text-xs font-bold rounded-xl border border-[#2e334a] text-slate-400 hover:text-white hover:bg-[#2e334a]/40 transition-all"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-bold rounded-xl bg-blue-600 text-white hover:bg-blue-500 active:scale-95 transition-all shadow-lg shadow-blue-600/20 cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Apply Edit</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
}
