/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  MAIN_SECTION_HEADINGS,
  HeadingCategory,
  SubheadingItem,
  SubSubheadingOption
} from '../data/navigationTree';
import { GlowLogo } from './GlowLogo';
import { getAdminConfig, subscribeAdminConfig } from '../data/adminStore';
import {
  ArrowLeft,
  ArrowRight,
  Layers,
  FolderArchive,
  Film,
  Scissors,
  Sliders,
  Hash,
  PenTool,
  FileCheck,
  FileText,
  Zap,
  ImageIcon,
  Scan,
  Shield,
  Lock,
  FileSignature,
  Maximize2,
  Minimize2,
  Bot,
  Stethoscope,
  Building2,
  Search,
  CheckSquare,
  Droplet,
  RotateCw,
  Crop,
  KeyRound,
  ShieldAlert,
  Activity,
  Eye,
  MessageSquare,
  Sparkles,
  Globe,
  ListTree,
  Database,
  Flag,
  GraduationCap,
  DollarSign,
  HardDrive,
  FolderDown,
  RotateCcw,
  ChevronRight,
  Upload,
  Download,
  Ruler,
  Palette,
  Type,
  LogOut
} from 'lucide-react';

const ICON_MAP: Record<string, any> = {
  Layers,
  FolderArchive,
  Scissors,
  Sliders,
  Hash,
  PenTool,
  FileCheck,
  Zap,
  ImageIcon,
  Scan,
  Shield,
  Lock,
  FileSignature,
  Bot,
  Stethoscope,
  Building2,
  CheckSquare,
  Droplet,
  RotateCw,
  Crop,
  KeyRound,
  ShieldAlert,
  Activity,
  Eye,
  MessageSquare,
  Sparkles,
  Globe,
  ListTree,
  Database,
  Flag,
  GraduationCap,
  DollarSign,
  HardDrive,
  FolderDown,
  Download,
  RotateCcw,
  FileText,
  Ruler,
  Palette,
  Type
};

interface HierarchicalNavProps {
  onSelectFinalFunction: (toolId: string) => void;
  pdfDoc: any;
  originalFileName: string;
  pagesCount: number;
  onFileUploadClick: () => void;
  onDownloadPDF?: () => void;
  onOpenPreview?: () => void;
  handleClearPDF: () => void;
  theme: any;
  onSignOut?: () => void;
  glowTheme?: string;
  setGlowTheme?: (theme: any) => void;
  onOpenBulkAutoSigner?: () => void;
  onOpenBulkSigner?: () => void;
}

export const HierarchicalMenuNavigator: React.FC<HierarchicalNavProps> = ({
  onSelectFinalFunction,
  pdfDoc,
  originalFileName,
  pagesCount,
  onFileUploadClick,
  onDownloadPDF,
  onOpenPreview,
  handleClearPDF,
  theme,
  onSignOut,
  glowTheme,
  setGlowTheme,
  onOpenBulkAutoSigner,
  onOpenBulkSigner
}) => {
  // Navigation level state:
  // 1: Main Section Boxes (Page 1)
  // 2: Subheadings / Sub-categories (Page 2)
  // 3: Working Options & Tools (Page 3)
  const [navLevel, setNavLevel] = useState<1 | 2 | 3>(1);
  const [selectedHeadingId, setSelectedHeadingId] = useState<string | null>(null);
  const [selectedSubheadingId, setSelectedSubheadingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isExpandedGrid, setIsExpandedGrid] = useState<boolean>(false);

  const [adminCfg, setAdminCfg] = useState(() => getAdminConfig());
  const [showThemeDropdown, setShowThemeDropdown] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeAdminConfig((updated) => {
      setAdminCfg(updated);
    });
    return () => unsubscribe();
  }, []);

  // Get active selected objects
  const activeHeading = MAIN_SECTION_HEADINGS.find((h) => h.id === selectedHeadingId) || null;
  const activeSubheading = activeHeading?.subheadings.find((s) => s.id === selectedSubheadingId) || null;

  // Handlers for strict 1-level drill-down
  const handleSelectHeading = (heading: HeadingCategory) => {
    setSelectedHeadingId(heading.id);
    setSelectedSubheadingId(null);
    setNavLevel(2); // Page 2: Subheadings under selected section
  };

  const handleSelectSubheading = (subheading: SubheadingItem) => {
    setSelectedSubheadingId(subheading.id);
    setNavLevel(3); // Page 3: Specific working options
  };

  const handleSelectSubSubheadingOption = (option: SubSubheadingOption) => {
    // Navigates directly to final level: Working Function workspace
    onSelectFinalFunction(option.toolId);
  };

  // Back navigation handler
  const handleBackUpOneLevel = () => {
    if (navLevel === 3) {
      setSelectedSubheadingId(null);
      setNavLevel(2);
    } else if (navLevel === 2) {
      setSelectedHeadingId(null);
      setSelectedSubheadingId(null);
      setNavLevel(1);
    }
  };

  // Forward navigation handler (layer-wise forward option)
  const handleForwardOneLevel = () => {
    if (navLevel === 1 && selectedHeadingId) {
      setNavLevel(2);
    } else if (navLevel === 2 && selectedSubheadingId) {
      setNavLevel(3);
    }
  };

  const canGoForward = (navLevel === 1 && Boolean(selectedHeadingId)) || (navLevel === 2 && Boolean(selectedSubheadingId));

  // Direct breadcrumb click handler
  const handleBreadcrumbClick = (targetLevel: 1 | 2 | 3) => {
    if (targetLevel === 1) {
      setSelectedHeadingId(null);
      setSelectedSubheadingId(null);
      setNavLevel(1);
    } else if (targetLevel === 2 && selectedHeadingId) {
      setSelectedSubheadingId(null);
      setNavLevel(2);
    }
  };

  // Helper to render icon
  const renderIcon = (iconName?: string, className: string = "w-5 h-5") => {
    if (!iconName) return <Layers className={className} />;
    const Component = ICON_MAP[iconName] || Layers;
    return <Component className={className} />;
  };

  const isRoseVelvet = glowTheme === 'rose-velvet';

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-500 ${theme.bg}`}>
      
      {/* HEADER BAR FOR DOCUMENT STATUS & LAYER-WISE NAVIGATION */}
      <header className={`border-b backdrop-blur-xl shadow-md transition-all sticky top-0 z-50 ${theme.headerBg}`}>
        {/* Top Header Row: Title & Document Memory Status */}
        <div className="max-w-[1850px] mx-auto px-6 py-3.5 flex flex-wrap items-center justify-between gap-4 border-b border-slate-200/60 dark:border-slate-800/60">
          <div className="flex items-center gap-3">
            <div className={`p-1.5 rounded-xl border shadow-md backdrop-blur-md flex items-center justify-center shrink-0 ${
              isRoseVelvet ? 'bg-pink-500/20 border-pink-300/40 text-pink-200' : 'bg-slate-900/90 dark:bg-white/10 border-slate-700/50 dark:border-white/25 text-cyan-400'
            }`}>
              <GlowLogo size="xs" />
            </div>
            <div className="flex flex-col justify-center">
              <h1 className="text-base font-black tracking-tight leading-tight">
                <span className={`bg-clip-text text-transparent font-black ${
                  isRoseVelvet
                    ? 'bg-gradient-to-r from-rose-100 via-pink-300 to-rose-200'
                    : 'bg-gradient-to-r from-cyan-500 via-indigo-500 to-fuchsia-500 dark:from-cyan-300 dark:via-indigo-300 dark:to-fuchsia-400'
                }`}>
                  {adminCfg?.uiTextOverrides?.brandingLogoText || 'GlowPDF'}
                </span>
                {!adminCfg?.uiTextOverrides?.brandingLogoText && (
                  <span className="text-white font-extrabold ml-1.5">
                    Suite
                  </span>
                )}
              </h1>
              <p className={`text-[11px] font-bold bg-clip-text text-transparent tracking-wide flex items-center gap-1 mt-0.5 ${
                isRoseVelvet
                  ? 'bg-gradient-to-r from-rose-200 via-pink-200 to-rose-300'
                  : 'bg-gradient-to-r from-amber-500 via-fuchsia-500 to-cyan-500 dark:from-amber-300 dark:via-fuchsia-300 dark:to-cyan-300'
              }`}>
                {adminCfg?.uiTextOverrides?.brandingHeaderTitle || '✨ Makes your documents glow'}
              </p>
            </div>
          </div>

          {/* Top Right Header: Theme Symbols, Document Vault, Media Studio & Sign Out Buttons */}
          <div className="flex items-center gap-2.5">
            {setGlowTheme && (
              <div className="flex items-center gap-2">
                {/* GO WITH ROSEE GLOW Toggle Button */}
                <button
                  type="button"
                  onClick={() => {
                    if (isRoseVelvet) {
                      setGlowTheme('light-slate');
                      try { localStorage.setItem('glowpdf_theme', 'light-slate'); } catch (e) {}
                    } else {
                      setGlowTheme('rose-velvet');
                      try { localStorage.setItem('glowpdf_theme', 'rose-velvet'); } catch (e) {}
                    }
                  }}
                  className={`px-3 py-2 rounded-xl text-white transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer flex items-center gap-2 shrink-0 border ${
                    isRoseVelvet
                      ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 border-rose-300 shadow-[0_0_20px_rgba(244,63,94,0.9)] ring-2 ring-rose-300/80'
                      : 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 hover:from-rose-500 hover:to-pink-500 border-rose-300/40 shadow-[0_0_15px_rgba(244,63,94,0.6)]'
                  }`}
                  title={isRoseVelvet ? 'Click to exit Rosee Glow and return to normal theme' : 'Click to activate Rosee Glow theme'}
                >
                  <Sparkles className="w-4 h-4 text-white animate-pulse shrink-0 drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
                  <span className="text-white font-extrabold tracking-wider uppercase text-xs">
                    {isRoseVelvet ? '✓ ROSEE GLOW ACTIVE (CLICK TO EXIT)' : (adminCfg?.uiTextOverrides?.roseeGlowBtnText || '✨ GO WITH ROSEE GLOW')}
                  </span>
                </button>

                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowThemeDropdown(!showThemeDropdown)}
                    className={`px-3 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-2 font-bold text-xs shadow-xs border ${
                      isRoseVelvet
                        ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 text-white border-rose-300/60 shadow-[0_0_15px_rgba(244,63,94,0.6)]'
                        : theme.isLight
                          ? 'bg-white border-slate-300 text-slate-800 hover:bg-slate-50'
                          : 'bg-[#151824] border-slate-700 text-white hover:bg-[#1e2336]'
                    }`}
                    title="Select Theme"
                  >
                    <span className="text-base">🎨</span>
                    <span className="hidden md:inline font-extrabold">{isRoseVelvet ? 'Rosee Glow' : 'Theme'}</span>
                  </button>

                {showThemeDropdown && (
                  <div className={`absolute right-0 mt-2 w-56 rounded-2xl shadow-2xl border p-2 z-50 grid grid-cols-1 gap-1 max-h-80 overflow-y-auto ${
                    isRoseVelvet 
                      ? 'bg-[#4d0c24] border-[#ec4899]/50 text-white shadow-[0_0_30px_rgba(236,72,153,0.4)]' 
                      : theme.isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-[#141724] border-[#2b304a] text-white'
                  }`}>
                    <div className="px-2 py-1 text-[10px] font-black uppercase tracking-wider opacity-80">Select Aesthetic Theme</div>
                    {[
                      { id: 'rose-velvet', label: 'Rosee Glow Velvet', symbol: '🌹' },
                      { id: 'light-slate', label: 'Light Studio', symbol: '🌟' },
                      { id: 'cyberpunk-neon', label: 'Dark Neon', symbol: '⚡' },
                      { id: 'solar-amber', label: 'Warm Solar', symbol: '☀️' },
                      { id: 'standard', label: 'Minimal Paper', symbol: '📄' },
                      { id: 'sepia-warm', label: 'Sepia Warm', symbol: '📜' },
                      { id: 'midnight', label: 'Midnight', symbol: '🌙' },
                      { id: 'nordic-frost', label: 'Nordic Frost', symbol: '❄️' },
                      { id: 'warm-cream', label: 'Warm Cream', symbol: '☕' },
                      { id: 'cosmic-dark', label: 'Cosmic Dark', symbol: '🌌' },
                      { id: 'matrix-green', label: 'Matrix Green', symbol: '💚' },
                      { id: 'crimson-cyber', label: 'Crimson Cyber', symbol: '🔴' },
                      { id: 'vibrant-dusk', label: 'Vibrant Dusk', symbol: '🌇' },
                    ].map((t) => (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => {
                          setGlowTheme(t.id);
                          try { localStorage.setItem('glowpdf_theme', t.id); } catch (_) {}
                          setShowThemeDropdown(false);
                        }}
                        className={`w-full px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 cursor-pointer text-left ${
                          glowTheme === t.id
                            ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 text-white font-extrabold shadow-md'
                            : (isRoseVelvet ? 'hover:bg-[#701a45] text-pink-100' : theme.isLight ? 'hover:bg-slate-100 text-slate-700' : 'hover:bg-[#1e2235] text-slate-200')
                        }`}
                      >
                        <span className="text-base">{t.symbol}</span>
                        <span>{t.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

            {/* Bulk PDF Signer Header Button */}
            <button
              type="button"
              onClick={() => {
                if (onOpenBulkSigner) onOpenBulkSigner();
                if (onOpenBulkAutoSigner) onOpenBulkAutoSigner();
                if (onSelectFinalFunction) onSelectFinalFunction('bulk-auto-signer');
              }}
              className={`px-3.5 py-2 rounded-xl text-white font-black text-xs transition-all hover:scale-105 active:scale-95 cursor-pointer flex items-center gap-2 shrink-0 group ${
                isRoseVelvet
                  ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 hover:from-rose-500 hover:to-pink-500 border border-rose-300/40 shadow-[0_0_15px_rgba(244,63,94,0.6)]'
                  : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 shadow-md shadow-blue-500/25 border border-blue-400/40'
              }`}
              title="Open Bulk PDF Auto-Signer Workspace"
            >
              <FileSignature className="w-4 h-4 text-pink-200 group-hover:scale-110 transition-transform" />
              <span className="font-black tracking-wide">Bulk PDF Signer</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (onSelectFinalFunction) {
                  onSelectFinalFunction('doc-vault');
                }
              }}
              className={`px-3.5 py-2 rounded-xl font-bold text-xs transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-xs flex items-center gap-2 shrink-0 ${
                isRoseVelvet
                  ? 'bg-pink-500/20 text-pink-200 border border-pink-400/40 hover:bg-pink-500/30'
                  : 'bg-purple-500/10 hover:bg-purple-500/20 text-purple-600 dark:text-purple-400 border border-purple-500/30'
              }`}
              title="Document Vault"
            >
              <FolderArchive className={`w-4 h-4 ${isRoseVelvet ? 'text-pink-300' : 'text-purple-600 dark:text-purple-400'}`} />
              <span className="font-extrabold text-xs hidden sm:inline">Document Vault</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (onSelectFinalFunction) {
                  onSelectFinalFunction('media-studio');
                }
              }}
              className={`px-3.5 py-2 rounded-xl font-bold text-xs transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-xs flex items-center gap-2 shrink-0 ${
                isRoseVelvet
                  ? 'bg-rose-500/20 text-rose-200 border border-rose-400/40 hover:bg-rose-500/30'
                  : 'bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30'
              }`}
              title="Integrated Photo & Video Media Studio"
            >
              <Film className={`w-4 h-4 ${isRoseVelvet ? 'text-rose-300' : 'text-indigo-600 dark:text-indigo-400'}`} />
              <span className="font-extrabold text-xs hidden sm:inline">Media Studio</span>
            </button>

            {onSignOut && (
              <button
                type="button"
                onClick={onSignOut}
                className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/30 font-bold text-xs transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-xs flex items-center gap-2 shrink-0"
                title="Sign Out of Console"
              >
                <LogOut className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                <span className="font-extrabold text-xs hidden sm:inline">Sign Out</span>
              </button>
            )}
          </div>
        </div>

        {/* Bottom Header Sub-Row: Layer-wise Backward & Forward Navigation Options */}
        <div className={`max-w-[1850px] mx-auto px-6 py-2 flex flex-wrap items-center justify-between gap-3 text-xs font-mono ${
          isRoseVelvet
            ? 'bg-[#4d0c24]/90 text-pink-100 border-t border-b border-[#fbcfe8]/20'
            : 'bg-slate-100/90 dark:bg-[#0c0e18]/90 text-slate-300'
        }`}>
          
          {/* Layer-wise Navigation Buttons & Breadcrumbs */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Backward Sign Button */}
            <button
              type="button"
              onClick={handleBackUpOneLevel}
              disabled={navLevel === 1}
              className={`p-1.5 px-2.5 rounded-xl font-bold flex items-center gap-1 text-xs transition-all ${
                navLevel > 1
                  ? (isRoseVelvet ? 'bg-[#701a45] hover:bg-[#831843] text-white border border-[#fbcfe8]/40 cursor-pointer shadow-sm hover:scale-105 active:scale-95' : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 cursor-pointer shadow-sm hover:scale-105 active:scale-95')
                  : 'bg-slate-200 dark:bg-slate-900/50 text-slate-400 dark:text-slate-600 border border-slate-300/50 dark:border-slate-800/50 cursor-not-allowed opacity-60'
              }`}
              title={navLevel > 1 ? `Go back to Level ${navLevel - 1}` : 'At Level 1'}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span className="text-[11px] font-mono">L{navLevel > 1 ? navLevel - 1 : 1}</span>
            </button>

            {/* Forward Sign Button */}
            <button
              type="button"
              onClick={handleForwardOneLevel}
              disabled={!canGoForward}
              className={`p-1.5 px-2.5 rounded-xl font-bold flex items-center gap-1 text-xs transition-all ${
                canGoForward
                  ? (isRoseVelvet ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 text-white border border-rose-300/50 shadow-md hover:scale-105 active:scale-95' : 'bg-blue-600 hover:bg-blue-500 text-white border border-blue-500 cursor-pointer shadow-sm hover:scale-105 active:scale-95')
                  : 'bg-slate-200 dark:bg-slate-900/50 text-slate-400 dark:text-slate-600 border border-slate-300/50 dark:border-slate-800/50 cursor-not-allowed opacity-60'
              }`}
              title={canGoForward ? `Forward to Level ${navLevel + 1}` : 'Select an item to advance'}
            >
              <span className="text-[11px] font-mono">L{navLevel < 3 ? navLevel + 1 : 3}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <span className={`h-4 w-[1px] mx-1 hidden sm:inline-block ${isRoseVelvet ? 'bg-[#fbcfe8]/30' : 'bg-slate-300 dark:bg-slate-800'}`} />

            {/* Layer Trail Breadcrumbs */}
            <span className={`font-extrabold text-[10px] uppercase tracking-wider hidden md:inline-block ${isRoseVelvet ? 'text-pink-200' : 'text-slate-500 dark:text-slate-400'}`}>
              LAYER TRAIL:
            </span>

            {/* Node 1: Main Sections + Search Box directly beside it */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleBreadcrumbClick(1)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 ${
                  navLevel === 1
                    ? (isRoseVelvet ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 text-white shadow-md font-extrabold' : 'bg-blue-600 text-white shadow-sm')
                    : (isRoseVelvet ? 'bg-[#701a45] hover:bg-[#831843] text-pink-100 border border-[#fbcfe8]/30' : 'bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300')
                }`}
              >
                1. Main Sections
              </button>

              {/* Search Box placed directly beside Main Sections */}
              <div className="relative w-44 sm:w-56 md:w-72">
                <Search className={`w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 ${isRoseVelvet ? 'text-pink-300' : 'text-slate-400'}`} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="🔍 Search all tools..."
                  className={`w-full text-xs pl-8 pr-3 py-1.5 rounded-xl border font-medium shadow-xs focus:outline-none ${
                    isRoseVelvet
                      ? 'bg-[#2d0413]/90 border-[#fbcfe8]/40 text-white placeholder:text-pink-300/60 focus:border-[#ec4899]'
                      : 'bg-white dark:bg-[#181c2e] border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-blue-500'
                  }`}
                />
              </div>

              {/* Box Size Toggle Button (In line with Search input) */}
              <button
                type="button"
                onClick={() => setIsExpandedGrid((prev) => !prev)}
                className={`px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 shadow-2xs ${
                  isExpandedGrid
                    ? (isRoseVelvet ? 'bg-pink-500/20 text-pink-200 border-pink-400/50 shadow-xs ring-1 ring-pink-400/40' : 'bg-blue-600/15 text-blue-600 dark:text-blue-400 border-blue-500/40 shadow-xs ring-1 ring-blue-500/30')
                    : (isRoseVelvet ? 'bg-[#701a45] border-[#fbcfe8]/30 text-pink-100 hover:bg-[#831843]' : 'bg-white dark:bg-[#181c2e] border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800')
                }`}
                title={isExpandedGrid ? "Switch to Compact Box View" : "Switch to Larger Box View (Better Visibility & Roomier Padding)"}
              >
                {isExpandedGrid ? (
                  <>
                    <Minimize2 className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-pink-300' : 'text-blue-500'}`} />
                    <span className="hidden xl:inline">Compact Cards</span>
                  </>
                ) : (
                  <>
                    <Maximize2 className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-pink-300' : 'text-slate-500 dark:text-slate-400'}`} />
                    <span className="hidden xl:inline">Larger Cards</span>
                  </>
                )}
              </button>
            </div>

            {/* Node 2 */}
            {activeHeading && (
              <>
                <ChevronRight className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-pink-300' : 'text-slate-400'}`} />
                <button
                  type="button"
                  onClick={() => handleBreadcrumbClick(2)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    navLevel === 2
                      ? (isRoseVelvet ? 'bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 text-white shadow-md' : 'bg-blue-600 text-white shadow-sm')
                      : (isRoseVelvet ? 'bg-[#701a45] hover:bg-[#831843] text-pink-100 border border-[#fbcfe8]/30' : 'bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300')
                  }`}
                >
                  {renderIcon(activeHeading.iconName, "w-3 h-3 inline mr-1")}
                  2. Section {activeHeading.sectionNumber}
                </button>
              </>
            )}

            {/* Node 3 */}
            {activeSubheading && (
              <>
                <ChevronRight className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-pink-300' : 'text-slate-400'}`} />
                <div className={`px-2.5 py-1 rounded-lg text-xs font-bold text-white shadow-sm truncate max-w-[220px] ${
                  isRoseVelvet ? 'bg-gradient-to-r from-rose-600 to-pink-600' : 'bg-purple-600'
                }`}>
                  {renderIcon(activeSubheading.iconName, "w-3 h-3 inline mr-1")}
                  3. {activeSubheading.title}
                </div>
              </>
            )}
          </div>

          {/* Right: Active PDF Indicator Badge, Preview Button & Level Step Indicators */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                if (pdfDoc && onOpenPreview) {
                  onOpenPreview();
                } else {
                  onFileUploadClick();
                }
              }}
              className="px-2.5 py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-700 dark:text-emerald-300 border border-emerald-500/40 text-[10px] font-extrabold font-mono flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs hover:scale-[1.02] active:scale-98"
              title={`Active PDF Document: ${originalFileName || 'Active_Document.pdf'} (Click to preview or switch)`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${pdfDoc ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
              <span className="text-[9px] font-mono font-black uppercase px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-800 dark:text-emerald-200 border border-emerald-500/30">
                .PDF
              </span>
              <span className={`uppercase text-[9px] hidden md:inline ${isRoseVelvet ? 'text-pink-200/80' : 'text-slate-500 dark:text-slate-400'}`}>ACTIVE:</span>
              <span className="truncate max-w-[120px] sm:max-w-[180px] font-black">
                {originalFileName || 'Active_Document.pdf'}
              </span>
            </button>

            {pdfDoc && onOpenPreview && (
              <button
                type="button"
                onClick={onOpenPreview}
                className={`px-2.5 py-1 rounded-lg border text-[10px] font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs hover:scale-105 active:scale-95 ${
                  isRoseVelvet ? 'bg-pink-500/20 hover:bg-pink-500/30 text-pink-200 border-pink-400/40' : 'bg-blue-600/15 hover:bg-blue-600/25 text-blue-600 dark:text-blue-400 border-blue-500/40'
                }`}
                title="Preview Active PDF Document"
              >
                <Eye className={`w-3.5 h-3.5 ${isRoseVelvet ? 'text-pink-300' : 'text-blue-500'}`} />
                <span className="hidden sm:inline">Preview PDF</span>
              </button>
            )}

            <div className={`hidden lg:flex items-center gap-1 p-1 rounded-xl border ${
              isRoseVelvet ? 'bg-[#3b071e]/90 border-[#ec4899]/30' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
            }`}>
              <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                navLevel === 1 
                  ? (isRoseVelvet ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white' : 'bg-blue-600 text-white') 
                  : (isRoseVelvet ? 'text-pink-300/60' : 'text-slate-400')
              }`}>
                L1: Sections
              </span>
              <span className={`${isRoseVelvet ? 'text-pink-300/40' : 'text-slate-400'} text-[10px]`}>➔</span>
              <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                navLevel === 2 
                  ? (isRoseVelvet ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white' : 'bg-blue-600 text-white') 
                  : (isRoseVelvet ? 'text-pink-300/60' : 'text-slate-400')
              }`}>
                L2: Subheadings
              </span>
              <span className={`${isRoseVelvet ? 'text-pink-300/40' : 'text-slate-400'} text-[10px]`}>➔</span>
              <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                navLevel === 3 
                  ? (isRoseVelvet ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white' : 'bg-purple-600 text-white') 
                  : (isRoseVelvet ? 'text-pink-300/60' : 'text-slate-400')
              }`}>
                L3: Options
              </span>
            </div>
          </div>

        </div>
      </header>

      {/* MAIN CONTENT AREA BY LEVEL */}
      <main className="flex-1 max-w-[1850px] w-full mx-auto p-6 md:p-8 flex flex-col gap-8">

        {/* ========================================================================= */}
        {/* PAGE 1: LEVEL 1 — MAIN SECTIONS (PROMINENT BIG BOXES WITH SECTION HEADINGS) */}
        {/* ========================================================================= */}
        {navLevel === 1 && (
          <div className="flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-200">

            {/* COMPACT OR EXPANDED SECTION BOXES GRID */}
            <div className={isExpandedGrid ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5"}>
              {(() => {
                // Using reactive adminCfg from state
                const disabledSections = adminCfg?.disabledSections || [];
                const sectionOrder = adminCfg?.sectionOrder || [];
                const enabledTools = adminCfg?.enabledTools || {};

                let headings = [...MAIN_SECTION_HEADINGS].filter(
                  (h) => !disabledSections.includes(h.id)
                );

                if (sectionOrder.length > 0) {
                  headings.sort((a, b) => {
                    const idxA = sectionOrder.indexOf(a.id);
                    const idxB = sectionOrder.indexOf(b.id);
                    if (idxA !== -1 && idxB !== -1) return idxA - idxB;
                    if (idxA !== -1) return -1;
                    if (idxB !== -1) return 1;
                    return 0;
                  });
                }

                return headings.filter((heading) => {
                  const q = searchQuery.toLowerCase().trim();
                  if (!q) return true;
                  return (
                    heading.title.toLowerCase().includes(q) ||
                    heading.subtitle.toLowerCase().includes(q) ||
                    heading.description.toLowerCase().includes(q) ||
                    heading.subheadings.some((s) =>
                      s.title.toLowerCase().includes(q) ||
                      s.subSubheadings.some((opt) => opt.title.toLowerCase().includes(q))
                    )
                  );
                }).map((heading) => {
                const totalOptions = heading.subheadings.reduce((acc, sub) => acc + sub.subSubheadings.length, 0);

                return (
                  <div
                    key={heading.id}
                    onClick={() => handleSelectHeading(heading)}
                    className={`group relative ${theme.sectionalBoxBg} hover:border-blue-500 dark:hover:border-blue-500 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 rounded-xl cursor-pointer flex flex-col justify-between overflow-hidden ${
                      isExpandedGrid ? 'p-5 min-h-[160px]' : 'p-3'
                    }`}
                  >
                    {/* Top Section Color Strip */}
                    <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${heading.colorGradient}`} />

                    <div>
                      {/* Section Badge & Number Header */}
                      <div className="flex items-center justify-between gap-1.5 mb-2">
                        <div className="flex items-center gap-2">
                          <div className={`w-8 h-8 rounded-lg border flex items-center justify-center transition-all duration-200 shadow-xs shrink-0 ${
                            heading.sectionNumber % 2 === 0
                              ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400 group-hover:bg-cyan-600 group-hover:text-white'
                              : 'bg-amber-500/10 border-amber-500/30 text-amber-400 group-hover:bg-amber-600 group-hover:text-white'
                          }`}>
                            {renderIcon(heading.iconName, "w-4 h-4")}
                          </div>
                          <div>
                            <span className={`text-[9px] font-mono font-black uppercase tracking-wider block leading-none ${
                              heading.sectionNumber % 2 === 0 ? 'text-cyan-400' : 'text-amber-400'
                            }`}>
                              SECTION {heading.sectionNumber}
                            </span>
                            <span className={`text-[8px] font-mono font-extrabold uppercase px-1.5 py-0.2 rounded border inline-block mt-0.5 ${
                              heading.sectionNumber % 2 === 0 
                                ? 'bg-cyan-950/40 text-cyan-300 border-cyan-800/60' 
                                : 'bg-amber-950/40 text-amber-300 border-amber-800/60'
                            }`}>
                              {heading.badge}
                            </span>
                          </div>
                        </div>

                        <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded-md border shrink-0 ${
                          heading.sectionNumber % 2 === 0
                            ? 'bg-cyan-950/40 text-cyan-200 border-cyan-800/40'
                            : 'bg-amber-950/40 text-amber-200 border-amber-800/40'
                        }`}>
                          {totalOptions} tools
                        </span>
                      </div>

                      {/* Title & Short Description */}
                      <h3 className={`font-bold text-white tracking-tight group-hover:text-blue-400 transition-colors leading-tight ${
                        isExpandedGrid ? 'text-sm line-clamp-2' : 'text-xs line-clamp-1'
                      }`}>
                        {heading.title}
                      </h3>
                      <p className={`text-slate-200 mt-1 leading-snug font-medium ${
                        isExpandedGrid ? 'text-xs line-clamp-3' : 'text-[11px] line-clamp-1'
                      }`}>
                        {heading.description}
                      </p>
                    </div>

                  </div>
                );
              })})()}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* PAGE 2: LEVEL 2 — SUBHEADINGS UNDER SELECTED MAIN SECTION */}
        {/* ========================================================================= */}
        {navLevel === 2 && activeHeading && (
          <div className="flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-200">
            
            {/* Page 2 Header Banner */}
            <div className={`p-3 md:p-4 rounded-2xl border shadow-md backdrop-blur-2xl flex flex-wrap items-center justify-between gap-3 ${
              isRoseVelvet
                ? 'bg-gradient-to-r from-[#701a45] via-[#831843] to-[#701a45] border-[#ec4899]/40 shadow-xl shadow-rose-950/60 text-white'
                : theme.isLight
                  ? 'bg-gradient-to-r from-blue-50/90 via-sky-50/80 to-indigo-50/90 border-blue-200 shadow-blue-900/5'
                  : 'bg-[#121524]/95 border-slate-800 shadow-black/40'
            }`}>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleBackUpOneLevel}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                      isRoseVelvet ? 'bg-[#4d0c24] hover:bg-[#831843] text-pink-100 border border-[#fbcfe8]/30' : 'bg-slate-800 text-slate-200 hover:text-white'
                    }`}
                  >
                    <ArrowLeft className="w-3 h-3" />
                    <span>Back to Main Sections</span>
                  </button>

                  <span className={`text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded-md border ${
                    isRoseVelvet ? 'bg-[#ec4899]/20 text-pink-200 border-[#ec4899]/40' : 'bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30'
                  }`}>
                    PAGE 2 OF 3: SECTION {activeHeading.sectionNumber} SUBHEADINGS
                  </span>
                </div>

                <div className="flex items-center gap-2 mt-0.5">
                  <div className={`p-1.5 rounded-lg shadow-xs ${isRoseVelvet ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white' : 'bg-blue-600 text-white'}`}>
                    {renderIcon(activeHeading.iconName, "w-4 h-4")}
                  </div>
                  <h2 className="text-base md:text-lg font-black text-white tracking-tight">
                    {activeHeading.title}
                  </h2>
                </div>
                <p className={`text-[11px] font-medium ${isRoseVelvet ? 'text-pink-200/90' : 'text-slate-500 dark:text-slate-400'}`}>
                  Showing subheadings under Section {activeHeading.sectionNumber}. Click a subheading box below to select a specific editing tool.
                </p>
              </div>

              {/* Subheadings Count Badge */}
              <div className="flex items-center gap-2 shrink-0">
                <span className={`text-[10px] font-mono font-extrabold px-2.5 py-1 rounded-xl border ${
                  isRoseVelvet ? 'bg-[#ec4899]/20 text-pink-200 border-[#ec4899]/40' : 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30'
                }`}>
                  {activeHeading.subheadings.length} SUBHEADINGS AVAILABLE
                </span>
              </div>
            </div>

            {/* SUBHEADINGS CARDS GRID */}
            <div className={isExpandedGrid ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3"}>
              {activeHeading.subheadings.map((sub) => (
                <div
                  key={sub.id}
                  onClick={() => handleSelectSubheading(sub)}
                  className={`group relative backdrop-blur-xl transition-all duration-200 rounded-xl cursor-pointer flex flex-col justify-between overflow-hidden ${
                    isRoseVelvet
                      ? 'bg-gradient-to-br from-[#701a45] to-[#4d0c24] border border-[#fbcfe8]/30 hover:border-[#ec4899] hover:shadow-[0_0_20px_rgba(236,72,153,0.4)] text-white'
                      : 'bg-gradient-to-br from-purple-50/90 via-fuchsia-50/40 to-indigo-50/50 dark:bg-[#121525]/95 border border-purple-200/90 dark:border-slate-800/80 hover:border-purple-500 dark:hover:border-purple-500 shadow-xs hover:shadow-lg hover:-translate-y-0.5'
                  } ${isExpandedGrid ? 'p-5 min-h-[175px]' : 'p-3 min-h-[135px]'}`}
                >
                  <div className={`absolute top-0 left-0 right-0 h-1 ${isRoseVelvet ? 'bg-gradient-to-r from-rose-500 via-pink-500 to-rose-400' : 'bg-gradient-to-r from-purple-500 via-indigo-500 to-blue-500'}`} />

                  <div>
                    {/* Subheading Icon & Badge */}
                    <div className="flex items-center justify-between gap-1.5 mb-2">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-200 shadow-xs shrink-0 ${
                        isRoseVelvet
                          ? 'bg-pink-500/20 border border-pink-400/40 text-pink-200 group-hover:bg-[#ec4899] group-hover:text-white'
                          : 'bg-purple-500/10 dark:bg-purple-500/20 border border-purple-500/30 text-purple-600 dark:text-purple-400 group-hover:bg-purple-600 group-hover:text-white'
                      }`}>
                        {renderIcon(sub.iconName, "w-4 h-4")}
                      </div>

                      <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded-md border shrink-0 ${
                        isRoseVelvet ? 'bg-[#3b071e] text-pink-200 border-[#fbcfe8]/20' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}>
                        {sub.subSubheadings.length} tools
                      </span>
                    </div>

                    {/* Title & Description */}
                    <h3 className={`font-black tracking-tight transition-colors leading-tight ${
                      isRoseVelvet ? 'text-white group-hover:text-pink-300' : 'text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400'
                    } ${isExpandedGrid ? 'text-sm line-clamp-2' : 'text-xs line-clamp-1'}`}>
                      {sub.title}
                    </h3>
                    <p className={`mt-1 leading-snug font-medium ${
                      isRoseVelvet ? 'text-pink-100/80' : 'text-slate-500 dark:text-slate-400'
                    } ${isExpandedGrid ? 'text-xs line-clamp-3' : 'text-[11px] line-clamp-2'}`}>
                      {sub.description}
                    </p>
                  </div>

                  {/* Bottom Action */}
                  <div className={`mt-2.5 pt-1.5 border-t flex items-center justify-between text-[10px] font-bold ${
                    isRoseVelvet ? 'border-[#fbcfe8]/15 text-pink-300' : 'border-slate-100 dark:border-slate-800/80 text-purple-600 dark:text-purple-400'
                  }`}>
                    <span>View Options ({sub.subSubheadings.length})</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* PAGE 3: LEVEL 3 — WORKING OPTIONS & SPECIFIC TOOLS */}
        {/* ========================================================================= */}
        {navLevel === 3 && activeHeading && activeSubheading && (
          <div className="flex flex-col gap-6 animate-in fade-in zoom-in-95 duration-200">
            
            {/* Page 3 Header Banner */}
            <div className={`p-3 md:p-4 rounded-2xl border shadow-md backdrop-blur-2xl flex flex-wrap items-center justify-between gap-3 ${
              isRoseVelvet
                ? 'bg-gradient-to-r from-[#701a45] via-[#831843] to-[#701a45] border-[#ec4899]/40 shadow-xl shadow-rose-950/60 text-white'
                : theme.isLight
                  ? 'bg-gradient-to-r from-purple-50/90 via-fuchsia-50/80 to-indigo-50/90 border-purple-200 shadow-purple-900/5'
                  : 'bg-[#121524]/95 border-slate-800 shadow-black/40'
            }`}>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleBackUpOneLevel}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                      isRoseVelvet ? 'bg-[#4d0c24] hover:bg-[#831843] text-pink-100 border border-[#fbcfe8]/30' : 'bg-slate-800 text-slate-200 hover:text-white'
                    }`}
                  >
                    <ArrowLeft className="w-3 h-3" />
                    <span>Back to Subheadings</span>
                  </button>

                  <span className={`text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded-md border ${
                    isRoseVelvet ? 'bg-[#ec4899]/20 text-pink-200 border-[#ec4899]/40' : 'bg-purple-500/15 text-purple-600 dark:text-purple-400 border-purple-500/30'
                  }`}>
                    PAGE 3 OF 3: WORKING FUNCTIONS
                  </span>
                </div>

                <div className="flex items-center gap-2 mt-0.5">
                  <div className={`p-1.5 rounded-lg shadow-xs ${isRoseVelvet ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white' : 'bg-purple-600 text-white'}`}>
                    {renderIcon(activeSubheading.iconName, "w-4 h-4")}
                  </div>
                  <h2 className="text-base md:text-lg font-black text-white tracking-tight">
                    {activeSubheading.title} Tools
                  </h2>
                </div>
                <p className={`text-[11px] font-medium ${isRoseVelvet ? 'text-pink-200/90' : 'text-slate-500 dark:text-slate-400'}`}>
                  Click any tool below to open its working PDF Editor Workspace screen to upload and perform edits.
                </p>
              </div>

              {/* Options Count Badge */}
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <span className={`text-[10px] font-mono font-extrabold px-2.5 py-1 rounded-xl border ${
                  isRoseVelvet ? 'bg-[#ec4899]/20 text-pink-200 border-[#ec4899]/40' : 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/30'
                }`}>
                  {activeSubheading.subSubheadings.length} WORKING FUNCTIONS READY
                </span>
              </div>
            </div>

            {/* WORKING FUNCTION OPTIONS CARDS GRID */}
            <div className={isExpandedGrid ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3"}>
              {activeSubheading.subSubheadings
                .filter((option) => !adminCfg?.disabledTools?.includes(option.toolId))
                .map((option) => (
                <div
                  key={option.id}
                  onClick={() => handleSelectSubSubheadingOption(option)}
                  className={`group relative backdrop-blur-xl transition-all duration-200 rounded-xl cursor-pointer flex flex-col justify-between overflow-hidden ${
                    isRoseVelvet
                      ? 'bg-gradient-to-br from-[#701a45] to-[#4d0c24] border border-[#fbcfe8]/30 hover:border-[#ec4899] hover:shadow-[0_0_20px_rgba(236,72,153,0.4)] text-white'
                      : 'bg-gradient-to-br from-emerald-50/90 via-teal-50/40 to-cyan-50/50 dark:bg-[#121525]/95 border border-emerald-200/90 dark:border-slate-800/80 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-xs hover:shadow-lg hover:-translate-y-0.5'
                  } ${isExpandedGrid ? 'p-5 min-h-[175px]' : 'p-3 min-h-[135px]'}`}
                >
                  <div className={`absolute top-0 left-0 right-0 h-1 ${isRoseVelvet ? 'bg-gradient-to-r from-rose-500 via-pink-500 to-rose-400' : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600'}`} />

                  <div>
                    {/* Badge & Icon Header */}
                    <div className="flex items-center justify-between gap-1.5 mb-2">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-200 shadow-xs shrink-0 ${
                        isRoseVelvet
                          ? 'bg-pink-500/20 border border-pink-400/40 text-pink-200 group-hover:bg-[#ec4899] group-hover:text-white'
                          : 'bg-emerald-500/10 dark:bg-emerald-500/20 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 group-hover:bg-emerald-600 group-hover:text-white'
                      }`}>
                        {renderIcon(option.iconName, "w-4 h-4")}
                      </div>

                      <span className={`text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded border shrink-0 ${
                        isRoseVelvet ? 'bg-[#3b071e] text-pink-200 border-[#fbcfe8]/20' : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                      }`}>
                        {option.badge}
                      </span>
                    </div>

                    {/* Title & Description */}
                    <h3 className={`font-black tracking-tight transition-colors leading-tight ${
                      isRoseVelvet ? 'text-white group-hover:text-pink-300' : 'text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400'
                    } ${isExpandedGrid ? 'text-sm line-clamp-2' : 'text-xs line-clamp-1'}`}>
                      {option.title}
                    </h3>
                    <p className={`mt-1 leading-snug font-medium ${
                      isRoseVelvet ? 'text-pink-100/80' : 'text-slate-500 dark:text-slate-400'
                    } ${isExpandedGrid ? 'text-xs line-clamp-3' : 'text-[11px] line-clamp-2'}`}>
                      {option.desc}
                    </p>
                  </div>

                  {/* Launch Final Function Screen Button */}
                  <div className={`mt-2.5 pt-1.5 border-t flex items-center justify-between text-[10px] font-bold ${
                    isRoseVelvet ? 'border-[#fbcfe8]/15 text-pink-300' : 'border-slate-100 dark:border-slate-800/80 text-emerald-600 dark:text-emerald-400'
                  }`}>
                    <span>Launch Tool</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </main>
    </div>
  );
};
